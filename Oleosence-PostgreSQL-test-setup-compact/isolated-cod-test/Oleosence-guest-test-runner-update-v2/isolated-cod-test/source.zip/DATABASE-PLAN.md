# Database foundation — 15 October 2026

## Included

Products remain the existing three catalog records with editable copy, integer RSD minor-unit prices, available stock, revision checks, persistent sanitized photos and audit history. This release does not add a new-product creation screen.

Migration 003 adds minimal persistent Google customer records, uniquely keyed by provider and Google subject. Email changes update that same identity; matching email addresses never merge identities. No access token, password or admin role is stored on the customer. The approved administrator can read a paginated customer directory. Customer persistence is explicitly enabled with `CUSTOMER_DATABASE_ENABLED=1`; default is 0. A persistence failure prevents a new login session rather than pretending that the customer was saved. Existing RAM sessions still expire on restart.

Migration 004 adds structured order headers and immutable item snapshots: customer reference, delivery contact, product ID/internal SKU, name, unit price, quantity, line total, subtotal, delivery estimate and total. Money is integer RSD minor units. Creation computes 300 RSD delivery below 3500 RSD subtotal, otherwise zero; this is a one-package estimate, saved with its policy version. Later product edits or shipping-rule changes cannot rewrite historical snapshots. Customer-scoped idempotency rejects conflicting retries; database constraints enforce sealed totals and lines.

Historical model-version 1 structured orders are drafts only: unreserved stock and payment not processed. Creation is disabled by default, available only to an explicitly opted-in internal repository caller in isolated tests. The separate model-version 2 COD endpoint is default-disabled; see COD-CHECKOUT.md. Admin can view such drafts but cannot advance their status. Legacy status-only records remain compatible. No existing test orders are imported.

## Agreed inventory workflow

The owner explicitly selected daily absolute B2C Excel replacement after processing orders/stornos in Pantheon. No reconciliation reservations or freeze are added. Accepted COD orders decrement shop stock atomically. The export/import timing risk remains; stale already-previewed imports are rejected by product revisions. Cancellation never automatically restores stock.

No reservation ledger or per-order export reconciliation is included, following the owner’s selected simpler workflow. See COD-CHECKOUT.md for cancellation and operational checks.

## Controlled activation plan

1. Approve the source update and take a recoverable database backup. Keep the previously deployed archive for code rollback. Test this package in a disposable PostgreSQL database first.
2. Preserve the existing Google client configuration, exact `CUSTOMER_AUTH_ORIGIN=https://olesence.rs` and previously approved `CUSTOMER_AUTH_REDIRECT_HOSTS`. The canonical-host patch is merged and regression-tested. Do not copy secret values into chat or source.
3. The database owner enters `DATABASE_URL` securely in the hosting environment. Only enable `ADMIN_ENABLED=1` with `ADMIN_EMAILS=vujslobodan@gmail.com`. Set `CUSTOMER_DATABASE_ENABLED=1` only when ready to persist customer profiles. No default first-user administrator exists.
4. Startup initializes migrations 001–005 under the existing advisory lock and a transaction, before listening. Existing products are not overwritten by seed inserts. The migration ledger applies each new version once; repeated startup is tested with persisted COD records. Test on the target PostgreSQL version first; PGlite tests do not establish hosted privileges, TLS or operational readiness.
5. Verify approved-admin access, customer denial, two distinct Google identities, persistence after restart, customer directory protection, canonical-host redirects, stock import preview/conflict handling and photo retrieval. Keep checkout disabled.
6. A code rollback does not undo schema changes or delete customer/order records. If restoration is needed, use the provider's tested backup/restore process, with separately approved data changes. Do not drop tables as an automatic rollback.

No live migration, deployment, credential change or production order was performed while preparing this package.

## Stock-source update, 15 October 2026

The owner selected Magacin Bio Prodavnica B2C as the sole inventory source. Daily report imports require this section and exclude other warehouse sections with a visible warning. Missing B2C product rows preserve existing stock. This does not itself enable checkout.
