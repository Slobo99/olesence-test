# Kupovina bez registracije

Ova verzija omogućava kupovinu bez Google naloga kada su CHECKOUT_COD_ENABLED=1 i CHECKOUT_GUEST_ENABLED=1. Novi prekidač je podrazumevano isključen. Administratorska Google prijava ostaje obavezna za upravljanje prodavnicom.

Gost unosi ime, telefon i adresu za dostavu u Srbiji. Imejl je obavezan; proverava se format, bez obavezne registracije ili potvrde imejl adrese. Nalog kupca se ne kreira. Google prijava je zasebna, opciona mogućnost. Imejl prijava i slanje potvrda nisu uključeni.

Pregledač dobija nasumičnu, zaštićenu sesiju važeću 24 sata. Potvrde i porudžbine gosta dostupne su samo uz tu sesiju. Broj porudžbine ili imejl sami ne otkrivaju porudžbinu. Brisanje kolačića ili istek sesije prekida pristup; neizvestan pokušaj ne treba ponavljati novom porudžbinom pre provere kod prodavnice. Prijava na Google ne prenosi automatski prethodne gostujuće porudžbine u nalog.

Sesije i ograničenja zahteva čuvaju se u bazi, pa ponovno pokretanje servera ne resetuje rok ili ograničenje. Ograničenja su zaštita od prekomernog saobraćaja, ne potvrda identiteta gosta. Zajednički limiti su 1.000 novih sesija na sat, najviše 60 u minutu i 100 pokušaja slanja porudžbine u minutu. Pojedinačna sesija dozvoljava 60 obračuna i 90 čitanja u minutu, odnosno 10 pokušaja slanja porudžbine na sat. Ograničenje kreiranja sesija je zajedničko, pa veliki broj zahteva može privremeno blokirati nove goste. Nema CAPTCHA, nove usluge ili IP identifikacije.

Migracija 006 dodaje zasebne gostujuće sesije i vlasnika gostujuće porudžbine. Postojeći kupci, porudžbine i administracija se čuvaju. Ne izmišljaju se Google identiteti. Povratak staroj verziji zahteva proveru kompatibilnosti sa gostujućim porudžbinama; ne brisati novu migraciju ili podatke kao način povratka.

Cene, dostava i zalihe ostaju serverske. Svaka prihvaćena porudžbina jednom umanjuje zalihu; ponovljen isti zahtev vraća istu porudžbinu. Plaćanje ostaje pouzećem. Otkazivanje ne vraća automatski stanje: prodavac usklađuje zalihu i Pantheon ručno. Jutarnji Excel i dalje zamenjuje stanje.

Za kasniju imejl prijavu potrebno je zasebno odobriti pošiljaoca i provajdera slanja, verifikaciju domena i odgovarajuća DNS podešavanja. Linkovi moraju biti kratkog roka, jednokratni, sa heširanim tokenima i ograničenjem zahteva. Ne povezivati automatski naloge i stare porudžbine samo na osnovu unetog imejla. Tajne se unose bezbednim podešavanjem, ne kroz dokument ili razgovor.
