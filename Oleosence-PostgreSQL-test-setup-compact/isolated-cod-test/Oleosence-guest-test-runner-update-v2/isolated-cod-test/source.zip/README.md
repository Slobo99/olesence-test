# Oleosence administracija

Pripremljen kod administracije za postojeći izdvojeni Oleosence servis. Nije automatski objavljen. Kod za poručivanje pouzećem je uključen u ovaj paket, ali ostaje isključen podrazumevanom konfiguracijom. Statički preview nije menjan.

## Šta je uključeno

- Google prijava ostaje postojeći serverski OAuth tok. Administracija proverava odobrenu adresu na serveru pri svakom zahtevu, nezavisno od bilo koje browser uloge.
- Uređivanje naziva, opisa i osnovnih tekstova proizvoda, cene u RSD, slobodne količine za prodaju i dostupnosti.
- Postojeće deklaracije/upozorenja, originalne slike, ID proizvoda i prazna registracija se čuvaju. Ovaj panel ne uređuje zdravstvene tvrdnje, deklaracije, registracioni broj, FAQ ili slajder. Fotografija proizvoda se može zameniti kroz poseban potvrđen upload.
- Uvoz slobodne količine za prodaju iz originalnog XLS izveštaja ili jednostavnog XLSX šablona: pregled izmena, zatim posebna potvrda. Nema automatskog uvoza, Pantheon konekcije niti stvarnih količina u početnim podacima.
- Pregled i dozvoljene promene statusa budućih porudžbina. Zaštićeni API za poručivanje pouzećem zahteva posebno uključivanje; nema kartične naplate ni slanja obaveštenja.
- Trajno čuvanje kataloga, zaliha, potvrđenih Google kupaca, budućih porudžbina i istorije promena u PostgreSQL. Nema JSON/file fallback-a na prolaznom disku.

## Bezbedna konfiguracija i aktivacija

Podrazumevano ADMIN_ENABLED=0. Niko ne postaje administrator registracijom, prvom prijavom ili promenom browser podataka. Za početak je korisnik odobrio samo `vujslobodan@gmail.com`; to je dokumentovan izbor, ne aktivna konfiguracija u ovom paketu.

Aktivacija zahteva prethodno odobren i kreiran trajni PostgreSQL, bezbedan unos njegovog kredencijala i posebno odobreno postavljanje koda i pristupa. Ne praviti bazu, pretplatu ili nove kredencijale samo na osnovu ovog dokumenta. Tajne se unose bezbedno u hosting panelu, nikada u chat, ZIP, Git, JavaScript, screenshot ili `.env` u repozitorijumu.

Promenljive:

- CUSTOMER_AUTH_ORIGIN: tačno postojeće HTTPS poreklo bez završnog `/`
- CUSTOMER_GOOGLE_ENABLED, GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET: postojeća odobrena OAuth konfiguracija, bez izmene traženih scope-ova
- CHECKOUT_COD_ENABLED=1: samo nakon odobrene objave i provere uslova za pokretanje iz COD-CHECKOUT.md; podrazumevano 0
- CHECKOUT_GUEST_ENABLED=1: opciona kupovina bez registracije uz uključen COD; podrazumevano 0, detalji u GUEST-CHECKOUT.md
- CUSTOMER_DATABASE_ENABLED=1: uključuje trajno čuvanje Google identiteta i administratorski pregled kupaca; podrazumevano 0
- ADMIN_ENABLED=1: samo posle odobrenja aktivacije
- ADMIN_EMAILS=vujslobodan@gmail.com: tačna odobrena adresa; nema wildcard-a
- DATABASE_URL: PostgreSQL konekcija iz bezbednog hosting panela
- RENDER=true i PORT: obezbeđuje platforma

Google email se koristi tek nakon provere potpisanog Google ID tokena, issuer/audience/nonce/isteka i email_verified. Zahteva se Gmail adresa iz odobrene liste. Nije dovoljno poslati email u API-ju. Promene ADMIN_EMAILS zahtevaju restart/redeploy; svaka sesija se proverava prema novoj konfiguraciji. Google sesije imaju najviše jedan sat i gube se pri restartu. Gostujuće sesije, ako su uključene, čuvaju se u bazi i traju najviše 24 sata. Jedna Node instanca je podržana; trajni session store i per-client rate limiting ostaju poseban budući posao za javnu produkciju.

Servis sluša HTTP samo iza Render TLS proxy-ja i proverava javni Host i x-forwarded-proto. Ne izlagati port direktno internetu. Ne isključivati verifikaciju TLS sertifikata baze; koristiti bezbednu konfiguraciju koju daje odobreni provider. DATABASE_URL sa sslmode=no-verify/disable ne koristiti za javnu mrežu. Pool: najviše 5 konekcija, 5s connection/query limit.

## Postavljanje posle odobrenja

Build: `npm ci --ignore-scripts && npm run check`. Start: `npm start`. Health: `/healthz` (liveness, ne proverava bazu). Kada je admin uključen, inicijalizacija baze mora uspeti pre otvaranja servera; neuspeh prekida start.

Inicijalizacija u jednoj transakciji uz PostgreSQL advisory lock primenjuje nedostajuće migracije 001–006. Početni katalog se unosi samo za nedostajuće ID-jeve, pa restart ne prepisuje postojeće izmene. Sve početne količine su `null` (nepoznato), dostupnost `false`; postojeće cene su 1.490 / 1.590 / 840 RSD. Za novo poručivanje pouzećem dostava je 300 RSD, besplatna od ukupno 3.500 RSD vrednosti proizvoda.

Ovaj prvi migrator koristi aplikacionu DB ulogu i DDL dozvole. Pre dalje produkcijske faze razdvojiti migracionu ulogu i najmanje potrebne runtime privilegije. Audit je append-only kroz aplikacione API-je; vlasnik baze može ga menjati, zato nije kriptografski neizmenljiv dnevnik. Pre aktivacije dogovoriti backup, retenciju, povratak i proveru restore-a. Besplatan kratkotrajan DB nije trajno rešenje za porudžbine.

## Rad u panelu

Prijaviti se odobrenim Google nalogom na `/account`, zatim otvoriti `/admin`. Kupci i anonimni zahtevi nemaju pristup admin HTML/JS/CSS ni API-jima. Korisniku bez dozvole server vraća 401/403; za isključenu administraciju 404. Baza nedostupna: izmene se ne prikazuju kao sačuvane.

Cene se unose kao RSD i čuvaju u celobrojnim parama. Granica je 1.000.000 RSD, količina 0–1.000.000 komada. Dostupnost se može uključiti samo uz poznatu pozitivnu količinu. Promene nose verziju; ako je drugi tab već promenio proizvod, ceo pokušaj se odbija sa 409. Ponovo učitati i pregledati pre novog čuvanja. Istorija čuva prethodni i novi zapis i verifikovani Google subject administratora.

Javni katalog čita sačuvane cene/tekstove/dostupnost preko `/api/catalog`. Količina i istorija se ne objavljuju. Ako je katalog nedostupan, prikazuju se osnovni podaci sa jasnim upozorenjem da cene i dostupnost treba ponovo proveriti. Poručivanje je dostupno samo kada je posebno uključeno i proizvod ima poznatu dovoljnu količinu i uključenu dostupnost. Promene su vidljive nakon ponovnog otvaranja/osvežavanja prodavnice.

## Fotografije proizvoda

Svaki proizvod ima prikaz trenutne fotografije i izbor nove JPEG/PNG datoteke. Izbor prikazuje lokalni pregled i dimenzije; sam izbor ne šalje fotografiju serveru. Tek dugme za čuvanje i izričita potvrda šalju datoteku i objavljuju novu sliku u istom hostovanom katalogu. Ako su tekst/cena/količina tog proizvoda izmenjeni, prvo ih sačuvati ili odbaciti, pa birati fotografiju. Drugi nesačuvani proizvodi ostaju u formularima. Prijava, administratorsko pravo, Origin, CSRF i verzija proizvoda proveravaju se pri svakom upload-u; konflikt 409 ništa ne menja.

Prihvaćeni ulaz: JPEG ili PNG, najviše 3 MiB, do 12 megapiksela i najviše 8192 piksela po strani. MIME zaglavlje mora odgovarati stvarnom formatu. SVG, animacije, pogrešan format i oštećene slike se odbijaju. Server proverava zaglavlje i dekodira stvarne piksele kroz Sharp 0.35.5, zatim pravi novu JPEG datoteku: najviše 1600×1600, proporcionalno bez povećavanja malih slika, belo pozadinsko platno za transparentnost, do 1,5 MiB. EXIF/GPS i ostali originalni metapodaci se ne čuvaju; orijentacija se primenjuje pre ponovnog enkodiranja. Originalni upload se ne trajno čuva. Obrada je ograničena vremenom, brojem piksela i na jednu istovremenu sliku.

Normalizovane fotografije se čuvaju kao PostgreSQL bytea, ne na prolaznom Render disku. Nije potreban novi bucket, nalog ili kredencijal. Putanja se izvodi iz SHA-256 normalizovanih bajtova i nema korisnički filename: `/media/{hash}.jpg`. Odgovor je fiksno image/jpeg uz nosniff, same-origin resource policy i dug cache za nepromenljive bajtove. Stare fotografije ostaju dostupne na starom URL-u zbog istorije i keširanja; uploadovati samo fotografije namenjene javnom katalogu. Promena slike nije brisanje stare kopije niti njeno povlačenje iz javnog keša.

Migracija 002 se primenjuje u istoj bezbednoj inicijalizaciji kao 001. Upis slike, izmena verzije proizvoda i audit su jedna transakcija; identičan hash se ne duplira. Audit beleži URL/verziju proizvoda, bez binarne fotografije. Ukupna kvota svih novih i istorijskih slika je 100 MiB logičkih bajtova, zaštićena globalnim transakcionim zaključavanjem. Pri punoj kvoti novi upload se odbija; postojeći proizvod/slika ostaje nepromenjen. Nema automatskog brisanja, povećanja kapaciteta ili dodatnih troškova. Čišćenje istorije zahteva zaseban plan, pregled posledica i odgovarajuću potvrdu; ovaj panel nema dugme za trajno brisanje fotografija. Preostali prostor baze služi katalogu, audit-u i budućim porudžbinama.

Svih 11 originalnih statičkih slika ostaje neizmenjeno. Upload menja samo fotografiju izabranog proizvoda u hostovanom katalogu i korpi, ne slajder ili odvojeni statički preview. Za veći katalog kasnije razmotriti zasebno odobreno objektno skladište.

## Excel zalihe

### Originalni dnevni XLS izveštaj

Primarni format je postojeći BIFF8 `.xls` izvoz „Pregled trenutne zalihe po skladištima i identu”. Uvoz prepoznaje red zaglavlja sa A=Ident, C=Naziv, J=Zaliha, M=JM i sekcije A=Skladište:, B=naziv magacina. Po korisnikovom izričitom izboru od 15. oktobra koristi se isključivo slobodna količina iz `Magacin Bio Prodavnica B2C`. B2C sekcija mora biti prisutna. Ostali magacini se isključuju i imenuju u upozorenju pregleda; njihove količine se nikada ne sabiraju. Ponovljena sekcija magacina ili neispravan red blokira pregled. Ako proizvod nije naveden u B2C delu, njegovo stanje ostaje nepromenjeno.

Mapiranje iz izvornog sistema je fiksno: O001 → divlji-origano, O002 → cetiri-lopova, O003 → crni-kim. Jedinica mora biti KOM. Duplikat istog identifikatora unutar magacina, nepoznat B2C identifikator, necelobrojna/negativna/prazna količina ili prekoračen zbir odbija ceo izveštaj. Redovi `UKUPNO skladište` se preskaču. Kolone Cena/Vrednost/Valuta se nikada ne koriste za prodajne cene. Nazivi/zapremine iz izveštaja ne prepisuju javne tekstove proizvoda.

Pregled pokazuje izvorni Ident, B2C količinu i isključene magacine pre potvrde. Originalna datoteka se ne čuva u serveru, repozitorijumu ili dnevniku; samo potvrđeno novo stanje ulazi u bazu. Nema zakazanog jutarnjeg zadatka: administrator ručno učitava novi izveštaj i potvrđuje. Stari pregledi ističu posle pet minuta.

Za XLS, preflight ograničava OLE sektor-lance/cikluse/dužine, broj direktorijumskih stavki i ukupan deklarisani sadržaj; skenira ceo BIFF Workbook i odbija formule, enkripciju, makroe i spoljne veze. SheetJS CE 0.20.3 je preuzet sa zvaničnog vendor URL-a iz https://docs.sheetjs.com/docs/getting-started/installation/nodejs/ (ne zastarela npm verzija 0.18.5). Parser je dodatno izdvojen u vremenski i memorijski ograničen worker.

### Opcioni jednostavni XLSX šablon

U jednostavan šablon unositi samo potvrđene B2C količine. Koristiti XLSX, radni list `Zalihe` (ili prvi list), tačno dve kolone u prvom redu:

- SKU
- availableQuantity

Poznati SKU: `crni-kim`, `divlji-origano`, `cetiri-lopova`. SKU se ne preimenuje. Šablon sadrži prazne količine, koje treba popuniti; prazno nije nula. Red koji nije uključen u datoteku ostaje nepromenjen. Dopunski list `Uputstvo` se ne uvozi.

Uvoz **zamenjuje** slobodnu količinu za prodaju, ne dodaje je i ne predstavlja ukupno fizičko stanje magacina. Formula, tekstualni broj, razlomak, negativan broj, prazan podatak, ponovljen ili nepoznat SKU odbija celu datoteku. Limit 1 MB, 500 data redova. Pozitivna količina zadržava postojeći ručni prekidač dostupnosti; nula ga isključuje. Nova prihvaćena porudžbina atomarno umanjuje stanje prodavnice. Po izričitom izboru vlasnika nema dodatnog obračuna rezervacija pri uvozu: prvo se obrade porudžbine i storna u Pantheonu, zatim izveze svež Excel i učita. Porudžbina nastala između izvoza i primene može biti prepisana starijim stanjem; vlasnik je upoznat sa ovim rizikom. Stari pregled uvoza se odbija ako je porudžbina promenila verziju proizvoda nakon pregleda. Otkazivanje ne vraća količinu automatski; korekcija ide ručno kroz Pantheon/Excel ili kontrolisanu izmenu stanja.

Prvo se prikazuje staro i novo stanje, zatim administrator potvrđuje primenu. Pregled važi pet minuta i vezan je za tu sesiju; može se iskoristiti jednom. Svaki red nosi verziju iz pregleda. Promena bilo kog proizvoda između pregleda i primene odbija ceo uvoz. Zaključavanje sortiranih redova, izmene i audit su jedna transakcija. Prevelike/šifrovane/makro/eksterne-link ZIP strukture se odbijaju; pre parsiranja vrši se bounded inflation sa ukupnim limitom 5 MB. Parser radi u worker-u sa limitom vremena, memorije i najviše dva paralelna posla.

## Porudžbine

Baza počinje bez porudžbina. Admin može menjati samo status već postojećih budućih zapisa, verzionisano i uz audit:

- pending → processing ili cancelled
- processing → shipped ili cancelled
- shipped → completed

Nema povratnih prelaza, naplate, refundiranja, uređivanja kupca, brisanja niti promene zaliha kao sporednog efekta. Postojeće lokalne test-porudžbine nisu prenete. Audit porudžbina čuva samo ID, status i verziju, bez punih podataka kupca. Kreiranje realnih porudžbina ostaje budući odvojeno odobren tok.

## Testovi i ograničenja

`npm run check` proverava sintaksu i sve Node testove. Pokriva postojeći OAuth, HTTP kontrole, odbijanje kupaca, CSRF, odjavu, ograničenja inputa, konkurentne verzije, atomsku primenu/audit rollback, XLSX greške i UI ponašanje. SQL integracioni test koristi stvarni PostgreSQL WASM engine PGlite u privremenoj memoriji. Ovo proverava SQL/migracije/transakcije, ali ne zamenu za test konekcije, TLS-a, prava, backup-a i pool-a na odobrenoj hostovanoj bazi. Fake pool testovi dodatno proveravaju failure injection.

Google flow u ovoj promeni koristi offline test providere. Stvarni Google login nije ponovo izvršen za admin jer kod nije postavljen i pristup nije aktiviran. Ne tvrditi da admin online radi dok nisu provereni pravi odobreni nalog, odbijen drugi nalog, baza, XLSX preview/apply/stale, odjava i sadržaj posle restarta.

Transitive uuid je pinovan na zakrpljeni 11.1.1 za ExcelJS. Online provera poznatih npm produkcijskih zavisnosti tokom izrade nije prijavila ranjivosti, ali to nije potpuni audit: dev zavisnosti i interni delovi vendor SheetJS paketa nisu pokriveni tom tvrdnjom. Novo slanje dependency metapodataka registru nije ponavljano bez odobrenja. Zaključane verzije su u package-lock.json; lokalni testovi proveravaju oba parsera.

## Kupci i poručivanje pouzećem (16. oktobar 2026)

Pogledajte [COD-CHECKOUT.md](COD-CHECKOUT.md) za novi tok kupovine, bezbedno ponavljanje, operativne korake i uslove za javno pokretanje; [DATABASE-PLAN.md](DATABASE-PLAN.md) opisuje migracije. Trajni kupci i checkout se posebno uključuju, podrazumevano su isključeni. Migracije 001–005 čuvaju ranije draft/legacy zapise; nove COD porudžbine imaju nepromenljive iznose, stavke i kontakt. Google identitet, administratorska ograničenja i kanonski domen olesence.rs su sačuvani.
