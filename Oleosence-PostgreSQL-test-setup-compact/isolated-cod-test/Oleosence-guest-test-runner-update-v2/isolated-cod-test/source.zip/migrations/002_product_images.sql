-- Applied inside the same initialization transaction/advisory lock as 001.
-- Content-addressed immutable images remain available for old URLs and history.
CREATE TABLE IF NOT EXISTS admin_product_images (
  hash text PRIMARY KEY CHECK (hash ~ '^[a-f0-9]{64}$'),
  bytes bytea NOT NULL CHECK (octet_length(bytes) > 0 AND octet_length(bytes) <= 1572864),
  mime text NOT NULL CHECK (mime = 'image/jpeg'),
  width integer NOT NULL CHECK (width BETWEEN 1 AND 1600),
  height integer NOT NULL CHECK (height BETWEEN 1 AND 1600),
  created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO admin_schema_migrations(version) VALUES (2) ON CONFLICT DO NOTHING;
