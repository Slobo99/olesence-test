-- Applied within the shared migration transaction. Minimal customer identity, independently keyed from mutable email addresses.
CREATE TABLE IF NOT EXISTS commerce_customers (
 id uuid PRIMARY KEY,
 sequence_id bigint GENERATED ALWAYS AS IDENTITY UNIQUE,
 provider text NOT NULL CHECK (provider = 'google'),
 subject text NOT NULL CHECK (length(subject) BETWEEN 1 AND 255),
 email text NOT NULL CHECK (length(email) BETWEEN 3 AND 254),
 name text NOT NULL DEFAULT '' CHECK (length(name) <= 100),
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 last_login_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(provider, subject)
);
INSERT INTO admin_schema_migrations(version) VALUES (3) ON CONFLICT DO NOTHING;
