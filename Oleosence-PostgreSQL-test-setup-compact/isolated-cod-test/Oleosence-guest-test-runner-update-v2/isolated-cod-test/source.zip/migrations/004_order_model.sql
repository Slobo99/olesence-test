-- Applied in the initialization transaction. Commerce foundation only. Structured records are non-fulfillable drafts.
-- Legacy admin_orders remain unchanged, with all new fields NULL.
ALTER TABLE admin_orders DROP CONSTRAINT IF EXISTS admin_orders_status_check;
ALTER TABLE admin_orders ADD CONSTRAINT admin_orders_status_check CHECK (status IN ('draft','pending','processing','shipped','completed','cancelled'));
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS model_version integer;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS snapshot_sealed boolean;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS customer_id uuid REFERENCES commerce_customers(id) ON DELETE RESTRICT;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS contact_snapshot jsonb;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS currency text;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS subtotal_minor bigint;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS delivery_minor bigint;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS total_minor bigint;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS shipping_snapshot jsonb;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS payment_status text;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS inventory_status text;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS idempotency_key text;
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS request_hash text;
ALTER TABLE admin_orders DROP CONSTRAINT IF EXISTS admin_orders_structured_check;
ALTER TABLE admin_orders ADD CONSTRAINT admin_orders_structured_check CHECK (
 (model_version IS NULL AND snapshot_sealed IS NULL AND customer_id IS NULL AND contact_snapshot IS NULL AND currency IS NULL AND subtotal_minor IS NULL AND delivery_minor IS NULL AND total_minor IS NULL AND shipping_snapshot IS NULL AND payment_status IS NULL AND inventory_status IS NULL AND idempotency_key IS NULL AND request_hash IS NULL)
 OR
 (model_version IS NOT NULL AND model_version = 1 AND snapshot_sealed IS NOT NULL AND customer_id IS NOT NULL AND contact_snapshot IS NOT NULL AND jsonb_typeof(contact_snapshot) = 'object'
 AND currency IS NOT NULL AND currency = 'RSD' AND subtotal_minor IS NOT NULL AND subtotal_minor BETWEEN 0 AND 40000000000
 AND delivery_minor IS NOT NULL AND delivery_minor BETWEEN 0 AND 100000000 AND total_minor IS NOT NULL AND total_minor = subtotal_minor + delivery_minor
 AND shipping_snapshot IS NOT NULL AND jsonb_typeof(shipping_snapshot) = 'object'
 AND payment_status IS NOT NULL AND payment_status = 'not_processed'
 AND inventory_status IS NOT NULL AND inventory_status = 'unreserved'
 AND status = 'draft' AND idempotency_key IS NOT NULL AND idempotency_key ~ '^[a-zA-Z0-9_-]{16,100}$'
 AND request_hash IS NOT NULL AND request_hash ~ '^[a-f0-9]{64}$')
);
CREATE UNIQUE INDEX IF NOT EXISTS admin_orders_customer_idempotency ON admin_orders(customer_id,idempotency_key) WHERE model_version = 1;
CREATE INDEX IF NOT EXISTS admin_orders_customer_history ON admin_orders(customer_id,sequence_id DESC) WHERE model_version = 1;
CREATE TABLE IF NOT EXISTS admin_order_items (
 order_id text NOT NULL REFERENCES admin_orders(id) ON DELETE RESTRICT,
 line_number integer NOT NULL CHECK (line_number BETWEEN 1 AND 20),
 product_id text NOT NULL REFERENCES admin_products(id) ON DELETE RESTRICT,
 sku_snapshot text NOT NULL CHECK (length(sku_snapshot) BETWEEN 1 AND 128),
 name_snapshot text NOT NULL CHECK (length(name_snapshot) BETWEEN 1 AND 120),
 quantity integer NOT NULL CHECK (quantity BETWEEN 1 AND 20),
 unit_price_minor bigint NOT NULL CHECK (unit_price_minor BETWEEN 0 AND 100000000),
 line_total_minor bigint NOT NULL CHECK (line_total_minor = unit_price_minor * quantity),
 product_revision integer NOT NULL CHECK (product_revision > 0),
 PRIMARY KEY(order_id,line_number), UNIQUE(order_id,product_id)
);
CREATE OR REPLACE FUNCTION protect_order_snapshot() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.model_version IS NOT NULL AND (
  NEW.model_version IS DISTINCT FROM OLD.model_version OR (OLD.snapshot_sealed AND NEW.snapshot_sealed IS DISTINCT FROM OLD.snapshot_sealed) OR NEW.customer_id IS DISTINCT FROM OLD.customer_id
  OR NEW.contact_snapshot IS DISTINCT FROM OLD.contact_snapshot OR NEW.currency IS DISTINCT FROM OLD.currency
  OR NEW.subtotal_minor IS DISTINCT FROM OLD.subtotal_minor OR NEW.delivery_minor IS DISTINCT FROM OLD.delivery_minor
  OR NEW.total_minor IS DISTINCT FROM OLD.total_minor OR NEW.shipping_snapshot IS DISTINCT FROM OLD.shipping_snapshot
  OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key OR NEW.request_hash IS DISTINCT FROM OLD.request_hash
  OR NEW.document IS DISTINCT FROM OLD.document OR NEW.id IS DISTINCT FROM OLD.id OR NEW.created_at IS DISTINCT FROM OLD.created_at
 ) THEN RAISE EXCEPTION 'Order snapshots are immutable'; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS admin_orders_snapshot_immutable ON admin_orders;
CREATE TRIGGER admin_orders_snapshot_immutable BEFORE UPDATE ON admin_orders FOR EACH ROW EXECUTE FUNCTION protect_order_snapshot();
CREATE OR REPLACE FUNCTION check_unsealed_order() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE sealed boolean;
BEGIN
 SELECT snapshot_sealed INTO sealed FROM admin_orders WHERE id=NEW.order_id FOR UPDATE;
 IF sealed IS DISTINCT FROM false THEN RAISE EXCEPTION 'Cannot append to sealed order snapshot'; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS admin_order_items_only_unsealed ON admin_order_items;
CREATE TRIGGER admin_order_items_only_unsealed BEFORE INSERT ON admin_order_items FOR EACH ROW EXECUTE FUNCTION check_unsealed_order();
CREATE OR REPLACE FUNCTION protect_order_item() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Order line snapshots are immutable'; END $$;
DROP TRIGGER IF EXISTS admin_order_items_immutable ON admin_order_items;
CREATE TRIGGER admin_order_items_immutable BEFORE UPDATE OR DELETE ON admin_order_items FOR EACH ROW EXECUTE FUNCTION protect_order_item();
-- Check complete order arithmetic at transaction commit, after all lines exist.
CREATE OR REPLACE FUNCTION check_order_lines() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE target_id text; header admin_orders%ROWTYPE; count_lines bigint; sum_lines bigint;
BEGIN
 IF TG_TABLE_NAME = 'admin_orders' THEN target_id := NEW.id; ELSE target_id := NEW.order_id; END IF;
 SELECT * INTO header FROM admin_orders WHERE id = target_id;
 IF header.model_version = 1 THEN
  SELECT COUNT(*), COALESCE(SUM(line_total_minor),0) INTO count_lines,sum_lines FROM admin_order_items WHERE order_id = target_id;
  IF header.snapshot_sealed IS NOT TRUE OR count_lines < 1 OR count_lines > 20 OR sum_lines <> header.subtotal_minor THEN RAISE EXCEPTION 'Order lines do not match snapshot totals'; END IF;
 END IF;
 RETURN NULL;
END $$;
DROP TRIGGER IF EXISTS admin_orders_check_lines ON admin_orders;
CREATE CONSTRAINT TRIGGER admin_orders_check_lines AFTER INSERT OR UPDATE ON admin_orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION check_order_lines();
DROP TRIGGER IF EXISTS admin_order_items_check_totals ON admin_order_items;
CREATE CONSTRAINT TRIGGER admin_order_items_check_totals AFTER INSERT ON admin_order_items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION check_order_lines();
INSERT INTO admin_schema_migrations(version) VALUES (4) ON CONFLICT DO NOTHING;
