-- Applied in the initialization transaction. Feature remains disabled by default.
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS payment_method text;
ALTER TABLE admin_orders DROP CONSTRAINT IF EXISTS admin_orders_structured_check;
ALTER TABLE admin_orders ADD CONSTRAINT admin_orders_structured_check CHECK (
 (model_version IS NULL AND snapshot_sealed IS NULL AND customer_id IS NULL AND contact_snapshot IS NULL AND currency IS NULL AND subtotal_minor IS NULL AND delivery_minor IS NULL AND total_minor IS NULL AND shipping_snapshot IS NULL AND payment_status IS NULL AND inventory_status IS NULL AND idempotency_key IS NULL AND request_hash IS NULL AND payment_method IS NULL)
 OR
 (model_version IS NOT NULL AND model_version IN (1,2) AND snapshot_sealed IS NOT NULL AND customer_id IS NOT NULL
 AND contact_snapshot IS NOT NULL AND jsonb_typeof(contact_snapshot)='object' AND currency IS NOT NULL AND currency='RSD'
 AND subtotal_minor IS NOT NULL AND subtotal_minor BETWEEN 0 AND 40000000000 AND delivery_minor IS NOT NULL AND delivery_minor BETWEEN 0 AND 100000000
 AND total_minor IS NOT NULL AND total_minor=subtotal_minor+delivery_minor AND shipping_snapshot IS NOT NULL AND jsonb_typeof(shipping_snapshot)='object'
 AND payment_status IS NOT NULL AND inventory_status IS NOT NULL AND idempotency_key IS NOT NULL AND idempotency_key ~ '^[a-zA-Z0-9_-]{16,100}$'
 AND request_hash IS NOT NULL AND request_hash ~ '^[a-f0-9]{64}$'
 AND ((model_version=1 AND status='draft' AND payment_status='not_processed' AND inventory_status='unreserved' AND payment_method IS NULL)
 OR (model_version=2 AND payment_method IS NOT NULL AND payment_method='cod'
 AND ((status IN ('pending','processing','shipped','completed') AND payment_status='cod_due' AND inventory_status='deducted')
 OR (status='cancelled' AND payment_status='cod_cancelled' AND inventory_status='deducted_manual_adjustment_required')))))
);
DROP INDEX IF EXISTS admin_orders_customer_idempotency;
CREATE UNIQUE INDEX admin_orders_customer_idempotency ON admin_orders(customer_id,idempotency_key) WHERE model_version IN (1,2);
DROP INDEX IF EXISTS admin_orders_customer_history;
CREATE INDEX admin_orders_customer_history ON admin_orders(customer_id,sequence_id DESC) WHERE model_version IN (1,2);
CREATE OR REPLACE FUNCTION protect_order_snapshot() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.model_version IS NOT NULL AND (
  NEW.model_version IS DISTINCT FROM OLD.model_version OR (OLD.snapshot_sealed AND NEW.snapshot_sealed IS DISTINCT FROM OLD.snapshot_sealed) OR NEW.customer_id IS DISTINCT FROM OLD.customer_id
  OR NEW.contact_snapshot IS DISTINCT FROM OLD.contact_snapshot OR NEW.currency IS DISTINCT FROM OLD.currency
  OR NEW.subtotal_minor IS DISTINCT FROM OLD.subtotal_minor OR NEW.delivery_minor IS DISTINCT FROM OLD.delivery_minor
  OR NEW.total_minor IS DISTINCT FROM OLD.total_minor OR NEW.shipping_snapshot IS DISTINCT FROM OLD.shipping_snapshot
  OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key OR NEW.request_hash IS DISTINCT FROM OLD.request_hash
  OR NEW.payment_method IS DISTINCT FROM OLD.payment_method OR NEW.document IS DISTINCT FROM OLD.document OR NEW.id IS DISTINCT FROM OLD.id OR NEW.created_at IS DISTINCT FROM OLD.created_at
 ) THEN RAISE EXCEPTION 'Order snapshots are immutable'; END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION check_order_lines() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE target_id text; header admin_orders%ROWTYPE; count_lines bigint; sum_lines bigint;
BEGIN
 IF TG_TABLE_NAME = 'admin_orders' THEN target_id := NEW.id; ELSE target_id := NEW.order_id; END IF;
 SELECT * INTO header FROM admin_orders WHERE id = target_id;
 IF header.model_version IN (1,2) THEN
  SELECT COUNT(*), COALESCE(SUM(line_total_minor),0) INTO count_lines,sum_lines FROM admin_order_items WHERE order_id = target_id;
  IF header.snapshot_sealed IS NOT TRUE OR count_lines < 1 OR count_lines > 20 OR sum_lines <> header.subtotal_minor THEN RAISE EXCEPTION 'Order lines do not match snapshot totals'; END IF;
 END IF;
 RETURN NULL;
END $$;
INSERT INTO admin_schema_migrations(version) VALUES (5) ON CONFLICT DO NOTHING;
