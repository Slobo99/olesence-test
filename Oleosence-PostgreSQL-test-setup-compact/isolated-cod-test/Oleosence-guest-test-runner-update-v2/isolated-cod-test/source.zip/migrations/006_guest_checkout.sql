-- Applied in the initialization transaction. Guest checkout never creates customer identities.
CREATE TABLE IF NOT EXISTS guest_checkout_sessions (
 id uuid PRIMARY KEY,
 token_hash text NOT NULL UNIQUE CHECK (token_hash ~ '^[a-f0-9]{64}$'),
 csrf_token text NOT NULL CHECK (csrf_token ~ '^[A-Za-z0-9_-]{32,128}$'),
 created_at timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz NOT NULL CHECK (expires_at > created_at AND expires_at <= created_at + interval '24 hours'),
 quote_window_started_at timestamptz NOT NULL DEFAULT now(),
 quote_count integer NOT NULL DEFAULT 0 CHECK (quote_count >= 0),
 submit_window_started_at timestamptz NOT NULL DEFAULT now(),
 submit_count integer NOT NULL DEFAULT 0 CHECK (submit_count >= 0),
 read_window_started_at timestamptz NOT NULL DEFAULT now(),
 read_count integer NOT NULL DEFAULT 0 CHECK (read_count >= 0)
);
CREATE INDEX IF NOT EXISTS guest_checkout_sessions_expiry ON guest_checkout_sessions(expires_at);
CREATE TABLE IF NOT EXISTS guest_checkout_limits (
 bucket text PRIMARY KEY CHECK (bucket IN ('session_creation','session_creation_burst','global_submission')),
 window_started_at timestamptz NOT NULL DEFAULT now(),
 request_count integer NOT NULL DEFAULT 0 CHECK (request_count >= 0)
);
INSERT INTO guest_checkout_limits(bucket) VALUES ('session_creation'),('session_creation_burst'),('global_submission') ON CONFLICT DO NOTHING;

ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS guest_id uuid REFERENCES guest_checkout_sessions(id) ON DELETE RESTRICT;
ALTER TABLE admin_orders DROP CONSTRAINT IF EXISTS admin_orders_structured_check;
ALTER TABLE admin_orders ADD CONSTRAINT admin_orders_structured_check CHECK (
 (model_version IS NULL AND snapshot_sealed IS NULL AND customer_id IS NULL AND guest_id IS NULL AND contact_snapshot IS NULL AND currency IS NULL AND subtotal_minor IS NULL AND delivery_minor IS NULL AND total_minor IS NULL AND shipping_snapshot IS NULL AND payment_status IS NULL AND inventory_status IS NULL AND idempotency_key IS NULL AND request_hash IS NULL AND payment_method IS NULL)
 OR
 (model_version IS NOT NULL AND model_version IN (1,2) AND snapshot_sealed IS NOT NULL
 AND ((model_version=1 AND customer_id IS NOT NULL AND guest_id IS NULL)
 OR (model_version=2 AND ((customer_id IS NOT NULL AND guest_id IS NULL) OR (customer_id IS NULL AND guest_id IS NOT NULL))))
 AND contact_snapshot IS NOT NULL AND jsonb_typeof(contact_snapshot)='object' AND currency IS NOT NULL AND currency='RSD'
 AND subtotal_minor IS NOT NULL AND subtotal_minor BETWEEN 0 AND 40000000000 AND delivery_minor IS NOT NULL AND delivery_minor BETWEEN 0 AND 100000000
 AND total_minor IS NOT NULL AND total_minor=subtotal_minor+delivery_minor AND shipping_snapshot IS NOT NULL AND jsonb_typeof(shipping_snapshot)='object'
 AND payment_status IS NOT NULL AND inventory_status IS NOT NULL AND idempotency_key IS NOT NULL AND idempotency_key ~ '^[a-zA-Z0-9_-]{16,100}$'
 AND request_hash IS NOT NULL AND request_hash ~ '^[a-f0-9]{64}$'
 AND ((model_version=1 AND status='draft' AND payment_status='not_processed' AND inventory_status='unreserved' AND payment_method IS NULL)
 OR (model_version=2 AND payment_method IS NOT NULL AND payment_method='cod'
 AND ((status IN ('pending','processing','shipped','completed') AND payment_status='cod_due' AND inventory_status='deducted')
 OR (status='cancelled' AND payment_status='cod_cancelled' AND inventory_status='deducted_manual_adjustment_required')))))
);
CREATE UNIQUE INDEX IF NOT EXISTS admin_orders_guest_idempotency ON admin_orders(guest_id,idempotency_key) WHERE model_version=2;
CREATE INDEX IF NOT EXISTS admin_orders_guest_history ON admin_orders(guest_id,sequence_id DESC) WHERE model_version=2 AND guest_id IS NOT NULL;

-- Keep all prior snapshot and line protections; add immutable guest ownership.
CREATE OR REPLACE FUNCTION protect_order_snapshot() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF OLD.model_version IS NOT NULL AND (
  NEW.model_version IS DISTINCT FROM OLD.model_version OR (OLD.snapshot_sealed AND NEW.snapshot_sealed IS DISTINCT FROM OLD.snapshot_sealed) OR NEW.customer_id IS DISTINCT FROM OLD.customer_id
  OR NEW.guest_id IS DISTINCT FROM OLD.guest_id
  OR NEW.contact_snapshot IS DISTINCT FROM OLD.contact_snapshot OR NEW.currency IS DISTINCT FROM OLD.currency
  OR NEW.subtotal_minor IS DISTINCT FROM OLD.subtotal_minor OR NEW.delivery_minor IS DISTINCT FROM OLD.delivery_minor
  OR NEW.total_minor IS DISTINCT FROM OLD.total_minor OR NEW.shipping_snapshot IS DISTINCT FROM OLD.shipping_snapshot
  OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key OR NEW.request_hash IS DISTINCT FROM OLD.request_hash
  OR NEW.payment_method IS DISTINCT FROM OLD.payment_method OR NEW.document IS DISTINCT FROM OLD.document OR NEW.id IS DISTINCT FROM OLD.id OR NEW.created_at IS DISTINCT FROM OLD.created_at
 ) THEN RAISE EXCEPTION 'Order snapshots are immutable'; END IF;
 RETURN NEW;
END $$;
INSERT INTO admin_schema_migrations(version) VALUES (6) ON CONFLICT DO NOTHING;
