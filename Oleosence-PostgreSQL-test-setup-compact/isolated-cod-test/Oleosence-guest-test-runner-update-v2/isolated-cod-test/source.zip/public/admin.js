const $ = id => document.getElementById(id);
const state = { csrf: null, view: 'products', epoch: 0, controller: null, products: [], cursor: null, busy: false, dirty: false, preview: null, drafts: new Map(), images: new Map() };
const labels = {products: ['KATALOG', 'Proizvodi'], customers:['NALOG', 'Kupci'], orders: ['PRODAJA', 'Porudžbine'], audit: ['EVIDENCIJA', 'Istorija izmena']};
const transitions = {pending:['processing','cancelled'],processing:['shipped','cancelled'],shipped:['completed'],completed:[],cancelled:[]};
const statuses = {draft:'Nacrt',pending:'Na čekanju',processing:'U obradi',shipped:'Poslata',completed:'Završena',cancelled:'Otkazana'};
const limits = {name:120,description:2000,botanical:120,category:120,volume:120,ingredients:2000,method:500,note:2000};
const names = {name:'Naziv proizvoda',description:'Opis',botanical:'Botanički naziv',category:'Kategorija',volume:'Zapremina',ingredients:'Sastav',method:'Način dobijanja',note:'Napomena'};
const declarationLabels = {benefit:'Namena',usage:'Upotreba',notes:'Napomene',warnings:'Upozorenja',storage:'Čuvanje',editorialCaveat:'Dodatno upozorenje'};
function el(tag, text, className) { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; }
function status(text, error = false) { $('status').textContent = text; $('status').className = `notice${error ? ' error' : ''}`; }
export function parsePrice(value) {
  const match = /^(\d+)(?:[.,](\d{1,2}))?$/.exec(value.trim());
  if (!match) throw new Error('Cena mora biti pozitivan iznos u RSD, sa najviše dve decimale, bez separatora hiljada.');
  const minor = BigInt(match[1]) * 100n + BigInt((match[2] || '').padEnd(2, '0'));
  if (minor > 100000000n) throw new Error('Cena je previsoka.');
  return Number(minor);
}
export function parseStock(value) {
  if (!value.trim()) return null;
  if (!/^\d+$/.test(value.trim()) || !Number.isSafeInteger(Number(value)) || Number(value)>1000000) throw new Error('Zaliha mora biti ceo broj od 0 do 1.000.000.');
  return Number(value);
}
function money(minor) {return Number.isSafeInteger(minor) ? new Intl.NumberFormat('sr-Latn-RS',{style:'currency',currency:'RSD'}).format(minor/100) : 'Iznos nije poznat';}
function date(value) {const d = new Date(value); return Number.isNaN(d.getTime()) ? 'Datum nije poznat' : d.toLocaleString('sr-Latn-RS');}
function updateDirty() {state.dirty=state.drafts.size>0||state.images.size>0;}
function clearImage(id) {const selected=state.images.get(id);if(selected)URL.revokeObjectURL(selected.url);state.images.delete(id);updateDirty();}
function clearImages() {for(const id of state.images.keys())clearImage(id);}
function clearSensitive() {
  clearImages();
  state.epoch++; state.controller?.abort(); state.csrf=null; state.products=[]; state.cursor=null; state.preview=null; state.dirty=false; state.busy=false; state.drafts.clear();
  $('content').replaceChildren(); $('identity').textContent=''; $('workspace').hidden=true; $('more').hidden=true;
  if ($('confirm').open) $('confirm').close('cancel');
  $('confirm-message').textContent='';$('customers-tab').hidden=true;
}
function access(code) {
  clearSensitive(); $('access').hidden=false;
  const storage = code === 503;
  $('access-title').textContent=storage ? 'Skladište podataka nije spremno' : 'Administratorski pristup je ograničen';
  $('access-message').textContent=storage ? 'Trajno čuvanje podataka trenutno nije dostupno. Izmene nisu omogućene. Pokušajte ponovo kada skladište bude podešeno.' : code===403 ? 'Ovaj Google nalog nema administratorsku dozvolu. Prijavite se odobrenim nalogom.' : 'Prijavite se odobrenim Google nalogom. Ako ste već bili prijavljeni, sesija je istekla.';
  status(storage ? 'Panel trenutno nije dostupan.' : 'Prijava je potrebna.',true);
}
async function api(path, options = {}) {
  const requestEpoch=state.epoch;
  const response = await fetch(path,{credentials:'same-origin',cache:'no-store',...options,headers:{...options.headers}});
  let data; try {data=await response.json();} catch { data={}; }
  if (!response.ok) {
    if ([401,403,503].includes(response.status)&&requestEpoch===state.epoch) access(response.status);
    const error = new Error(response.status===409 ? 'Podaci su u međuvremenu promenjeni. Osvežite prikaz i ponovo unesite izmene.' : [400,413,422].includes(response.status) ? 'Podaci nisu prihvaćeni. Proverite sva polja i format datoteke.' : response.status===429 ? 'Previše zahteva. Sačekajte trenutak i pokušajte ponovo.' : 'Zahtev nije uspeo. Proverite vezu i osvežite podatke pre ponovnog pokušaja.');
    if(response.status===422&&typeof data.error==='string')error.message=`Datoteka nije prihvaćena: ${data.error.slice(0,500)}`;
    error.status=response.status; throw error;
  }
  return data;
}
function dirtyGuard() {return !state.dirty || window.confirm('Imate nesačuvane izmene. Odbaciti ih i nastaviti?');}
async function confirmSave(message) {
  $('confirm-message').textContent=message;
  return new Promise(resolve=> {const dialog=$('confirm');dialog.returnValue='cancel';dialog.addEventListener('close',()=>resolve(dialog.returnValue==='save'),{once:true});dialog.showModal();});
}
function setBusy(value) {
  state.busy=value;
  document.querySelectorAll('#workspace button, #workspace input, #workspace textarea, #workspace select').forEach(node=>node.disabled=value);
}
async function boot() {
  clearSensitive(); $('access').hidden=true; status('Proveravamo administratorski pristup…');
  const epoch=state.epoch;
  try {
    const session=await api('/admin/api/session');
    if(epoch!==state.epoch)return;
    if(!session.csrfToken) throw new Error('Sesija nije ispravna. Ponovo se prijavite.');
    state.csrf=session.csrfToken;
    $('customers-tab').hidden=!session.capabilities?.customers;
    $('identity').textContent=session.user?.email || session.user?.name || 'Administrator';
    $('workspace').hidden=false; await load('products');
  } catch(error) {if(epoch!==state.epoch)return; status(error.message,true); $('access').hidden=false; $('access-message').textContent='Provera pristupa nije završena. Pokušajte ponovo.';}
}
async function load(view=state.view, append=false, preserveDrafts=false) {
  if (!state.csrf || state.busy) return;
  state.controller?.abort(); state.controller=new AbortController(); const epoch=++state.epoch;
  state.view=view;state.preview=null;if(!preserveDrafts){state.drafts.clear();clearImages();}updateDirty();
  document.querySelectorAll('[data-view]').forEach(node=>{if(node.dataset.view===view)node.setAttribute('aria-current','page');else node.removeAttribute('aria-current');});
  $('section-label').textContent=labels[view][0];$('section-title').textContent=labels[view][1];
  $('content').setAttribute('aria-busy','true');$('more').hidden=true;
  if(!append) $('content').replaceChildren(el('p','Učitavanje…','muted'));
  status('Učitavamo najnovije podatke…');
  try {
    const query=append&&state.cursor ? `?before=${encodeURIComponent(state.cursor)}` : '';
    const data=await api(`/admin/api/${view}${query}`,{signal:state.controller.signal});
    if(epoch!==state.epoch)return;
    if(!append)$('content').replaceChildren();
    if(view==='products') {state.products=data.products || [];renderProducts();}
    else if(view==='customers')renderCustomers(data.customers||[],append);
    else if(view==='orders')renderOrders(data.orders || [],append);
    else renderAudit(data.entries || [],append);
    state.cursor=data.nextCursor || null;$('more').hidden=!state.cursor;
    status('Podaci su ažurni. Izmene se čuvaju tek nakon vaše potvrde.');return true;
  }catch(error){if(epoch!==state.epoch || error.name==='AbortError')return;status(error.message,true);if(!append)$('content').replaceChildren(el('p','Podatke nije moguće učitati. Pokušajte ponovo pomoću dugmeta „Osveži podatke”.','muted'));}
  finally{if(epoch===state.epoch)$('content').setAttribute('aria-busy','false');}
}
function field(key,value,{label=names[key],max=limits[key],multiline=false,required=false,hint='',inputMode}={}) {
  const wrap=el('label',label,'field');const input=el(multiline?'textarea':'input');input.name=key;input.value=value??'';input.required=required;if(max)input.maxLength=max;if(inputMode)input.inputMode=inputMode;wrap.append(input);
  if(hint)wrap.append(el('small',hint));return wrap;
}
function track(form,product){form.addEventListener('input',()=>{state.dirty=true;if(product)state.drafts.set(product.id,{product,values:Object.fromEntries(new FormData(form))});});}
function empty(title,description){const box=el('div',undefined,'empty');box.append(el('h3',title),el('p',description));$('content').append(box);}
function renderProducts() {
  $('product-count').textContent=String(state.products.length);renderImport();
  if(!state.products.length){empty('Katalog je prazan','Nema proizvoda dostupnih za uređivanje.');return;}
  const grid=el('div',undefined,'product-grid');
  for(const current of state.products){
    const draft=state.drafts.get(current.id);const p=draft?.product||current;
    const form=el('form',undefined,'product-card');const head=el('header');
    head.append(el('span',p.available?'Dostupno':'Nedostupno',`tag${p.available?'':' off'}`),el('h3',p.name),el('span',`SKU: ${p.id} · Verzija ${p.version}`,'small'));form.append(head);
    form.append(renderProductImage(p));
    form.append(field('name',p.name,{required:true}),field('description',p.description,{multiline:true}));
    const pair=el('div',undefined,'pair');pair.append(field('price',Number.isSafeInteger(p.priceMinor)?`${Math.floor(p.priceMinor/100)},${String(p.priceMinor%100).padStart(2,'0')}`:'',{label:'Cena (RSD)',required:true,inputMode:'decimal',max:12,hint:'Npr. 1490,00'}),field('stockQuantity',p.stockQuantity,{label:'Zaliha (kom.)',inputMode:'numeric',max:7,hint:'Prazno = nepoznato'}));form.append(pair);
    const available=el('label',undefined,'check'),checkbox=el('input');checkbox.type='checkbox';checkbox.name='available';checkbox.checked=Boolean(p.available);available.append(checkbox,document.createTextNode('Proizvod je dostupan'));form.append(available);
    const details=el('details');details.append(el('summary','Detalji proizvoda'));for(const key of ['botanical','category','volume','ingredients','method','note'])details.append(field(key,p[key],{multiline:['ingredients','note'].includes(key)}));form.append(details);
    const declaration=el('details');declaration.append(el('summary','Deklaracija i upozorenja · samo čitanje'));for(const [key,value]of Object.entries(p.declaration || {})){declaration.append(el('p',`${declarationLabels[key] || key}: ${value}`));}form.append(declaration);
    const message=el('p','','form-message');message.setAttribute('role','status');const save=el('button','Sačuvaj izmene','save');save.type='submit';form.append(message,save);if(draft){for(const input of form.elements){if(input.name==='available')input.checked=Object.hasOwn(draft.values,'available');else if(input.name&&Object.hasOwn(draft.values,input.name))input.value=draft.values[input.name];}}track(form,p);
    form.addEventListener('submit',async event=>{
      event.preventDefault();if(state.busy)return;
      let patch;
      try {const values=new FormData(form);patch={version:p.version,priceMinor:parsePrice(values.get('price')),stockQuantity:parseStock(values.get('stockQuantity')),available:checkbox.checked};for(const key of Object.keys(limits))patch[key]=String(values.get(key)||'').trim();if(!patch.name)throw new Error('Unesite naziv proizvoda.');if(patch.available&&(patch.stockQuantity===null||patch.stockQuantity===0))throw new Error('Za dostupan proizvod unesite potvrđenu zalihu veću od nule.');}catch(error){message.textContent=error.message;return;}
      await saveChange(`/admin/api/products/${encodeURIComponent(p.id)}`,patch,`Proizvod „${patch.name}”: cena ${money(patch.priceMinor)}, zaliha ${patch.stockQuantity??'nepoznata'}, ${patch.available?'dostupan':'nedostupan'}.`,message);
    });grid.append(form);
  }$('content').append(grid);
}
export function productImageSource(product) {
  if(typeof product.imagePath==='string'&&/^\/media\/[a-f0-9]{64}\.jpg$/.test(product.imagePath))return product.imagePath;
  if(typeof product.image==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_.-]*\.(?:jpe?g|png|webp)$/i.test(product.image))return `/assets/${product.image}`;
  return null;
}
export function validateImageFile(file) {
  if(!file||!['image/jpeg','image/png'].includes(file.type)||!file.size||file.size>3*1024*1024)throw new Error('Izaberite nepraznu JPEG ili PNG fotografiju do 3 MiB.');
}
function renderProductImage(p) {
  const box=el('section',undefined,'product-image');box.setAttribute('aria-label','Fotografija proizvoda');
  const current=el('img');current.alt=`Trenutna fotografija: ${p.name}`;current.className='product-thumbnail';
  const source=productImageSource(p),dimensions=el('p','','small');
  if(source){current.src=source;box.append(current);current.addEventListener('load',()=>{if(current.naturalWidth&&current.naturalHeight)dimensions.textContent=`Trenutna fotografija: ${current.naturalWidth} × ${current.naturalHeight} px`;});}
  else box.append(el('p','Fotografija nije dostupna.','small'));
  if(Number.isSafeInteger(p.imageWidth)&&Number.isSafeInteger(p.imageHeight)&&p.imageWidth>0&&p.imageHeight>0)dimensions.textContent=`Trenutna fotografija: ${p.imageWidth} × ${p.imageHeight} px`;
  box.append(dimensions,el('p','Čuvanjem objavljujete fotografiju proizvoda u javnom katalogu ovog sajta. Izbor datoteke pravi samo lokalni pregled; ništa se ne šalje pre potvrde. JPEG/PNG do 3 MiB i 12 megapiksela. Server uklanja metapodatke i čuva JPEG do 1600 px i 1,5 MiB.','small'));
  const label=el('label','Nova fotografija (JPEG ili PNG)','field'),input=el('input');input.type='file';input.accept='image/jpeg,image/png';label.append(input);
  const preview=el('div',undefined,'image-preview'),message=el('p','','form-message');message.setAttribute('role','status');
  const actions=el('div',undefined,'image-actions'),save=el('button','Sačuvaj fotografiju'),clear=el('button','Ukloni izbor','secondary');save.type=clear.type='button';actions.append(save,clear);box.append(label,preview,message,actions);
  const show=()=>{preview.replaceChildren();const selected=state.images.get(p.id);actions.hidden=!selected;if(!selected)return;selected.refresh=show;selected.reject=text=>{clearImage(p.id);input.value='';message.textContent=text;show();};const img=el('img');img.className='product-thumbnail';img.alt='Lokalni pregled nove fotografije';img.src=selected.url;preview.append(img,el('p',selected.width?`Novi lokalni pregled: ${selected.width} × ${selected.height} px`:'Proveravamo dimenzije fotografije…','small'));};
  // The unnamed file control is independent of the product text form and draft.
  input.addEventListener('input',event=>event.stopPropagation());
  input.addEventListener('change',()=>{
    if(state.busy)return;clearImage(p.id);message.textContent='';const file=input.files[0];
    try{validateImageFile(file);}catch(error){input.value='';message.textContent=error.message;show();return;}
    let url;try{url=URL.createObjectURL(file);}catch{message.textContent='Lokalni pregled nije dostupan u ovom pregledaču.';input.value='';show();return;}
    const selected={file,url,version:p.version,width:null,height:null};state.images.set(p.id,selected);updateDirty();show();
    const probe=new Image();
    probe.onload=()=>{if(state.images.get(p.id)!==selected)return;const width=probe.naturalWidth,height=probe.naturalHeight;if(!width||!height||width*height>12000000){selected.reject('Fotografija mora imati najviše 12 megapiksela.');}else{selected.width=width;selected.height=height;selected.refresh();}};
    probe.onerror=()=>{if(state.images.get(p.id)!==selected)return;selected.reject('Fotografiju nije moguće otvoriti. Izaberite ispravnu JPEG ili PNG datoteku.');};probe.src=url;
  });
  clear.addEventListener('click',()=>{if(state.busy)return;clearImage(p.id);input.value='';message.textContent='';show();});
  save.addEventListener('click',async()=>{
    if(state.busy)return;const selected=state.images.get(p.id);if(!selected)return;
    if(state.drafts.has(p.id)){message.textContent='Najpre sačuvajte tekstualne izmene ovog proizvoda ili ih odbacite osvežavanjem prikaza, pa ponovo izaberite fotografiju.';return;}
    if(!selected.width){message.textContent='Sačekajte proveru dimenzija fotografije.';return;}
    setBusy(true);const epoch=state.epoch;
    try{
      if(!await confirmSave(`Objaviti novu fotografiju proizvoda „${p.name}” u javnom katalogu ovog sajta? Trenutna fotografija biće zamenjena nakon čuvanja.`))return;
      if(epoch!==state.epoch||!state.csrf||state.images.get(p.id)!==selected)return;
      const data=await api(`/admin/api/products/${encodeURIComponent(p.id)}/image`,{method:'POST',headers:{'Content-Type':selected.file.type,'X-CSRF-Token':state.csrf,'X-Product-Version':String(selected.version)},body:selected.file});
      if(epoch!==state.epoch)return;
      const updated=data.product||data;state.products=state.products.map(product=>product.id===p.id?updated:product);clearImage(p.id);$('content').replaceChildren();renderProducts();status('Fotografija je sačuvana i objavljena u javnom katalogu ovog sajta.');
    }catch(error){if(epoch===state.epoch){message.textContent=error.status===409?'Proizvod je u međuvremenu promenjen. Fotografija nije sačuvana. Osvežite prikaz uz potvrdu odbacivanja izbora i ponovo pregledajte proizvod pre slanja.':error.message;status(message.textContent,true);}}
    finally{if(epoch===state.epoch)setBusy(false);}
  });show();return box;
}
async function saveChange(path,patch,summary,message) {
  if(state.busy)return;setBusy(true);const epoch=state.epoch;
  try {
    if(!await confirmSave(summary))return;if(epoch!==state.epoch || !state.csrf)return;
    await api(path,{method:'PATCH',headers:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},body:JSON.stringify(patch)});
    if(epoch!==state.epoch)return;
    state.drafts.delete(decodeURIComponent(path.split('/').at(-1)));updateDirty();setBusy(false);const refreshed=await load(state.view,false,true);if(state.csrf&&refreshed)status('Izmene su uspešno sačuvane i podaci su ponovo učitani.');
  }catch(error){if(epoch===state.epoch){message.textContent=error.message;status(error.message,true);}}
  finally{if(epoch===state.epoch)setBusy(false);}
}
function renderCustomers(customers,append){
 if(!customers.length&&!append){empty('Još nema sačuvanih kupaca','Potvrđene Google prijave se čuvaju tek kada je uključeno trajno čuvanje kupaca.');return;}
 for(const customer of customers){const card=el('article',undefined,'order-card');card.append(el('h3',customer.name||'Kupac'),el('p',customer.email),el('p',`ID: ${customer.id}`,'small'),el('p',`Poslednja prijava: ${date(customer.lastLoginAt)}`,'small'));$('content').append(card);}
}
function renderOrders(orders,append){
  if(!orders.length&&!append){empty('Još nema porudžbina','Ovde će se pojaviti stvarne porudžbine kada prijem porudžbina bude omogućen.');return;}
  for(const current of orders){const draft=state.drafts.get(current.id);const order=draft?.product||current;const card=el('article',undefined,'order-card');const head=el('div',undefined,'order-header');head.append(el('h3',`Porudžbina ${order.id}`),el('span',statuses[order.status]||order.status,'tag'));card.append(head,el('p',date(order.createdAt),'small'));
    const cod=order.paymentMethod==='cod'||order.paymentStatus==='cod_due';
    if(order.status==='draft')card.append(el('p','Nacrt: zaliha nije rezervisana, plaćanje nije izvršeno i isporuka nije aktivirana.','notice'));
    if(cod)card.append(el('p',order.paymentStatus==='cod_cancelled'?'Pouzeće otkazano. Ovaj panel ne potvrđuje naplatu.':'Plaćanje pouzećem · iznos dospeva pri preuzimanju. Ovaj panel ne potvrđuje naplatu.','notice'));
    if(order.customer)card.append(el('p',[order.customer.name,order.customer.email].filter(Boolean).join(' · '),'small'));
    if(order.contact){const contact=el('section',undefined,'order-contact');contact.append(el('h4','Kontakt i adresa za dostavu'));for(const value of [order.contact.fullName,order.contact.email,order.contact.phone,order.contact.address,[order.contact.postalCode,order.contact.city,order.contact.country==='RS'?'Srbija':order.contact.country].filter(Boolean).join(' ')])if(value)contact.append(el('p',value));card.append(contact);}
    if(Array.isArray(order.items)){const list=el('ul');for(const item of order.items)list.append(el('li',`${item.name||item.productId||item.id} × ${item.quantity}${Number.isSafeInteger(item.unitPriceMinor)?` · ${money(item.unitPriceMinor)} / kom.`:''}${Number.isSafeInteger(item.lineTotalMinor)?` = ${money(item.lineTotalMinor)}`:''}`));card.append(list);}
    if(Number.isSafeInteger(order.subtotalMinor))card.append(el('p',`Vrednost proizvoda: ${money(order.subtotalMinor)}`));
    if(Number.isSafeInteger(order.deliveryMinor))card.append(el('p',`Dostava${order.shipping?.method==='courier'?' kurirskom službom':''}${order.shipping?.isEstimate?' (procena)':''}: ${money(order.deliveryMinor)}`));
    if(order.totalMinor!==undefined)card.append(el('p',`Ukupno${cod?(order.paymentStatus==='cod_cancelled'?' (otkazana porudžbina)':' za plaćanje pouzećem'):''}: ${money(order.totalMinor)}`));
    if(['deducted','deducted_manual_adjustment_required'].includes(order.inventoryStatus))card.append(el('p','Zaliha je umanjena pri prijemu porudžbine.','small'));
    if(cod)card.append(el('p',order.status==='cancelled'?'Porudžbina je otkazana. Zaliha nije automatski vraćena; proverite Pantheon/Excel i ručno uskladite stanje.':'Otkazivanje ne vraća automatski zalihu. Ako se porudžbina otkaže, proverite Pantheon/Excel i ručno uskladite stanje.','notice'));
    const form=el('form'),wrap=el('label','Status','field'),select=el('select');select.name='status';for(const key of [order.status,...(transitions[order.status]||[])]){const title=statuses[key]||key;const option=el('option',title);option.value=key;option.selected=order.status===key;select.append(option);}wrap.append(select);form.append(wrap);
    const message=el('p','','form-message');message.setAttribute('role','status');const save=el('button','Sačuvaj status');save.type='submit';form.append(message,save);if(draft&&Object.hasOwn(draft.values,'status'))select.value=draft.values.status;track(form,order);form.addEventListener('submit',event=>{event.preventDefault();const cancellation=select.value==='cancelled'&&cod?' Zaliha se neće automatski vratiti. Proverite Pantheon/Excel i ručno uskladite stanje.':'';saveChange(`/admin/api/orders/${encodeURIComponent(order.id)}`,{version:order.version,status:select.value},`Porudžbina ${order.id}: status „${statuses[select.value]}”.${cancellation}`,message);});if(transitions[order.status]?.length)card.append(form);$('content').append(card);
  }
}
function renderAudit(entries,append){
  if(!entries.length&&!append){empty('Nema zabeleženih izmena','Sačuvane promene proizvoda i porudžbina pojaviće se ovde.');return;}
  for(const entry of entries){const card=el('article',undefined,'audit-entry');card.append(el('h3',entry.action||'Izmena'),el('p',`${date(entry.createdAt||entry.timestamp)} · ${entry.actorEmail||entry.actor?.email||entry.actorId||'Administrator'}`,'small'));
    card.append(el('p',`Stavka: ${entry.targetId||entry.entityId||entry.productId||entry.orderId||'—'}`,'small'));
    const details=el('details');details.append(el('summary','Prikaži zapis'),el('pre',JSON.stringify(entry,null,2)));card.append(details);$('content').append(card);
  }
}
function renderImport(){
 const box=el('details',undefined,'import-panel');box.append(el('summary','Uvoz raspoloživih zaliha iz Excel datoteke'));
 box.append(el('p','Podržan je originalni dnevni izveštaj .xls do 1 MB. Koristi se samo raspoloživo za prodaju iz magacina Magacin Bio Prodavnica B2C. Njegove količine zamenjuju trenutno stanje zaliha; cene iz izveštaja se ne uvoze. B2C sekcija je obavezna. Ostali magacini se isključuju i navode u upozorenju pregleda. Možete koristiti i .xlsx šablon sa kolonama SKU i availableQuantity. Nema automatskog povezivanja sa Pantheon sistemom.'));
 const label=el('label','Excel datoteka (.xls ili .xlsx)','field'),input=el('input');input.type='file';input.accept='.xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';label.append(input);const preview=el('button','Proveri datoteku','secondary');preview.type='button';const result=el('div'),message=el('p','','form-message');message.setAttribute('role','status');box.append(label,preview,message,result);
 input.addEventListener('change',()=>{state.preview=null;result.replaceChildren();message.textContent='';});
 preview.addEventListener('click',async()=>{
  if(state.busy)return;const file=input.files[0];state.preview=null;result.replaceChildren();
  if(!file||!/\.xlsx?$/i.test(file.name)||file.size>1024*1024||!file.size){message.textContent='Izaberite nepraznu .xls ili .xlsx datoteku veličine do 1 MB.';return;}
  if(!dirtyGuard())return;setBusy(true);const epoch=state.epoch;message.textContent='Proveravamo datoteku…';
  try {const data=await api('/admin/api/stock/preview',{method:'POST',headers:{'Content-Type':file.name.toLowerCase().endsWith('.xls')?'application/vnd.ms-excel':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','X-CSRF-Token':state.csrf},body:file});if(epoch!==state.epoch)return;state.preview=data;message.textContent=`Provereno ${data.rows.length} stavki. Pregled važi do ${date(data.expiresAt)}.`;
   result.append(el('p','Uvoze se samo prijavljeni redovi iz B2C magacina. Proizvodi kojih nema u B2C delu datoteke ostaju nepromenjeni; odsustvo reda ne znači potvrđenu nulu.'));if(Array.isArray(data.warnings)&&data.warnings.length){const warnings=el('div',undefined,'notice');warnings.setAttribute('role','status');warnings.append(el('strong','Proverite pre potvrde'));const warningList=el('ul');for(const warning of data.warnings)warningList.append(el('li',String(warning)));warnings.append(warningList);result.append(warnings);}const list=el('ul');for(const row of data.rows){const item=el('li',`${row.name} (${row.id})${row.sourceIdent?` · Ident: ${row.sourceIdent}`:''}: ${row.oldQuantity??'nepoznato'} → ${row.stockQuantity} kom.`);if(Array.isArray(row.warehouseQuantities)){const breakdown=el('ul');for(const warehouse of row.warehouseQuantities)breakdown.append(el('li',`${warehouse.warehouse}: ${warehouse.quantity} kom.`));item.append(breakdown);}list.append(item);}result.append(list);
   const apply=el('button','Potvrdi zamenu zaliha');apply.type='button';result.append(apply);apply.addEventListener('click',async()=>{
    if(state.busy||!state.preview)return;setBusy(true);const token=state.preview.previewToken;const generation=state.epoch;
    try {if(!await confirmSave(`Zameniti raspoloživo stanje zaliha za ${data.rows.length} proizvoda prikazanim količinama iz pregledane datoteke? Cene se ne menjaju.`))return;if(generation!==state.epoch||!state.csrf)return;await api('/admin/api/stock/apply',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},body:JSON.stringify({previewToken:token})});if(generation!==state.epoch)return;state.preview=null;state.dirty=false;setBusy(false);const refreshed=await load('products');if(state.csrf&&refreshed)status('Zalihe su sačuvane. Proverite dostupnost svakog proizvoda.');}
    catch(error){if(generation===state.epoch){state.preview=null;result.replaceChildren();message.textContent=`${error.message} Ponovo proverite datoteku pre uvoza.`;}}
    finally{if(generation===state.epoch)setBusy(false);}
   });
  }catch(error){if(epoch===state.epoch)message.textContent=error.message;}finally{if(epoch===state.epoch)setBusy(false);}
 });$('content').append(box);
}
if(typeof document!=='undefined'){
 document.querySelectorAll('[data-view]').forEach(node=>node.addEventListener('click',()=>{if(!state.busy&&dirtyGuard())load(node.dataset.view);}));
 $('refresh').addEventListener('click',()=>{if(dirtyGuard())load();});$('retry').addEventListener('click',boot);$('more').addEventListener('click',()=>{if(dirtyGuard())load(state.view,true);});
 window.addEventListener('pageshow',boot);window.addEventListener('pagehide',clearSensitive);
 window.addEventListener('beforeunload',event=>{if(state.dirty){event.preventDefault();event.returnValue='';}});
 async function checkSession(){if(document.hidden||!state.csrf||state.busy)return;const epoch=state.epoch;try{const session=await api('/admin/api/session');if(epoch===state.epoch){state.csrf=session.csrfToken;
    $('customers-tab').hidden=!session.capabilities?.customers;}}catch(error){if(state.csrf)status('Provera sesije nije uspela. Pre čuvanja će se ponovo proveriti pristup.',true);}}
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkSession();});setInterval(checkSession,60000);
}
