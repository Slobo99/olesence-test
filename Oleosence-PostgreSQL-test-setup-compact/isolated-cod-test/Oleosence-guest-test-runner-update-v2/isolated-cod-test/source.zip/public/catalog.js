export const settings = Object.freeze({ brand: 'olésence', locale: 'sr-Latn', mode: 'preview', checkoutEnabled: false, currency: 'RSD' });
const declarations = {
  "crni-kim": {
    "benefit": "Ulje crnog kima doprinosi održavanju normalnog nivoa glukoze u krvi.",
    "usage": "1 kašičica (3 ml) dnevno, po mogućnosti pre jela.",
    "notes": "Dodaci ishrani se ne mogu koristiti kao zamena za raznovrsnu i uravnoteženu ishranu i zdrav način života. Čuvati van domašaja male dece.",
    "warnings": "Preporučene dnevne doze se ne smeju prekoračiti. Proizvod ne treba da koriste osobe osetljive na sastojke proizvoda, na terapiji antikoagulansima i drugim lekovima, deca, trudnice i dojilje. Osobe koje koriste lekove, pre upotrebe bi trebalo da konsultuju lekara zbog moguće interakcije sa pojedinim lekovima. Izbegavati kontakt sa očima.",
    "storage": "Čuvati van domašaja dece, dobro zatvoreno, na tamnom i hladnom mestu.",
  },
  "divlji-origano": {
    "editorialCaveat": "Ulje divljeg origana treba izbegavati i tokom dojenja. Pre upotrebe proverite konačnu deklaraciju i posavetujte se sa lekarom ili farmaceutom.",
    "benefit": "Divlji origano može da doprinosi: normalnoj funkciji imunog sistema i respiratornog trakta i normalnoj funkciji organa za varenje.",
    "usage": "Oralno: 1–2 kapi u kašičicu maslinovog ili kokosovog ulja, jednom dnevno, do 10 dana, samo pod nadzorom stručnog lica (nutricionista, farmaceut ili lekar).",
    "notes": "Dodaci ishrani se ne mogu koristiti kao zamena za raznovrsnu i uravnoteženu ishranu i zdrav način života. Čuvati van domašaja male dece.",
    "warnings": "Preporučene dnevne doze se ne smeju prekoračiti. Ulje je izuzetno snažno – ne koristiti nerazblaženo! Proizvod ne treba da koriste osobe osetljive na sastojke proizvoda, osobe koje primenjuju lekove za terapiju dijabetesa, osobe koje imaju sklonost ka hemoragiji i drugim poremećajima krvarenja. Nije namenjeno deci, trudnicama niti osobama sa osetljivom kožom. Pre oralne upotrebe obavezno konsultovati lekara. Izbegavati kontakt sa očima.",
    "storage": "Čuvati van domašaja dece, dobro zatvoreno, na tamnom i hladnom mestu.",
  },
  "cetiri-lopova": {
    "benefit": "Etarsko ulje eukaliptusa i limuna mogu da doprinose normalnoj funkciji respiratornog trakta.",
    "usage": "Oralno: 1–2 kapi u kašičicu meda ili ulja, jednom dnevno, samo pod nadzorom stručnog lica (farmaceut ili lekar).",
    "notes": "Dodaci ishrani se ne mogu koristiti kao zamena za raznovrsnu i uravnoteženu ishranu i zdrav način života. Čuvati van domašaja male dece.",
    "warnings": "Preporučene dnevne doze se ne smeju prekoračiti. Ne koristiti nerazblaženo. Ne preporučuje se kod osoba sa zapaljenskim oboljenjima gastrointestinalnog trakta, oboljenjima žučne kese ili oštećenom funkcijom jetre, kod osoba sa bronhijalnom astmom ili bronhitisom, kao ni na oštećenoj i osetljivoj koži (opekotine, lezije ili kožni osipi), deci, trudnicama i dojiljama, kao i kod osoba osetljivim na sastojke proizvoda. Pre oralne upotrebe obavezno konsultovati lekara. Izbegavati kontakt sa licem i očima.",
    "storage": "Čuvati van domašaja dece, dobro zatvoreno, na tamnom i hladnom mestu.",
  }
};
const seedProducts = Object.freeze([
  {id:'crni-kim', priceMinor:149000, name:'Ulje crnog kima', botanical:'Nigella sativa L.', category:'Biljno ulje', volume:'250 ml', image:'crni-kim.jpg', tone:'blue', description:'Ulje semena crnog kima, dobijeno mehaničkim ceđenjem.', ingredients:'Ulje semena biljke Nigella sativa.', method:'Hladno ceđenje.', note:'Zapremina od 250 ml navedena je na dostavljenom pakovanju.', },
  {id:'divlji-origano', priceMinor:159000, name:'Ulje divljeg origana', botanical:'Origanum vulgare L.', category:'Eterično ulje', volume:null, image:'origano.jpg', tone:'green', description:'Eterično ulje divljeg origana prepoznatljivog, intenzivnog mirisa.', ingredients:'Eterično ulje divljeg origana.', method:null, note:'Zapremina i način dobijanja čekaju potvrdu proizvođača.', },
  {id:'cetiri-lopova', priceMinor:84000, name:'Ulje 4 lopova', botanical:'Mešavina eteričnih ulja', category:'Mešavina', volume:null, image:'cetiri-lopova.jpg', tone:'berry', description:'Aromatična mešavina eteričnih ulja karanfilića, limuna, cimeta, eukaliptusa i ruzmarina.', ingredients:'Eterična ulja karanfilića, limuna, cimeta, eukaliptusa i ruzmarina.', method:null, note:'Zapremina čeka potvrdu proizvođača.', }
].map(product => Object.freeze({...product, declaration: Object.freeze(declarations[product.id])})));
export let products=seedProducts;
if(typeof window!=='undefined'){
 try{const response=await fetch('/api/catalog',{cache:'no-store'});if(!response.ok)throw Error();const data=await response.json();if(Array.isArray(data.products)&&data.products.length===3&&data.products.every(p=>seedProducts.some(s=>s.id===p.id)))products=Object.freeze(data.products.map(p=>Object.freeze(p)));else throw Error();}
 catch{document.documentElement.dataset.catalogUnavailable='true';}
}
export function normalizeCart(raw) {
  if (!Array.isArray(raw)) return [];
  const quantities = new Map();
  for (const item of raw) if (item && products.some(p=>p.id===item.id) && Number.isInteger(item.quantity) && item.quantity>0) quantities.set(item.id, Math.min(20,(quantities.get(item.id)||0)+item.quantity));
  return [...quantities].map(([id,quantity])=>({id,quantity}));
}

export const shippingPolicy = Object.freeze({ currency:'RSD', perPackageMinor:30000, freeFromMinor:350000 });
export function formatMoney(minor){if(!Number.isSafeInteger(minor)||minor<0)throw new RangeError('Invalid amount');return new Intl.NumberFormat('sr-Latn-RS',{style:'currency',currency:'RSD',minimumFractionDigits:2,maximumFractionDigits:2}).format(minor/100);}
export function shippingEstimateMinor(subtotalMinor,packageCount=1){if(!Number.isSafeInteger(subtotalMinor)||subtotalMinor<0||!Number.isSafeInteger(packageCount)||packageCount<1)throw new RangeError('Invalid shipping estimate');if(subtotalMinor===0||subtotalMinor>=shippingPolicy.freeFromMinor)return 0;const amount=shippingPolicy.perPackageMinor*packageCount;if(!Number.isSafeInteger(amount))throw new RangeError('Invalid shipping estimate');return amount;}
export function quoteCart(raw,packageCount=1){const items=normalizeCart(raw);const count=items.reduce((n,i)=>n+i.quantity,0);const subtotalMinor=items.reduce((n,i)=>n+products.find(p=>p.id===i.id).priceMinor*i.quantity,0);const deliveryMinor=shippingEstimateMinor(subtotalMinor,packageCount);return {count,subtotalMinor,deliveryMinor,totalMinor:subtotalMinor+deliveryMinor,estimatedPackages:count?packageCount:0,freeDelivery:subtotalMinor>=shippingPolicy.freeFromMinor,isEstimate:true};}
