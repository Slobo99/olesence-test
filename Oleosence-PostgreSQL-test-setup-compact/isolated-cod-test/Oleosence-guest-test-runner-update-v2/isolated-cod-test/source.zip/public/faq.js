export const faqItems = Object.freeze([
  {
    "id": "safety-1",
    "question": "Da li su ulja 100% čista i prirodna, bez dodataka i razblaživača?",
    "blocks": [
      {
        "type": "p",
        "text": "Prema sastavu navedenom u dostavljenoj dokumentaciji, drugi sastojci nisu deklarisani. Ulje divljeg origana sadrži etarsko ulje origana sa najmanje 80% karvakrola. Ulje 4 lopova je mešavina etarskih ulja karanfilića (50%), limuna (20%), cimeta (18%), eukaliptusa (6%) i ruzmarina (6%). Ulje crnog kima je hladno presovano jestivo biljno ulje semena crnog kima, sa 1–3,5% timohinona. To opisuje deklarisani sastav; samo stručno mišljenje nije laboratorijska potvrda čistoće svake serije."
      }
    ]
  },
  {
    "id": "safety-2",
    "question": "Da li je registrovano kao dodatak ishrani ili aroma?",
    "blocks": [
      {
        "type": "p",
        "text": "U stručnim mišljenjima sva tri proizvoda svrstana su u dodatke ishrani, uz usaglašavanje sa navedenim komentarima. Predviđena je oralna upotreba pod uslovima iz njihovih deklaracija. Broj i datum upisa u bazu Ministarstva zdravlja još nisu dostupni, pa završen upis trenutno ne potvrđujemo."
      }
    ]
  },
  {
    "id": "safety-3",
    "question": "Kako se ulja čuvaju i koliko traju nakon otvaranja?",
    "blocks": [
      {
        "type": "p",
        "text": "Čuvati van domašaja dece, dobro zatvoreno, na tamnom i hladnom mestu. Rok „najbolje upotrebiti do“ naveden je na pakovanju. Poseban rok nakon otvaranja nije naveden u dostavljenim stručnim mišljenjima; taj podatak treba potvrditi prema konačnoj deklaraciji konkretnog proizvoda."
      }
    ]
  },
  {
    "id": "safety-4",
    "question": "Kolika je dnevna količina i da li se uzima u vodi, medu, ulju ili kapsuli?",
    "blocks": [
      {
        "type": "p",
        "text": "Način primene razlikuje se po proizvodu. U stručnim mišljenjima navedeno je:"
      },
      {
        "type": "list",
        "items": [
          "Divlji origano: 1–2 kapi u kašičicu maslinovog ili kokosovog ulja, jednom dnevno, do 10 dana, samo pod nadzorom nutricioniste, farmaceuta ili lekara. Pre oralne upotrebe obavezna je konsultacija sa lekarom.",
          "Ulje 4 lopova: 1–2 kapi u kašičicu meda ili ulja, jednom dnevno, samo pod nadzorom farmaceuta ili lekara. Pre oralne upotrebe obavezna je konsultacija sa lekarom.",
          "Crni kim: 3 ml dnevno, po mogućnosti pre jela. Količinu meriti u mililitrima; veličina kućnih kašičica varira."
        ]
      },
      {
        "type": "p",
        "text": "Voda i kućno punjenje kapsula nisu navedeni načini primene ovih proizvoda. Ne prekoračivati navedene dnevne količine i proveriti upozorenja za konkretan proizvod."
      }
    ]
  },
  {
    "id": "safety-5",
    "question": "Da li su ulja za unutrašnju upotrebu i šta znači „food grade“?",
    "blocks": [
      {
        "type": "p",
        "text": "Dostavljena dokumentacija predviđa oralnu upotrebu sva tri proizvoda uz njihove posebne doze i ograničenja. U tabelama specifikacija sirovina navodi se kvalitet „food grade“. Taj navod nije potvrda završene registracije niti znači da je proizvod bezbedan za svakoga ili u bilo kojoj količini. Za upotrebu su merodavni konačna deklaracija, upozorenja i, gde je navedeno, stručni nadzor."
      }
    ]
  },
  {
    "id": "safety-6",
    "question": "Da li ulja smeju da se koriste nerazblažena?",
    "blocks": [
      {
        "type": "p",
        "text": "Ulje divljeg origana i Ulje 4 lopova ne koristiti nerazblažena. Pratiti tačno navedeni način primene za svaki proizvod. Crni kim je hladno presovano jestivo biljno ulje, a u njegovoj deklaraciji nije propisano razblaživanje; navedena dnevna količina je 3 ml. Izbegavati kontakt sa očima i poštovati sva upozorenja na pakovanju."
      }
    ]
  },
  {
    "id": "safety-7",
    "question": "Da li proizvode mogu da koriste deca, trudnice i dojilje?",
    "blocks": [
      {
        "type": "p",
        "text": "Ova ulja nisu namenjena deci i trudnicama. Ulje 4 lopova i ulje crnog kima ne preporučuju se ni dojiljama; za ulje origana stručno mišljenje takođe preporučuje izbegavanje tokom dojenja. Nemojte prilagođavati dozu za dete na svoju ruku. Dodatna ograničenja zavise od proizvoda, postojećih oboljenja i terapije, pa pre upotrebe proverite celu deklaraciju i posavetujte se sa lekarom ili farmaceutom."
      }
    ]
  },
  {
    "id": "ordering",
    "question": "Da li mogu da poručim proizvode i koliko iznosi dostava?",
    "blocks": [
      {
        "type": "p",
        "text": "Možete istražiti proizvode i dodati ih u korpu, ali poručivanje i plaćanje nisu omogućeni. Dostava je 300 din po paketu, a za vrednost proizvoda od 3.500 din besplatna. Broj paketa i dostupnost potvrđuju se pre poručivanja."
      }
    ]
  }
].map(item => Object.freeze(item)));
