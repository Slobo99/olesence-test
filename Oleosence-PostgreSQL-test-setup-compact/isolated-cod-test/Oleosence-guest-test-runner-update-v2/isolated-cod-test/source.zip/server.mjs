import {createGuestStore} from './src/guest-store.mjs';
import {createCodStore} from './src/cod-store.mjs';
import {createCheckout} from './src/checkout.mjs';
import http from 'node:http';
import pg from 'pg';
import {createCustomerStore,readCustomerDatabaseConfig} from './src/customer-store.mjs';
import {products as seedProducts} from './public/catalog.js';
import {createAdmin,readAdminConfig} from './src/admin.mjs';
import {createPostgresStore,StoreError} from './src/admin-store.mjs';
import {readFile,readdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {AuthError,createCustomerAuth,readConfig} from './src/customer-auth.mjs';

export function readHostedConfig(env=process.env){
 const origin=env.CUSTOMER_AUTH_ORIGIN;
 let u;try{u=new URL(origin);}catch{throw Error('Set CUSTOMER_AUTH_ORIGIN to the exact assigned HTTPS origin.');}
 if(u.protocol!=='https:'||u.origin!==origin||u.username||u.password||u.port||u.hostname==='localhost'||u.hostname==='127.0.0.1')throw Error('A canonical public HTTPS origin without a path, port or credentials is required.');
 // This HTTP listener is only safe behind Render TLS termination. Never expose it directly.
 if(env.RENDER!=='true')throw Error('Hosted entrypoint requires the Render TLS proxy environment.');
 const redirectHosts=(env.CUSTOMER_AUTH_REDIRECT_HOSTS||'').split(',').map(x=>x.trim()).filter(Boolean);
 if(redirectHosts.length>8||new Set(redirectHosts).size!==redirectHosts.length)throw Error('Provide at most eight unique redirect hosts.');
 for(const host of redirectHosts){let alias;try{alias=new URL('https://'+host);}catch{throw Error('Invalid redirect host.');}
  if(alias.host!==host||alias.hostname!==host||alias.origin!=='https://'+host||host===u.host||!host.includes('.')||!/^([a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(host)||host==='127.0.0.1')throw Error('Redirect hosts must be exact lowercase DNS names, distinct from the canonical host.');
 }
 const config={origin,host:u.host,redirectHosts,auth:readConfig(env),admin:readAdminConfig(env),customerDatabaseEnabled:readCustomerDatabaseConfig(env),checkoutEnabled:env.CHECKOUT_COD_ENABLED==='1',guestCheckoutEnabled:env.CHECKOUT_GUEST_ENABLED==='1'};
 if(config.checkoutEnabled&&(!config.auth||!config.admin.enabled||!config.customerDatabaseEnabled))throw Error('COD checkout requires Google login, persistent customers and product administration.');
 if(config.guestCheckoutEnabled&&!config.checkoutEnabled)throw Error('Guest checkout requires COD checkout.');
 return config;
}
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.txt':'text/plain; charset=utf-8'};
export async function createHostedServer({config=readHostedConfig(),provider,clock=Date.now,rateLimit=60,store=null,customerStore=null,codStore=null,guestStore=null}={}){
 if(config.customerDatabaseEnabled&&!customerStore)throw Error('Persistent customer repository required.');
 if(config.checkoutEnabled&&(!config.customerDatabaseEnabled||!config.auth||!config.admin?.enabled||!store||!customerStore||!codStore))throw Error('COD checkout dependencies are not configured.');
 if(config.guestCheckoutEnabled&&(!config.checkoutEnabled||!guestStore))throw Error('Guest checkout dependencies are not configured.');
 const auth=createCustomerAuth({config:config.auth,provider,clock,capacity:250,resolveCustomer:config.customerDatabaseEnabled&&customerStore?user=>customerStore.upsertVerifiedGoogleUser(user):null});
 const admin=createAdmin({config:config.admin,auth,store,customerStore,origin:config.origin,clock});
 const checkout=createCheckout({enabled:config.checkoutEnabled,guestEnabled:config.guestCheckoutEnabled,guestStore,auth,codStore,origin:config.origin,clock});
 const adminFiles=new Map();
 for(const name of ['admin.html','admin.js','admin.css'])adminFiles.set('/'+name,{bytes:await readFile(new URL('./public/'+name,import.meta.url)),type:types[name.slice(name.lastIndexOf('.'))]});
 const files=new Map();
 // Explicit public allowlist: do not mount the project directory, uploads, local test server, or SPA fallback.
 const names=['index.html','app.js','catalog.js','slider.js','faq.js','styles.css','robots.txt','account.html','account.js','test-shop.css','checkout.html','checkout.js','checkout.css'];
 for(const name of names)files.set('/'+name,{bytes:await readFile(new URL('./public/'+name,import.meta.url)),type:types[name.slice(name.lastIndexOf('.'))]});
 for(const name of await readdir(new URL('./public/assets/',import.meta.url))){if(!/^[a-z0-9-]+\.(png|jpg)$/.test(name))throw Error('Unexpected public asset');files.set('/assets/'+name,{bytes:await readFile(new URL('./public/assets/'+name,import.meta.url)),type:types[name.slice(name.lastIndexOf('.'))]});}
 for(const slug of ['crni-kim','divlji-origano','cetiri-lopova']){const file={bytes:await readFile(new URL('./public/proizvod/'+slug+'/index.html',import.meta.url)),type:types['.html']};for(const suffix of ['', '/', '/index.html'])files.set('/proizvod/'+slug+suffix,file);}
 let windowStart=clock(),starts=0,callbacks=0;
 function limit(kind){if(clock()-windowStart>=60000){windowStart=clock();starts=callbacks=0;}if(kind==='start'?++starts>rateLimit:++callbacks>rateLimit*2)throw new AuthError(429,'Previše pokušaja. Sačekajte minut pa pokušajte ponovo.');}
 const server=http.createServer({maxHeaderSize:16384},async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Robots-Tag','noindex, nofollow');res.setHeader('Strict-Transport-Security','max-age=86400');
  res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'; object-src 'none'");
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  const send=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
  try{
   if(req.url.length>8192)throw new AuthError(414,'Request too long.');
   // Health probes disclose no configuration or identity and need not carry the public Host.
   if(req.method==='GET'&&req.url==='/healthz')return send(200,{ok:true,mode:'test'});
   const redirectHost=(config.redirectHosts||[]).includes(req.headers.host);
   if(req.headers.host!==config.host&&!redirectHost)throw new AuthError(421,'Unknown host.');
   if(req.headers['x-forwarded-proto']!=='https')throw new AuthError(400,'HTTPS proxy required.');
   if(!req.url.startsWith('/')||req.url.startsWith('//'))throw new AuthError(400,'Invalid request.');
   if(/[\\\x00-\x20\x7f]/.test(req.url))throw new AuthError(400,'Invalid request.');
   const url=new URL(req.url,config.origin),p=url.pathname;
   if(url.origin!==config.origin)throw new AuthError(400,'Invalid request.');
   if(redirectHost){
    // Never replay POST bodies, cookies, or OAuth codes onto a different origin.
    if(!['GET','HEAD'].includes(req.method))throw new AuthError(421,'Use the canonical site.');
    let decodedPath;try{decodedPath=decodeURIComponent(p);}catch{throw new AuthError(400,'Invalid request.');}
    const authPath=/^\/auth(?:\/|$)/i.test(decodedPath);
    res.writeHead(authPath?303:308,{Location:config.origin+(authPath?'/account':url.pathname+url.search)});return res.end();
   }
   const callback=p==='/auth/google/callback'&&req.method==='GET';
   const site=req.headers['sec-fetch-site'];
   const navigation=req.method==='GET'&&req.headers['sec-fetch-mode']==='navigate'&&req.headers['sec-fetch-dest']==='document'&&(callback||p==='/'||p==='/account'||p==='/checkout'||p==='/admin'||p==='/admin.html'||files.get(p)?.type===types['.html']);
   if(req.headers.origin&&req.headers.origin!==config.origin)throw new AuthError(403,'Origin rejected.');
   if(site&&!['same-origin','none'].includes(site)&&!navigation)throw new AuthError(403,'Cross-site request rejected.');
   if(p.startsWith('/api/checkout/'))return await checkout.handle(req,url,send,res);
   if(p.startsWith('/admin/api/'))return await admin.handle(req,url,send);
   if(p==='/admin'||adminFiles.has(p)){admin.session(req);const file=adminFiles.get(p==='/admin'?'/admin.html':p);if(!['GET','HEAD'].includes(req.method))throw new AuthError(405,'Method not allowed.');res.writeHead(200,{'Content-Type':file.type});return res.end(req.method==='HEAD'?undefined:file.bytes);}
   const media=p.match(/^\/media\/([a-f0-9]{64})\.jpg$/);
   if(media&&['GET','HEAD'].includes(req.method)){
    if(!config.admin?.enabled||!store)throw new AuthError(404,'Not found.');
    const image=await store.getImage(media[1]);if(!image)throw new AuthError(404,'Not found.');
    res.writeHead(200,{'Content-Type':'image/jpeg','Content-Length':image.bytes.length,'Cache-Control':'public, max-age=31536000, immutable','Content-Disposition':'inline; filename="product.jpg"','Cross-Origin-Resource-Policy':'same-origin'});return res.end(req.method==='HEAD'?undefined:image.bytes);
   }
   if(req.method==='GET'&&p==='/api/catalog'){if(!config.admin?.enabled||!store)return send(200,{products:seedProducts});const products=await store.listProducts();return send(200,{products:products.map(({stockQuantity,version,updatedAt,...p})=>({...p,available:p.available===true&&stockQuantity>0}))});}
   if(req.method==='GET'&&p==='/auth/session'){const s=auth.session(req);return send(200,{enabled:auth.enabled,user:s?.user??null,csrfToken:s?.csrfToken??null,testOnly:!config.checkoutEnabled,checkoutLinked:!!config.checkoutEnabled});}
   if(req.method==='POST'&&p==='/auth/google/start'){
    if(req.headers.origin!==config.origin)throw new AuthError(403,'Same-origin login required.');
    limit('start');return send(200,{url:auth.start(req,res)});
   }
   if(callback){try{limit('callback');await auth.callback(req,res,url);res.writeHead(303,{Location:'/account'});}catch(e){if(!(e instanceof AuthError))throw e;res.writeHead(303,{Location:'/account?login=failed'});}return res.end();}
   if(req.method==='POST'&&p==='/auth/logout'){
    if(req.headers.origin!==config.origin)throw new AuthError(403,'Same-origin logout required.');auth.logout(req,res);return send(200,{signedOut:true});
   }
   const path=p==='/'?'/index.html':p==='/account'?'/account.html':p==='/checkout'?'/checkout.html':p;
   const file=files.get(path);
   if((req.method==='GET'||req.method==='HEAD')&&file){res.writeHead(200,{'Content-Type':file.type});return res.end(req.method==='HEAD'?undefined:file.bytes);}
   throw new AuthError(404,'Not found.');
  }catch(e){send(e instanceof AuthError||e instanceof StoreError?e.status:500,{error:e instanceof AuthError||e instanceof StoreError?e.message:'Usluga trenutno nije dostupna. Pokušajte ponovo.'});}
 });
 server.requestTimeout=10000;server.headersTimeout=10000;server.keepAliveTimeout=5000;server.maxRequestsPerSocket=100;
 return {server,auth,async close(){checkout.close();admin.close();auth.close();if(server.listening)await new Promise(r=>server.close(r));}};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const config=readHostedConfig();
 let store=null,customerStore=null,codStore=null,guestStore=null;
 if(config.admin.enabled||config.customerDatabaseEnabled){
  // Use provider-supplied TLS settings; never disable certificate verification.
  const pool=new pg.Pool({connectionString:process.env.DATABASE_URL,max:5,connectionTimeoutMillis:5000,idleTimeoutMillis:30000,statement_timeout:5000});
  pool.on('error',()=>console.error('Database connection unavailable.'));
  store=createPostgresStore(pool);await store.initialize(seedProducts);if(config.customerDatabaseEnabled)customerStore=createCustomerStore(pool);if(config.checkoutEnabled)codStore=createCodStore(pool);if(config.guestCheckoutEnabled)guestStore=createGuestStore(pool);
 }
 const app=await createHostedServer({config,store,customerStore,codStore,guestStore});const port=Number(process.env.PORT||10000);
 if(!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid PORT');
 app.server.listen(port,'0.0.0.0',()=>console.log(config.checkoutEnabled?'Oleosence service ready. COD checkout configured.':'Oleosence service ready. Checkout remains disabled.'));
 for(const signal of ['SIGTERM','SIGINT'])process.once(signal,async()=>{await app.close();if(store)await store.close();process.exit(0);});
}
