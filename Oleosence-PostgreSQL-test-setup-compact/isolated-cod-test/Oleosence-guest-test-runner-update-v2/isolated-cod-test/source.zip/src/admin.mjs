import {timingSafeEqual,randomBytes} from 'node:crypto';
import {sanitizeProductImage,MAX_IMAGE_BYTES} from './product-image.mjs';
import {AuthError} from './customer-auth.mjs';
import {parseStockWorkbook} from './stock-import.mjs';
export function readAdminConfig(env=process.env){
 const enabled=env.ADMIN_ENABLED==='1';
 const emails=(env.ADMIN_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
 if(emails.some(x=>!/^([^\s@]+)@([^\s@]+)\.[^\s@]+$/.test(x)))throw Error('Invalid ADMIN_EMAILS');
 if(enabled&&(!emails.length||!env.DATABASE_URL))throw Error('Admin requires explicit ADMIN_EMAILS and persistent DATABASE_URL.');
 return {enabled,emails};
}
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
export async function readBody(req,max=32768){if(req.headers['content-length']&&Number(req.headers['content-length'])>max)throw new AuthError(413,'Datoteka ili zahtev je prevelik.');const chunks=[];let n=0;for await(const b of req){n+=b.length;if(n>max)throw new AuthError(413,'Datoteka ili zahtev je prevelik.');chunks.push(b);}return Buffer.concat(chunks);}
async function json(req){if(req.headers['content-type']?.split(';')[0]!=='application/json')throw new AuthError(415,'Potreban je JSON zahtev.');try{const value=JSON.parse((await readBody(req)).toString('utf8'));if(!value||typeof value!=='object'||Array.isArray(value))throw Error();return value;}catch(e){if(e instanceof AuthError)throw e;throw new AuthError(400,'Neispravan JSON.');}}
export function createAdmin({config={enabled:false,emails:[]},auth,store,customerStore=null,origin,clock=Date.now}){
 const previews=new Map();let imageUploadBusy=false;let lastWindow=clock(),mutations=0;
 function clean(){for(const [key,p]of previews)if(p.expiresAt<=clock())previews.delete(key);}
 function session(req){if(!config.enabled)throw new AuthError(404,'Not found.');const s=auth.session(req);if(!s)throw new AuthError(401,'Prijavite se Google nalogom.');if(s.user.provider!=='google'||!config.emails.includes(s.user.email.toLowerCase()))throw new AuthError(403,'Ovaj nalog nema administratorski pristup.');return s;}
 return {session,async handle(req,url,send){
  const s=session(req),p=url.pathname;
  if(req.method==='GET'&&p==='/admin/api/session')return send(200,{user:{email:s.user.email,name:s.user.name,role:'admin'},csrfToken:s.csrfToken,capabilities:{customers:!!customerStore}});
  if(!store)throw new AuthError(503,'Trajna baza još nije podešena. Izmene nisu dostupne.');
  if(!['GET','HEAD'].includes(req.method)){
   if(req.headers.origin!==origin||!equal(req.headers['x-csrf-token'],s.csrfToken))throw new AuthError(403,'Sesija ili zaštita zahteva nije važeća. Osvežite stranicu.');
   if(clock()-lastWindow>=60000){lastWindow=clock();mutations=0;}if(++mutations>60)throw new AuthError(429,'Previše izmena. Sačekajte minut.');
  }
  if(req.method==='GET'&&p==='/admin/api/customers'){if(!customerStore)throw new AuthError(503,'Trajno čuvanje kupaca još nije uključeno.');return send(200,await customerStore.listCustomers({before:url.searchParams.get('before')||undefined,limit:Number(url.searchParams.get('limit')||50)}));}
  if(req.method==='GET'&&p==='/admin/api/products')return send(200,{products:await store.listProducts()});
  if(req.method==='GET'&&['/admin/api/orders','/admin/api/audit'].includes(p)){
   const before=url.searchParams.get('before')||undefined,limit=Number(url.searchParams.get('limit')||50);
   if((before&&!/^\d{1,19}$/.test(before))||!Number.isInteger(limit)||limit<1||limit>100)throw new AuthError(400,'Neispravna stranica.');
   return send(200,await (p.endsWith('orders')?store.listOrders({before,limit}):store.listAudit({before,limit})));
  }
  const imageMatch=p.match(/^\/admin\/api\/products\/([a-zA-Z0-9-]{1,100})\/image$/);
  if(req.method==='POST'&&imageMatch){
   if(imageUploadBusy)throw new AuthError(429,'Druga slika se obrađuje. Pokušajte ponovo.');
   const mime=req.headers['content-type'],rawVersion=req.headers['x-product-version'];
   if(!['image/jpeg','image/png'].includes(mime))throw new AuthError(415,'Dozvoljene su samo JPEG i PNG fotografije.');
   if(typeof rawVersion!=='string'||!/^\d{1,10}$/.test(rawVersion)||!Number.isSafeInteger(Number(rawVersion))||Number(rawVersion)<1)throw new AuthError(400,'Nedostaje važeća verzija proizvoda.');
   imageUploadBusy=true;try{const image=await sanitizeProductImage(await readBody(req,MAX_IMAGE_BYTES),mime);return send(200,await store.updateProductImage(imageMatch[1],Number(rawVersion),image,s.user));}finally{imageUploadBusy=false;}
  }
  const match=p.match(/^\/admin\/api\/(products|orders)\/([a-zA-Z0-9-]{1,100})$/);
  if(req.method==='PATCH'&&match){const {version,...patch}=await json(req);return send(200,await (match[1]==='products'?store.updateProduct(match[2],version,patch,s.user):store.updateOrder(match[2],version,patch,s.user)));}
  if(req.method==='POST'&&p==='/admin/api/stock/preview'){
   if(!['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-excel'].includes(req.headers['content-type']))throw new AuthError(415,'Izaberite .xls ili .xlsx datoteku.');
   clean();if(previews.size>=50)throw new AuthError(429,'Previše pregleda. Sačekajte pet minuta.');
   const parsed=await parseStockWorkbook(await readBody(req,1048576));const products=await store.listProducts();
   const rows=parsed.map(r=>{const product=products.find(p=>p.id===r.id);if(!product)throw new AuthError(422,'Nepoznat SKU: '+r.id);return {...r,name:product.name,oldQuantity:product.stockQuantity,version:product.version};});
   const previewToken=randomBytes(32).toString('base64url'),expiresAt=clock()+300000;
   const warnings=products.filter(p=>!rows.some(r=>r.id===p.id)).map(p=>`Proizvod ${p.name} nije u datoteci; njegovo stanje ostaje nepromenjeno.`);
   for(const warehouse of new Set(rows.flatMap(row=>row.excludedWarehouses||[])))warnings.push(`Magacin ${warehouse} je isključen iz uvoza; koristi se samo Magacin Bio Prodavnica B2C.`);
   previews.set(previewToken,{rows,expiresAt,subject:s.user.id,csrf:s.csrfToken});return send(200,{previewToken,rows,expiresAt,warnings});
  }
  if(req.method==='POST'&&p==='/admin/api/stock/apply'){
   const body=await json(req);if(Object.keys(body).some(k=>k!=='previewToken'))throw new AuthError(400,'Neispravan zahtev.');clean();const preview=previews.get(body.previewToken);
   if(!preview||preview.subject!==s.user.id||!equal(preview.csrf,s.csrfToken))throw new AuthError(409,'Pregled je istekao. Ponovo učitajte datoteku.');
   previews.delete(body.previewToken);return send(200,{products:await store.applyStockImport(preview.rows.map(({id,version,stockQuantity})=>({id,version,stockQuantity})),s.user)});
  }
  throw new AuthError(404,'Not found.');
 },close(){previews.clear();}};
}
