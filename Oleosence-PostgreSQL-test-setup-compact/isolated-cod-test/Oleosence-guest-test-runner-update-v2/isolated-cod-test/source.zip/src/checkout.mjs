import {timingSafeEqual,randomBytes,createHash} from 'node:crypto';
import {AuthError} from './customer-auth.mjs';
import {readBody} from './admin.mjs';
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const validCustomer=id=>typeof id==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(id);
async function json(req){if(req.headers['content-type']?.split(';')[0]!=='application/json')throw new AuthError(415,'Potreban je JSON zahtev.');try{const body=JSON.parse((await readBody(req,16384)).toString('utf8'));if(!body||typeof body!=='object'||Array.isArray(body))throw Error();return body;}catch(e){if(e instanceof AuthError)throw e;throw new AuthError(400,'Neispravan JSON.');}}
function keys(body,allowed){if(Object.keys(body).some(k=>!allowed.includes(k)))throw new AuthError(400,'Nepoznata polja zahteva.');}
export function createCheckout({enabled=false,guestEnabled=false,guestStore=null,auth,codStore,origin,clock=Date.now}){
 const limits=new Map();
 const guestCookie='__Host-olesence_guest';
 const tokenHash=token=>createHash('sha256').update(token).digest('hex');
 function readGuestToken(req){const values=(req.headers.cookie||'').split(';').map(x=>x.trim()).filter(x=>x.startsWith(guestCookie+'='));if(values.length!==1)return null;const value=values[0].slice(guestCookie.length+1);return /^[a-zA-Z0-9_-]{43}$/.test(value)?value:null;}
 async function guestSession(req){if(!guestEnabled||!guestStore)return null;const token=readGuestToken(req);return token?guestStore.getSession(tokenHash(token)):null;}

 function limit(id,write){const now=clock();for(const[k,v]of limits)if(v.until<=now)limits.delete(k);let row=limits.get(id);if(!row){if(limits.size>=1000)throw new AuthError(429,'Usluga je zauzeta. Pokušajte kasnije.');row={until:now+60000,read:0,write:0};limits.set(id,row);}const key=write?'write':'read';if(++row[key]>(write?15:90))throw new AuthError(429,'Previše zahteva. Sačekajte minut pa pokušajte ponovo.');}
 return {async handle(req,url,send,res){
  const p=url.pathname,s=auth.session(req);
  let guest=s?null:await guestSession(req);
  if(req.method==='GET'&&p==='/api/checkout/session'){
   if(enabled&&guestEnabled&&guestStore&&!s&&!guest){
    const token=randomBytes(32).toString('base64url');guest=await guestStore.createSession({tokenHash:tokenHash(token),csrfToken:randomBytes(32).toString('base64url')});
    res.setHeader('Set-Cookie',`${guestCookie}=${token}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=86400`);
   }
   if(guest&&!await guestStore.consumeRateLimit(guest.id,'read'))throw new AuthError(429,'Previše zahteva. Sačekajte minut pa pokušajte ponovo.');
   return send(200,{enabled:!!enabled,user:s?.user??null,csrfToken:s?.csrfToken??guest?.csrfToken??null,customerReady:s?validCustomer(s.user.customerId):!!guest,guest:!!guest,guestId:guest?.id??null});
  }
  if(!enabled||!codStore)throw new AuthError(503,'Poručivanje trenutno nije omogućeno.');
  if(!s&&!guest)throw new AuthError(401,'Otvorite stranicu porudžbine da započnete kupovinu ili se prijavite.');
  if(s&&!validCustomer(s.user.customerId))throw new AuthError(409,'Ponovo se prijavite da biste povezali nalog kupca.');
  const customerId=s?.user.customerId,owner=guest?{guestId:guest.id}:customerId,csrfToken=s?.csrfToken??guest.csrfToken;
  if(!['GET','HEAD'].includes(req.method)){if(req.headers.origin!==origin||!equal(req.headers['x-csrf-token'],csrfToken))throw new AuthError(403,'Sesija ili zaštita zahteva nije važeća. Ponovo se prijavite ili osvežite stranicu.');}
  if(guest){const kind=req.method==='POST'?(p==='/api/checkout/orders'?'submit':'quote'):'read';if(!await guestStore.consumeRateLimit(guest.id,kind))throw new AuthError(429,'Previše zahteva. Sačekajte pa pokušajte ponovo.');}else limit(customerId,req.method==='POST'&&p==='/api/checkout/orders');
  if(req.method==='POST'&&p==='/api/checkout/quote'){const body=await json(req);keys(body,['items']);return send(200,await codStore.quote(owner,body.items));}
  if(req.method==='POST'&&p==='/api/checkout/orders'){const body=await json(req);keys(body,['items','contact','shippingMethod','paymentMethod','expectedTotalMinor']);const result=await codStore.createOrder({...body,...(guest?{owner}:{customerId}),idempotencyKey:req.headers['idempotency-key']});return send(result.replayed?200:201,result);}
  if(req.method==='GET'&&p==='/api/checkout/orders')return send(200,await (guest?codStore.listGuestOrders(guest.id,{before:url.searchParams.get('before')||null,limit:Number(url.searchParams.get('limit')||25)}):codStore.listCustomerOrders(customerId,{before:url.searchParams.get('before')||null,limit:Number(url.searchParams.get('limit')||25)})));
  const match=p.match(/^\/api\/checkout\/orders\/(COD-[a-f0-9-]{36})$/);if(req.method==='GET'&&match){const order=await (guest?codStore.getOwnerOrder(owner,match[1]):codStore.getCustomerOrder(customerId,match[1]));if(!order)throw new AuthError(404,'Porudžbina nije pronađena.');return send(200,{order});}
  throw new AuthError(404,'Not found.');
 },close(){limits.clear();}};
}
