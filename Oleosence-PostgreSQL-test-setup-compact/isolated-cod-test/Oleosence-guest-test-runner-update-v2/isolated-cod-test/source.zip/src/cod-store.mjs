import {randomUUID,createHash} from 'node:crypto';
import {StoreError} from './admin-store.mjs';
const reject=(status,message)=>{throw new StoreError(status,message);};
const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&[Object.prototype,null].includes(Object.getPrototypeOf(x));
function exact(value,keys){if(!plain(value)||Object.keys(value).some(k=>!keys.includes(k)))reject(400,'Nepoznata ili neispravna polja zahteva.');}
function uuid(value){if(typeof value!=='string'||! /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value))reject(400,'Potreban je potvrđen nalog kupca.');return value.toLowerCase();}
function owner(value){
 if(typeof value==='string')return {customerId:uuid(value)};
 exact(value,['customerId','guestId']);
 if(Object.keys(value).length!==1)reject(400,'Neispravan vlasnik porudžbine.');
 return Object.hasOwn(value,'customerId')?{customerId:uuid(value.customerId)}:{guestId:uuid(value.guestId)};
}
const ownerColumn=value=>Object.hasOwn(value,'guestId')?'guest_id':'customer_id';
const ownerId=value=>value.guestId??value.customerId;
function cleanText(value,label,min,max){if(typeof value!=='string'||value.trim().length<min||value.trim().length>max||/[\x00-\x1f\x7f<>]/.test(value))reject(400,'Neispravno polje: '+label+'.');return value.trim();}
function items(raw,versioned=false){
 if(!Array.isArray(raw)||raw.length<1||raw.length>20)reject(400,'Korpa mora sadržati 1–20 različitih proizvoda.');
 const seen=new Set();return raw.map(i=>{exact(i,versioned?['productId','quantity','expectedRevision']:['productId','quantity']);if(typeof i.productId!=='string'||! /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/.test(i.productId)||seen.has(i.productId)||!Number.isSafeInteger(i.quantity)||i.quantity<1||i.quantity>20||versioned&&(!Number.isSafeInteger(i.expectedRevision)||i.expectedRevision<1))reject(400,'Neispravan proizvod, količina ili verzija.');seen.add(i.productId);return {productId:i.productId,quantity:i.quantity,...(versioned?{expectedRevision:i.expectedRevision}:{})};}).sort((a,b)=>a.productId<b.productId?-1:a.productId>b.productId?1:0);
}
function normalize(input){
 exact(input,['customerId','owner','items','contact','shippingMethod','paymentMethod','expectedTotalMinor','idempotencyKey']);
 if(Object.hasOwn(input,'owner')&&Object.hasOwn(input,'customerId'))reject(400,'Neispravan vlasnik porudžbine.');
 const identity=Object.hasOwn(input,'owner')?owner(input.owner):{customerId:uuid(input.customerId)};
 if(typeof input.idempotencyKey!=='string'||! /^[a-zA-Z0-9_-]{16,100}$/.test(input.idempotencyKey))reject(400,'Nedostaje ispravan ključ zahteva.');
 if(input.shippingMethod!=='courier'||input.paymentMethod!=='cod')reject(400,'Dostupno je samo plaćanje pouzećem uz dostavu.');
 if(!Number.isSafeInteger(input.expectedTotalMinor)||input.expectedTotalMinor<0)reject(400,'Ponovo pregledajte ukupan iznos.');
 exact(input.contact,['fullName','email','phone','address','city','postalCode','country']);const c=input.contact;
 const contact={fullName:cleanText(c.fullName,'ime i prezime',2,100),email:cleanText(c.email,'email',3,254),phone:cleanText(c.phone,'telefon',6,30),address:cleanText(c.address,'adresa',3,180),city:cleanText(c.city,'grad',2,100),postalCode:cleanText(c.postalCode,'poštanski broj',5,5),country:c.country};
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.email)||!/^\+?[\d ()-]{6,30}$/.test(contact.phone)||contact.phone.replace(/\D/g,'').length<6||!/^\d{5}$/.test(contact.postalCode)||contact.country!=='RS')reject(400,'Proverite kontakt i adresu za dostavu u Srbiji.');
 // Keep the legacy customer hash shape, so pre-migration retries still replay.
 return {...identity,items:items(input.items,true),contact,shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:input.expectedTotalMinor,idempotencyKey:input.idempotencyKey};
}
const shipping=Object.freeze({method:'courier',policyVersion:'cod-rsd-flat-v1',isEstimate:false,deliveryMinor:30000,freeFromMinor:350000});
function totals(lines){const subtotalMinor=lines.reduce((s,i)=>s+i.lineTotalMinor,0);const deliveryMinor=subtotalMinor>=350000?0:30000;return {items:lines,subtotalMinor,deliveryMinor,totalMinor:subtotalMinor+deliveryMinor,currency:'RSD',shipping:{...shipping},paymentMethod:'cod'};}
function mapOrder(row,lines){return {id:row.id,customerId:row.customer_id,...(row.guest_id?{guestId:row.guest_id}:{}),status:row.status,version:row.revision,createdAt:row.created_at,currency:row.currency,contact:row.contact_snapshot,subtotalMinor:Number(row.subtotal_minor),deliveryMinor:Number(row.delivery_minor),totalMinor:Number(row.total_minor),shipping:row.shipping_snapshot,paymentMethod:row.payment_method,paymentStatus:row.payment_status,inventoryStatus:row.inventory_status,items:lines.map(i=>({productId:i.product_id,sku:i.sku_snapshot,name:i.name_snapshot,quantity:i.quantity,unitPriceMinor:Number(i.unit_price_minor),lineTotalMinor:Number(i.line_total_minor),productRevision:i.product_revision}))};}
export function createCodStore(pool){
 if(!pool||typeof pool.connect!=='function'||typeof pool.query!=='function')throw new TypeError('PostgreSQL pool required.');
 async function transaction(work){const client=await pool.connect();try{await client.query('BEGIN');const result=await work(client);await client.query('COMMIT');return result;}catch(error){try{await client.query('ROLLBACK');}catch{}throw error;}finally{client.release();}}
 async function withItems(client,row){return mapOrder(row,(await client.query('SELECT * FROM admin_order_items WHERE order_id=$1 ORDER BY line_number',[row.id])).rows);}
 async function requireOwner(client,identity,write=false){
  const guest=Object.hasOwn(identity,'guestId');
  const result=await client.query('SELECT id FROM '+(guest?'guest_checkout_sessions WHERE id=$1 AND expires_at>now()':'commerce_customers WHERE id=$1')+(write?' FOR UPDATE':''),[ownerId(identity)]);
  if(!result.rows.length)reject(guest?401:404,guest?'Sesija kupovine je istekla. Ponovo otvorite korpu.':'Nalog kupca nije pronađen.');
 }
 function orderId(id){if(typeof id!=='string'||! /^COD-[a-f0-9-]{36}$/.test(id))reject(400,'Neispravan broj porudžbine.');return id;}
 function page({before=null,limit=25}={}){if(!Number.isInteger(limit)||limit<1||limit>100||before!==null&&(typeof before!=='string'||! /^[1-9][0-9]{0,18}$/.test(before)||BigInt(before)>9223372036854775807n))reject(400,'Neispravna stranica porudžbina.');return {before,limit};}
 async function readOrder(identity,id){orderId(id);return transaction(async client=>{if(identity.guestId)await requireOwner(client,identity);const result=await client.query('SELECT * FROM admin_orders WHERE '+ownerColumn(identity)+'=$1 AND id=$2 AND model_version=2',[ownerId(identity),id]);return result.rows.length?withItems(client,result.rows[0]):null;});}
 async function listOrders(identity,options){const {before,limit}=page(options);return transaction(async client=>{if(identity.guestId)await requireOwner(client,identity);const result=await client.query('SELECT * FROM admin_orders WHERE '+ownerColumn(identity)+'=$1 AND model_version=2 AND ($2::bigint IS NULL OR sequence_id<$2::bigint) ORDER BY sequence_id DESC LIMIT $3',[ownerId(identity),before,limit+1]);const selected=result.rows.slice(0,limit),orders=[];for(const row of selected)orders.push(await withItems(client,row));return {orders,nextCursor:result.rows.length>limit?String(selected.at(-1).sequence_id):null};});}
 async function priceLines(client,list,write=false){const lines=[],locked=[];for(const item of list){const result=await client.query('SELECT id,document,revision FROM admin_products WHERE id=$1 '+(write?'FOR UPDATE':'FOR SHARE'),[item.productId]);if(!result.rows.length)reject(404,'Proizvod nije pronađen.');const p=result.rows[0],d=p.document;if(write&&p.revision!==item.expectedRevision)reject(409,'Cena ili zaliha je promenjena. Ponovo pregledajte obračun.');if(d.available!==true||!Number.isSafeInteger(d.stockQuantity)||d.stockQuantity<item.quantity)reject(409,'Proizvod nije dostupan u traženoj količini.');if(typeof d.name!=='string'||!d.name.trim()||d.name.length>120||!Number.isSafeInteger(d.priceMinor)||d.priceMinor<0||d.priceMinor>100000000)reject(409,'Cena proizvoda nije potvrđena.');lines.push({productId:p.id,name:d.name,quantity:item.quantity,unitPriceMinor:d.priceMinor,lineTotalMinor:d.priceMinor*item.quantity,productRevision:p.revision});locked.push(p);}return {lines,locked};}
 return {
  async quote(value,raw){const identity=owner(value),list=items(raw);return transaction(async client=>{await requireOwner(client,identity);return totals((await priceLines(client,list)).lines);});},
  async createOrder(input){const clean=normalize(input),hash=createHash('sha256').update(JSON.stringify(clean)).digest('hex');return transaction(async client=>{
   // Per-owner row lock plus a scoped unique key handles duplicate submissions.
   await requireOwner(client,clean,true);
   const existing=await client.query('SELECT * FROM admin_orders WHERE '+ownerColumn(clean)+'=$1 AND idempotency_key=$2 AND model_version IN (1,2)',[ownerId(clean),clean.idempotencyKey]);if(existing.rows.length){const prior=existing.rows[0];if(prior.model_version!==2||prior.request_hash!==hash)reject(409,'Ključ zahteva je već korišćen za drugačiji sadržaj.');return {order:await withItems(client,prior),replayed:true};}
   // Stable product order matches Excel import locks. No long-lived reservations.
   const {lines,locked}=await priceLines(client,clean.items,true);const q=totals(lines);if(q.totalMinor!==clean.expectedTotalMinor)reject(409,'Ukupan iznos je promenjen. Ponovo pregledajte obračun.');
   const id='COD-'+randomUUID();
   await client.query(`INSERT INTO admin_orders(id,document,status,model_version,snapshot_sealed,${ownerColumn(clean)},contact_snapshot,currency,subtotal_minor,delivery_minor,total_minor,shipping_snapshot,payment_method,payment_status,inventory_status,idempotency_key,request_hash)
    VALUES($1,$2::jsonb,'pending',2,false,$3,$4::jsonb,'RSD',$5,$6,$7,$8::jsonb,'cod','cod_due','deducted',$9,$10)`,[id,JSON.stringify({kind:'cod_order'}),ownerId(clean),JSON.stringify(clean.contact),q.subtotalMinor,q.deliveryMinor,q.totalMinor,JSON.stringify(q.shipping),clean.idempotencyKey,hash]);
   let n=0;for(const line of lines)await client.query('INSERT INTO admin_order_items(order_id,line_number,product_id,sku_snapshot,name_snapshot,quantity,unit_price_minor,line_total_minor,product_revision) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',[id,++n,line.productId,line.productId,line.name,line.quantity,line.unitPriceMinor,line.lineTotalMinor,line.productRevision]);
   for(let i=0;i<locked.length;i++){const p=locked[i],stockQuantity=p.document.stockQuantity-lines[i].quantity;const document={...p.document,stockQuantity};if(stockQuantity===0)document.available=false;await client.query('UPDATE admin_products SET document=$2::jsonb,revision=revision+1,updated_at=now() WHERE id=$1',[p.id,JSON.stringify(document)]);}
   const sealed=await client.query('UPDATE admin_orders SET snapshot_sealed=true WHERE id=$1 RETURNING *',[id]);return {order:await withItems(client,sealed.rows[0]),replayed:false};
  });},
  async getOwnerOrder(value,id){return readOrder(owner(value),id);},
  async getCustomerOrder(customerId,id){return readOrder({customerId:uuid(customerId)},id);},
  async listCustomerOrders(customerId,options){return listOrders({customerId:uuid(customerId)},options);},
  async listGuestOrders(guestId,options){return listOrders({guestId:uuid(guestId)},options);}
 };
}
