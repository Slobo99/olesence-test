import {randomBytes, createHash, timingSafeEqual} from 'node:crypto';
import {OAuth2Client} from 'google-auth-library';
export class AuthError extends Error { constructor(status, message) { super(message); this.status=status; } }
const random=()=>randomBytes(32).toString('base64url');
const hash=s=>createHash('sha256').update(s).digest('hex');
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const COOKIE='__Host-oleosence_customer';
export function readConfig(env=process.env) {
 const origin=env.CUSTOMER_AUTH_ORIGIN, clientId=env.GOOGLE_CLIENT_ID, clientSecret=env.GOOGLE_CLIENT_SECRET;
 if(env.CUSTOMER_GOOGLE_ENABLED!=='1'||!origin||!clientId||!clientSecret)return null;
 let u;try{u=new URL(origin);}catch{throw Error('Invalid CUSTOMER_AUTH_ORIGIN');}
 if(u.origin!==origin||u.username||u.password||!['http:','https:'].includes(u.protocol))throw Error('Origin must be exact, without path or credentials.');
 if(u.protocol!=='https:'&&!['127.0.0.1','localhost'].includes(u.hostname))throw Error('HTTPS required outside loopback.');
 if(!/^[a-zA-Z0-9._-]+\.apps\.googleusercontent\.com$/.test(clientId)||/placeholder|your-|example/i.test(clientId)||clientSecret.length<16||/placeholder|your-secret/i.test(clientSecret))throw Error('Real approved Google client configuration required.');
 return {origin,clientId,clientSecret,redirectUri:origin+'/auth/google/callback',secure:u.protocol==='https:'};
}
export function createGoogleProvider(config) {
 const client=new OAuth2Client({clientId:config.clientId,clientSecret:config.clientSecret,redirectUri:config.redirectUri,transporterOptions:{timeout:10000}});
 return {authorizationURL({state,nonce,verifier}) {return client.generateAuthUrl({scope:['openid','email','profile'],access_type:'online',state,nonce,code_challenge:createHash('sha256').update(verifier).digest('base64url'),code_challenge_method:'S256',prompt:'select_account'});},
 async exchange({code,verifier}) {
  const {tokens}=await client.getToken({code,codeVerifier:verifier,redirect_uri:config.redirectUri});
  if(!tokens.id_token)throw new AuthError(401,'Google did not return an identity token.');
  // Official library verifies signature against Google certificates, issuer, audience and expiry.
  const ticket=await client.verifyIdToken({idToken:tokens.id_token,audience:config.clientId});
  return ticket.getPayload(); // Access/refresh tokens are never retained or returned.
 }};
}
export function validateClaims(c,{clientId,nonce,now}) {
 if(!c||!['https://accounts.google.com','accounts.google.com'].includes(c.iss)||c.aud!==clientId||(c.azp!==undefined&&c.azp!==clientId)||!Number.isInteger(c.exp)||c.exp<=now||!Number.isInteger(c.iat)||c.iat>now+60||c.iat>c.exp||!equal(c.nonce,nonce)||typeof c.sub!=='string'||!/^[\x21-\x7e]{1,255}$/.test(c.sub)||c.email_verified!==true||typeof c.email!=='string'||c.email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email))throw new AuthError(401,'Google identity could not be verified.');
 return {id:'google:'+c.sub,provider:'google',subject:c.sub,email:c.email,name:typeof c.name==='string'?c.name.slice(0,100):'',role:'customer'};
}
export function createCustomerAuth({config=null,provider=config?createGoogleProvider(config):null,clock=Date.now,capacity=1000,resolveCustomer=null}={}) {
 if(config && !config.secure)throw Error('Hosted cookies require HTTPS.');
 const sessions=new Map(),pending=new Map();
 const cookie=(value,maxAge)=>`${COOKIE}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${config?.secure?'; Secure':''}`;
 function clean(){const now=clock();for(const map of [sessions,pending])for(const [id,value] of map)if(value.expires<=now)map.delete(id);}
 function idFrom(req){const matches=(req.headers.cookie||'').split(';').map(x=>x.trim()).filter(x=>x.startsWith(COOKIE+'='));if(matches.length!==1)return null;const id=matches[0].slice(COOKIE.length+1);return /^[\w-]{43}$/.test(id)?hash(id):null;}
 function session(req){clean();return sessions.get(idFrom(req))||null;}
 function requireConfig(){if(!config||!provider)throw new AuthError(503,'Google prijava još nije podešena.');}
 return {enabled:!!(config&&provider),session,
 start(req,res){requireConfig();clean();if(pending.size>=capacity)throw new AuthError(429,'Try again later.');const id=random(),state=random(),nonce=random(),verifier=random();const prior=idFrom(req);if(prior){pending.delete(prior);sessions.delete(prior);}pending.set(hash(id),{state,nonce,verifier,expires:clock()+300000});res.setHeader('Set-Cookie',cookie(id,300));return provider.authorizationURL({state,nonce,verifier});},
 async callback(req,res,url){requireConfig();clean();const id=idFrom(req),flow=pending.get(id);pending.delete(id);if(flow)res.setHeader('Set-Cookie',cookie('',0));
  if(!flow||url.searchParams.getAll('state').length!==1||!equal(url.searchParams.get('state'),flow.state))throw new AuthError(400,'Login expired or invalid. Please start again.');
  if(url.searchParams.has('error'))throw new AuthError(400,'Google login was cancelled. Please start again.');
  const code=url.searchParams.get('code');if(url.searchParams.getAll('code').length!==1||!code||code.length>4096)throw new AuthError(400,'Missing or invalid login code.');
  let claims;try{claims=await provider.exchange({code,verifier:flow.verifier});}catch{throw new AuthError(401,'Google identity could not be verified.');}
  const user=validateClaims(claims,{clientId:config.clientId,nonce:flow.nonce,now:Math.floor(clock()/1000)});
  if(resolveCustomer){try{const customer=await resolveCustomer(user);if(!customer||typeof customer.id!=='string'||! /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(customer.id))throw Error();user.customerId=customer.id;}catch{throw new AuthError(503,'Nalog trenutno nije moguće sačuvati. Pokušajte ponovo.');}}
  clean();if(sessions.size>=capacity)throw new AuthError(429,'Try again later.');const next=random();sessions.set(hash(next),{user,csrfToken:random(),expires:clock()+3600000});res.setHeader('Set-Cookie',cookie(next,3600));return user;
 },
 logout(req,res){const s=session(req);if(!s||!equal(req.headers['x-csrf-token'],s.csrfToken))throw new AuthError(403,'Invalid session or CSRF token.');sessions.delete(idFrom(req));res.setHeader('Set-Cookie',cookie('',0));},
 close(){sessions.clear();pending.clear();}};
}
