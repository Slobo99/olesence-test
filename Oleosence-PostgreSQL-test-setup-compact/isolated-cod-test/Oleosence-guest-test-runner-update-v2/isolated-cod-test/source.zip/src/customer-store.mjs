import {randomUUID} from 'node:crypto';
import {StoreError} from './admin-store.mjs';
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
const customer=row=>row?{id:row.id,email:row.email,name:row.name,createdAt:row.created_at,updatedAt:row.updated_at,lastLoginAt:row.last_login_at}:null;
export function readCustomerDatabaseConfig(env=process.env){const enabled=env.CUSTOMER_DATABASE_ENABLED==='1';if(enabled&&!env.DATABASE_URL)throw Error('Persistent customer storage requires DATABASE_URL.');return enabled;}
export function createCustomerStore(pool){
 return {
  // Only call after signature/audience/nonce/email verification by customer-auth.
  async upsertVerifiedGoogleUser(user){
   if(!user||user.provider!=='google'||typeof user.subject!=='string'||! /^[\x21-\x7e]{1,255}$/.test(user.subject)||user.id!=='google:'+user.subject||typeof user.email!=='string'||user.email.length>254||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)||typeof user.name!=='string'||user.name.length>100)throw new StoreError(400,'Verified identity required.');
   const {rows}=await pool.query(`INSERT INTO commerce_customers (id, provider, subject, email, name) VALUES ($1, 'google', $2, $3, $4)
    ON CONFLICT(provider,subject) DO UPDATE SET email=EXCLUDED.email,name=EXCLUDED.name,updated_at=now(),last_login_at=now()
    RETURNING id,email,name,created_at,updated_at,last_login_at`,[randomUUID(),user.subject,user.email,user.name]);
   return customer(rows[0]);
  },
  async getCustomer(id){if(typeof id!=='string'||!uuid.test(id))throw new StoreError(400,'Invalid customer ID.');const {rows}=await pool.query('SELECT id,email,name,created_at,updated_at,last_login_at FROM commerce_customers WHERE id=$1',[id]);return customer(rows[0]);},
  async listCustomers({before,limit=50}={}){
   if(!Number.isInteger(limit)||limit<1||limit>100||(before!==undefined&&(typeof before!=='string'||! /^[1-9][0-9]{0,18}$/.test(before)||BigInt(before)>9223372036854775807n)))throw new StoreError(400,'Invalid customer page.');
   const {rows}=await pool.query('SELECT sequence_id,id,email,name,created_at,updated_at,last_login_at FROM commerce_customers WHERE ($1::bigint IS NULL OR sequence_id < $1::bigint) ORDER BY sequence_id DESC LIMIT $2',[before??null,limit+1]);
   const chosen=rows.slice(0,limit);return {customers:chosen.map(customer),nextCursor:rows.length>limit?String(chosen.at(-1).sequence_id):null};
  }
 };
}
