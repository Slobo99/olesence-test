import {randomUUID,createHash} from 'node:crypto';
import {StoreError} from './admin-store.mjs';
const reject=(status,message)=>{throw new StoreError(status,message);};
const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x)&&[Object.prototype,null].includes(Object.getPrototypeOf(x));
function exact(value,keys){if(!plain(value)||Object.keys(value).some(k=>!keys.includes(k)))reject(400,'Unknown or invalid order fields.');}
function uuid(value){if(typeof value!=='string'||! /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value))reject(400,'Valid server-resolved customer ID required.');return value.toLowerCase();}
function cleanText(value,label,min,max){if(typeof value!=='string'||value.trim().length<min||value.trim().length>max||/[\x00-\x1f\x7f<>]/.test(value))reject(400,'Invalid '+label+'.');return value.trim();}
function normalize(input){
 exact(input,['customerId','items','contact','shippingMethod','idempotencyKey']);
 const customerId=uuid(input.customerId);
 if(typeof input.idempotencyKey!=='string'||! /^[a-zA-Z0-9_-]{16,100}$/.test(input.idempotencyKey))reject(400,'Valid idempotency key required.');
 if(input.shippingMethod!=='delivery-estimate')reject(400,'Only an explicitly estimated delivery draft is supported.');
 if(!Array.isArray(input.items)||input.items.length<1||input.items.length>20)reject(400,'Draft requires 1–20 distinct products.');
 const seen=new Set();const items=input.items.map(item=>{
  exact(item,['productId','quantity','expectedRevision']);
  if(typeof item.productId!=='string'||! /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/.test(item.productId)||seen.has(item.productId)||!Number.isSafeInteger(item.quantity)||item.quantity<1||item.quantity>20||!Number.isSafeInteger(item.expectedRevision)||item.expectedRevision<1)reject(400,'Invalid product, quantity or revision.');
  seen.add(item.productId);return {productId:item.productId,quantity:item.quantity,expectedRevision:item.expectedRevision};
 }).sort((a,b)=>a.productId<b.productId?-1:a.productId>b.productId?1:0);
 exact(input.contact,['fullName','email','phone','address','city','postalCode','country']);const c=input.contact;
 const contact={fullName:cleanText(c.fullName,'name',2,100),email:cleanText(c.email,'email',3,254),phone:cleanText(c.phone,'phone',6,30),address:cleanText(c.address,'address',3,180),city:cleanText(c.city,'city',2,100),postalCode:cleanText(c.postalCode,'postal code',5,5),country:c.country};
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.email)||!/^\+?[\d ()-]{6,30}$/.test(contact.phone)||contact.phone.replace(/\D/g,'').length<6||!/^\d{5}$/.test(contact.postalCode)||contact.country!=='RS')reject(400,'Invalid contact or Serbian delivery address.');
 return {customerId,items,contact,shippingMethod:input.shippingMethod,idempotencyKey:input.idempotencyKey};
}
function mapOrder(row,items){return {id:row.id,customerId:row.customer_id,status:row.status,version:row.revision,createdAt:row.created_at,currency:row.currency,contact:row.contact_snapshot,subtotalMinor:Number(row.subtotal_minor),deliveryMinor:Number(row.delivery_minor),totalMinor:Number(row.total_minor),shipping:row.shipping_snapshot,paymentStatus:row.payment_status,inventoryStatus:row.inventory_status,items:items.map(i=>({productId:i.product_id,sku:i.sku_snapshot,name:i.name_snapshot,quantity:i.quantity,unitPriceMinor:Number(i.unit_price_minor),lineTotalMinor:Number(i.line_total_minor),productRevision:i.product_revision}))};}
export function createOrderStore(pool,{allowDraftCreation=false}={}){
 if(!pool||typeof pool.connect!=='function'||typeof pool.query!=='function')throw new TypeError('PostgreSQL pool required.');
 async function transaction(work){const client=await pool.connect();try{await client.query('BEGIN');const result=await work(client);await client.query('COMMIT');return result;}catch(error){try{await client.query('ROLLBACK');}catch{}throw error;}finally{client.release();}}
 async function withItems(client,row){const result=await client.query('SELECT * FROM admin_order_items WHERE order_id=$1 ORDER BY line_number',[row.id]);return mapOrder(row,result.rows);}
 return {
  // Internal foundation only, never exposed by an HTTP route. A draft neither
  // promises stock nor reserves it. Customer ID MUST come from verified session.
  async createDraftOrder(input){
   if(!allowDraftCreation)reject(503,'Order creation is disabled until checkout and inventory reconciliation are implemented.');
   const clean=normalize(input);const hash=createHash('sha256').update(JSON.stringify(clean)).digest('hex');
   return transaction(async client=>{
    // Serialize same-customer submissions, including a first-seen duplicate key.
    const customer=await client.query('SELECT id FROM commerce_customers WHERE id=$1 FOR UPDATE',[clean.customerId]);
    if(!customer.rows.length)reject(404,'Customer not found.');
    const existing=await client.query('SELECT * FROM admin_orders WHERE customer_id=$1 AND idempotency_key=$2 AND model_version=1',[clean.customerId,clean.idempotencyKey]);
    if(existing.rows.length){if(existing.rows[0].request_hash!==hash)reject(409,'Idempotency key belongs to different content.');return {order:await withItems(client,existing.rows[0]),replayed:true};}
    const lines=[];let subtotal=0;
    for(const item of clean.items){
     const result=await client.query('SELECT id,document,revision FROM admin_products WHERE id=$1 FOR SHARE',[item.productId]);
     if(!result.rows.length)reject(404,'Product not found.');const p=result.rows[0];
     if(p.revision!==item.expectedRevision)reject(409,'Product changed; review a fresh quote.');
     if(typeof p.document.name!=='string'||!p.document.name.trim()||p.document.name.length>120||!Number.isSafeInteger(p.document.priceMinor)||p.document.priceMinor<0||p.document.priceMinor>100000000)reject(409,'Product price or name is not ready.');
     const line={productId:p.id,sku:p.id,name:p.document.name,quantity:item.quantity,unitPriceMinor:p.document.priceMinor,lineTotalMinor:p.document.priceMinor*item.quantity,productRevision:p.revision};
     subtotal+=line.lineTotalMinor;lines.push(line);
    }
    const delivery=subtotal>=350000?0:30000;
    const shipping={method:'delivery-estimate',policyVersion:'rsd-one-package-v1',estimatedPackages:1,isEstimate:true,perPackageMinor:30000,freeFromMinor:350000};
    const id='DRAFT-'+randomUUID();
    const result=await client.query(`INSERT INTO admin_orders(id,document,status,model_version,snapshot_sealed,customer_id,contact_snapshot,currency,subtotal_minor,delivery_minor,total_minor,shipping_snapshot,payment_status,inventory_status,idempotency_key,request_hash)
     VALUES($1,$2::jsonb,'draft',1,false,$3,$4::jsonb,'RSD',$5,$6,$7,$8::jsonb,'not_processed','unreserved',$9,$10) RETURNING *`,[id,JSON.stringify({kind:'unreserved_draft'}),clean.customerId,JSON.stringify(clean.contact),subtotal,delivery,subtotal+delivery,JSON.stringify(shipping),clean.idempotencyKey,hash]);
    let n=0;for(const line of lines)await client.query('INSERT INTO admin_order_items(order_id,line_number,product_id,sku_snapshot,name_snapshot,quantity,unit_price_minor,line_total_minor,product_revision) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',[id,++n,line.productId,line.sku,line.name,line.quantity,line.unitPriceMinor,line.lineTotalMinor,line.productRevision]);
    const sealed=await client.query('UPDATE admin_orders SET snapshot_sealed=true WHERE id=$1 RETURNING *',[id]);
    return {order:await withItems(client,sealed.rows[0]),replayed:false};
   });
  },
  async getCustomerOrder(customerId,id){uuid(customerId);if(typeof id!=='string'||id.length>128)reject(400,'Invalid order ID.');const result=await pool.query('SELECT * FROM admin_orders WHERE customer_id=$1 AND id=$2 AND model_version=1',[customerId,id]);if(!result.rows.length)return null;return withItems(pool,result.rows[0]);},
  async listCustomerOrders(customerId,{before=null,limit=25}={}){
   uuid(customerId);if(!Number.isInteger(limit)||limit<1||limit>100||before!==null&&(typeof before!=='string'||! /^[1-9][0-9]{0,18}$/.test(before)||BigInt(before)>9223372036854775807n))reject(400,'Invalid history pagination.');
   const result=await pool.query('SELECT * FROM admin_orders WHERE customer_id=$1 AND model_version=1 AND ($2::bigint IS NULL OR sequence_id<$2::bigint) ORDER BY sequence_id DESC LIMIT $3',[customerId,before,limit+1]);const selected=result.rows.slice(0,limit);const orders=[];for(const row of selected)orders.push(await withItems(pool,row));return {orders,nextCursor:result.rows.length>limit?String(selected.at(-1).sequence_id):null};
  }
 };
}
