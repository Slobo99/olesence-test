import sharp from 'sharp';
import {createHash} from 'node:crypto';
import {parentPort,workerData} from 'node:worker_threads';
import {inspectProductImage} from './product-image.mjs';
sharp.cache(false);sharp.concurrency(1);
try{
 const bytes=Buffer.from(workerData.bytes),header=inspectProductImage(bytes,workerData.mime);
 const pipeline=sharp(bytes,{failOn:'warning',limitInputPixels:12000000,limitInputChannels:4,sequentialRead:true,ignoreIcc:true});
 const metadata=await pipeline.metadata();
 if(metadata.format!==header.format||metadata.width!==header.width||metadata.height!==header.height||(metadata.pages&&metadata.pages!==1))throw Error();
 const {data,info}=await pipeline.rotate().resize({width:1600,height:1600,fit:'inside',withoutEnlargement:true}).flatten({background:'#ffffff'}).jpeg({quality:85,chromaSubsampling:'4:2:0'}).timeout({seconds:5}).toBuffer({resolveWithObject:true});
 if(data.length>1572864||info.width>1600||info.height>1600)throw Error();
 parentPort.postMessage({image:{hash:createHash('sha256').update(data).digest('hex'),bytes:data,width:info.width,height:info.height,mime:'image/jpeg'}});
}catch{parentPort.postMessage({error:true});}
