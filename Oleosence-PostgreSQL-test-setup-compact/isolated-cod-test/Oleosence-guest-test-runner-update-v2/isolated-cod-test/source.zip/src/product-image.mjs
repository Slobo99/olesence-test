import {Worker} from 'node:worker_threads';
import {AuthError} from './customer-auth.mjs';
export const MAX_IMAGE_BYTES=3*1024*1024;
const fail=()=>{throw new AuthError(422,'Izaberite ispravnu JPEG ili PNG fotografiju do 3 MB i 12 megapiksela. Animacije nisu podržane.');};
function dimensions(width,height){if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>8192||height>8192||width*height>12000000)fail();return {width,height};}
export function inspectProductImage(bytes,mime){
 if(!Buffer.isBuffer(bytes)||!bytes.length||bytes.length>MAX_IMAGE_BYTES)fail();
 if(mime==='image/png'){
  if(bytes.length<45||bytes.subarray(0,8).toString('hex')!=='89504e470d0a1a0a')fail();
  let pos=8,info=null,ended=false,chunks=0;
  while(pos+12<=bytes.length){const size=bytes.readUInt32BE(pos),type=bytes.subarray(pos+4,pos+8).toString('ascii');if(size>MAX_IMAGE_BYTES||pos+12+size>bytes.length||++chunks>10000)fail();
   if(!info){if(type!=='IHDR'||size!==13)fail();info=dimensions(bytes.readUInt32BE(pos+8),bytes.readUInt32BE(pos+12));}
   if(['acTL','fcTL','fdAT'].includes(type))fail();
   pos+=12+size;if(type==='IEND'){if(size!==0||pos!==bytes.length)fail();ended=true;break;}
  }
  if(!ended||!info)fail();return {...info,format:'png'};
 }
 if(mime==='image/jpeg'){
  if(bytes.length<4||bytes[0]!==255||bytes[1]!==216)fail();let pos=2,info=null,segments=0;
  while(pos<bytes.length){if(bytes[pos++]!==255)fail();while(bytes[pos]===255)pos++;const marker=bytes[pos++];if(marker===0xda){if(!info)fail();return {...info,format:'jpeg'};}if(marker===0xd9)break;if(marker===0x01||(marker>=0xd0&&marker<=0xd7))continue;if(pos+2>bytes.length||++segments>10000)fail();const length=bytes.readUInt16BE(pos);if(length<2||pos+length>bytes.length)fail();
   if([0xc0,0xc2].includes(marker)){if(info||length<8)fail();info=dimensions(bytes.readUInt16BE(pos+5),bytes.readUInt16BE(pos+3));}
   else if(marker>=0xc0&&marker<=0xcf&&![0xc4,0xc8,0xcc].includes(marker))fail();
   pos+=length;
  }fail();
 }
 fail();
}
export async function sanitizeProductImage(bytes,mime){
 inspectProductImage(bytes,mime);
 return new Promise((resolve,reject)=>{
  let worker;try{worker=new Worker(new URL('./product-image-worker.mjs',import.meta.url),{workerData:{bytes,mime},execArgv:[],resourceLimits:{maxOldGenerationSizeMb:64,maxYoungGenerationSizeMb:16}});}catch{reject(new AuthError(503,'Obrada slike trenutno nije dostupna.'));return;}
  let settled=false;const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);void worker.terminate();error?reject(new AuthError(422,'Slika nije prihvaćena. Proverite format, veličinu i dimenzije.')):resolve({...value,bytes:Buffer.from(value.bytes)});};
  const timer=setTimeout(()=>finish(true),7000);worker.once('message',message=>finish(message.error,message.image));worker.once('error',()=>finish(true));worker.once('exit',()=>finish(true));
 });
}
