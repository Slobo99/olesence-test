export const reportWarehouses=Object.freeze(['Magacin Bio Prodavnica B2C']);
export const reportIdentifiers=Object.freeze({O001:'divlji-origano',O002:'cetiri-lopova',O003:'crni-kim'});
export function parseStockReport(grid){
 if(!Array.isArray(grid)||grid.length>1000)throw Error('Izveštaj ima previše redova.');
 const clean=value=>typeof value==='string'?value.trim():value;
 const header=grid.findIndex(row=>clean(row?.[0])==='Ident'&&clean(row?.[2])==='Naziv'&&clean(row?.[9])==='Zaliha'&&clean(row?.[12])==='JM');
 if(header<0)throw Error('Nepoznat raspored izveštaja. Očekuju se Ident, Naziv, Zaliha i JM.');
 const found=new Map(),seen=new Set(),warehouses=new Set();let warehouse=null;
 for(let i=header+1;i<grid.length;i++){
  const row=grid[i]||[],ident=clean(row[0]);
  if(ident==='Skladište:'){warehouse=clean(row[1]);if(typeof warehouse!=='string'||!warehouse||warehouse.length>200||/[\x00-\x1f]/.test(warehouse))throw Error(`Red ${i+1}: neispravan naziv magacina.`);if(warehouses.has(warehouse))throw Error(`Red ${i+1}: ponovljena sekcija magacina.`);warehouses.add(warehouse);continue;}
  if(ident===null||ident===undefined||ident===''){if(['UKUPNO skladište','UKUPNO sve'].includes(clean(row[2]))&&(row[9]===null||row[9]===undefined)&&(row[12]===null||row[12]===undefined))continue;if(typeof row[9]==='string'&&/^[1-9][0-9]{0,2}\/[1-9][0-9]{0,2}$/.test(row[9])&&clean(row[7])==='Strana'&&row.every((v,n)=>n===7||n===9||v===null||v===undefined||v===''))continue;if([row[2],row[9],row[12]].some(v=>v!==null&&v!==undefined&&v!==''))throw Error(`Red ${i+1}: proizvod nema identifikator.`);continue;}
  if(typeof ident!=='string'||!ident||ident.length>100||(warehouse===reportWarehouses[0]&&!Object.hasOwn(reportIdentifiers,ident)))throw Error(`Red ${i+1}: nepoznat identifikator.`);
  if(!warehouse)throw Error(`Red ${i+1}: proizvod nije u sekciji magacina.`);
  if(typeof row[2]!=='string'||!row[2].trim())throw Error(`Red ${i+1}: nedostaje naziv proizvoda.`);
  if(clean(row[12])!=='KOM')throw Error(`Red ${i+1}: očekuje se jedinica KOM.`);
  const quantity=row[9];if(!Number.isSafeInteger(quantity)||quantity<0||quantity>1000000)throw Error(`Red ${i+1}: količina mora biti ceo broj 0–1000000.`);
  const key=warehouse+'|'+ident;if(seen.has(key))throw Error(`Red ${i+1}: ponovljen identifikator u istom magacinu.`);seen.add(key);
  if(warehouse!==reportWarehouses[0])continue;
  const id=reportIdentifiers[ident],existing=found.get(id)||{id,stockQuantity:0,sourceIdent:ident,warehouseQuantities:[]};existing.stockQuantity+=quantity;if(existing.stockQuantity>1000000)throw Error(`Red ${i+1}: zbir prelazi dozvoljenu količinu.`);existing.warehouseQuantities.push({warehouse,quantity});found.set(id,existing);
 }
 if(!warehouses.has(reportWarehouses[0]))throw Error('Nedostaje obavezni magacin Magacin Bio Prodavnica B2C.');
 if(!found.size)throw Error('Izveštaj nema prepoznate proizvode.');
 const excludedWarehouses=[...warehouses].filter(w=>w!==reportWarehouses[0]);
 return [...found.values()].map(row=>({...row,excludedWarehouses}));
}
