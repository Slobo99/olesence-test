import {inflateRawSync} from 'node:zlib';
import {Worker} from 'node:worker_threads';
import {inspectLegacyWorkbook} from './xls-preflight.mjs';
import {AuthError} from './customer-auth.mjs';
// Inspect ZIP directory before decompression. Reject macros, external links and bombs.
export function inspectWorkbookZip(bytes){
 if(!Buffer.isBuffer(bytes)||bytes.length<22||bytes.length>1048576)throw new AuthError(422,'Neispravna .xlsx datoteka (najviše 1 MB).');
 let e=-1;for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(bytes.readUInt32LE(i)===0x06054b50){e=i;break;}
 if(e<0||bytes.readUInt16LE(e+4)||bytes.readUInt16LE(e+6)||bytes.readUInt16LE(e+8)!==bytes.readUInt16LE(e+10))throw new AuthError(422,'Nepodržan XLSX arhiv.');
 const count=bytes.readUInt16LE(e+10),size=bytes.readUInt32LE(e+12),offset=bytes.readUInt32LE(e+16);
 if(!count||count>100||offset+size!==e)throw new AuthError(422,'Previše sadržaja u radnoj svesci.');
 let pos=offset,total=0;const names=new Set();
 for(let i=0;i<count;i++){
  if(pos+46>e||bytes.readUInt32LE(pos)!==0x02014b50)throw new AuthError(422,'Oštećena .xlsx datoteka.');
  const flags=bytes.readUInt16LE(pos+8),method=bytes.readUInt16LE(pos+10),compressed=bytes.readUInt32LE(pos+20),expanded=bytes.readUInt32LE(pos+24),len=bytes.readUInt16LE(pos+28),extra=bytes.readUInt16LE(pos+30),comment=bytes.readUInt16LE(pos+32);
  const name=bytes.subarray(pos+46,pos+46+len).toString('utf8');total+=expanded;
  if(flags&1||![0,8].includes(method)||total>5242880||expanded>2097152||expanded>Math.max(65536,compressed*100)||names.has(name)||/vba|externalLinks|\.\.|^\//i.test(name))throw new AuthError(422,'Nepodržan ili prevelik sadržaj radne sveske.');
  const local=bytes.readUInt32LE(pos+42);
  if(local+30>offset||bytes.readUInt32LE(local)!==0x04034b50)throw new AuthError(422,'Oštećena lokalna ZIP stavka.');
  const localNameLength=bytes.readUInt16LE(local+26),localExtraLength=bytes.readUInt16LE(local+28),start=local+30+localNameLength+localExtraLength;
  if(start+compressed>offset||bytes.readUInt16LE(local+8)!==method||bytes.subarray(local+30,local+30+localNameLength).toString('utf8')!==name)throw new AuthError(422,'Neusklađene ZIP stavke.');
  try{const raw=bytes.subarray(start,start+compressed),decoded=method===0?raw:inflateRawSync(raw,{maxOutputLength:Math.max(1,expanded)});if(decoded.length!==expanded)throw Error();}catch{throw new AuthError(422,'Oštećen ili prevelik raspakovan sadržaj.');}
  names.add(name);pos+=46+len+extra+comment;if(pos>e)throw new AuthError(422,'Oštećena arhiva.');
 }
 if(pos!==e||!names.has('xl/workbook.xml'))throw new AuthError(422,'Potreban je XLSX format.');
}
let activeParsers=0;
export async function parseStockWorkbook(bytes){if(activeParsers>=2)throw new AuthError(429,'Obrada je zauzeta. Pokušajte ponovo.');const format=bytes.subarray(0,8).toString('hex')==='d0cf11e0a1b11ae1'?'xls':'xlsx';if(format==='xls')inspectLegacyWorkbook(bytes);else inspectWorkbookZip(bytes);activeParsers++;return new Promise((resolve,reject)=>{
 let worker;try{worker=new Worker(new URL('./stock-worker.mjs',import.meta.url),{workerData:{bytes,format},execArgv:[],resourceLimits:{maxOldGenerationSizeMb:64,maxYoungGenerationSizeMb:16}});}catch{activeParsers--;reject(new AuthError(503,'Obrada trenutno nije dostupna.'));return;}
 let settled=false;const finish=(error,value)=>{if(settled)return;settled=true;activeParsers--;clearTimeout(timer);void worker.terminate();error?reject(new AuthError(422,error)):resolve(value);};
 const timer=setTimeout(()=>finish('Obrada datoteke je trajala predugo.'),5000);
 worker.once('message',m=>finish(m.error,m.rows));worker.once('error',()=>finish('Datoteka nije mogla da se obradi.'));worker.once('exit',()=>finish('Obrada datoteke nije uspela.'));
});}
