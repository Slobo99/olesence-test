import ExcelJS from 'exceljs';
import * as XLSX from 'xlsx';
import {parseStockReport} from './report-import.mjs';
import {parentPort,workerData} from 'node:worker_threads';
try{
 if(workerData.format==='xls'){
 const book=XLSX.read(Buffer.from(workerData.bytes),{type:'buffer',dense:false,cellFormula:true,cellHTML:false,cellStyles:false,sheetRows:1000,bookVBA:true});
 if(book.vbaraw||book.SheetNames.length!==1)throw Error('Očekuje se jedan list bez makroa.');
 const sheet=book.Sheets[book.SheetNames[0]],range=XLSX.utils.decode_range(sheet['!ref']||'A1');if(range.e.r>=1000||range.e.c>=32)throw Error('Prevelik izveštaj.');
 for(const [key,cell]of Object.entries(sheet))if(!key.startsWith('!')&&(cell.f||cell.l||cell.t==='e'))throw Error('Formule i greške nisu dozvoljene.');
 const grid=XLSX.utils.sheet_to_json(sheet,{header:1,raw:true,defval:null,blankrows:true,range:0});parentPort.postMessage({rows:parseStockReport(grid)});
 }else{
 const workbook=new ExcelJS.Workbook();await workbook.xlsx.load(Buffer.from(workerData.bytes));
 if(workbook.worksheets.length>5)throw Error('Previše listova.');
 for(const tab of workbook.worksheets){if(tab.rowCount>1000||tab.columnCount>32)throw Error('Prevelik list.');tab.eachRow(row=>row.eachCell(cell=>{if(cell.value&&typeof cell.value==='object')throw Error('Formule, veze i posebne ćelije nisu dozvoljeni.');}));}
 const sheet=workbook.getWorksheet('Zalihe')||workbook.worksheets[0];
 if(!sheet||sheet.rowCount>501||sheet.columnCount>2)throw Error('Najviše 500 redova i dve kolone: SKU i availableQuantity.');
 if(sheet.getCell('A1').value!=='SKU'||sheet.getCell('B1').value!=='availableQuantity')throw Error('Prvi red mora biti SKU i availableQuantity.');
 const rows=[],seen=new Set();
 for(let n=2;n<=sheet.rowCount;n++){
  const id=sheet.getCell(n,1).value,stockQuantity=sheet.getCell(n,2).value;
  if(id===null&&stockQuantity===null)continue;
  if(typeof id!=='string'||! /^[a-z0-9-]{1,100}$/.test(id)||seen.has(id))throw Error(`Red ${n}: neispravan ili ponovljen SKU.`);
  if(!Number.isSafeInteger(stockQuantity)||stockQuantity<0||stockQuantity>1000000)throw Error(`Red ${n}: količina mora biti ceo broj od 0 do 1000000. Prazna polja i formule nisu dozvoljeni.`);
  seen.add(id);rows.push({id,stockQuantity});
 }
 if(!rows.length)throw Error('Datoteka nema popunjene količine.');
 parentPort.postMessage({rows});
 }
}catch(e){parentPort.postMessage({error:/^(Red |Prvi red|Najviše|Datoteka nema|Očekuje se|Prevelik|Formule|Izveštaj|Nepoznat raspored|Nedostaje jedan)/.test(e.message||'')?e.message.slice(0,240):'Neispravna ili nepodržana Excel datoteka.'});}
