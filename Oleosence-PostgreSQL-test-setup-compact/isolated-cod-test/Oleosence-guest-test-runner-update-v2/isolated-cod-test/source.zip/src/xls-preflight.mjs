import {AuthError} from './customer-auth.mjs';
const fail=()=>{throw new AuthError(422,'Neispravan ili nepodržan XLS izveštaj. Koristite originalni izvoz bez formula, makroa i spoljnih veza.');};
// Narrow, bounded CFB reader used only to validate and inspect uncompressed BIFF8.
export function inspectLegacyWorkbook(bytes){
 if(!Buffer.isBuffer(bytes)||bytes.length<512||bytes.length>1048576||bytes.subarray(0,8).toString('hex')!=='d0cf11e0a1b11ae1')fail();
 const major=bytes.readUInt16LE(26),shift=bytes.readUInt16LE(30),sectorSize=2**shift;
 if(bytes.readUInt16LE(28)!==0xfffe||!((major===3&&shift===9)||(major===4&&shift===12))||bytes.readUInt16LE(32)!==6||bytes.readUInt32LE(56)!==4096||bytes.readUInt32LE(72)!==0||bytes.length%sectorSize)fail();
 const count=bytes.length/sectorSize-1,END=0xfffffffe,FREE=0xffffffff;
 const sector=n=>{if(!Number.isInteger(n)||n<0||n>=count)fail();return bytes.subarray((n+1)*sectorSize,(n+2)*sectorSize);};
 const fatCount=bytes.readUInt32LE(44);if(!fatCount||fatCount>109||fatCount>count)fail();const fat=[],fatIds=new Set();
 for(let i=0;i<fatCount;i++){const id=bytes.readUInt32LE(76+4*i);if(fatIds.has(id))fail();fatIds.add(id);const b=sector(id);for(let j=0;j<sectorSize;j+=4)fat.push(b.readUInt32LE(j));}
 const chain=(start,table,read,max,expected=null)=>{const visited=new Set(),parts=[];let at=start;while(at!==END){if(at===FREE||visited.has(at)||visited.size>=max||at>=table.length)fail();visited.add(at);parts.push(read(at));at=table[at];}const result=Buffer.concat(parts);if(expected!==null&&(result.length<expected||result.length-expected>=parts[0]?.length))fail();return expected===null?result:result.subarray(0,expected);};
 const dir=chain(bytes.readUInt32LE(48),fat,sector,count);if(dir.length>131072)fail();const entries=[];
 for(let i=0;i<dir.length;i+=128){const type=dir[i+66];if(!type)continue;const n=dir.readUInt16LE(i+64);if(n<2||n>64||n%2)fail();const name=dir.subarray(i,i+n-2).toString('utf16le');if(/vba|project|encrypted|encryption|objectpool/i.test(name))fail();const size=Number(dir.readBigUInt64LE(i+120));if(!Number.isSafeInteger(size)||size>1048576)fail();entries.push({name,type,size,start:dir.readUInt32LE(i+116)});}
 if(entries.length>100||entries.reduce((sum,e)=>sum+(e.type===2?e.size:0),0)>5242880)fail();
 const roots=entries.filter(e=>e.type===5),books=entries.filter(e=>e.type===2&&['Workbook','Book'].includes(e.name));if(roots.length!==1||books.length!==1)fail();
 const miniFatCount=bytes.readUInt32LE(64);if(miniFatCount>count)fail();let miniFat=[],miniStream=Buffer.alloc(0);
 if(miniFatCount){const miniBytes=chain(bytes.readUInt32LE(60),fat,sector,count,miniFatCount*sectorSize);for(let i=0;i<miniBytes.length;i+=4)miniFat.push(miniBytes.readUInt32LE(i));miniStream=chain(roots[0].start,fat,sector,count,roots[0].size);}
 const readEntry=e=>e.size===0?Buffer.alloc(0):e.size>=4096?chain(e.start,fat,sector,count,e.size):chain(e.start,miniFat,n=>{if((n+1)*64>miniStream.length)fail();return miniStream.subarray(n*64,(n+1)*64);},Math.ceil(miniStream.length/64),e.size);
 for(const e of entries.filter(e=>e.type===2))readEntry(e); // Every stream chain is bounded, including unused streams.
 const workbook=readEntry(books[0]);let pos=0,records=0;
 while(pos<workbook.length){if(pos+4>workbook.length)fail();const id=workbook.readUInt16LE(pos),len=workbook.readUInt16LE(pos+2);pos+=4;if(len>8224||pos+len>workbook.length||++records>20000)fail();
  if([0x0006,0x0206,0x0406,0x002f,0x01ae,0x0017,0x0023,0x0018,0x01b8,0x0800].includes(id))fail();
  if(id===0x0200&&len>=14){const lastRow=workbook.readUInt32LE(pos+4),lastCol=workbook.readUInt16LE(pos+10);if(lastRow>1000||lastCol>32)fail();}
  if(id===0x0809&&(len<4||workbook.readUInt16LE(pos)!==0x0600))fail();
  pos+=len;
 }
 return true;
}
