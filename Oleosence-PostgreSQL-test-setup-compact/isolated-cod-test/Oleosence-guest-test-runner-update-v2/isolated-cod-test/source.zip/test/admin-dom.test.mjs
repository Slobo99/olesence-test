import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
import {products as catalog} from '../public/catalog.js';
const html=await readFile(new URL('../public/admin.html',import.meta.url),'utf8');
const source=(await readFile(new URL('../public/admin.js',import.meta.url),'utf8')).replaceAll('export function ','function ');
const response=(json,status=200)=>({ok:status>=200&&status<300,status,json:async()=>json});
const until=async(predicate,message='Condition timed out')=>{for(let i=0;i<200;i++){if(predicate())return;await new Promise(r=>setTimeout(r,5));}assert.fail(message);};
async function fixture(t){
 const dom=new JSDOM(html,{url:'https://admin.example.test/admin',runScripts:'outside-only'});const w=dom.window;await new Promise(r=>w.addEventListener('load',r,{once:true}));
 const data={products:catalog.map(p=>({...p,stockQuantity:null,available:false,version:1})),patches:[],gets:[],deny:false,delay:null,conflict:false,imports:[],previewRows:[{id:'crni-kim',name:'Ulje crnog kima',oldQuantity:null,stockQuantity:10,version:1,sourceIdent:'ORIGINAL-SKU',warehouseQuantities:[{warehouse:'Magacin Bio Prodavnica B2C',quantity:10}]}]};
 w.confirm=()=>true;w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(value=''){this.returnValue=value;this.open=false;this.dispatchEvent(new w.Event('close'));};
 w.fetch=async(path,options={})=>{
  if(data.deny)return response({},401);
  if(path==='/admin/api/stock/preview'){data.imports.push({path,options});return response({previewToken:'preview-token',rows:data.previewRows,warnings:data.previewWarnings||[],expiresAt:Date.now()+300000});}
  if(path==='/admin/api/stock/apply'){data.imports.push({path,options});return response({products:data.products});}
  if(path==='/admin/api/session'&&data.sessionDelay)return data.sessionDelay;
  if(path==='/admin/api/session')return response({user:{email:'admin@example.test'},csrfToken:'test-csrf',capabilities:{customers:!!data.customersEnabled}});
  if(options.method==='PATCH'){const body=JSON.parse(options.body);data.patches.push({path,body,headers:options.headers});if(data.patchDelay)return data.patchDelay;if(data.conflict)return response({},409);data.products=data.products.map(p=>p.id===path.split('/').at(-1)?{...p,...body,version:p.version+1}:p);return response({product:data.products[0]});}
  data.gets.push(path);if(data.delay){const pending=data.delay;data.delay=null;return pending;}
  if(path.startsWith('/admin/api/products'))return response({products:data.products});
  if(path.startsWith('/admin/api/customers'))return response({customers:data.customerRows||[],nextCursor:null});
  if(path.startsWith('/admin/api/orders'))return response({orders:[],nextCursor:null});
  if(path.startsWith('/admin/api/audit'))return response({entries:[],nextCursor:null});
  throw Error(`Unexpected request: ${path}`);
 };
 vm.runInContext(source,dom.getInternalVMContext());w.dispatchEvent(new w.Event('pageshow'));
 await until(()=>w.document.querySelectorAll('.product-card').length===3);
 t.after(()=>w.close());
 const $=selector=>w.document.querySelector(selector);
 const edit=(selector,value)=>{const input=$(selector);input.value=value;input.dispatchEvent(new w.Event('input',{bubbles:true}));};
 const submit=index=>w.document.querySelectorAll('.product-card')[index].dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
 const close=value=>$('#confirm').close(value);
 return {w,data,$,edit,submit,close};
}
test('DOM: cancel does not save; repeated clicks cannot submit twice; success waits for server',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);
 edit('.product-card [name="price"]','1290,45');submit(0);assert.equal($('#confirm').open,true);assert.equal($('.product-card button[type="submit"]').disabled,true);submit(0);assert.equal(data.patches.length,0);close('cancel');await until(()=>!$('.product-card button[type="submit"]').disabled);assert.equal(data.patches.length,0);
 submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(data.patches.length,1);assert.equal(data.patches[0].body.priceMinor,129045);assert.equal(data.patches[0].headers['X-CSRF-Token'],'test-csrf');assert.equal($('.product-card [name="price"]').value,'1290,45');
});
test('DOM: saving one product preserves another draft and its original version',async t=>{
 const {data,$,edit,submit,close,w}=await fixture(t);
 edit('.product-card:nth-child(1) [name="name"]','Prvi novi naziv');edit('.product-card:nth-child(2) [name="name"]','Drugi nesačuvan naziv');
 data.products[1]={...data.products[1],version:8,name:'Novije serversko ime'};
 submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal($('.product-card:nth-child(2) [name="name"]').value,'Drugi nesačuvan naziv');assert.match($('.product-card:nth-child(2) header').textContent,/Verzija 1/);
 const unload=new w.Event('beforeunload',{cancelable:true});w.dispatchEvent(unload);assert.equal(unload.defaultPrevented,true);
 data.conflict=true;submit(1);close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal(data.patches[1].body.version,1);assert.equal($('.product-card:nth-child(2) [name="name"]').value,'Drugi nesačuvan naziv');
});
test('DOM: expired session immediately removes products, identity, drafts and open confirmation',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);edit('.product-card [name="name"]','Privatni nacrt');submit(0);data.deny=true;close('save');await until(()=>!$('#access').hidden);assert.equal($('#workspace').hidden,true);assert.equal($('#identity').textContent,'');assert.equal($('#content').childElementCount,0);assert.equal($('#confirm').open,false);
 data.deny=false;$('#retry').click();await until(()=>$('.product-card'));assert.notEqual($('.product-card [name="name"]').value,'Privatni nacrt');
});
test('DOM: stale refresh cannot replace newer navigation or clear a newer valid session',async t=>{
 const {data,$}=await fixture(t);let resolve;data.delay=new Promise(r=>resolve=r);$('#refresh').click();$('[data-view="orders"]').click();await until(()=>$('#content').textContent.includes('Još nema porudžbina'));resolve(response({},401));await new Promise(r=>setTimeout(r,20));assert.equal($('#workspace').hidden,false);assert.equal($('#identity').textContent,'admin@example.test');assert.match($('#content').textContent,/Još nema porudžbina/);
});
test('DOM: pageshow revalidates session and clears previous edits, 409 never shows success',async t=>{
 const {data,$,w,edit,submit,close}=await fixture(t);edit('.product-card [name="name"]','Nesačuvano');data.conflict=true;submit(0);close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.doesNotMatch($('#status').textContent,/uspešno/);w.dispatchEvent(new w.Event('pageshow'));await until(()=>$('.product-card'));assert.notEqual($('.product-card [name="name"]').value,'Nesačuvano');assert.equal($('#workspace').hidden,false);
});
test('DOM: API-supplied markup remains text content',async t=>{
 const {data,$}=await fixture(t);data.products[0]={...data.products[0],name:'<img src=x onerror=alert(1)>',declaration:{warnings:'<script>alert(1)</script>'}};$('#refresh').click();await until(()=>$('.product-card h3')?.textContent.includes('<img'));assert.equal($('#content img[src="x"], #content [onerror]'),null);assert.equal($('#content script'),null);assert.match($('.product-card').textContent,/<script>alert\(1\)<\/script>/);
});
test('DOM: Escape after an earlier save cannot reuse the previous save decision',async t=>{
 const {data,$,w,edit,submit,close}=await fixture(t);edit('.product-card [name="price"]','200');submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(data.patches.length,1);
 edit('.product-card [name="price"]','300');submit(0);assert.equal($('#confirm').returnValue,'cancel');const dialog=$('#confirm');dialog.open=false;dialog.dispatchEvent(new w.Event('close'));await until(()=>!$('.product-card button[type="submit"]').disabled);assert.equal(data.patches.length,1);
});

test('DOM: pending save stays disabled and does not report optimistic success',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);let resolve;data.patchDelay=new Promise(r=>resolve=r);edit('.product-card [name="price"]','456');submit(0);close('save');await until(()=>data.patches.length===1);assert.equal($('.product-card button[type="submit"]').disabled,true);assert.doesNotMatch($('#status').textContent,/uspešno/);submit(0);assert.equal(data.patches.length,1);resolve(response({},409));await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal($('.product-card button[type="submit"]').disabled,false);
});

test('DOM: original XLS preview sends legacy Excel type and shows identifier and only B2C quantity',async t=>{
 const {data,$,w,close}=await fixture(t);const input=$('input[type="file"]');assert.match(input.accept,/\.xls,/);const file=new w.File(['mock original XLS'],'Dnevni izveštaj.XLS',{type:'application/vnd.ms-excel'});Object.defineProperty(input,'files',{configurable:true,value:[file]});input.dispatchEvent(new w.Event('change'));$('.import-panel button').click();await until(()=>data.imports.length===1&&!$('.import-panel button').disabled);assert.equal(data.imports[0].options.headers['Content-Type'],'application/vnd.ms-excel');assert.equal(data.imports[0].options.body,file);assert.match($('.import-panel').textContent,/ORIGINAL-SKU/);assert.match($('.import-panel').textContent,/Magacin Bio Prodavnica B2C: 10 kom/);assert.doesNotMatch($('.import-panel').textContent,/Skladište upakovanih proizvoda: 13 kom/);assert.match($('.import-panel').textContent,/→ 10 kom/);assert.match($('.import-panel').textContent,/cene iz izveštaja se ne uvoze/);$('.import-panel button:last-child').click();assert.equal($('#confirm').open,true);close('cancel');await until(()=>!$('.import-panel button').disabled);assert.equal(data.imports.length,1);
 input.dispatchEvent(new w.Event('change'));assert.doesNotMatch($('.import-panel').textContent,/ORIGINAL-SKU/);
});
test('DOM: optional XLSX template preserves the modern Excel content type',async t=>{
 const {data,$,w}=await fixture(t);const input=$('input[type="file"]');Object.defineProperty(input,'files',{value:[new w.File(['mock XLSX'],'stock.xlsx')]});input.dispatchEvent(new w.Event('change'));$('.import-panel button').click();await until(()=>data.imports.length===1&&!$('.import-panel button').disabled);assert.equal(data.imports[0].options.headers['Content-Type'],'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
});

test('DOM: import preview shows server warnings safely and never invents missing warehouse zeros',async t=>{
 const {data,$,w}=await fixture(t);data.previewWarnings=['Drugi magacin je isključen iz uvoza.','<img src=x onerror=alert(1)>'];data.previewRows[0].warehouseQuantities=[{warehouse:'Magacin Bio Prodavnica B2C',quantity:10}];data.previewRows[0].stockQuantity=10;const input=$('input[type="file"]');Object.defineProperty(input,'files',{value:[new w.File(['mock XLS'],'stock.xls')]});input.dispatchEvent(new w.Event('change'));$('.import-panel button').click();await until(()=>data.imports.length===1&&!$('.import-panel button').disabled);assert.match($('.import-panel').textContent,/Uvoze se samo prijavljeni redovi iz B2C magacina/);assert.match($('.import-panel').textContent,/Proizvodi kojih nema u B2C delu datoteke ostaju nepromenjeni/);assert.match($('.import-panel').textContent,/odsustvo reda ne znači potvrđenu nulu/);assert.match($('.import-panel .notice').textContent,/Drugi magacin je isključen iz uvoza/);assert.match($('.import-panel .notice').textContent,/<img/);assert.equal($('.import-panel img'),null);assert.doesNotMatch($('.import-panel').textContent,/Skladište upakovanih proizvoda: 0/);
});

test('DOM: customer directory is capability gated, literal text, and cleared on session expiry',async t=>{
 const {data,$,w}=await fixture(t);assert.equal($('#customers-tab').hidden,true);
 data.customersEnabled=true;data.customerRows=[{id:'customer-id',name:'<img src=x onerror=alert(1)>',email:'user@example.test',lastLoginAt:'2026-10-15T08:00:00Z'}];
 w.dispatchEvent(new w.Event('pageshow'));await until(()=>!$('#customers-tab').hidden);$('#customers-tab').click();await until(()=>$('#content').textContent.includes('user@example.test'));
 assert.match($('#content').textContent,/<img src=x/);assert.equal($('#content img[src="x"], #content [onerror]'),null);
 data.deny=true;$('#refresh').click();await until(()=>$('#workspace').hidden);assert.equal($('#customers-tab').hidden,true);assert.equal($('#content').childElementCount,0);
});

test('DOM: late session capability response cannot undo pagehide clearing',async t=>{
 const {data,$,w}=await fixture(t);Object.defineProperty(w.document,'hidden',{configurable:true,value:false});let resolve;
 data.sessionDelay=new Promise(r=>resolve=r);w.document.dispatchEvent(new w.Event('visibilitychange'));w.dispatchEvent(new w.Event('pagehide'));
 resolve(response({csrfToken:'stale',capabilities:{customers:true}}));await new Promise(r=>setTimeout(r,20));assert.equal($('#customers-tab').hidden,true);assert.equal($('#workspace').hidden,true);
});
