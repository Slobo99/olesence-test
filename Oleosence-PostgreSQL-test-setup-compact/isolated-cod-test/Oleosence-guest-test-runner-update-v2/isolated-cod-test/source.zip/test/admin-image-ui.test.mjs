import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
import {products as catalog} from '../public/catalog.js';
import {validateImageFile,productImageSource} from '../public/admin.js';
const html=await readFile(new URL('../public/admin.html',import.meta.url),'utf8');
const source=(await readFile(new URL('../public/admin.js',import.meta.url),'utf8')).replaceAll('export function ','function ');
const response=(json,status=200)=>({ok:status>=200&&status<300,status,json:async()=>json});
const until=async predicate=>{for(let i=0;i<200;i++){if(predicate())return;await new Promise(r=>setTimeout(r,5));}assert.fail('Condition timed out');};
async function fixture(t){
 const dom=new JSDOM(html,{url:'https://admin.example.test/admin',runScripts:'outside-only'}),w=dom.window;await new Promise(r=>w.addEventListener('load',r,{once:true}));t.after(()=>w.close());
 const data={products:catalog.map(p=>({...p,version:7,available:false,stockQuantity:null})),uploads:[],revoked:[],created:[],probes:[],status:200,confirmations:0};
 w.confirm=()=>{data.confirmations++;return data.allowDiscard??true;};
 w.URL.createObjectURL=file=>{const url=`blob:test-${data.created.length}`;data.created.push({file,url});return url;};w.URL.revokeObjectURL=url=>data.revoked.push(url);
 w.Image=class{constructor(){data.probes.push(this);}set src(value){this.url=value;}load(width=800,height=600){this.naturalWidth=width;this.naturalHeight=height;this.onload();}fail(){this.onerror();}};
 w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(value=''){this.returnValue=value;this.open=false;this.dispatchEvent(new w.Event('close'));};
 w.fetch=async(path,options={})=>{
  if(path==='/admin/api/session')return response({csrfToken:'image-csrf',user:{email:'admin@example.test'}});
  if(options.method==='POST'){data.uploads.push({path,options});if(data.status!==200)return response({},data.status);const id=path.split('/').at(-2),product={...data.products.find(p=>p.id===id),version:8,imagePath:`/media/${'a'.repeat(64)}.jpg`,imageWidth:800,imageHeight:600};data.products=data.products.map(p=>p.id===id?product:p);return response({product});}
  if(options.method==='PATCH')return response({});
  if(path==='/admin/api/products')return response({products:data.products});
  throw Error(`Unexpected request ${path}`);
 };
 vm.runInContext(source,dom.getInternalVMContext());w.dispatchEvent(new w.Event('pageshow'));await until(()=>w.document.querySelectorAll('.product-card').length===3);
 const $=selector=>w.document.querySelector(selector),card=(index=0)=>w.document.querySelectorAll('.product-card')[index];
 const select=(file=new w.File(['photo'],'photo.png',{type:'image/png'}),index=0)=>{const input=card(index).querySelector('input[type=file]');Object.defineProperty(input,'files',{configurable:true,value:file?[file]:[]});input.dispatchEvent(new w.Event('input',{bubbles:true}));input.dispatchEvent(new w.Event('change',{bubbles:true}));return file;};
 const save=(index=0)=>card(index).querySelector('.image-actions button').click();
 const edit=(index,value)=>{const input=card(index).querySelector('[name=name]');input.value=value;input.dispatchEvent(new w.Event('input',{bubbles:true}));};
 return {w,data,$,card,select,save,edit,close:value=>$('#confirm').close(value)};
}
test('image file validation is exact MIME, nonempty and bounded; sources are same-origin allowlisted paths',()=>{
 for(const file of [null,{type:'image/svg+xml',size:10},{type:'image/jpeg',size:0},{type:'image/png',size:3*1024*1024+1},{type:'text/html',size:10}])assert.throws(()=>validateImageFile(file));
 validateImageFile({type:'image/jpeg',size:3*1024*1024});validateImageFile({type:'image/png',size:1});
 for(const image of ['../secret.png','//evil/a.png','x.jpg" onerror="alert(1)','data:image/png,hi','x.svg'])assert.equal(productImageSource({image}),null);
 assert.equal(productImageSource({image:'crni-kim.jpg'}),'/assets/crni-kim.jpg');assert.equal(productImageSource({imagePath:`/media/${'a'.repeat(64)}.jpg`}),`/media/${'a'.repeat(64)}.jpg`);assert.equal(productImageSource({imagePath:'https://evil/image.jpg',image:'safe.png'}),'/assets/safe.png');
});
test('image selection is local only; cancel and Escape never upload; save uses raw file and concurrency headers',async t=>{
 const {data,$,select,save,close,w}=await fixture(t);const file=select();data.probes.at(-1).load();assert.equal(data.uploads.length,0);assert.equal($('.image-preview img').src,'blob:test-0');assert.match($('.image-preview').textContent,/800 × 600/);
 save();assert.equal($('#confirm').open,true);assert.match($('#confirm-message').textContent,/javnom katalogu/);close('cancel');await until(()=>!$('.image-actions button').disabled);assert.equal(data.uploads.length,0);
 save();assert.equal($('#confirm').returnValue,'cancel');$('#confirm').open=false;$('#confirm').dispatchEvent(new w.Event('close'));await until(()=>!$('.image-actions button').disabled);assert.equal(data.uploads.length,0);
 save();save();close('save');await until(()=>data.uploads.length===1&&!$('.image-actions button').disabled);const upload=data.uploads[0];assert.equal(upload.path,'/admin/api/products/crni-kim/image');assert.equal(upload.options.body,file);assert.deepEqual({...upload.options.headers},{'Content-Type':'image/png','X-CSRF-Token':'image-csrf','X-Product-Version':'7'});assert.match($('#status').textContent,/objavljena/);assert.deepEqual(data.revoked,['blob:test-0']);assert.match($('.product-thumbnail').src,/\/media\/a{64}\.jpg$/);
});
test('invalid types, empty/oversized files, decode failures and excessive dimensions stay local',async t=>{
 const {data,w,select,save,$}=await fixture(t);
 for(const file of [new w.File(['x'],'photo.svg',{type:'image/svg+xml'}),new w.File([],'empty.jpg',{type:'image/jpeg'}),{type:'image/png',size:3*1024*1024+1}]){select(file);assert.match($('.product-image .form-message').textContent,/JPEG ili PNG/);}
 assert.equal(data.created.length,0);select();save();assert.equal($('#confirm').open,false);data.probes.at(-1).load(4001,3000);assert.match($('.product-image .form-message').textContent,/12 megapiksela/);select();data.probes.at(-1).fail();assert.match($('.product-image .form-message').textContent,/nije moguće otvoriti/);assert.equal(data.uploads.length,0);assert.equal(data.revoked.length,2);
});
test('reselection and clear revoke object URLs; late old decoder callbacks cannot replace new preview',async t=>{
 const {data,select,card,$}=await fixture(t);select();const old=data.probes.at(-1);select();assert.deepEqual(data.revoked,['blob:test-0']);old.load(5000,5000);assert.equal($('.image-preview img').src,'blob:test-1');data.probes.at(-1).load();card().querySelector('.image-actions button:last-child').click();assert.equal($('.image-preview img'),null);assert.deepEqual(data.revoked,['blob:test-0','blob:test-1']);
});
test('own text draft blocks image upload while another product draft and local image survive successful upload',async t=>{
 const {data,select,save,edit,close,card,$}=await fixture(t);edit(1,'Neizmenjen nacrt');select(undefined,1);data.probes.at(-1).load();save(1);assert.match(card(1).querySelector('.product-image .form-message').textContent,/Najpre sačuvajte/);assert.equal($('#confirm').open,false);
 select();data.probes.at(-1).load();save();close('save');await until(()=>data.uploads.length===1&&!$('.image-actions button').disabled);assert.equal(card(1).querySelector('[name=name]').value,'Neizmenjen nacrt');assert.match(card(1).querySelector('header').textContent,/Verzija 7/);assert.equal(card(1).querySelector('.image-preview img').src,'blob:test-0');assert.deepEqual(data.revoked,['blob:test-1']);
});
test('409 retains selection and draft, never reloads/overwrites silently; refresh requires discard decision',async t=>{
 const {data,select,save,close,$,card,edit}=await fixture(t);data.status=409;edit(1,'Sačuvaj nacrt');select();data.probes.at(-1).load();save();close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal(data.revoked.length,0);assert.match(card().querySelector('header').textContent,/Verzija 7/);assert.equal(card(1).querySelector('[name=name]').value,'Sačuvaj nacrt');data.allowDiscard=false;$('#refresh').click();assert.equal(data.confirmations,1);assert.ok($('.image-preview img'));assert.doesNotMatch($('#status').textContent,/objavljena/);
});
test('expired session clears all previews, files and dialog; pageshow and pagehide revoke local URLs',async t=>{
 const {data,select,save,close,w,$}=await fixture(t);select();data.probes.at(-1).load();data.status=401;save();close('save');await until(()=>$('#workspace').hidden);assert.deepEqual(data.revoked,['blob:test-0']);assert.equal($('#content').childElementCount,0);assert.equal($('#confirm').open,false);
 w.dispatchEvent(new w.Event('pageshow'));await until(()=>$('.product-card'));select();w.dispatchEvent(new w.Event('pageshow'));await until(()=>$('.product-card'));assert.deepEqual(data.revoked,['blob:test-0','blob:test-1']);select();w.dispatchEvent(new w.Event('pagehide'));assert.deepEqual(data.revoked,['blob:test-0','blob:test-1','blob:test-2']);
});
test('thumbnail metadata and malicious names cannot inject DOM or external image URLs',async t=>{
 const {data,$}=await fixture(t);data.products[0]={...data.products[0],name:'<img src=x onerror=alert(1)>',image:'x.jpg" onerror="alert(1)',imagePath:'https://evil.test/tracker',imageWidth:800,imageHeight:600};$('#refresh').click();await until(()=>$('.product-card h3')?.textContent.startsWith('<img'));assert.equal($('.product-card:first-child img'),null);assert.equal($('#content [onerror]'),null);assert.equal($('#content script'),null);assert.match($('.product-image').textContent,/800 × 600/);
});
test('pending preview finishes in the current card after another image save rebuilds the catalog',async t=>{
 const {data,select,save,close,card,$}=await fixture(t);select(undefined,1);const pending=data.probes.at(-1);select();data.probes.at(-1).load();save();close('save');await until(()=>data.uploads.length===1&&!$('.image-actions button').disabled);pending.load(700,500);assert.match(card(1).querySelector('.image-preview').textContent,/700 × 500/);
});
