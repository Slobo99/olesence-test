import test from 'node:test';
import assert from 'node:assert/strict';
import {createPostgresStore, StoreError} from '../src/admin-store.mjs';
import {products} from '../public/catalog.js';
const actor = {id: 'google:verified-test-admin', email: 'private@example.test'};
const copy = value => structuredClone(value);
function fakePool() {
  let state = {products: new Map(), orders: new Map(), audit: []};
  let backup;
  const calls = [];
  let auditFailure = false, released = 0, ended = false;
  async function query(sql, args = []) {
    calls.push({sql, args});
    if (sql === 'BEGIN') { backup = copy(state); return {rows: []}; }
    if (sql === 'COMMIT') { backup = null; return {rows: []}; }
    if (sql === 'ROLLBACK') { state = backup; backup = null; return {rows: []}; }
    if (sql.startsWith('-- Applied') || sql.startsWith('SELECT pg_advisory') || sql.startsWith('SELECT version FROM admin_schema_migrations')) return {rows: []};
    if (sql.startsWith('INSERT INTO admin_products')) {
      if (!state.products.has(args[0])) state.products.set(args[0], {id: args[0], document: JSON.parse(args[1]), revision: 1, updated_at: 'time-1'});
      return {rows: []};
    }
    if (sql.startsWith('INSERT INTO admin_audit')) {
      if (auditFailure) throw Error('Audit unavailable');
      state.audit.push({id: String(state.audit.length + 1), entity_type: args[0], entity_id: args[1], actor_id: args[2], action: 'update', before_snapshot: JSON.parse(args[3]), after_snapshot: JSON.parse(args[4]), created_at: 'time-2'});
      return {rows: []};
    }
    if (sql.startsWith('SELECT') && sql.includes('FROM admin_products')) return {rows: copy(args.length ? [state.products.get(args[0])].filter(Boolean) : [...state.products.values()].sort((a, b) => a.id.localeCompare(b.id)))};
    if (sql.startsWith('UPDATE admin_products')) {
      const row = state.products.get(args[0]); row.document = JSON.parse(args[1]); row.revision++; row.updated_at = 'time-2'; return {rows: [copy(row)]};
    }
    if (sql.startsWith('UPDATE admin_orders')) {
      const row = state.orders.get(args[0]); row.status = args[1]; row.revision++; return {rows: [copy(row)]};
    }
    if (sql.startsWith('SELECT') && sql.includes('FROM admin_orders')) {
      if (sql.includes('FOR UPDATE')) return {rows: copy([state.orders.get(args[0])].filter(Boolean))};
      return {rows: copy([...state.orders.values()].filter(row => args[0] === null || BigInt(row.sequence_id) < BigInt(args[0])).sort((a, b) => Number(b.sequence_id) - Number(a.sequence_id)).slice(0, args[1]))};
    }
    if (sql.startsWith('SELECT') && sql.includes('FROM admin_audit')) return {rows: copy(state.audit.filter(row => args[0] === null || BigInt(row.id) < BigInt(args[0])).reverse().slice(0, args[1]))};
    throw Error('Unhandled fake SQL: ' + sql);
  }
  return {query, connect: async () => ({query, release: () => released++}), end: async () => {ended = true;}, calls, get state() {return state;}, get released() {return released;}, get ended() {return ended;}, failAudit() {auditFailure = true;}};
}
async function seeded() {const pool = fakePool(), store = createPostgresStore(pool); await store.initialize(products); return {pool, store};}
const status = expected => error => error instanceof StoreError && error.status === expected;

test('initialization preserves catalog, unknown stock and edits across repeat initialization', async () => {
  const {pool, store} = await seeded();
  const rows = await store.listProducts();
  assert.equal(rows.length, 3);
  for (const row of rows) {
    assert.equal(row.version, 1); assert.equal(row.stockQuantity, null); assert.equal(row.available, false);
    assert.deepEqual(row.declaration, products.find(p => p.id === row.id).declaration);
  }
  await store.updateProduct('crni-kim', 1, {name: 'Edited'}, actor);
  await store.initialize(products);
  assert.equal((await store.listProducts()).find(p => p.id === 'crni-kim').name, 'Edited');
  assert.equal(pool.released, 3);
  await store.close(); assert.equal(pool.ended, true);
});
test('update locks the row, merges fields, increments version and audits atomically', async () => {
  const {pool, store} = await seeded();
  const updated = await store.updateProduct('crni-kim', 1, {priceMinor: 12300, stockQuantity: 4, available: true}, actor);
  assert.equal(updated.version, 2); assert.equal(updated.name, products[0].name); assert.equal(updated.priceMinor, 12300);
  assert.equal(pool.state.audit.length, 1); assert.equal(pool.state.audit[0].actor_id, actor.id);
  assert.equal(pool.state.audit[0].before_snapshot.priceMinor, 149000);
  assert.equal(pool.state.audit[0].after_snapshot.version, 2);
  assert.equal(JSON.stringify(pool.state.audit).includes(actor.email), false);
  assert.match(pool.calls.find(c => c.sql.startsWith('SELECT') && c.sql.includes('FOR UPDATE')).sql, /WHERE id = \$1 FOR UPDATE/);
  assert.equal(pool.calls.at(-1).sql, 'COMMIT');
});
test('stale version rejects rather than overwriting and missing product is 404', async () => {
  const {pool, store} = await seeded();
  await store.updateProduct('crni-kim', 1, {name: 'First'}, actor);
  await assert.rejects(store.updateProduct('crni-kim', 1, {name: 'Second'}, actor), status(409));
  assert.equal(pool.calls.at(-1).sql, 'ROLLBACK'); assert.equal(pool.state.audit.length, 1);
  await assert.rejects(store.updateProduct('missing', 1, {name: 'No'}, actor), status(404));
});
test('audit failure rolls product change back and releases client', async () => {
  const {pool, store} = await seeded(); pool.failAudit();
  await assert.rejects(store.updateProduct('crni-kim', 1, {name: 'No commit'}, actor), /Audit unavailable/);
  assert.equal(pool.state.products.get('crni-kim').revision, 1); assert.equal(pool.released, 2);
});
test('rejects invalid values, immutable fields, unverified actors and impossible availability', async () => {
  const {store} = await seeded();
  for (const patch of [{priceMinor: 1.2}, {stockQuantity: -1}, {available: 'true'}, {role: 'admin'}, {declaration: {warnings: ''}}, {image: 'x.jpg'}, {}, {name: ''}]) await assert.rejects(store.updateProduct('crni-kim', 1, patch, actor), status(400));
  await assert.rejects(store.updateProduct('crni-kim', 1, {available: true}, actor), status(400));
  await assert.rejects(store.updateProduct('crni-kim', 1, {name: 'X'}, {id: 'email:unverified'}), status(403));
});
test('stock import replaces quantities, keeps positive stock unpublished and audits each product', async () => {
  const {pool, store} = await seeded();
  const changed = await store.applyStockImport([{id: 'divlji-origano', version: 1, stockQuantity: 7}, {id: 'crni-kim', version: 1, stockQuantity: 2}], actor);
  assert.deepEqual(changed.map(p => p.id), ['crni-kim', 'divlji-origano']);
  assert.equal(changed.every(p => p.available === false && p.version === 2), true);
  assert.equal(pool.state.audit.length, 2);
  await store.updateProduct('crni-kim', 2, {available: true}, actor);
  const zero = await store.applyStockImport([{id: 'crni-kim', version: 3, stockQuantity: 0}], actor);
  assert.equal(zero[0].available, false);
});
test('any stale stock import row rejects whole batch before writes', async () => {
  const {pool, store} = await seeded();
  await assert.rejects(store.applyStockImport([{id: 'crni-kim', version: 1, stockQuantity: 7}, {id: 'divlji-origano', version: 2, stockQuantity: 8}], actor), status(409));
  assert.equal(pool.state.products.get('crni-kim').document.stockQuantity, null);
  assert.equal(pool.state.audit.length, 0);
  assert.equal(pool.calls.some(c => c.sql.startsWith('UPDATE')), false);
  for (const rows of [[{id: 'crni-kim', version: 1, stockQuantity: ''}], [{id: 'crni-kim', version: 1}], [{id: 'crni-kim', version: 1, stockQuantity: 1}, {id: 'crni-kim', version: 1, stockQuantity: 2}]]) await assert.rejects(store.applyStockImport(rows, actor), status(400));
});
test('orders start empty, valid transitions audit only status and reject payment edits', async () => {
  const {pool, store} = await seeded();
  assert.deepEqual(await store.listOrders(), {orders: [], nextCursor: null});
  pool.state.orders.set('order-1', {id: 'order-1', sequence_id: '1', document: {customer: {email: 'never-audit@example.test'}, totalMinor: 12300}, status: 'pending', revision: 1});
  await assert.rejects(store.updateOrder('order-1', 1, {status: 'completed'}, actor), status(409));
  const order = await store.updateOrder('order-1', 1, {status: 'processing'}, actor);
  assert.equal(order.status, 'processing'); assert.equal(order.version, 2);
  assert.deepEqual(pool.state.audit[0].after_snapshot, {id: 'order-1', status: 'processing', version: 2});
  assert.equal(JSON.stringify(pool.state.audit).includes('never-audit'), false);
  await assert.rejects(store.updateOrder('order-1', 2, {status: 'shipped', paymentStatus: 'paid'}, actor), status(400));
  await store.updateOrder('order-1', 2, {status: 'shipped'}, actor);
  await store.updateOrder('order-1', 3, {status: 'completed'}, actor);
  await assert.rejects(store.updateOrder('order-1', 4, {status: 'cancelled'}, actor), status(409));
});
test('audit keyset pages are bounded, stable and reject invalid cursors', async () => {
  const {store} = await seeded();
  await store.updateProduct('crni-kim', 1, {name: 'One'}, actor);
  await store.updateProduct('crni-kim', 2, {name: 'Two'}, actor);
  const first = await store.listAudit({limit: 1});
  assert.equal(first.entries[0].id, '2'); assert.equal(first.nextCursor, '2');
  const second = await store.listAudit({limit: 1, before: first.nextCursor});
  assert.equal(second.entries[0].id, '1'); assert.equal(second.nextCursor, null);
  for (const options of [{limit: 101}, {before: "1;DROP TABLE x"}, {before: '9999999999999999999'}, {limit: 0}]) await assert.rejects(store.listAudit(options), status(400));
});
test('stock import audit failure rolls back every product and audit entry', async () => {
  const {pool, store} = await seeded(); pool.failAudit();
  await assert.rejects(store.applyStockImport([{id: 'crni-kim', version: 1, stockQuantity: 2}, {id: 'divlji-origano', version: 1, stockQuantity: 3}], actor), /Audit unavailable/);
  assert.equal([...pool.state.products.values()].every(row => row.revision === 1 && row.document.stockQuantity === null), true);
  assert.equal(pool.state.audit.length, 0); assert.equal(pool.calls.at(-1).sql, 'ROLLBACK');
});
test('SQL-looking product text is parameterized, never interpolated', async () => {
  const {pool, store} = await seeded();
  const name = "Name'); DROP TABLE admin_products; --";
  await store.updateProduct('crni-kim', 1, {name}, actor);
  assert.equal(pool.calls.some(call => call.sql.includes(name)), false);
  assert.equal((await store.listProducts()).find(row => row.id === 'crni-kim').name, name);
});
test('orders paginate without leaking sequence bookkeeping', async () => {
  const {pool, store} = await seeded();
  for (let n = 1; n <= 3; n++) pool.state.orders.set(`order-${n}`, {id: `order-${n}`, sequence_id: String(n), document: {}, status: 'pending', revision: 1});
  const first = await store.listOrders({limit: 2});
  assert.deepEqual(first.orders.map(row => row.id), ['order-3', 'order-2']); assert.equal(first.nextCursor, '2');
  assert.equal(Object.hasOwn(first.orders[0], 'sequence_id'), false);
  const second = await store.listOrders({limit: 2, before: first.nextCursor});
  assert.deepEqual(second.orders.map(row => row.id), ['order-1']); assert.equal(second.nextCursor, null);
  await store.updateOrder('order-1', 1, {status: 'cancelled'}, actor);
  await assert.rejects(store.updateOrder('order-1', 2, {status: 'processing'}, actor), status(409));
});
test('product limits and import bounds match the admin form contract', async () => {
  const {store} = await seeded();
  for (const [key, limit] of Object.entries({name: 120, botanical: 120, category: 120, volume: 120, description: 2000, ingredients: 2000, note: 2000, method: 500})) await assert.rejects(store.updateProduct('crni-kim', 1, {[key]: 'x'.repeat(limit + 1)}, actor), status(400));
  for (const patch of [{name: null}, {botanical: null}, {category: null}, {description: null}, {ingredients: null}, {priceMinor: null}, {priceMinor: 100000001}, {stockQuantity: 1000001}]) await assert.rejects(store.updateProduct('crni-kim', 1, patch, actor), status(400));
  await assert.rejects(store.applyStockImport([{id: 'crni-kim', version: 1, stockQuantity: 1000001}], actor), status(400));
  await assert.rejects(store.applyStockImport(Array.from({length: 501}, (_, n) => ({id: `product-${n}`, version: 1, stockQuantity: 1})), actor), status(400));
  const accepted = await store.updateProduct('crni-kim', 1, {priceMinor: 100000000, stockQuantity: 1000000, name: 'x'.repeat(120)}, actor);
  assert.equal(accepted.stockQuantity, 1000000);
});

// PGlite runs PostgreSQL in WASM. This adapter intentionally serializes connections:
// it exercises real SQL/transactions, not production pg networking or pool behavior.
async function embeddedPool() {
  const {PGlite} = await import('@electric-sql/pglite');
  const db = new PGlite();
  let tail = Promise.resolve();
  async function connect() {
    const previous = tail;
    let release;
    tail = new Promise(resolve => {release = resolve;});
    await previous;
    return {
      query: async (sql, params) => params === undefined && sql.startsWith('-- Applied') ? (await db.exec(sql)).at(-1) : db.query(sql, params),
      release
    };
  }
  return {connect, query: async (sql, params) => {const client = await connect(); try {return await client.query(sql, params);} finally {client.release();}}, end: () => db.close()};
}

test('real embedded PostgreSQL executes migration, persistence, atomic imports, locking conflicts, audit and orders', async () => {
  const pool = await embeddedPool();
  const store = createPostgresStore(pool);
  try {
    await store.initialize(products);
    assert.equal((await store.listProducts()).length, 3);
    const results = await Promise.allSettled([
      store.updateProduct('crni-kim', 1, {name: 'First concurrent save'}, actor),
      store.updateProduct('crni-kim', 1, {name: 'Second concurrent save'}, actor)
    ]);
    assert.equal(results.filter(r => r.status === 'fulfilled').length, 1);
    assert.equal(results.find(r => r.status === 'rejected').reason.status, 409);
    await store.initialize(products);
    assert.equal((await store.listProducts()).find(p => p.id === 'crni-kim').version, 2);
    await assert.rejects(store.applyStockImport([{id: 'cetiri-lopova', version: 1, stockQuantity: 5}, {id: 'crni-kim', version: 1, stockQuantity: 6}], actor), status(409));
    assert.equal((await store.listProducts()).find(p => p.id === 'cetiri-lopova').stockQuantity, null);
    const changed = await store.applyStockImport([{id: 'cetiri-lopova', version: 1, stockQuantity: 5}, {id: 'crni-kim', version: 2, stockQuantity: 6}], actor);
    assert.equal(changed.length, 2);
    assert.equal((await store.listAudit()).entries.length, 3);
    const page = await store.listAudit({limit: 2});
    assert.equal(page.entries.length, 2); assert.ok(page.nextCursor);
    assert.equal((await store.listAudit({before: page.nextCursor, limit: 2})).entries.length, 1);
    assert.deepEqual(await store.listOrders(), {orders: [], nextCursor: null});
    await pool.query('INSERT INTO admin_orders (id, document) VALUES ($1, $2::jsonb)', ['test-order', JSON.stringify({customer: {email: 'do-not-audit@example.test'}})]);
    const order = await store.updateOrder('test-order', 1, {status: 'processing'}, actor);
    assert.equal(order.version, 2);
    assert.equal((await store.listOrders()).orders[0].status, 'processing');
    const last = (await store.listAudit({limit: 1})).entries[0];
    assert.deepEqual(last.after, {id: 'test-order', status: 'processing', version: 2});
    assert.equal(JSON.stringify(last).includes('do-not-audit'), false);
    // Force a PostgreSQL constraint error on audit insertion, after product UPDATE.
    await pool.query("ALTER TABLE admin_audit ADD CONSTRAINT reject_test_actor CHECK (actor_id <> 'google:rollback-test')");
    await assert.rejects(store.updateProduct('cetiri-lopova', 2, {name: 'must roll back'}, {id: 'google:rollback-test'}), /reject_test_actor/);
    assert.equal((await store.listProducts()).find(p => p.id === 'cetiri-lopova').version, 2);
  } finally {await store.close();}
});
