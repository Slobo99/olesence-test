import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {parsePrice,parseStock} from '../public/admin.js';
test('admin converts decimal RSD without floating point rounding',()=>{assert.equal(parsePrice('1490,25'),149025);assert.equal(parsePrice('0.01'),1);assert.equal(parsePrice(' 9,1 '),910);assert.equal(parsePrice('0'),0);assert.equal(parsePrice('1000000'),100000000);});
test('admin rejects ambiguous, out-of-bounds and malformed prices',()=>{for(const value of ['1,234','1.234,00','-1','Infinity','1e3','','1000000.01','999999999999999999999'])assert.throws(()=>parsePrice(value));});
test('admin distinguishes unknown and zero stock, enforces bounded integers',()=>{assert.equal(parseStock(''),null);assert.equal(parseStock(' '),null);assert.equal(parseStock('0'),0);assert.equal(parseStock('1000000'),1000000);for(const value of ['1.2','-1','NaN','1e2','1000001'])assert.throws(()=>parseStock(value));});
test('admin uses safe DOM APIs and declares accessible protected workspace',async()=>{const js=await readFile(new URL('../public/admin.js',import.meta.url),'utf8');const html=await readFile(new URL('../public/admin.html',import.meta.url),'utf8');assert.doesNotMatch(js,/innerHTML|outerHTML|insertAdjacentHTML/);assert.match(js,/X-CSRF-Token/);assert.match(js,/pagehide/);assert.match(js,/pageshow/);assert.match(html,/id="workspace" hidden/);assert.match(html,/lang="sr-Latn"/);assert.match(html,/aria-live="polite"/);});
