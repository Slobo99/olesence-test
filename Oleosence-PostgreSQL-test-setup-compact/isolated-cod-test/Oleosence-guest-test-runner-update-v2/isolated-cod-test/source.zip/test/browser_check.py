# Local browser smoke test through a synthetic HTTPS-origin bridge; not a live Render test.
# Start loopback test server as described in README.md first.
import urllib.request
from playwright.sync_api import sync_playwright
ORIGIN='https://test-login.onrender.com'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1280,'height':900})
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 def route(r):
  u=r.request.url
  if not u.startswith(ORIGIN): r.abort();return
  req=urllib.request.Request('http://127.0.0.1:4188'+u[len(ORIGIN):],headers={'Host':'test-login.onrender.com','X-Forwarded-Proto':'https'},method=r.request.method)
  with urllib.request.urlopen(req) as x:r.fulfill(status=x.status,headers=dict(x.headers),body=x.read())
 page.route('**/*',route)
 page.goto(ORIGIN+'/');page.wait_for_load_state('networkidle')
 assert page.get_by_role('link',name='Moj nalog').count()==1
 page.get_by_role('link',name='Moj nalog').click()
 page.get_by_text('Google prijava još nije podešena.',exact=False).wait_for()
 assert page.locator('#google-login').is_disabled()
 page.goto(ORIGIN+'/account?login=failed')
 page.get_by_text('Prijava je otkazana, istekla ili nije potvrđena.',exact=False).wait_for()
 assert page.url==ORIGIN+'/account'
 page.go_back();page.wait_for_load_state('networkidle')
 assert page.locator('#google-login').is_disabled()
 for slug in ['crni-kim','divlji-origano','cetiri-lopova']:
  page.goto(ORIGIN+'/proizvod/'+slug)
  assert page.locator('h1').count()==1
  assert page.get_by_role('link',name='Moj nalog').count()==1
 page.set_viewport_size({'width':390,'height':844});page.goto(ORIGIN+'/account')
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
 assert not errors,errors
 browser.close()
 print('Browser smoke passed: desktop/mobile account, disabled login, error recovery/history, three product pages; no JS errors.')
