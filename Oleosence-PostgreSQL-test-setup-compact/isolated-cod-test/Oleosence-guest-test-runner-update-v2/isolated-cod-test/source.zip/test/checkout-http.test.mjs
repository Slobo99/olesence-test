import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import ExcelJS from 'exceljs';
import {PGlite} from '@electric-sql/pglite';
import {createHostedServer,readHostedConfig} from '../server.mjs';
import {createPostgresStore} from '../src/admin-store.mjs';
import {createCustomerStore} from '../src/customer-store.mjs';
import {createCodStore} from '../src/cod-store.mjs';

const origin='https://checkout-test.onrender.com',host='checkout-test.onrender.com',clientId='checkout-unit-test.apps.googleusercontent.com';
const contact={fullName:'Test Kupac',email:'buyer@example.invalid',phone:'0600000000',address:'Izmisljena 1',city:'Beograd',postalCode:'11000',country:'RS'};
const orderBody=(patch={})=>({items:[{productId:'crni-kim',quantity:1,expectedRevision:1}],contact:{...contact},shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:179000,...patch});
const quoteBody={items:[{productId:'crni-kim',quantity:1}]};
const jsonHeaders=headers=>({...headers,'content-type':'application/json'});

async function setup(t,{enabled=true}={}){
 const db=new PGlite();let queue=Promise.resolve();
 async function acquire(){const previous=queue;let release;queue=new Promise(resolve=>{release=resolve;});await previous;return release;}
 // All PGlite operations use its one session. This explicitly serializes local
 // transaction tests and does not simulate independent production pool clients.
 const query=(sql,args)=>sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args);
 const pool={async query(sql,args){const release=await acquire();try{return await query(sql,args);}finally{release();}},async connect(){const release=await acquire();return {query,release};}};
 for(const file of ['001_admin.sql','002_product_images.sql','003_customers.sql','004_order_model.sql','005_cod_checkout.sql'])await db.exec(await readFile(new URL('../migrations/'+file,import.meta.url),'utf8'));
 for(const [id,priceMinor] of [['crni-kim',149000],['divlji-origano',159000]])await db.query('INSERT INTO admin_products(id,document) VALUES($1,$2::jsonb)',[id,JSON.stringify({name:'Original '+id,priceMinor,stockQuantity:5,available:true})]);
 const store=createPostgresStore(pool),customerStore=createCustomerStore(pool),codStore=createCodStore(pool);
 let flow,identity;
 // Exercise the existing Google authorization callback and its opaque session
 // cookie. Only the external provider exchange is mocked; there is no auth bypass.
 const provider={authorizationURL(value){flow=value;return 'https://accounts.google.com/mock';},async exchange({code,verifier}){assert.equal(code,'fixture-code');assert.equal(verifier,flow.verifier);return {iss:'https://accounts.google.com',aud:clientId,sub:identity.subject,email:identity.email,email_verified:true,name:'Fixture Customer',nonce:flow.nonce,iat:1000,exp:4600,role:'admin'};}};
 const config={origin,host,redirectHosts:['alternate.example.invalid'],auth:{origin,clientId,clientSecret:'fictional-test-only-secret',redirectUri:origin+'/auth/google/callback',secure:true},admin:{enabled:true,emails:['admin@example.invalid']},customerDatabaseEnabled:true,checkoutEnabled:enabled};
 const app=await createHostedServer({config,provider,clock:()=>1000000,store,customerStore,codStore});
 await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));
 t.after(async()=>{await app.close();await db.close();});
 function request(path,{method='GET',headers={},body}={}){return new Promise((resolve,reject)=>{const req=http.request({hostname:'127.0.0.1',port:app.server.address().port,path,method,headers:{host,'x-forwarded-proto':'https',...headers}},res=>{let text='';res.on('data',bytes=>{text+=bytes;});res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,text,json:()=>JSON.parse(text)}));});req.on('error',reject);req.end(body);});}
 async function login(subject='buyer',email=subject+'@example.invalid'){
  identity={subject,email};const start=await request('/auth/google/start',{method:'POST',headers:{origin}});assert.equal(start.status,200);
  const initialCookie=start.headers['set-cookie'][0].split(';')[0];const done=await request('/auth/google/callback?state='+flow.state+'&code=fixture-code',{headers:{cookie:initialCookie}});assert.equal(done.status,303);
  const cookie=done.headers['set-cookie'][0].split(';')[0];assert.notEqual(cookie,initialCookie);
  const session=(await request('/auth/session',{headers:{cookie}})).json();assert.equal(session.user.role,'customer');
  return {headers:{cookie,origin,'x-csrf-token':session.csrfToken},session};
 }
 const post=(path,headers,body,key)=>request(path,{method:'POST',headers:{...jsonHeaders(headers),...(key?{'idempotency-key':key}:{})},body:typeof body==='string'?body:JSON.stringify(body)});
 const stock=async(id='crni-kim')=>(await db.query('SELECT document,revision FROM admin_products WHERE id=$1',[id])).rows[0];
 const countOrders=async()=>(await db.query('SELECT count(*)::int AS count FROM admin_orders')).rows[0].count;
 return {app,db,request,login,post,stock,countOrders,config,store,customerStore,codStore};
}

test('COD configuration is off by default and cannot activate without every dependency',async()=>{
 const base={RENDER:'true',CUSTOMER_AUTH_ORIGIN:origin};assert.equal(readHostedConfig(base).checkoutEnabled,false);assert.equal(readHostedConfig({...base,CHECKOUT_COD_ENABLED:'0'}).checkoutEnabled,false);
 for(const extra of [{},{CUSTOMER_DATABASE_ENABLED:'1',DATABASE_URL:'postgresql://fixture'},{CUSTOMER_GOOGLE_ENABLED:'1',GOOGLE_CLIENT_ID:clientId,GOOGLE_CLIENT_SECRET:'fictional-test-only-secret',ADMIN_ENABLED:'1',ADMIN_EMAILS:'admin@example.invalid',DATABASE_URL:'postgresql://fixture'}])assert.throws(()=>readHostedConfig({...base,...extra,CHECKOUT_COD_ENABLED:'1'}));
 const valid={...base,CHECKOUT_COD_ENABLED:'1',CUSTOMER_GOOGLE_ENABLED:'1',GOOGLE_CLIENT_ID:clientId,GOOGLE_CLIENT_SECRET:'fictional-test-only-secret',ADMIN_ENABLED:'1',ADMIN_EMAILS:'admin@example.invalid',CUSTOMER_DATABASE_ENABLED:'1',DATABASE_URL:'postgresql://fixture'};assert.equal(readHostedConfig(valid).checkoutEnabled,true);
 await assert.rejects(createHostedServer({config:{origin,host,checkoutEnabled:true,customerDatabaseEnabled:false,auth:null}}),/dependencies/);
});

test('disabled checkout rejects quotes and orders even with an authenticated customer',async t=>{
 const {request,login,post,countOrders,stock}=await setup(t,{enabled:false});const {headers}=await login();
 const session=(await request('/api/checkout/session',{headers})).json();assert.equal(session.enabled,false);
 assert.equal((await post('/api/checkout/quote',headers,quoteBody)).status,503);assert.equal((await post('/api/checkout/orders',headers,orderBody(),'disabled_order_key')).status,503);assert.equal((await request('/api/checkout/orders',{headers})).status,503);
 assert.equal(await countOrders(),0);assert.equal((await stock()).document.stockQuantity,5);assert.equal((await request('/auth/session',{headers})).json().checkoutLinked,false);
});

test('checkout requires verified login and refuses forged identity headers or cookies',async t=>{
 const {request,post,countOrders}=await setup(t);
 const session=(await request('/api/checkout/session')).json();assert.equal(session.enabled,true);assert.equal(session.user,null);assert.equal(session.customerReady,false);assert.equal(session.csrfToken,null);
 for(const headers of [{origin},{origin,'x-customer-id':'11111111-1111-4111-8111-111111111111','x-user-role':'admin'},{origin,cookie:'__Host-oleosence_customer=forged'}]){
  assert.equal((await post('/api/checkout/quote',headers,quoteBody)).status,401);assert.equal((await post('/api/checkout/orders',headers,orderBody(),'anonymous_key_0001')).status,401);assert.equal((await request('/api/checkout/orders',{headers})).status,401);
 }
 assert.equal(await countOrders(),0);
});

test('checkout enforces canonical host, HTTPS proxy, exact Origin, fetch metadata and session CSRF',async t=>{
 const {request,login,post,countOrders}=await setup(t);const {headers}=await login();
 for(const patch of [{origin:undefined},{origin:'https://evil.invalid'},{'x-csrf-token':undefined},{'x-csrf-token':'wrong'},{'x-csrf-token':'é'.repeat(43)},{'sec-fetch-site':'cross-site'},{'sec-fetch-site':'same-site'}]){
  const altered={...headers,...patch};for(const key of Object.keys(altered))if(altered[key]===undefined)delete altered[key];
  assert.equal((await post('/api/checkout/quote',altered,quoteBody)).status,403,JSON.stringify(patch));
  assert.equal((await post('/api/checkout/orders',altered,orderBody(),'security_key_00001')).status,403,JSON.stringify(patch));
 }
 for(const [patch,expected] of [[{host:'attacker.invalid'},421],[{host:'alternate.example.invalid'},421],[{'x-forwarded-proto':'http'},400],[{'x-forwarded-proto':'https,http'},400]])assert.equal((await post('/api/checkout/orders',{...headers,...patch},orderBody(),'host_check_key_001')).status,expected);
 assert.equal(await countOrders(),0);
 const quote=await post('/api/checkout/quote',headers,quoteBody);assert.equal(quote.status,200);assert.equal(quote.headers['access-control-allow-origin'],undefined);assert.equal(quote.headers['cache-control'],'no-store');
 assert.equal((await request('/auth/logout',{method:'POST',headers})).status,200);assert.equal((await post('/api/checkout/orders',headers,orderBody(),'signed_out_key_001')).status,401);
});

test('real HTTP quote, submit, retry and history use only the authenticated customer',async t=>{
 const {request,login,post,stock,countOrders}=await setup(t);const buyer=await login('buyer');
 const ready=(await request('/api/checkout/session',{headers:buyer.headers})).json();assert.equal(ready.customerReady,true);assert.equal(ready.user.customerId,buyer.session.user.customerId);
 const quote=await post('/api/checkout/quote',buyer.headers,quoteBody);assert.equal(quote.status,200);assert.equal(quote.json().totalMinor,179000);assert.equal(quote.json().items[0].unitPriceMinor,149000);assert.equal(quote.json().items[0].productRevision,1);assert.equal((await stock()).document.stockQuantity,5);
 const submitted=await post('/api/checkout/orders',buyer.headers,orderBody(),'http_order_key_0001');assert.equal(submitted.status,201);const saved=submitted.json();assert.equal(saved.replayed,false);assert.equal(saved.order.customerId,buyer.session.user.customerId);assert.equal(saved.order.paymentStatus,'cod_due');
 const retried=await post('/api/checkout/orders',buyer.headers,orderBody(),'http_order_key_0001');assert.equal(retried.status,200);assert.equal(retried.json().replayed,true);assert.equal(retried.json().order.id,saved.order.id);assert.equal((await stock()).document.stockQuantity,4);assert.equal(await countOrders(),1);
 assert.equal((await request('/api/checkout/orders/'+saved.order.id,{headers:buyer.headers})).json().order.id,saved.order.id);assert.equal((await request('/api/checkout/orders',{headers:buyer.headers})).json().orders.length,1);
 const other=await login('other');assert.notEqual(other.session.user.customerId,buyer.session.user.customerId);
 assert.equal((await request('/api/checkout/orders/'+saved.order.id,{headers:other.headers})).status,404);assert.deepEqual((await request('/api/checkout/orders',{headers:other.headers})).json().orders,[]);
 assert.equal((await post('/api/checkout/orders',other.headers,orderBody({customerId:buyer.session.user.customerId}),'forged_owner_key_01')).status,400);
 assert.equal((await post('/api/checkout/quote',other.headers,{...quoteBody,customerId:buyer.session.user.customerId})).status,400);
 assert.equal((await request('/admin/api/orders',{headers:buyer.headers})).status,403);assert.equal(await countOrders(),1);
});

test('body size, JSON shape, client totals, payment type and idempotency key fail closed',async t=>{
 const {post,login,request,countOrders,stock}=await setup(t);const {headers}=await login();
 const huge=JSON.stringify({items:quoteBody.items,padding:'x'.repeat(17000)});
 assert.equal((await post('/api/checkout/quote',{...headers,'transfer-encoding':'chunked'},huge)).status,413);
 assert.equal((await request('/api/checkout/quote',{method:'POST',headers:{...jsonHeaders(headers),'content-length':Buffer.byteLength(huge)},body:huge})).status,413);
 for(const body of ['{','null','[]','1','"text"'])assert.equal((await post('/api/checkout/quote',headers,body)).status,400);
 assert.equal((await request('/api/checkout/quote',{method:'POST',headers:{...headers,'content-type':'text/plain'},body:JSON.stringify(quoteBody)})).status,415);
 assert.equal((await post('/api/checkout/quote',headers,{items:[{productId:'crni-kim',quantity:1,priceMinor:1}]})).status,400);
 for(const patch of [{paymentMethod:'card'},{totalMinor:1},{paymentStatus:'paid'},{idempotencyKey:'body_key_not_allowed'},{items:[{productId:'crni-kim',quantity:1,expectedRevision:1,unitPriceMinor:1}]}])assert.equal((await post('/api/checkout/orders',headers,orderBody(patch),'invalid_body_key_01')).status,400);
 assert.equal((await post('/api/checkout/orders',headers,orderBody())).status,400);assert.equal((await post('/api/checkout/orders',headers,orderBody(),'short')).status,400);assert.equal((await post('/api/checkout/orders',headers,orderBody(),'k'.repeat(101))).status,400);
 assert.equal((await post('/api/checkout/orders',headers,orderBody({expectedTotalMinor:1}),'forged_total_key_01')).status,409);
 assert.equal((await post('/api/checkout/orders',headers,orderBody({items:[{productId:'crni-kim',quantity:1,expectedRevision:2}]}),'stale_quote_key_001')).status,409);
 assert.equal(await countOrders(),0);assert.equal((await stock()).document.stockQuantity,5);
});

test('no public paid, card, status-change or alternate order creation route exists',async t=>{
 const {login,request,post,countOrders}=await setup(t);const {headers}=await login();
 for(const path of ['/api/orders','/api/payments','/api/payment-intents','/api/checkout/cards','/api/checkout/payment','/api/checkout/payments','/api/checkout/paid'])assert.equal((await post(path,headers,{paymentStatus:'paid'})).status,404,path);
 assert.equal((await request('/api/checkout/orders',{method:'PATCH',headers:jsonHeaders(headers),body:'{"status":"completed"}'})).status,404);
 assert.equal((await request('/api/checkout/orders',{method:'DELETE',headers})).status,404);assert.equal(await countOrders(),0);
});

test('admin import preview becomes stale after checkout, and later cancellation never restocks',async t=>{
 const {login,request,post,stock}=await setup(t);const admin=await login('admin','admin@example.invalid'),buyer=await login('buyer');
 const workbook=new ExcelJS.Workbook();const sheet=workbook.addWorksheet('Zalihe');sheet.addRow(['SKU','availableQuantity']);sheet.addRow(['crni-kim',30]);sheet.addRow(['divlji-origano',30]);const bytes=Buffer.from(await workbook.xlsx.writeBuffer());
 const preview=()=>request('/admin/api/stock/preview',{method:'POST',headers:{...admin.headers,'content-type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'},body:bytes});
 const firstPreview=await preview();assert.equal(firstPreview.status,200);assert.equal(firstPreview.json().rows[0].version,1);
 const created=await post('/api/checkout/orders',buyer.headers,orderBody(),'import_race_key_01');assert.equal(created.status,201);const order=created.json().order;
 const stale=await post('/admin/api/stock/apply',admin.headers,{previewToken:firstPreview.json().previewToken});assert.equal(stale.status,409);assert.equal((await stock()).document.stockQuantity,4);assert.equal((await stock('divlji-origano')).document.stockQuantity,5);
 const newPreview=await preview();assert.equal(newPreview.status,200);assert.equal((await post('/admin/api/stock/apply',admin.headers,{previewToken:newPreview.json().previewToken})).status,200);assert.equal((await stock()).document.stockQuantity,30);
 const cancel=()=>request('/admin/api/orders/'+order.id,{method:'PATCH',headers:jsonHeaders(admin.headers),body:JSON.stringify({version:1,status:'cancelled'})});
 const cancelled=await cancel();assert.equal(cancelled.status,200);assert.equal(cancelled.json().paymentStatus,'cod_cancelled');assert.equal(cancelled.json().inventoryStatus,'deducted_manual_adjustment_required');assert.equal((await stock()).document.stockQuantity,30);assert.equal((await cancel()).status,409);
 const history=await request('/api/checkout/orders/'+order.id,{headers:buyer.headers});assert.equal(history.json().order.status,'cancelled');assert.equal(history.json().order.totalMinor,179000);
});
