import test from 'node:test';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash,generateKeyPairSync,sign} from 'node:crypto';
import {OAuth2Client} from 'google-auth-library';
import {createCustomerAuth,createGoogleProvider,readConfig,validateClaims} from '../src/customer-auth.mjs';
const clientId='unit-test.apps.googleusercontent.com';
const config={clientId,clientSecret:'fictional-test-only-secret',origin:'https://test-login.onrender.com',redirectUri:'https://test-login.onrender.com/auth/google/callback',secure:true};
const req=(cookie='',headers={})=>({headers:{cookie,...headers}});
const response=()=>({headers:{},setHeader(k,v){this.headers[k]=v;}});
const cookie=r=>r.headers['Set-Cookie'].split(';')[0];
const claims=(nonce,patch={})=>({iss:'https://accounts.google.com',aud:clientId,sub:'12345',iat:1000,exp:4600,email:'fictional@example.invalid',email_verified:true,name:'Fictional Customer',nonce,...patch});
function fixture({patch={},exchangeError=false,capacity=1000}={}){
 let now=1000000,flow,calls=0;
 const provider={authorizationURL(f){flow=f;return 'https://accounts.google.com/mock';},async exchange({code,verifier}){calls++;assert.equal(verifier,flow.verifier);assert.equal(code,'fictional-code');if(exchangeError)throw Error('secret token failure');return claims(flow.nonce,patch);}};
 const auth=createCustomerAuth({config,provider,clock:()=>now,capacity});
 function start(previous=''){const res=response();auth.start(req(previous),res);return {cookie:cookie(res),flow:{...flow},res};}
 async function finish(f,query=''){const res=response();const user=await auth.callback(req(f.cookie),res,new URL(config.redirectUri+'?state='+f.flow.state+'&code=fictional-code'+query));return {user,res,cookie:cookie(res)};}
 return {auth,start,finish,get calls(){return calls;},advance(ms){now+=ms;}};
}
test('missing or partial Google configuration is disabled; insecure/malformed config fails closed',()=>{
 for(const env of [{},{CUSTOMER_GOOGLE_ENABLED:'1'}, {CUSTOMER_GOOGLE_ENABLED:'1',GOOGLE_CLIENT_ID:clientId}])assert.equal(readConfig(env),null);
 const env={CUSTOMER_GOOGLE_ENABLED:'1',GOOGLE_CLIENT_ID:clientId,GOOGLE_CLIENT_SECRET:'fictional-test-only-secret',CUSTOMER_AUTH_ORIGIN:'https://oleosence.rs'};
 assert.equal(readConfig(env).redirectUri,'https://oleosence.rs/auth/google/callback');
 for(const origin of ['http://oleosence.rs','https://oleosence.rs/path','https://user@oleosence.rs','not-url'])assert.throws(()=>readConfig({...env,CUSTOMER_AUTH_ORIGIN:origin}));
 const auth=createCustomerAuth();assert.equal(auth.enabled,false);assert.throws(()=>auth.start(req(),response()),e=>e.status===503);
});
test('Google authorization URL uses only identity scopes, state, nonce and S256 PKCE',()=>{
 const p=createGoogleProvider(config),f={state:'state',nonce:'nonce',verifier:'test-verifier'};
 const u=new URL(p.authorizationURL(f));
 assert.equal(u.origin,'https://accounts.google.com');assert.equal(u.searchParams.get('scope'),'openid email profile');
 assert.equal(u.searchParams.get('response_type'),'code');assert.equal(u.searchParams.get('state'),f.state);assert.equal(u.searchParams.get('nonce'),f.nonce);
 assert.equal(u.searchParams.get('code_challenge_method'),'S256');assert.equal(u.searchParams.get('code_challenge'),createHash('sha256').update(f.verifier).digest('base64url'));
 assert.equal(u.searchParams.get('access_type'),'online');assert.equal(u.searchParams.get('redirect_uri'),config.redirectUri);assert.equal(u.searchParams.has('client_secret'),false);
});
test('mocked successful login rotates opaque cookie, fixes role to customer, and never returns provider tokens',async()=>{
 const f=fixture({patch:{role:'admin',roles:['admin'],access_token:'must-not-leak'}}),flow=f.start(),done=await f.finish(flow);
 assert.notEqual(done.cookie,flow.cookie);assert.match(done.res.headers['Set-Cookie'],/HttpOnly; SameSite=Lax/);assert.equal(f.auth.session(req(flow.cookie)),null);
 const s=f.auth.session(req(done.cookie));assert.equal(s.user.role,'customer');assert.equal(s.user.id,'google:12345');assert.equal(s.user.access_token,undefined);assert.match(s.csrfToken,/^[\w-]{43}$/);
 assert.equal(done.user.role,'customer');
});
test('state mismatch, duplicate state, cookie absence, and callback replay never exchange a code',async()=>{
 for(const kind of ['mismatch','duplicate','no-cookie']){
  const f=fixture(),flow=f.start(),r=response();let query='?state='+flow.flow.state+'&code=fictional-code';
  if(kind==='mismatch')query='?state=wrong&code=fictional-code';if(kind==='duplicate')query+='&state=extra';
  await assert.rejects(f.auth.callback(req(kind==='no-cookie'?'':flow.cookie),r,new URL(config.redirectUri+query)),e=>e.status===400);assert.equal(f.calls,0);
 }
 const f=fixture(),flow=f.start();await f.finish(flow);await assert.rejects(f.finish(flow),e=>e.status===400);assert.equal(f.calls,1);
});
test('cancelled, missing-code and expired flows fail closed and are consumed',async()=>{
 for(const query of ['?error=access_denied','?code=','?code=x&code=y']){
  const f=fixture(),flow=f.start();await assert.rejects(f.auth.callback(req(flow.cookie),response(),new URL(config.redirectUri+query+'&state='+flow.flow.state)),e=>e.status===400);assert.equal(f.calls,0);await assert.rejects(f.finish(flow));
 }
 const f=fixture(),flow=f.start();f.advance(300001);await assert.rejects(f.finish(flow),e=>e.status===400);assert.equal(f.calls,0);
});
test('provider failure gives generic error and no session; flow cannot be retried',async()=>{
 const f=fixture({exchangeError:true}),flow=f.start();await assert.rejects(f.finish(flow),e=>e.status===401&&!e.message.includes('secret'));assert.equal(f.auth.session(req(flow.cookie)),null);await assert.rejects(f.finish(flow),e=>e.status===400);
});
test('claim validation rejects nonce, issuer, audience, presenter, expiry, subject and unverified email',()=>{
 const valid=claims('nonce');validateClaims(valid,{clientId,nonce:'nonce',now:1000});
 for(const patch of [{nonce:'wrong'},{nonce:'é'.repeat(5)},{iss:'https://evil.invalid'},{aud:'other'},{aud:[clientId]},{azp:'other'},{exp:1000},{exp:'4600'},{iat:2000},{iat:5000},{sub:''},{sub:'a b'},{email_verified:false},{email_verified:'true'},{email:'bad'}])assert.throws(()=>validateClaims({...valid,...patch},{clientId,nonce:'nonce',now:1000}),e=>e.status===401,JSON.stringify(patch));
});
test('same email with different Google subjects produces separate customer identities',()=>{
 const opts={clientId,nonce:'nonce',now:1000};
 assert.notEqual(validateClaims(claims('nonce'),opts).id,validateClaims(claims('nonce',{sub:'6789'}),opts).id);
});
test('logout requires session CSRF, invalidates session, and expires cookie',async()=>{
 const f=fixture(),done=await f.finish(f.start()),s=f.auth.session(req(done.cookie));
 for(const token of [undefined,'wrong','é'.repeat(43)])assert.throws(()=>f.auth.logout(req(done.cookie,{'x-csrf-token':token}),response()),e=>e.status===403);
 const r=response();f.auth.logout(req(done.cookie,{'x-csrf-token':s.csrfToken}),r);assert.equal(f.auth.session(req(done.cookie)),null);assert.match(r.headers['Set-Cookie'],/Max-Age=0/);
 assert.throws(()=>f.auth.logout(req(done.cookie,{'x-csrf-token':s.csrfToken}),response()),e=>e.status===403);
});
test('sessions expire, restart clears them, cookies are strict, and caches are bounded',async()=>{
 const f=fixture(),done=await f.finish(f.start());assert.equal(f.auth.session(req(done.cookie+'; '+done.cookie)),null);assert.equal(f.auth.session(req('__Host-oleosence_customer=../../')),null);
 f.advance(3600001);assert.equal(f.auth.session(req(done.cookie)),null);
 const f2=fixture(),d2=await f2.finish(f2.start());f2.auth.close();assert.equal(f2.auth.session(req(d2.cookie)),null);
 const f3=fixture({capacity:1});f3.start();assert.throws(()=>f3.start(),e=>e.status===429);
});
test('HTTPS reusable auth module sets Secure cookie',()=>{
 const auth=createCustomerAuth({config:{...config,secure:true},provider:{authorizationURL:()=> 'https://accounts.google.com/mock'}});
 const r=response();auth.start(req(),r);assert.match(r.headers['Set-Cookie'],/; Secure$/);
});
test('official Google library rejects forged signatures and validates signed local fixtures without network',async()=>{
 const {privateKey,publicKey}=generateKeyPairSync('rsa',{modulusLength:2048});const client=new OAuth2Client();
 const now=Math.floor(Date.now()/1000),body={iss:'https://accounts.google.com',aud:clientId,sub:'local-fixture',iat:now,exp:now+600};
 const enc=x=>Buffer.from(JSON.stringify(x)).toString('base64url'),base=enc({alg:'RS256',kid:'fixture'})+'.'+enc(body),jwt=base+'.'+sign('RSA-SHA256',Buffer.from(base),privateKey).toString('base64url');
 const certs={fixture:publicKey.export({type:'spki',format:'pem'})};
 const verify=(token,audience=clientId)=>client.verifySignedJwtWithCertsAsync(token,certs,audience,['https://accounts.google.com']);
 assert.equal((await verify(jwt)).getPayload().sub,'local-fixture');
 await assert.rejects(verify(base+'.'+Buffer.alloc(256).toString('base64url')));
 await assert.rejects(verify(jwt,'wrong-audience'));
 const altered=enc({alg:'RS256',kid:'fixture'})+'.'+enc({...body,sub:'attacker'})+'.'+jwt.split('.')[2];await assert.rejects(verify(altered));
});
test('unsolicited callback cannot clear an authenticated customer cookie or session',async()=>{
 const f=fixture(),done=await f.finish(f.start()),res=response();
 await assert.rejects(f.auth.callback(req(done.cookie),res,new URL(config.redirectUri+'?error=access_denied')),e=>e.status===400);
 assert.equal(res.headers['Set-Cookie'],undefined);assert.equal(f.auth.session(req(done.cookie)).user.role,'customer');
});
