import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readHostedConfig,createHostedServer} from '../server.mjs';
const origin='https://olesence.rs',host='olesence.rs',legacy='legacy-test.onrender.com';
const env={RENDER:'true',CUSTOMER_AUTH_ORIGIN:origin,CUSTOMER_AUTH_REDIRECT_HOSTS:'olesence.com,'+legacy};
const request=(port,path,headers={},method='GET')=>new Promise((resolve,reject)=>{const q=http.request({hostname:'127.0.0.1',port,path,method,headers:{host,'x-forwarded-proto':'https',...headers}},r=>{let text='';r.on('data',b=>text+=b);r.on('end',()=>resolve({status:r.statusCode,headers:r.headers,text}));});q.on('error',reject);q.end();});
async function fixture(t){const a=await createHostedServer({config:readHostedConfig(env)});await new Promise(r=>a.server.listen(0,'127.0.0.1',r));t.after(()=>a.close());return (p,h,m)=>request(a.server.address().port,p,h,m);}
test('redirect configuration is optional, exact, bounded and rejects origin confusion',()=>{
 assert.deepEqual(readHostedConfig({RENDER:'true',CUSTOMER_AUTH_ORIGIN:origin}).redirectHosts,[]);
 assert.deepEqual(readHostedConfig(env).redirectHosts,['olesence.com',legacy]);
 for(const v of ['olesence.rs','evil.invalid/path','evil.invalid:443','user@evil.invalid','evil.invalid?x','evil.invalid#x','*.olesence.com','OLESENCE.COM','localhost','127.0.0.1','olesence.com,olesence.com','evil.invalid\\path','a.invalid,b.invalid,c.invalid,d.invalid,e.invalid,f.invalid,g.invalid,h.invalid,i.invalid'])assert.throws(()=>readHostedConfig({...env,CUSTOMER_AUTH_REDIRECT_HOSTS:v}),v);
});
test('canonical host continues serving unchanged public and disabled auth endpoints',async t=>{
 const get=await fixture(t);for(const p of ['/','/account','/proizvod/crni-kim','/styles.css'])assert.equal((await get(p)).status,200,p);
 assert.equal(JSON.parse((await get('/auth/session')).text).enabled,false);
 for(const p of ['/admin','/api/orders','/api/admin/state'])assert.equal((await get(p)).status,404,p);
});
test('approved aliases redirect GET and HEAD to fixed canonical origin preserving ordinary path/query',async t=>{
 const get=await fixture(t);
 for(const alias of ['olesence.com',legacy])for(const method of ['GET','HEAD']){
  const r=await get('/proizvod/crni-kim?from=domain',{host:alias},method);assert.equal(r.status,308);assert.equal(r.headers.location,origin+'/proizvod/crni-kim?from=domain');assert.equal(r.headers['set-cookie'],undefined);assert.equal(r.headers['cache-control'],'no-store');
 }
 assert.equal((await get('/?next=https://evil.invalid',{host:'olesence.com'})).headers.location,origin+'/?next=https://evil.invalid');
});
test('aliases never forward OAuth callback query or replay POST bodies',async t=>{
 const get=await fixture(t);for(const alias of ['olesence.com',legacy]){
  for(const p of ['/auth/google/callback?code=private-code&state=private-state','/auth/session','/auth/google/start','/%61uth/google/callback?code=private-code']){
   const r=await get(p,{host:alias});assert.equal(r.status,303,p);assert.equal(r.headers.location,origin+'/account');assert.equal(r.headers['set-cookie'],undefined);
  }
  for(const p of ['/auth/google/start','/auth/logout','/api/orders','/']){const r=await get(p,{host:alias,origin:'https://'+alias},'POST');assert.equal(r.status,421);assert.equal(r.headers.location,undefined);}
 }
});
test('unlisted hosts, forged forwarding, insecure proxy and protocol-relative targets cannot redirect',async t=>{
 const get=await fixture(t);
 for(const alias of ['evil.invalid','olesence.com.evil.invalid','www.olesence.com','olesence.com:443'])assert.equal((await get('/',{host:alias,'x-forwarded-host':'olesence.com'})).status,421);
 assert.equal((await get('/',{host:'olesence.com','x-forwarded-proto':'http'})).status,400);
 for(const p of ['//evil.invalid/path','/\\evil.invalid/path','/auth/%ZZ'])assert.equal((await get(p,{host:'olesence.com'})).status,400);
 assert.equal((await get('/healthz',{host:'internal'})).status,200);
});
