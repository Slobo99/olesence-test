import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {createHostedServer,readHostedConfig} from '../server.mjs';
import {createPostgresStore} from '../src/admin-store.mjs';
import {createCustomerStore} from '../src/customer-store.mjs';
import {createCodStore} from '../src/cod-store.mjs';
import {createGuestStore} from '../src/guest-store.mjs';
const origin='https://guest-test.onrender.com',host='guest-test.onrender.com';
const contact={fullName:'Synthetic Guest',email:'synthetic@example.invalid',phone:'0600000000',address:'Fictional 1',city:'Beograd',postalCode:'11000',country:'RS'};
async function setup(t,limits={}){
 const db=new PGlite();let queue=Promise.resolve();async function acquire(){const prior=queue;let release;queue=new Promise(r=>release=r);await prior;return release;}
 const query=(sql,args)=>sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args);
 const pool={async query(sql,args){const release=await acquire();try{return await query(sql,args);}finally{release();}},async connect(){const release=await acquire();return {query,release};}};
 const store=createPostgresStore(pool);await store.initialize([]);await db.query('INSERT INTO admin_products(id,document) VALUES($1,$2::jsonb)',['crni-kim',JSON.stringify({name:'Black cumin',priceMinor:149000,stockQuantity:2,available:true})]);
 const customerStore=createCustomerStore(pool),codStore=createCodStore(pool),guestStore=createGuestStore(pool,limits);
 const config={origin,host,auth:{origin,clientId:'test.apps.googleusercontent.com',clientSecret:'fictional-secret',redirectUri:origin+'/auth/google/callback',secure:true},admin:{enabled:true,emails:['owner@example.invalid']},customerDatabaseEnabled:true,checkoutEnabled:true,guestCheckoutEnabled:true};
 let flow;const provider={authorizationURL(v){flow=v;return 'https://accounts.google.com/mock';},async exchange(){const now=Math.floor(Date.now()/1000);return {iss:'https://accounts.google.com',aud:config.auth.clientId,sub:'synthetic-google-owner',email:'owner@example.invalid',email_verified:true,name:'Google Fixture',nonce:flow.nonce,iat:now,exp:now+3600};}};
 const app=await createHostedServer({config,store,customerStore,codStore,guestStore,provider});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));t.after(async()=>{await app.close();await db.close();});
 const request=(path,{method='GET',headers={},body}={})=>new Promise((resolve,reject)=>{const req=http.request({hostname:'127.0.0.1',port:app.server.address().port,path,method,headers:{host,'x-forwarded-proto':'https',...headers}},res=>{let text='';res.on('data',b=>text+=b);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,json:()=>JSON.parse(text)}));});req.on('error',reject);req.end(body===undefined?undefined:JSON.stringify(body));});
 async function session(){const r=await request('/api/checkout/session');assert.equal(r.status,200);const s=r.json(),cookie=r.headers['set-cookie'][0];return {s,cookie:cookie.split(';')[0],rawCookie:cookie,headers:{cookie:cookie.split(';')[0],origin,'x-csrf-token':s.csrfToken,'content-type':'application/json'}};}
 async function login(guestCookie){const start=await request('/auth/google/start',{method:'POST',headers:{origin,cookie:guestCookie}});assert.equal(start.status,200);const initial=start.headers['set-cookie'][0].split(';')[0];const done=await request('/auth/google/callback?state='+flow.state+'&code=fixture',{headers:{cookie:guestCookie+'; '+initial}});assert.equal(done.status,303);const authCookie=done.headers['set-cookie'][0].split(';')[0];const cookie=guestCookie+'; '+authCookie;const s=(await request('/auth/session',{headers:{cookie}})).json();return {cookie,s,headers:{cookie,origin,'x-csrf-token':s.csrfToken,'content-type':'application/json'}};}
 return {db,request,session,guestStore,login};
}
test('guest bootstrap uses secure opaque cookie; no Google customer is invented',async t=>{
 const f=await setup(t);const a=await f.session();assert.match(a.rawCookie,/^__Host-olesence_guest=[A-Za-z0-9_-]{43}; Path=\/; Secure; HttpOnly; SameSite=Lax; Max-Age=86400$/);assert.equal(a.s.guest,true);assert.equal(a.s.user,null);assert.equal(a.s.customerReady,true);
 const again=await f.request('/api/checkout/session',{headers:{cookie:a.cookie}});assert.equal(again.json().guestId,a.s.guestId);assert.equal(again.headers['set-cookie'],undefined);assert.equal((await f.db.query('SELECT count(*)::int AS n FROM commerce_customers')).rows[0].n,0);
 assert.equal((await f.request('/admin/api/orders',{headers:{cookie:a.cookie}})).status,401);
 assert.equal((await f.request('/api/checkout/orders',{headers:{cookie:'__Host-olesence_guest='+ 'a'.repeat(43)}})).status,401);
});
test('guest quote/order/replay/history are cookie scoped and retain price/stock/CSRF protections',async t=>{
 const f=await setup(t),a=await f.session(),b=await f.session();const qbody={items:[{productId:'crni-kim',quantity:1}]};
 for(const headers of [{},{...a.headers,origin:'https://evil.invalid'},{...a.headers,'x-csrf-token':'wrong'},{...a.headers,'sec-fetch-site':'cross-site'}])assert.ok([401,403].includes((await f.request('/api/checkout/quote',{method:'POST',headers,body:qbody})).status));
 const quote=(await f.request('/api/checkout/quote',{method:'POST',headers:a.headers,body:qbody})).json();assert.equal(quote.totalMinor,179000);
 const body={items:quote.items.map(i=>({productId:i.productId,quantity:i.quantity,expectedRevision:i.productRevision})),contact,shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:179000};const headers={...a.headers,'idempotency-key':'synthetic_guest_key_0001'};
 assert.equal((await f.request('/api/checkout/orders',{method:'POST',headers,body:{...body,expectedTotalMinor:1}})).status,409);
 assert.equal((await f.request('/api/checkout/orders',{method:'POST',headers:{...b.headers,'x-csrf-token':a.s.csrfToken,'idempotency-key':'synthetic_guest_key_0002'},body})).status,403);
 assert.equal((await f.request('/api/checkout/orders',{method:'POST',headers,body:{...body,guestId:a.s.guestId}})).status,400);
 const placed=await f.request('/api/checkout/orders',{method:'POST',headers,body});assert.equal(placed.status,201);const id=placed.json().order.id;assert.equal(placed.json().order.paymentStatus,'cod_due');assert.equal(placed.json().order.contact.email,contact.email);
 const replay=await f.request('/api/checkout/orders',{method:'POST',headers,body});assert.equal(replay.status,200);assert.equal(replay.json().order.id,id);
 assert.equal((await f.request('/api/checkout/orders/'+id,{headers:a.headers})).status,200);assert.equal((await f.request('/api/checkout/orders/'+id,{headers:b.headers})).status,404);assert.equal((await f.request('/api/checkout/orders/'+id,{headers:{'x-guest-id':a.s.guestId}})).status,401);
 assert.equal((await f.request('/api/checkout/orders',{headers:b.headers})).json().orders.length,0);assert.equal((await f.request('/api/checkout/orders',{headers:a.headers})).json().orders.length,1);
 assert.equal((await f.db.query("SELECT document FROM admin_products WHERE id='crni-kim'")).rows[0].document.stockQuantity,1);
 await f.db.query('UPDATE guest_checkout_sessions SET created_at=now()-interval \'2 hours\', expires_at=now()-interval \'1 second\' WHERE id=$1',[a.s.guestId]);assert.equal((await f.request('/api/checkout/orders/'+id,{headers:a.headers})).status,401);
});
test('persistent guest creation and request quotas reject excessive traffic',async t=>{
 const f=await setup(t,{creationLimit:1,quoteLimit:1}),a=await f.session();assert.equal((await f.request('/api/checkout/session')).status,429);
 const options={method:'POST',headers:a.headers,body:{items:[{productId:'crni-kim',quantity:1}]}};assert.equal((await f.request('/api/checkout/quote',options)).status,200);assert.equal((await f.request('/api/checkout/quote',options)).status,429);
});
test('guest HTTP orders require a valid email without account creation or verification',async t=>{
 const f=await setup(t),a=await f.session();
 const body={items:[{productId:'crni-kim',quantity:1,expectedRevision:1}],contact:{...contact},shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:179000};
 for(const [index,email] of [undefined,'','   ',null,'invalid','x@example','x\ny@example.invalid'].entries()){
  const result=await f.request('/api/checkout/orders',{method:'POST',headers:{...a.headers,'idempotency-key':'guest_email_invalid_'+index},body:{...body,contact:{...contact,email}}});
  assert.equal(result.status,400);
 }
 assert.equal((await f.db.query('SELECT count(*)::int AS count FROM admin_orders')).rows[0].count,0);
 assert.equal((await f.db.query('SELECT count(*)::int AS count FROM admin_order_items')).rows[0].count,0);
 const before=(await f.db.query("SELECT document,revision FROM admin_products WHERE id='crni-kim'")).rows[0];assert.equal(before.document.stockQuantity,2);assert.equal(before.revision,1);
 const valid=await f.request('/api/checkout/orders',{method:'POST',headers:{...a.headers,'idempotency-key':'guest_email_valid_001'},body:{...body,contact:{...contact,email:' synthetic@example.invalid '}}});
 assert.equal(valid.status,201);assert.equal(valid.json().order.contact.email,contact.email);assert.equal(valid.json().order.customerId,null);assert.equal(valid.json().order.guestId,a.s.guestId);
 assert.equal((await f.db.query('SELECT count(*)::int AS count FROM commerce_customers')).rows[0].count,0);
 const current=(await f.request('/api/checkout/session',{headers:a.headers})).json();assert.equal(current.user,null);assert.equal(current.guest,true);
});
test('guest enable flag fails closed without enabled COD',()=>{assert.throws(()=>readHostedConfig({RENDER:'true',CUSTOMER_AUTH_ORIGIN:origin,CHECKOUT_GUEST_ENABLED:'1'}),/Guest checkout/);});

test('Google identity takes precedence over guest cookie; logout restores only browser-owned guest history',async t=>{
 const f=await setup(t),a=await f.session();const body={items:[{productId:'crni-kim',quantity:1,expectedRevision:1}],contact,shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:179000};
 const made=await f.request('/api/checkout/orders',{method:'POST',headers:{...a.headers,'idempotency-key':'guest_google_boundary_01'},body});assert.equal(made.status,201);const id=made.json().order.id;
 const google=await f.login(a.cookie),both=(await f.request('/api/checkout/session',{headers:{cookie:google.cookie}})).json();assert.equal(both.guest,false);assert.equal(both.guestId,null);assert.equal(both.user.provider,'google');
 assert.equal((await f.request('/api/checkout/orders',{headers:google.headers})).json().orders.length,0);assert.equal((await f.request('/api/checkout/orders/'+id,{headers:google.headers})).status,404);
 assert.equal((await f.request('/api/checkout/orders',{method:'POST',headers:{...google.headers,'x-csrf-token':a.s.csrfToken,'idempotency-key':'guest_google_boundary_02'},body})).status,403);
 const logout=await f.request('/auth/logout',{method:'POST',headers:google.headers});assert.equal(logout.status,200);
 assert.equal((await f.request('/api/checkout/orders/'+id,{headers:a.headers})).status,200);assert.equal((await f.request('/admin/api/orders',{headers:a.headers})).status,401);
});
