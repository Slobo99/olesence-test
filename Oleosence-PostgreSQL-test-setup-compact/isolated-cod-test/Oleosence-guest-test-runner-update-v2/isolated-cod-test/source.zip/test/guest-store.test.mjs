import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {createCodStore} from '../src/cod-store.mjs';
import {createGuestStore} from '../src/guest-store.mjs';
import {createPostgresStore} from '../src/admin-store.mjs';

const customerId='11111111-1111-4111-8111-111111111111';
const unknownId='22222222-2222-4222-8222-222222222222';
const contact={fullName:'Gost Kupac',email:'guest@example.invalid',phone:'0600000000',address:'Izmisljena 1',city:'Beograd',postalCode:'11000',country:'RS'};
const status=expected=>error=>error.status===expected;
const hash=value=>createHash('sha256').update(value).digest('hex');
const sessionInput=index=>({tokenHash:hash('opaque-random-token-fixture-'+index),csrfToken:'csrf_fixture_'+String(index).padStart(32,'0')});
const input=(guestId,key='guest_order_key_0001',overrides={})=>({owner:{guestId},items:[{productId:'p1',quantity:1,expectedRevision:1}],contact:{...contact},shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:179000,idempotencyKey:key,...overrides});

async function fixture(t,{migrateGuest=true,guestOptions={}}={}){
 const db=new PGlite();
 // PGlite has one connection. Serialize complete transactions and standalone
 // queries. These checks verify SQL behavior, not a multi-connection race.
 let queue=Promise.resolve();
 async function acquire(){const previous=queue;let release;queue=new Promise(resolve=>{release=resolve;});await previous;return release;}
 const queries=[];
 const query=async(sql,args)=>{queries.push(sql);return sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args);};
 const pool={async query(sql,args){const release=await acquire();try{return await query(sql,args);}finally{release();}},async connect(){const release=await acquire();return {query,release};}};
 for(const file of ['001_admin.sql','002_product_images.sql','003_customers.sql','004_order_model.sql','005_cod_checkout.sql',...(migrateGuest?['006_guest_checkout.sql']:[])])await db.exec(await readFile(new URL('../migrations/'+file,import.meta.url),'utf8'));
 await db.query("INSERT INTO commerce_customers(id,provider,subject,email,name) VALUES($1,'google','verified-subject','buyer@example.invalid','Test Kupac')",[customerId]);
 for(const [id,priceMinor] of [['p1',149000],['p2',159000]])await db.query('INSERT INTO admin_products(id,document) VALUES($1,$2::jsonb)',[id,JSON.stringify({name:'Original '+id,priceMinor,stockQuantity:5,available:true})]);
 const guests=createGuestStore(pool,guestOptions),cod=createCodStore(pool);
 let sessionNumber=0;
 const newGuest=()=>guests.createSession(sessionInput(++sessionNumber));
 const stock=async(id='p1')=>(await db.query('SELECT document,revision FROM admin_products WHERE id=$1',[id])).rows[0];
 const counts=async()=>(await db.query('SELECT (SELECT count(*)::int FROM commerce_customers) AS customers,(SELECT count(*)::int FROM admin_orders) AS orders,(SELECT count(*)::int FROM admin_order_items) AS items')).rows[0];
 const expire=guestId=>db.query("UPDATE guest_checkout_sessions SET created_at=now()-interval '25 hours',expires_at=now()-interval '1 hour' WHERE id=$1",[guestId]);
 t.after(()=>db.close());
 return {db,pool,queries,guests,cod,newGuest,stock,counts,expire,admin:createPostgresStore(pool)};
}

test('guest sessions persist only token hashes, last 24 hours and never create customers',async t=>{
 const {db,pool,guests,newGuest,counts}=await fixture(t);
 const guest=await newGuest();
 assert.match(guest.id,/^[a-f0-9-]{36}$/);assert.equal(guest.csrfToken,sessionInput(1).csrfToken);
 assert.equal(new Date(guest.expiresAt)-new Date(guest.createdAt),86400000);
 assert.equal(Object.hasOwn(guest,'tokenHash'),false);
 const persisted=(await db.query('SELECT * FROM guest_checkout_sessions WHERE id=$1',[guest.id])).rows[0];
 assert.equal(persisted.token_hash,sessionInput(1).tokenHash);assert.equal(Object.hasOwn(persisted,'token'),false);
 assert.deepEqual(await createGuestStore(pool).getSession(sessionInput(1).tokenHash),guest);
 assert.equal(await guests.getSession('opaque-random-token-fixture-1'),null);
 assert.equal(await guests.getSession(hash('different-token')),null);
 assert.deepEqual(await counts(),{customers:1,orders:0,items:0});
 for(const patch of [{tokenHash:'bad'},{tokenHash:'A'.repeat(64)},{csrfToken:'short'},{csrfToken:'x'.repeat(32)+'<'},{}]){
  const value=Object.keys(patch).length?{...sessionInput(2),...patch}:{};
  await assert.rejects(guests.createSession(value),status(400));
 }
});

test('guest quote and COD creation use authoritative snapshots and deduct stock atomically',async t=>{
 const {db,cod,newGuest,stock,counts,queries}=await fixture(t);const guest=await newGuest();
 const quote=await cod.quote({guestId:guest.id},[{productId:'p1',quantity:1}]);
 assert.equal(quote.totalMinor,179000);assert.equal(quote.items[0].productRevision,1);assert.equal((await stock()).document.stockQuantity,5);
 const result=await cod.createOrder(input(guest.id));
 assert.equal(result.replayed,false);assert.equal(result.order.customerId,null);assert.equal(result.order.guestId,guest.id);
 assert.equal(result.order.contact.email,contact.email);assert.equal(result.order.totalMinor,179000);assert.equal(result.order.paymentStatus,'cod_due');assert.equal(result.order.inventoryStatus,'deducted');
 assert.deepEqual((await db.query('SELECT customer_id,guest_id,model_version,snapshot_sealed FROM admin_orders WHERE id=$1',[result.order.id])).rows[0],{customer_id:null,guest_id:guest.id,model_version:2,snapshot_sealed:true});
 assert.equal((await stock()).document.stockQuantity,4);assert.equal((await stock()).revision,2);
 assert.deepEqual(await counts(),{customers:1,orders:1,items:1});
 assert(queries.some(sql=>sql.includes('guest_checkout_sessions')&&sql.includes('FOR UPDATE')));
 assert(queries.some(sql=>sql.includes('admin_products')&&sql.includes('FOR UPDATE')));
});

test('guest email is required without creating an account; invalid contact and owners fail closed',async t=>{
 const {cod,newGuest,counts,stock}=await fixture(t);const guest=await newGuest();
 for(const patch of [{owner:{}},{owner:{guestId:guest.id,customerId}},{owner:{guestId:'invalid'}},{owner:{guestId:guest.id,extra:true}},{customerId},{contact:{...contact,email:'invalid'}},{contact:{...contact,email:null}},{contact:{...contact,email:'x\ny@example.invalid'}},{contact:{...contact,phone:'------'}},{contact:{...contact,fullName:''}},{contact:{...contact,address:''}},{contact:{...contact,city:''}},{contact:{...contact,postalCode:'1100'}},{contact:{...contact,country:'US'}}])await assert.rejects(cod.createOrder(input(guest.id,undefined,patch)),status(400));
 for(const email of [undefined,'','   ',null,42,[],{},'missing-at.example.invalid','x@','x@example'])await assert.rejects(cod.createOrder(input(guest.id,undefined,{contact:{...contact,email}})),status(400));
 const withoutEmail={...contact};delete withoutEmail.email;
 await assert.rejects(cod.createOrder(input(guest.id,undefined,{contact:withoutEmail})),status(400));
 await assert.rejects(cod.createOrder(input(guest.id,undefined,{owner:{customerId},contact:{...contact,email:''}})),status(400));
 await assert.rejects(cod.createOrder(input(guest.id,undefined,{owner:{customerId},contact:withoutEmail})),status(400));
 assert.deepEqual(await counts(),{customers:1,orders:0,items:0});
 assert.equal((await stock()).document.stockQuantity,5);assert.equal((await stock()).revision,1);
 const one=(await cod.createOrder(input(guest.id,undefined,{contact:{...contact,email:' guest@example.invalid '}}))).order;
 assert.equal(one.contact.email,'guest@example.invalid');assert.equal(one.customerId,null);assert.equal(one.guestId,guest.id);
 assert.deepEqual(await counts(),{customers:1,orders:1,items:1});
});

test('same-owner idempotency replays once and remains isolated between guests and customers',async t=>{
 const {cod,newGuest,stock,counts}=await fixture(t);const a=await newGuest(),b=await newGuest();
 const results=await Promise.all(Array.from({length:6},()=>cod.createOrder(input(a.id))));
 assert.equal(new Set(results.map(r=>r.order.id)).size,1);assert.equal(results.filter(r=>!r.replayed).length,1);
 await assert.rejects(cod.createOrder(input(a.id,undefined,{contact:{...contact,city:'Novi Sad'}})),status(409));
 const guestB=(await cod.createOrder(input(b.id,undefined,{items:[{productId:'p1',quantity:1,expectedRevision:2}]}))).order;
 const customer=(await cod.createOrder(input(a.id,undefined,{owner:{customerId},items:[{productId:'p1',quantity:1,expectedRevision:3}],contact:{...contact,email:'buyer@example.invalid'}}))).order;
 assert.equal(new Set([results[0].order.id,guestB.id,customer.id]).size,3);
 assert.equal((await stock()).document.stockQuantity,2);assert.deepEqual(await counts(),{customers:1,orders:3,items:3});
 assert.equal(await cod.getOwnerOrder({guestId:b.id},results[0].order.id),null);
 assert.equal(await cod.getCustomerOrder(customerId,results[0].order.id),null);
 assert.equal(await cod.getOwnerOrder({guestId:a.id},customer.id),null);
 assert.equal((await cod.listCustomerOrders(customerId)).orders.length,1);
 assert.equal((await cod.listGuestOrders(a.id)).orders.length,1);
});

test('guest history pagination is scoped and keeps snapshots after catalog edits',async t=>{
 const {cod,newGuest,admin}=await fixture(t);const a=await newGuest(),b=await newGuest();
 const orders=[];for(const revision of [1,2,3])orders.push((await cod.createOrder(input(a.id,'guest_history_key_'+revision,{items:[{productId:'p1',quantity:1,expectedRevision:revision}]}))).order);
 await admin.updateProduct('p1',4,{name:'Later name',priceMinor:1},'google:approved-admin');
 const first=await cod.listGuestOrders(a.id,{limit:2});assert.equal(first.orders.length,2);assert(first.nextCursor);assert.equal(first.orders[0].id,orders[2].id);
 const second=await cod.listGuestOrders(a.id,{limit:2,before:first.nextCursor});assert.equal(second.orders.length,1);assert.equal(second.nextCursor,null);assert.equal(second.orders[0].id,orders[0].id);
 assert.equal(second.orders[0].items[0].name,'Original p1');assert.equal(second.orders[0].items[0].unitPriceMinor,149000);
 assert.deepEqual((await cod.listGuestOrders(b.id)).orders,[]);
 assert.equal((await cod.getOwnerOrder({guestId:a.id},orders[0].id)).totalMinor,179000);
 for(const options of [{limit:0},{limit:101},{before:'-1'},{before:'1 OR 1=1'}])await assert.rejects(cod.listGuestOrders(a.id,options),status(400));
});

test('expiry blocks reads, quotes, order creation and duplicate replay without deleting orders',async t=>{
 const {db,guests,cod,newGuest,expire,counts,stock}=await fixture(t);const guest=await newGuest();const saved=await cod.createOrder(input(guest.id));await expire(guest.id);
 assert.equal(await guests.getSession(sessionInput(1).tokenHash),null);assert.equal(await guests.consumeRateLimit(guest.id,'read'),false);
 for(const action of [()=>cod.quote({guestId:guest.id},[{productId:'p1',quantity:1}]),()=>cod.createOrder(input(guest.id)),()=>cod.getOwnerOrder({guestId:guest.id},saved.order.id),()=>cod.listGuestOrders(guest.id),()=>cod.quote({guestId:unknownId},[{productId:'p1',quantity:1}])])await assert.rejects(action(),status(401));
 assert.deepEqual(await counts(),{customers:1,orders:1,items:1});assert.equal((await stock()).document.stockQuantity,4);
 assert.equal((await db.query('SELECT guest_id FROM admin_orders WHERE id=$1',[saved.order.id])).rows[0].guest_id,guest.id);
});

test('persistent quote, submit and read limits survive store reconstruction and reset by DB windows',async t=>{
 const options={quoteLimit:2,submitLimit:2,readLimit:2};const {db,pool,guests,newGuest}=await fixture(t,{guestOptions:options});const a=await newGuest(),b=await newGuest();
 for(const action of ['quote','submit','read']){
  const results=await Promise.all(Array.from({length:5},()=>guests.consumeRateLimit(a.id,action)));assert.equal(results.filter(Boolean).length,2);
  assert.equal(await createGuestStore(pool,options).consumeRateLimit(a.id,action),false);
  assert.equal(await guests.consumeRateLimit(b.id,action),true);
  await db.query(`UPDATE guest_checkout_sessions SET ${action}_window_started_at=now()-interval '2 hours' WHERE id=$1`,[a.id]);
  assert.equal(await guests.consumeRateLimit(a.id,action),true);
  assert.equal((await db.query(`SELECT ${action}_count AS count FROM guest_checkout_sessions WHERE id=$1`,[a.id])).rows[0].count,1);
 }
 for(const [id,action] of [[a.id,'constructor'],[a.id,'read_count=0'],['not-a-uuid','read']])await assert.rejects(guests.consumeRateLimit(id,action),status(400));
 assert.equal(await guests.consumeRateLimit(unknownId,'read'),false);
});

test('global session creation cap persists across stores and does not trust IPs or cookies',async t=>{
 const {db,pool,guests}=await fixture(t,{guestOptions:{creationLimit:3}});
 const attempts=await Promise.allSettled(Array.from({length:6},(_,i)=>guests.createSession(sessionInput(i))));
 assert.equal(attempts.filter(r=>r.status==='fulfilled').length,3);assert.equal(attempts.filter(r=>r.status==='rejected'&&r.reason.status===429).length,3);
 await assert.rejects(createGuestStore(pool,{creationLimit:3}).createSession(sessionInput(10)),status(429));
 assert.equal((await db.query('SELECT count(*)::int AS count FROM guest_checkout_sessions')).rows[0].count,3);
 assert.equal((await db.query("SELECT request_count FROM guest_checkout_limits WHERE bucket='session_creation'")).rows[0].request_count,3);
 await db.query("UPDATE guest_checkout_limits SET window_started_at=now()-interval '2 hours'");
 assert((await guests.createSession(sessionInput(10))).id);
 assert.equal((await db.query("SELECT request_count FROM guest_checkout_limits WHERE bucket='session_creation'")).rows[0].request_count,1);
});

test('global creation burst limit persists and rejected bursts do not spend the hourly quota',async t=>{
 const options={creationLimit:20,creationBurstLimit:2};const {db,pool,guests}=await fixture(t,{guestOptions:options});
 const attempts=await Promise.allSettled(Array.from({length:5},(_,i)=>guests.createSession(sessionInput(i))));
 assert.equal(attempts.filter(r=>r.status==='fulfilled').length,2);assert.equal(attempts.filter(r=>r.status==='rejected'&&r.reason.status===429).length,3);
 await assert.rejects(createGuestStore(pool,options).createSession(sessionInput(10)),status(429));
 assert.equal((await db.query("SELECT request_count FROM guest_checkout_limits WHERE bucket='session_creation'")).rows[0].request_count,2);
 await db.query("UPDATE guest_checkout_limits SET window_started_at=now()-interval '2 minutes' WHERE bucket='session_creation_burst'");
 assert((await guests.createSession(sessionInput(10))).id);
 assert.equal((await db.query("SELECT request_count FROM guest_checkout_limits WHERE bucket='session_creation'")).rows[0].request_count,3);
});

test('global submission cap spans guest cookies, persists, and rolls back rejected owner increments',async t=>{
 const options={globalSubmitLimit:3,submitLimit:10};const {db,pool,guests,newGuest}=await fixture(t,{guestOptions:options});const a=await newGuest(),b=await newGuest();
 const attempts=await Promise.all([guests.consumeRateLimit(a.id,'submit'),guests.consumeRateLimit(b.id,'submit'),guests.consumeRateLimit(a.id,'submit'),guests.consumeRateLimit(b.id,'submit'),guests.consumeRateLimit(a.id,'submit')]);
 assert.equal(attempts.filter(Boolean).length,3);
 assert.equal(await createGuestStore(pool,options).consumeRateLimit(b.id,'submit'),false);
 assert.equal((await db.query('SELECT sum(submit_count)::int AS count FROM guest_checkout_sessions')).rows[0].count,3);
 assert.equal((await db.query("SELECT request_count FROM guest_checkout_limits WHERE bucket='global_submission'")).rows[0].request_count,3);
 assert.equal(await guests.consumeRateLimit(a.id,'quote'),true);assert.equal(await guests.consumeRateLimit(b.id,'read'),true);
 await db.query("UPDATE guest_checkout_limits SET window_started_at=now()-interval '2 minutes' WHERE bucket='global_submission'");
 assert.equal(await guests.consumeRateLimit(b.id,'submit'),true);
 assert.equal((await db.query("SELECT request_count FROM guest_checkout_limits WHERE bucket='global_submission'")).rows[0].request_count,1);
});

test('expired abandoned sessions are cleaned while order owner references remain intact',async t=>{
 const {db,cod,newGuest,expire}=await fixture(t);const used=await newGuest(),abandoned=await newGuest();const saved=await cod.createOrder(input(used.id));await expire(used.id);await expire(abandoned.id);const fresh=await newGuest();
 const ids=(await db.query('SELECT id FROM guest_checkout_sessions')).rows.map(r=>r.id);
 assert.deepEqual(new Set(ids),new Set([used.id,fresh.id]));
 assert.equal((await db.query('SELECT guest_id FROM admin_orders WHERE id=$1',[saved.order.id])).rows[0].guest_id,used.id);
 await assert.rejects(db.query('DELETE FROM guest_checkout_sessions WHERE id=$1',[used.id]),/foreign key/i);
});

test('a migration keeps old customer idempotency and all snapshot protections',async t=>{
 const {db,cod,admin,stock}=await fixture(t,{migrateGuest:false});
 const submission={...input(null),customerId,contact:{...contact,email:'buyer@example.invalid'}};delete submission.owner;
 const original=await cod.createOrder(submission);
 // Pinned by running the unchanged production cod-store normalizer from archive SHA67268840.
 assert.equal((await db.query('SELECT request_hash FROM admin_orders WHERE id=$1',[original.order.id])).rows[0].request_hash,'cb42ef0a938043f860a9d6e02611019034824978374707006aebc343b140ad66');
 await db.exec(await readFile(new URL('../migrations/006_guest_checkout.sql',import.meta.url),'utf8'));
 const modern={...submission,owner:{customerId}};delete modern.customerId;
 const replay=await cod.createOrder(modern);assert.equal(replay.replayed,true);assert.equal(replay.order.id,original.order.id);assert.equal((await stock()).document.stockQuantity,4);
 await admin.initialize([]);await admin.initialize([]);
 assert.deepEqual((await db.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(r=>r.version),[1,2,3,4,5,6]);
 assert.equal((await cod.getCustomerOrder(customerId,original.order.id)).totalMinor,179000);
});

test('database rejects guest owner reassignment, ownerless orders, dual owners and guest drafts',async t=>{
 const {db,cod,newGuest}=await fixture(t);const a=await newGuest(),b=await newGuest();const {order}=await cod.createOrder(input(a.id));
 for(const sql of ["UPDATE admin_orders SET guest_id=$2 WHERE id=$1","UPDATE admin_orders SET guest_id=NULL,customer_id=$2 WHERE id=$1"]){await assert.rejects(db.query(sql,[order.id,sql.includes('customer_id')?customerId:b.id]),/immutable/i);}
 for(const sql of ["UPDATE admin_orders SET contact_snapshot='{}' WHERE id=$1","UPDATE admin_orders SET total_minor=1 WHERE id=$1","UPDATE admin_orders SET shipping_snapshot='{}' WHERE id=$1","UPDATE admin_orders SET snapshot_sealed=false WHERE id=$1","UPDATE admin_orders SET document='{}' WHERE id=$1","UPDATE admin_orders SET payment_status='paid' WHERE id=$1","UPDATE admin_orders SET inventory_status='unreserved' WHERE id=$1","UPDATE admin_order_items SET quantity=2,line_total_minor=298000 WHERE order_id=$1","DELETE FROM admin_order_items WHERE order_id=$1"])await assert.rejects(db.query(sql,[order.id]));
 const insert=`INSERT INTO admin_orders(id,document,status,model_version,snapshot_sealed,customer_id,guest_id,contact_snapshot,currency,subtotal_minor,delivery_minor,total_minor,shipping_snapshot,payment_method,payment_status,inventory_status,idempotency_key,request_hash)
  VALUES($1,'{}',$2,$3,true,$4,$5,'{}','RSD',0,0,0,'{}',$6,$7,$8,'constraint_test_key_01',$9)`;
 for(const [id,version,cid,gid] of [['ownerless',2,null,null],['twoowners',2,customerId,b.id],['guestdraft',1,null,b.id],['dualdraft',1,customerId,b.id]])await assert.rejects(db.query(insert,[id,version===1?'draft':'pending',version,cid,gid,version===1?null:'cod',version===1?'not_processed':'cod_due',version===1?'unreserved':'deducted',hash(id)]),/admin_orders_structured_check/);
 await assert.rejects(db.query(`INSERT INTO admin_orders(id,document,status,model_version,snapshot_sealed,guest_id,contact_snapshot,currency,subtotal_minor,delivery_minor,total_minor,shipping_snapshot,payment_method,payment_status,inventory_status,idempotency_key,request_hash)
  SELECT 'duplicate-guest-owner',document,status,model_version,snapshot_sealed,guest_id,contact_snapshot,currency,subtotal_minor,delivery_minor,total_minor,shipping_snapshot,payment_method,payment_status,inventory_status,idempotency_key,request_hash FROM admin_orders WHERE id=$1`,[order.id]),/admin_orders_guest_idempotency/);
 await db.exec('BEGIN');await db.query(insert,['no-lines','pending',2,null,b.id,'cod','cod_due','deducted',hash('no-lines')]);
 await assert.rejects(db.exec('COMMIT'),/Order lines do not match snapshot totals/);await db.exec('ROLLBACK');
 await assert.rejects(db.query("INSERT INTO admin_order_items(order_id,line_number,product_id,sku_snapshot,name_snapshot,quantity,unit_price_minor,line_total_minor,product_revision) VALUES($1,2,'p2','p2','Extra',1,0,0,1)",[order.id]),/sealed/i);
});

test('guest price, revision, availability and whole-basket failures preserve inventory',async t=>{
 const {db,cod,newGuest,stock,counts}=await fixture(t);const guest=await newGuest();
 for(const patch of [{expectedTotalMinor:1},{items:[{productId:'p1',quantity:1,expectedRevision:2}]},{items:[{productId:'p1',quantity:6,expectedRevision:1}]}])await assert.rejects(cod.createOrder(input(guest.id,undefined,patch)),status(409));
 await db.query("UPDATE admin_products SET document=document || '{\"stockQuantity\":0}' WHERE id='p2'");
 await assert.rejects(cod.createOrder(input(guest.id,undefined,{items:[{productId:'p1',quantity:1,expectedRevision:1},{productId:'p2',quantity:1,expectedRevision:1}],expectedTotalMinor:338000})),status(409));
 assert.equal((await stock()).document.stockQuantity,5);assert.equal((await stock()).revision,1);assert.deepEqual(await counts(),{customers:1,orders:0,items:0});
});

test('last-unit competition across guest and customer owners permits one transaction',async t=>{
 const {db,cod,newGuest,stock,counts}=await fixture(t);const guest=await newGuest();await db.query("UPDATE admin_products SET document=document || '{\"stockQuantity\":1}' WHERE id='p1'");
 const results=await Promise.allSettled([cod.createOrder(input(guest.id)),cod.createOrder(input(null,undefined,{owner:{customerId},contact:{...contact,email:'buyer@example.invalid'}}))]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(results.filter(r=>r.status==='rejected'&&r.reason.status===409).length,1);
 assert.equal((await stock()).document.stockQuantity,0);assert.equal((await stock()).document.available,false);assert.deepEqual(await counts(),{customers:1,orders:1,items:1});
});

test('guest commit failures roll back order lines and stock; admin cancellation never restores stock',async t=>{
 const {db,cod,newGuest,stock,counts,admin,queries}=await fixture(t);const guest=await newGuest();
 await db.exec(`CREATE FUNCTION reject_guest_fixture_commit() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'guest fixture rejects commit'; END $$;
 CREATE CONSTRAINT TRIGGER guest_fixture_commit_failure AFTER INSERT ON admin_orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION reject_guest_fixture_commit();`);
 await assert.rejects(cod.createOrder(input(guest.id)),/guest fixture rejects commit/);
 assert(queries.some(sql=>sql.includes('UPDATE admin_products')));assert(queries.includes('COMMIT'));assert(queries.includes('ROLLBACK'));
 assert.deepEqual(await counts(),{customers:1,orders:0,items:0});assert.equal((await stock()).document.stockQuantity,5);
 await db.exec('DROP TRIGGER guest_fixture_commit_failure ON admin_orders');
 const order=(await cod.createOrder(input(guest.id))).order;
 const cancelled=await admin.updateOrder(order.id,1,{status:'cancelled'},'google:approved-admin');
 assert.equal(cancelled.paymentStatus,'cod_cancelled');assert.equal(cancelled.inventoryStatus,'deducted_manual_adjustment_required');assert.equal((await stock()).document.stockQuantity,4);
 assert.equal((await cod.getOwnerOrder({guestId:guest.id},order.id)).status,'cancelled');
});
