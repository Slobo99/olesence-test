import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readFile,readdir} from 'node:fs/promises';
import {readHostedConfig,createHostedServer} from '../server.mjs';
const origin='https://test-login.onrender.com',host='test-login.onrender.com',clientId='unit-test.apps.googleusercontent.com';
const cfg={origin,host,auth:{origin,clientId,clientSecret:'fictional-test-only-secret',redirectUri:origin+'/auth/google/callback',secure:true}};
const request=(port,path,headers={},method='GET')=>new Promise((resolve,reject)=>{const q=http.request({hostname:'127.0.0.1',port,path,method,headers:{host,'x-forwarded-proto':'https',...headers}},r=>{let text='';r.on('data',b=>text+=b);r.on('end',()=>resolve({status:r.statusCode,headers:r.headers,text,json:()=>JSON.parse(text)}));});q.on('error',reject);q.end();});
async function app(t,options={}){const a=await createHostedServer({config:{origin,host,auth:null},...options});await new Promise(r=>a.server.listen(0,'127.0.0.1',r));t.after(()=>a.close());return {a,get:(p,h,m)=>request(a.server.address().port,p,h,m)};}
test('hosted config requires explicit canonical HTTPS origin and Render environment',()=>{
 assert.throws(()=>readHostedConfig({}));assert.throws(()=>readHostedConfig({CUSTOMER_AUTH_ORIGIN:origin}));
 for(const o of ['http://example.com','https://example.com/','https://user@example.com','https://example.com:8443','https://localhost'])assert.throws(()=>readHostedConfig({RENDER:'true',CUSTOMER_AUTH_ORIGIN:o}));
 assert.equal(readHostedConfig({RENDER:'true',CUSTOMER_AUTH_ORIGIN:origin}).auth,null);
 assert.equal(readHostedConfig({RENDER:'true',CUSTOMER_AUTH_ORIGIN:origin,CUSTOMER_GOOGLE_ENABLED:'1'}).auth,null);
});
test('disabled by default, only public assets served; all private/admin/order/traversal paths fail closed',async t=>{
 const {get}=await app(t);
 assert.equal((await get('/auth/session')).json().enabled,false);
 assert.equal((await get('/auth/google/start',{origin},'POST')).status,503);
 for(const p of ['/admin','/admin.html','/admin.js','/api/admin/state','/api/orders','/test-shop.html','/test-shop.js','/test-server.mjs','/customer-server.mjs','/src/customer-auth.mjs','/.env','/package.json','/node_modules/google-auth-library/package.json','/../server.mjs','/%2e%2e/server.mjs','/assets/../server.mjs','/unknown'])assert.equal((await get(p)).status,404,p);
 for(const p of ['/','/index.html','/account','/account.js','/styles.css','/catalog.js','/assets/origano.jpg','/proizvod/crni-kim','/proizvod/divlji-origano/','/proizvod/cetiri-lopova/index.html'])assert.equal((await get(p)).status,200,p);
 const r=await get('/');assert.match(r.text,/Moj nalog/);assert.match(r.headers['content-security-policy'],/frame-ancestors 'none'/);assert.equal(r.headers['cache-control'],'no-store');assert.equal(r.headers['access-control-allow-origin'],undefined);
});
test('strict host, proxy HTTPS, origin and fetch metadata controls; health exposes nothing',async t=>{
 const {get}=await app(t);
 for(const h of [{host:'attacker.invalid'},{'x-forwarded-proto':'http'},{'x-forwarded-proto':'https,http'},{origin:'https://evil.invalid'},{'sec-fetch-site':'same-site'},{'sec-fetch-site':'cross-site'}])assert.ok((await get('/auth/session',h)).status>=400);
 assert.equal((await get('/healthz',{host:'internal', 'x-forwarded-proto':'http'})).json().ok,true);
 assert.equal((await get('/auth/google/start',{},'POST')).status,403);
 assert.equal((await get('/auth/google/start')).status,404);
 assert.equal((await get('/auth/logout',{},'POST')).status,403);
 assert.equal((await get('/auth/logout')).status,404);
 for(const p of ['/','/account','/proizvod/crni-kim'])assert.equal((await get(p,{'sec-fetch-site':'cross-site','sec-fetch-mode':'navigate','sec-fetch-dest':'document'})).status,200);
});
test('hosted mocked login rotates Secure __Host cookie, callback replay fails, logout needs Origin and CSRF',async t=>{
 let flow;const provider={authorizationURL(f){flow=f;return 'https://accounts.google.com/mock';},async exchange(){return {iss:'https://accounts.google.com',aud:clientId,sub:'test-subject',iat:1000,exp:4600,nonce:flow.nonce,email:'test@example.invalid',email_verified:true,name:'Test',role:'admin'};}};
 const {get}=await app(t,{config:cfg,provider,clock:()=>1000000});
 const start=await get('/auth/google/start',{origin},'POST');assert.equal(start.status,200);assert.equal(start.json().url,'https://accounts.google.com/mock');
 const c=start.headers['set-cookie'][0];assert.match(c,/^__Host-oleosence_customer=/);assert.match(c,/HttpOnly; SameSite=Lax; Max-Age=300; Secure/);assert.ok(!c.includes('Domain='));
 const path='/auth/google/callback?state='+flow.state+'&code=fictional';
 const h={cookie:c.split(';')[0],'sec-fetch-site':'cross-site','sec-fetch-mode':'navigate','sec-fetch-dest':'document'};
 assert.equal((await get(path,{...h,'sec-fetch-mode':'cors'})).status,403);
 const done=await get(path,h);assert.equal(done.status,303);assert.equal(done.headers.location,'/account');
 const cookie=done.headers['set-cookie'][0].split(';')[0];assert.notEqual(cookie,h.cookie);
 const session=(await get('/auth/session',{cookie})).json();assert.equal(session.user.role,'customer');assert.equal(session.checkoutLinked,false);assert.equal(session.testOnly,true);
 assert.equal((await get(path,h)).headers.location,'/account?login=failed');
 assert.equal((await get('/auth/logout',{cookie,origin},'POST')).status,403);
 assert.equal((await get('/auth/logout',{cookie,origin,'x-csrf-token':session.csrfToken},'POST')).status,200);
 assert.equal((await get('/auth/session',{cookie})).json().user,null);
});
test('login flood is bounded; no X-Forwarded-For trust or unbounded rate-key map',async t=>{
 const {get}=await app(t,{rateLimit:2,config:cfg,provider:{authorizationURL:()=> 'https://accounts.google.com/mock'}});
 assert.equal((await get('/auth/google/start',{origin},'POST')).status,200);assert.equal((await get('/auth/google/start',{origin},'POST')).status,200);
 assert.equal((await get('/auth/google/start',{origin,'x-forwarded-for':'8.8.8.8'},'POST')).status,429);
});
test('package has no private test/admin/order implementations or inline executable scripts',async()=>{
 const files=await readdir(new URL('../',import.meta.url));for(const file of ['test-server.mjs','customer-server.mjs','.env'])assert.ok(!files.includes(file));
 const html=await readFile(new URL('../public/index.html',import.meta.url),'utf8');assert.ok(!/<script(?![^>]*src=)[^>]*>\s*\S/.test(html));
 const js=await readFile(new URL('../public/account.js',import.meta.url),'utf8');assert.ok(!js.includes('innerHTML'));assert.match(js,/pageshow/);assert.match(js,/login.disabled/);
});
