import test from 'node:test';
import assert from 'node:assert/strict';
import {PGlite} from '@electric-sql/pglite';
import {createPostgresStore} from '../src/admin-store.mjs';
import {createCustomerStore} from '../src/customer-store.mjs';
import {createOrderStore} from '../src/order-store.mjs';

test('admin reads sealed order snapshots, denies fulfillment, and repeated startup preserves data',async t=>{
 const db=new PGlite();t.after(()=>db.close());
 const query=(sql,args)=>sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args);
 const pool={query,async connect(){return {query,release(){}};}};
 const admin=createPostgresStore(pool);await admin.initialize([{id:'test-product',name:'Original name',priceMinor:149000}]);
 const customer=await createCustomerStore(pool).upsertVerifiedGoogleUser({id:'google:test-subject',provider:'google',subject:'test-subject',email:'test@example.invalid',name:'Test'});
 const {order}=await createOrderStore(pool,{allowDraftCreation:true}).createDraftOrder({customerId:customer.id,items:[{productId:'test-product',quantity:1,expectedRevision:1}],contact:{fullName:'Test Customer',email:'test@example.invalid',phone:'000000000',address:'Test 1',city:'Beograd',postalCode:'11000',country:'RS'},shippingMethod:'delivery-estimate',idempotencyKey:'integration_key_0001'});
 await admin.updateProduct('test-product',1,{name:'Later name',priceMinor:84000},'google:approved-admin');
 const listed=(await admin.listOrders()).orders[0];assert.equal(listed.id,order.id);assert.equal(listed.items[0].name,'Original name');assert.equal(listed.items[0].unitPriceMinor,149000);assert.equal(listed.totalMinor,179000);assert.equal(listed.customer.email,'test@example.invalid');
 await assert.rejects(admin.updateOrder(order.id,1,{status:'processing'},'google:approved-admin'),error=>error.status===409);
 await admin.initialize([]);assert.deepEqual((await admin.listOrders()).orders[0],listed);
 assert.equal((await db.query('SELECT count(*)::int AS n FROM commerce_customers')).rows[0].n,1);
 assert.equal((await db.query('SELECT count(*)::int AS n FROM admin_order_items')).rows[0].n,1);
});
