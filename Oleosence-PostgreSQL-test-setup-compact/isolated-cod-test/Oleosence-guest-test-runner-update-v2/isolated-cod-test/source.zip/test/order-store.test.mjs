import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {createOrderStore} from '../src/order-store.mjs';
const cid='11111111-1111-4111-8111-111111111111',other='22222222-2222-4222-8222-222222222222';
const contact={fullName:'Test Kupac',email:'example@example.invalid',phone:'000000000',address:'Izmisljena 1',city:'Beograd',postalCode:'11000',country:'RS'};
async function fixture(t){
 const db=new PGlite();let queue=Promise.resolve();const queries=[];
 const pool={query:async(sql,args)=>{queries.push(sql);return db.query(sql,args);},async connect(){let release;const wait=queue;queue=new Promise(r=>release=r);await wait;return {query:pool.query,release};}};
 for(const name of ['001_admin.sql','002_product_images.sql','003_customers.sql','004_order_model.sql'])await db.exec(await readFile(new URL('../migrations/'+name,import.meta.url),'utf8'));
 for(const [id,subject] of [[cid,'one'],[other,'two']])await db.query("INSERT INTO commerce_customers(id,provider,subject,email,name) VALUES($1,'google',$2,'test@example.invalid','Test')",[id,subject]);
 for(let i=1;i<=20;i++)await db.query('INSERT INTO admin_products(id,document) VALUES($1,$2::jsonb)',['p'+i,JSON.stringify({name:'Proizvod '+i,priceMinor:i===1?149000:i===2?159000:84000,stockQuantity:5,available:true})]);
 t.after(()=>db.close());return {db,pool,queries,store:createOrderStore(pool,{allowDraftCreation:true})};
}
const input=(key='unique_order_key_0001',overrides={})=>({customerId:cid,items:[{productId:'p1',quantity:1,expectedRevision:1}],contact,shippingMethod:'delivery-estimate',idempotencyKey:key,...overrides});
const status=code=>e=>e.status===code;
test('default off; drafts use server snapshots, never stock/payment/email changes',async t=>{
 const {db,pool,store,queries}=await fixture(t);await assert.rejects(createOrderStore(pool).createDraftOrder(input()),status(503));
 const {order,replayed}=await store.createDraftOrder(input());assert.equal(replayed,false);assert.equal(order.status,'draft');assert.equal(order.inventoryStatus,'unreserved');assert.equal(order.paymentStatus,'not_processed');assert.equal(order.subtotalMinor,149000);assert.equal(order.deliveryMinor,30000);assert.equal(order.totalMinor,179000);assert.equal(order.shipping.isEstimate,true);assert.equal(order.shipping.estimatedPackages,1);assert.equal(order.items[0].unitPriceMinor,149000);
 assert.equal((await db.query("SELECT document->>'stockQuantity' AS stock FROM admin_products WHERE id='p1'")).rows[0].stock,'5');assert(queries.some(s=>s.includes('commerce_customers')&&s.includes('FOR UPDATE')));assert(queries.some(s=>s.includes('admin_products')&&s.includes('FOR SHARE')));
});
test('same-customer duplicate submissions replay once; changed content conflicts',async t=>{
 const {db,store}=await fixture(t);const results=await Promise.all(Array.from({length:6},()=>store.createDraftOrder(input())));assert.equal(new Set(results.map(x=>x.order.id)).size,1);assert.equal(results.filter(x=>!x.replayed).length,1);assert.equal((await db.query('SELECT count(*)::int AS n FROM admin_orders')).rows[0].n,1);
 await assert.rejects(store.createDraftOrder(input(undefined,{contact:{...contact,city:'Novi Sad'}})),status(409));
 const second=await store.createDraftOrder(input(undefined,{customerId:other}));assert.notEqual(second.order.id,results[0].order.id);
});
test('snapshots and retries survive catalog price/name changes, preserve customer authorization',async t=>{
 const {db,store}=await fixture(t);const saved=await store.createDraftOrder(input());await db.query("UPDATE admin_products SET document=document || '{\"name\":\"Novo ime\",\"priceMinor\":1}',revision=2 WHERE id='p1'");
 const replay=await store.createDraftOrder(input());assert.equal(replay.replayed,true);assert.equal(replay.order.items[0].name,'Proizvod 1');assert.equal(replay.order.totalMinor,179000);assert.equal(await store.getCustomerOrder(other,saved.order.id),null);assert.equal((await store.listCustomerOrders(other)).orders.length,0);assert.equal((await store.getCustomerOrder(cid,saved.order.id)).items[0].unitPriceMinor,149000);
 await assert.rejects(store.createDraftOrder(input('another_unique_key_01')),status(409));
});
test('shipping threshold inclusive, all20 products, scoped history pagination',async t=>{
 const {db,store}=await fixture(t);await db.query("UPDATE admin_products SET document=document || '{\"priceMinor\":350000}' WHERE id='p1'");let r=await store.createDraftOrder(input());assert.equal(r.order.deliveryMinor,0);await db.query("UPDATE admin_products SET document=document || '{\"priceMinor\":349999}' WHERE id='p1'");r=await store.createDraftOrder(input('another_unique_key_02'));assert.equal(r.order.deliveryMinor,30000);
 const all=await store.createDraftOrder(input('another_unique_key_03',{items:Array.from({length:20},(_,i)=>({productId:'p'+(i+1),quantity:1,expectedRevision:1}))}));assert.equal(all.order.items.length,20);
 const page=await store.listCustomerOrders(cid,{limit:2});assert.equal(page.orders.length,2);assert(page.nextCursor);assert.equal((await store.listCustomerOrders(cid,{limit:2,before:page.nextCursor})).orders.length,1);assert.equal((await store.listCustomerOrders(other,{before:page.nextCursor})).orders.length,0);
});
test('reject malformed inputs and client prices without partial writes',async t=>{
 const {db,store}=await fixture(t);const cases=[{items:[]},{items:[{productId:'p1',quantity:1,expectedRevision:1,priceMinor:1}]},{items:[{productId:'p1',quantity:0,expectedRevision:1}]},{items:[{productId:'p1',quantity:1.5,expectedRevision:1}]},{items:Array(2).fill({productId:'p1',quantity:1,expectedRevision:1})},{totalMinor:0},{contact:{...contact,phone:'------'}},{contact:{...contact,postalCode:'BAD'}},{contact:{...contact,country:'US'}},{contact:{...contact,email:'x\ny@example.com'}},{contact:{...contact,address:'<script>'}},{shippingMethod:'paid'},{customerId:'invalid'},{idempotencyKey:'short'}];for(const bad of cases)await assert.rejects(store.createDraftOrder(input(undefined,bad)),status(400));
 await assert.rejects(store.createDraftOrder(input(undefined,{customerId:'33333333-3333-4333-8333-333333333333'})),status(404));await assert.rejects(store.createDraftOrder(input(undefined,{items:[{productId:'unknown',quantity:1,expectedRevision:1}]})),status(404));assert.equal((await db.query('SELECT count(*)::int AS n FROM admin_orders')).rows[0].n,0);
});
test('SQL constraints seal immutable snapshots and forbid fulfillment bypass',async t=>{
 const {db,store}=await fixture(t);const {order}=await store.createDraftOrder(input());
 for(const sql of ["UPDATE admin_orders SET total_minor=1 WHERE id=$1","UPDATE admin_orders SET status='processing' WHERE id=$1","UPDATE admin_orders SET customer_id='22222222-2222-4222-8222-222222222222' WHERE id=$1","UPDATE admin_orders SET snapshot_sealed=false WHERE id=$1","UPDATE admin_orders SET document='{}' WHERE id=$1","UPDATE admin_orders SET shipping_snapshot='{}' WHERE id=$1","UPDATE admin_order_items SET unit_price_minor=1 WHERE order_id=$1","DELETE FROM admin_order_items WHERE order_id=$1"] )await assert.rejects(db.query(sql,[order.id]));
 await assert.rejects(db.query("INSERT INTO admin_order_items(order_id,line_number,product_id,sku_snapshot,name_snapshot,quantity,unit_price_minor,line_total_minor,product_revision) VALUES($1,2,'p2','p2','Free extra',1,0,0,1)",[order.id]),/sealed/);
 assert.equal((await store.getCustomerOrder(cid,order.id)).totalMinor,179000);
});
test('commit rejects missing lines atomically and preserves legacy JSON orders',async t=>{
 const {db}=await fixture(t);await db.query("INSERT INTO admin_orders(id,document,status) VALUES('legacy','{\"unknownHistoricalData\":true}','pending')");assert.equal((await db.query("SELECT customer_id,subtotal_minor FROM admin_orders WHERE id='legacy'")).rows[0].subtotal_minor,null);
 await db.exec('BEGIN');await db.query(`INSERT INTO admin_orders(id,document,status,model_version,snapshot_sealed,customer_id,contact_snapshot,currency,subtotal_minor,delivery_minor,total_minor,shipping_snapshot,payment_status,inventory_status,idempotency_key,request_hash) VALUES('bad','{}','draft',1,true,$1,'{}','RSD',0,0,0,'{}','not_processed','unreserved','missing_lines_key_01',$2)`,[cid,'a'.repeat(64)]);await assert.rejects(db.exec('COMMIT'),/lines/);await db.exec('ROLLBACK');assert.equal((await db.query("SELECT count(*)::int AS n FROM admin_orders WHERE id='bad'")).rows[0].n,0);
 await db.exec(await readFile(new URL('../migrations/004_order_model.sql',import.meta.url),'utf8'));assert.equal((await db.query("SELECT document FROM admin_orders WHERE id='legacy'")).rows[0].document.unknownHistoricalData,true);
});
