# Poručivanje pouzećem — paket za pregled

## Pokretanje i uključivanje

Potreban je Node.js 22 ili noviji. `npm ci --ignore-scripts`, zatim `npm run check` proverava paket lokalno sa izmišljenim test podacima. `npm start` pokreće servis uz odobrenu postojeću hosting/OAuth/PostgreSQL konfiguraciju opisanu u README-u; ovo nije samostalni HTML preview. Ne unositi tajne u izvorni kod.

`CHECKOUT_COD_ENABLED=0` je podrazumevano. Vrednost 1 zahteva uključenu Google prijavu, administraciju i trajne kupce (`CUSTOMER_DATABASE_ENABLED=1`), ispravnu bazu i zasebno odobrenje postavljanja/aktivacije. Ni ovaj paket ni testovi ne uključuju postojeći servis. Artikli sa nepoznatom/nultom količinom ili isključenom dostupnošću ne mogu se poručiti. Uvoz pozitivne količine ne uključuje automatski dostupnost.

## Tok kupca

Google prijava → korpa → `/checkout` → ime, email, telefon, adresa, grad i poštanski broj u Srbiji → serverski pregled iznosa → izričita potvrda poručivanja pouzećem. Cena i dostava dolaze sa servera. Dostava je 300 RSD; za proizvode ukupno od 3.500 RSD uključivo je besplatna. Kartice nisu uključene. Email potvrde se ne šalju. Potvrda i istorija porudžbina dostupne su prijavljenom kupcu u prodavnici.

Kod prihvatanja u jednoj transakciji se čuvaju kupac, kontakt/adresa, nepromenljive stavke/cene/dostava/ukupan iznos i umanjuje stanje. Zaključavanje redova i provera količine sprečavaju dve uspešne kupovine poslednjeg komada. Trajni ključ ponovljenog zahteva sprečava drugu porudžbinu pri ponavljanju istog pokušaja. Promenjena cena/verzija zahteva novi pregled. Nepoznat ishod se ponavlja istim telom i ključem; kupac ne treba da šalje novu porudžbinu dok ne proveri prethodnu.

Ako posle prekida mreže ponavljanje ostaje blokirano, ne brisati sačuvani pokušaj naslepo i ne praviti novi ključ. Najpre proveriti istoriju prijavljenog kupca i administratorski zapis. Potvrđen pokušaj se može bezbedno ponavljati istim ključem. Za slučaj gde nema jasne potvrde ni pouzdanog odbijanja potreban je pregled administratora; ovaj paket namerno nema dugme koje zaobilazi tu zaštitu.

## Obrada i zalihe

Administrator vidi porudžbinu, kontakt, stavke i iznose. Dozvoljen tok: nova → u obradi → poslata → završena; otkazivanje je moguće pre slanja. Nijedan status ne tvrdi da je novac naplaćen: pouzeće ostaje za naplatu, otkazana porudžbina nema aktivnu naplatu.

Otkazivanje ne vraća stanje automatski. Administrator usklađuje storno u Pantheonu i novi dnevni Excel ili ručno proverenu količinu u panelu. Ovo izbegava dvostruko vraćanje nakon dnevnog uvoza.

Dnevni B2C Excel apsolutno zamenjuje slobodno stanje, prema izboru vlasnika. Najpre obraditi porudžbine i storna u Pantheonu, pa izvesti svež izveštaj i učitati ga. Nema dodatnih rezervacija, pojedinačnih oznaka prenosa ili zamrzavanja. Postoji poznat rizik novih porudžbina između izvoza i uvoza. Verzija proizvoda štiti od primene pregleda napravljenog pre nove porudžbine, ali ne prepoznaje starost samog Excel izvoza.

## Pre javnog pokretanja

- Posebno odobriti objavu i uključivanje poručivanja; proveriti realne cene, stanje i dostupnost sva tri artikla.
- Potvrditi tačne podatke prodavca, registraciju, uslove kupovine/povrata, privatnost i obaveštenja kupcu. Paket ih ne izmišlja i nije pravna provera.
- Proveriti fiskalizaciju/račune, kurira i operativnu obradu pouzeća.
- Proveriti backup i restore PostgreSQL baze, pristup kontaktima i period čuvanja.
- Uraditi odobren staging test sa nezavisnim PostgreSQL konekcijama i pravi browser smoke test pre javnog uključivanja. Ugrađeni PGlite testovi proveravaju SQL i rollback, ali serijalizuju jednu lokalnu konekciju.
- Postojeće sesije i ograničenje zahteva ostaju u memoriji jedne Node instance. Restart traži novu prijavu; porudžbine i ključevi ponavljanja ostaju u bazi. Više instanci zahteva zaseban zajednički session/rate-limit sloj.

Migracija 005 čuva stare draft/legacy zapise bez izmišljanja iznosa. Migrator primenjuje samo još neprimenjene verzije; ne pokretati stariji paket koji ponovo izvršava migraciju 004 preko novih COD porudžbina. Povratak aplikacije mora uzeti u obzir novu šemu i sačuvane porudžbine.
