# Validation — COD checkout candidate, 16 October 2026

## Baseline and checks

Built from the exact B2C v3 archive SHA-256 `b2274f7290939f6ce53e4b761b67293a2da1ea6c6a62ec2b9b8917f176a7f076` . Existing source was copied into a separate candidate tree. No live configuration or data changed.

The initial full `npm run check` passed 133/133 tests, independently repeated with zero failures or skips. This includes the 110 baseline tests plus 15 COD store and 8 HTTP integration tests. The added checkout UI harness passed 16/16 and covers uncertain/reloaded retries, account changes, cancelled replays and failed browser-storage cleanup. Independent review found no remaining high/critical backend defects after the two UI retry fixes.

New coverage: server-authoritative prices and delivery threshold, known/available stock, insufficient quantities, malformed/extra fields and forged totals, idempotent replay/conflict, rollback on deferred SQL failure, competing last-unit submissions, immutable snapshots, customer isolation, CSRF/origin/session checks, disabled-by-default dependencies, cancellation without restock, absolute import followed by cancellation, stale import-preview rejection, and repeated initialization with saved COD records.

HTTP tests exercise the real server and verified-session flow with isolated fictional OAuth and customer fixtures. No real credentials or customer data are used. All eleven static image assets and package-lock.json are byte-identical to v3; no dependencies were added for checkout.

Final frozen-source `npm run check`: **149/149 passed**, zero failures or skips. Every top-level src/public JavaScript file also passed syntax checking.

## Limits and activation checks

- PostgreSQL server/initdb binaries are not installed in this workspace. PGlite executes PostgreSQL semantics through a serialized single-session test adapter. Concurrent test calls do not establish multi-connection networked PostgreSQL behavior. Run an approved disposable PostgreSQL staging test of simultaneous last-unit orders and import/order contention before activation.
- Browser interaction tests use jsdom. Actual Chromium launch was attempted but the execution environment rejected required sandbox/socket operations before launch; no screenshots or visual-pass claim. A real-browser acceptance test remains a launch gate.
- No production migration, deployment, feature activation, real checkout, payment or email sending was performed.
- No new dependency vulnerability scan or comprehensive security certification is claimed.
- Sessions and rate limits are single-instance/in-memory; business records and idempotency are persistent PostgreSQL data.
- Daily Excel remains absolute replacement as chosen by the owner. The known export/import timing gap is not eliminated by product revision checks. Cancellation never restores stock automatically.

Before launch, complete COD-CHECKOUT.md checks: deployment approval, seller/legal/customer notices, fiscalization, delivery/payment operations, real catalog stock/availability, backup/restore, and browser/staging smoke checks. Keep CHECKOUT_COD_ENABLED=0 until approved activation.
