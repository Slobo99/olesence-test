import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';

export class StoreError extends Error {
  constructor(status, message) { super(message); this.name = 'StoreError'; this.status = status; }
}
const fail = (message) => { throw new StoreError(400, message); };
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const textFields = new Set(['name', 'botanical', 'category', 'volume', 'image', 'tone', 'description', 'ingredients', 'method', 'note']);
const textLimits = {name: 120, botanical: 120, category: 120, volume: 120, image: 120, tone: 120, description: 2000, ingredients: 2000, method: 500, note: 2000};
const declarationFields = new Set(['benefit', 'usage', 'notes', 'warnings', 'storage', 'editorialCaveat']);
const transitions = {pending: ['processing', 'cancelled'], processing: ['shipped', 'cancelled'], shipped: ['completed'], completed: [], cancelled: []};
function actorId(actor) {
  // Identity verification and allowlist authorization happen before this boundary.
  const id = typeof actor === 'string' ? actor : actor?.id;
  if (typeof id !== 'string' || !/^google:[\x21-\x7e]{1,255}$/.test(id)) throw new StoreError(403, 'Verified Google administrator required.');
  return id;
}
function versionNumber(version) {
  if (!Number.isSafeInteger(version) || version < 1 || version >= 2147483647) fail('Valid revision required.');
}
function resourceId(id) {
  if (typeof id !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,127}$/.test(id)) fail('Invalid resource ID.');
}
function productPatch(patch, seed = false) {
  if (!plain(patch) || !Object.keys(patch).length) fail('Product changes required.');
  const clean = {};
  for (const [key, value] of Object.entries(patch)) {
    if (textFields.has(key) && (seed || !['image', 'tone'].includes(key))) {
      if (!(typeof value === 'string' && value.length <= textLimits[key]) && !(value === null && ['volume', 'method', 'note'].includes(key))) fail('Invalid product text.');
      if (key === 'name' && !value.trim()) fail('Product name is required.');
      if (key === 'image' && !/^[a-zA-Z0-9_-]+\.(?:jpg|jpeg|png|webp)$/.test(value)) fail('Invalid catalog image.');
      clean[key] = value;
    } else if (key === 'priceMinor') {
      if (!Number.isSafeInteger(value) || value < 0 || value > 100000000) fail('Price must be a nonnegative integer in minor units.');
      clean[key] = value;
    } else if (key === 'stockQuantity') {
      if (value !== null && (!Number.isSafeInteger(value) || value < 0 || value > 1000000)) fail('Stock must be null or a nonnegative integer.');
      clean[key] = value;
    } else if (key === 'available') {
      if (typeof value !== 'boolean') fail('Availability must be a boolean.');
      clean[key] = value;
    } else if (key === 'declaration' && seed) {
      if (!plain(value) || !Object.keys(value).length || Object.entries(value).some(([k, v]) => !declarationFields.has(k) || typeof v !== 'string' || v.length > 10000)) fail('Invalid product declaration.');
      clean[key] = {...value};
    } else fail('Unknown product field.');
  }
  return clean;
}
const imageHash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const MAX_IMAGE_BYTES = 1572864;
const IMAGE_QUOTA_BYTES = 100 * 1024 * 1024;
function productImage(image) {
  if (!plain(image) || !imageHash(image.hash) || !Buffer.isBuffer(image.bytes) || image.mime !== 'image/jpeg' ||
      !Number.isInteger(image.width) || image.width < 1 || image.width > 1600 ||
      !Number.isInteger(image.height) || image.height < 1 || image.height > 1600) fail('Invalid product image.');
  if (!image.bytes.length) fail('Empty product image.');
  if (image.bytes.length > MAX_IMAGE_BYTES) throw new StoreError(413, 'Product image is too large.');
  // Own the bytes before the first await, preventing mutation during a transaction.
  const bytes = Buffer.from(image.bytes);
  if (createHash('sha256').update(bytes).digest('hex') !== image.hash) fail('Image hash does not match its contents.');
  return {hash: image.hash, bytes, mime: image.mime, width: image.width, height: image.height};
}
function pageOptions({before, limit = 50} = {}) {
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) fail('Limit must be between 1 and 100.');
  if (before !== undefined && before !== null && (typeof before !== 'string' || !/^[1-9][0-9]{0,18}$/.test(before) || BigInt(before) > 9223372036854775807n)) fail('Invalid pagination cursor.');
  return {before: before ?? null, limit};
}
function productDocument(row) { return {...row.document, id: row.id, version: row.revision, updatedAt: row.updated_at}; }
function orderDocument(row) { const basic={...row.document,id:row.id,status:row.status,version:row.revision,createdAt:row.created_at,updatedAt:row.updated_at};return [1,2].includes(row.model_version)?{...basic,customerId:row.customer_id,customer:{name:row.contact_snapshot.fullName,email:row.contact_snapshot.email},contact:row.contact_snapshot,currency:row.currency,subtotalMinor:Number(row.subtotal_minor),deliveryMinor:Number(row.delivery_minor),totalMinor:Number(row.total_minor),shipping:row.shipping_snapshot,paymentMethod:row.payment_method,paymentStatus:row.payment_status,inventoryStatus:row.inventory_status}:basic; }
const orderSnapshot = order => ({id: order.id, status: order.status, version: order.version});

export function createPostgresStore(pool) {
  if (!pool || typeof pool.connect !== 'function' || typeof pool.query !== 'function') throw new TypeError('PostgreSQL pool required.');
  async function transaction(work) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await work(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      try { await client.query('ROLLBACK'); } catch { /* Preserve original failure. */ }
      throw error;
    } finally { client.release(); }
  }
  async function audit(client, type, id, actor, before, after) {
    await client.query('INSERT INTO admin_audit (entity_type, entity_id, actor_id, before_snapshot, after_snapshot) VALUES ($1, $2, $3, $4::jsonb, $5::jsonb)', [type, id, actor, JSON.stringify(before), JSON.stringify(after)]);
  }
  return {
    async initialize(seedProducts = []) {
      if (!Array.isArray(seedProducts)) fail('Seed products must be an array.');
      const seeds = seedProducts.map(product => {
        resourceId(product?.id);
        const {id, ...fields} = product;
        const clean = productPatch(fields, true);
        if (!clean.name || clean.priceMinor === undefined) fail('Seed name and price required.');
        return {id, ...clean, stockQuantity: null, available: false};
      });
      const sql = await readFile(new URL('../migrations/001_admin.sql', import.meta.url), 'utf8');
      const imageSql = await readFile(new URL('../migrations/002_product_images.sql', import.meta.url), 'utf8');
      const customerSql=await readFile(new URL('../migrations/003_customers.sql',import.meta.url),'utf8');
      const orderSql=await readFile(new URL('../migrations/004_order_model.sql',import.meta.url),'utf8');
      await transaction(async client => {
        await client.query('SELECT pg_advisory_xact_lock($1)', [1733010131]);
        await client.query(sql); // 001 only creates absent base tables and the migration ledger.
        const applied = new Set((await client.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(row => row.version));
        for (const [version, source] of [[2,imageSql],[3,customerSql],[4,orderSql],[5,await readFile(new URL('../migrations/005_cod_checkout.sql', import.meta.url),'utf8')]]) {
          if (!applied.has(version)) await client.query(source);
        }
        for (const product of seeds) await client.query('INSERT INTO admin_products (id, document) VALUES ($1, $2::jsonb) ON CONFLICT (id) DO NOTHING', [product.id, JSON.stringify(product)]);
      });
    },
    async listProducts() {
      const {rows} = await pool.query('SELECT id, document, revision, updated_at FROM admin_products ORDER BY id');
      return rows.map(productDocument);
    },
    async updateProduct(id, version, patch, actor) {
      resourceId(id); versionNumber(version); const clean = productPatch(patch); const identity = actorId(actor);
      return transaction(async client => {
        const {rows} = await client.query('SELECT id, document, revision, updated_at FROM admin_products WHERE id = $1 FOR UPDATE', [id]);
        if (!rows.length) throw new StoreError(404, 'Product not found.');
        const row = rows[0];
        if (row.revision !== version) throw new StoreError(409, 'Product changed. Reload before saving.');
        const before = productDocument(row);
        const document = {...row.document, ...clean, id};
        if (clean.declaration) document.declaration = {...row.document.declaration, ...clean.declaration};
        if (document.available && (!Number.isSafeInteger(document.stockQuantity) || document.stockQuantity < 1)) fail('Available products require known positive stock.');
        const updated = await client.query('UPDATE admin_products SET document = $2::jsonb, revision = revision + 1, updated_at = now() WHERE id = $1 RETURNING id, document, revision, updated_at', [id, JSON.stringify(document)]);
        const after = productDocument(updated.rows[0]);
        await audit(client, 'product', id, identity, before, after);
        return after;
      });
    },
    async updateProductImage(id, version, image, actor) {
      resourceId(id); versionNumber(version); const clean = productImage(image); const identity = actorId(actor);
      return transaction(async client => {
        // All upload transactions acquire the quota lock before any product lock.
        // Old content is retained for existing URLs/history, so quota counts all rows.
        await client.query('SELECT pg_advisory_xact_lock($1)', [1733010132]);
        const {rows} = await client.query('SELECT id, document, revision, updated_at FROM admin_products WHERE id = $1 FOR UPDATE', [id]);
        if (!rows.length) throw new StoreError(404, 'Product not found.');
        const row = rows[0];
        if (row.revision !== version) throw new StoreError(409, 'Product changed. Reload before saving.');
        const before = productDocument(row);
        const imagePath = '/media/' + clean.hash + '.jpg';
        if (row.document.imagePath === imagePath) return before;
        await client.query('INSERT INTO admin_product_images (hash, bytes, mime, width, height) VALUES ($1, $2, $3, $4, $5) ON CONFLICT (hash) DO NOTHING', [clean.hash, clean.bytes, clean.mime, clean.width, clean.height]);
        const usage = await client.query('SELECT COALESCE(SUM(octet_length(bytes)), 0)::bigint AS total_bytes FROM admin_product_images');
        if (BigInt(usage.rows[0].total_bytes) > BigInt(IMAGE_QUOTA_BYTES)) throw new StoreError(413, 'Product image storage is full.');
        const document = {...row.document, id, imagePath};
        const updated = await client.query('UPDATE admin_products SET document = $2::jsonb, revision = revision + 1, updated_at = now() WHERE id = $1 RETURNING id, document, revision, updated_at', [id, JSON.stringify(document)]);
        const after = productDocument(updated.rows[0]);
        // Product snapshots contain the image URL only, never binary image data.
        await audit(client, 'product', id, identity, before, after);
        return after;
      });
    },
    async getImage(hash) {
      if (!imageHash(hash)) fail('Invalid image hash.');
      const {rows} = await pool.query('SELECT bytes, mime, width, height FROM admin_product_images WHERE hash = $1', [hash]);
      if (!rows.length) return null;
      return {bytes: Buffer.from(rows[0].bytes), mime: rows[0].mime, width: rows[0].width, height: rows[0].height};
    },
    async applyStockImport(rows, actor) {
      const identity = actorId(actor);
      if (!Array.isArray(rows) || !rows.length || rows.length > 500) fail('Import must contain between 1 and 500 product rows.');
      const seen = new Set();
      const entries = rows.map(row => {
        if (!plain(row) || Object.keys(row).some(key => !['id', 'version', 'stockQuantity'].includes(key))) fail('Invalid stock import row.');
        resourceId(row.id); versionNumber(row.version);
        if (!Number.isSafeInteger(row.stockQuantity) || row.stockQuantity < 0 || row.stockQuantity > 1000000) fail('Import stock must be an explicit nonnegative integer.');
        if (seen.has(row.id)) fail('Duplicate product in stock import.');
        seen.add(row.id);
        return {...row};
      }).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
      return transaction(async client => {
        const locked = [];
        for (const entry of entries) {
          const {rows: found} = await client.query('SELECT id, document, revision, updated_at FROM admin_products WHERE id = $1 FOR UPDATE', [entry.id]);
          if (!found.length) throw new StoreError(404, 'Imported product not found.');
          if (found[0].revision !== entry.version) throw new StoreError(409, 'Imported product changed. Reload before importing.');
          locked.push({entry, row: found[0]});
        }
        const products = [];
        for (const {entry, row} of locked) {
          const document = {...row.document, id: entry.id, stockQuantity: entry.stockQuantity};
          // Positive imported stock does not automatically activate sales.
          if (entry.stockQuantity === 0) document.available = false;
          const updated = await client.query('UPDATE admin_products SET document = $2::jsonb, revision = revision + 1, updated_at = now() WHERE id = $1 RETURNING id, document, revision, updated_at', [entry.id, JSON.stringify(document)]);
          const after = productDocument(updated.rows[0]);
          await audit(client, 'product', entry.id, identity, productDocument(row), after);
          products.push(after);
        }
        return products;
      });
    },
    async listOrders(options) {
      const {before, limit} = pageOptions(options);
      const {rows} = await pool.query('SELECT * FROM admin_orders WHERE ($1::bigint IS NULL OR sequence_id < $1::bigint) ORDER BY sequence_id DESC LIMIT $2', [before, limit + 1]);
      const selected = rows.slice(0, limit);
      const orders=[];for(const row of selected){const order=orderDocument(row);if([1,2].includes(row.model_version)){const items=await pool.query('SELECT product_id,sku_snapshot,name_snapshot,quantity,unit_price_minor,line_total_minor FROM admin_order_items WHERE order_id=$1 ORDER BY line_number',[row.id]);order.items=items.rows.map(item=>({productId:item.product_id,sku:item.sku_snapshot,name:item.name_snapshot,quantity:item.quantity,unitPriceMinor:Number(item.unit_price_minor),lineTotalMinor:Number(item.line_total_minor)}));}orders.push(order);}return {orders,nextCursor: rows.length > limit ? String(selected.at(-1).sequence_id) : null};
    },
    async updateOrder(id, version, patch, actor) {
      resourceId(id); versionNumber(version); const identity = actorId(actor);
      if (!plain(patch) || Object.keys(patch).length !== 1 || !Object.hasOwn(patch, 'status') || !Object.hasOwn(transitions, patch.status)) fail('Only a valid order status can be changed.');
      return transaction(async client => {
        const {rows} = await client.query('SELECT id, document, status, revision, created_at, updated_at, customer_id, model_version, payment_method, payment_status, inventory_status, contact_snapshot, currency, subtotal_minor, delivery_minor, total_minor, shipping_snapshot FROM admin_orders WHERE id = $1 FOR UPDATE', [id]);
        if (!rows.length) throw new StoreError(404, 'Order not found.');
        const row = rows[0];
        if (row.revision !== version) throw new StoreError(409, 'Order changed. Reload before saving.');
        if (row.customer_id && row.model_version !== 2) throw new StoreError(409, 'Draft order fulfillment is not enabled.');
        if (!transitions[row.status]?.includes(patch.status)) throw new StoreError(409, 'Order status transition is not allowed.');
        // Cancellations do NOT return stock: daily Excel may already include a correction.
        // The operator handles Pantheon/manual stock adjustment separately.
        const updated = row.model_version === 2
          ? await client.query("UPDATE admin_orders SET status=$2, payment_status=CASE WHEN $2='cancelled' THEN 'cod_cancelled' ELSE payment_status END, inventory_status=CASE WHEN $2='cancelled' THEN 'deducted_manual_adjustment_required' ELSE inventory_status END, revision=revision+1, updated_at=now() WHERE id=$1 RETURNING *",[id,patch.status])
          : await client.query('UPDATE admin_orders SET status = $2, revision = revision + 1, updated_at = now() WHERE id = $1 RETURNING id, document, status, revision, created_at, updated_at', [id, patch.status]);
        const after = orderDocument(updated.rows[0]);
        await audit(client, 'order', id, identity, orderSnapshot(orderDocument(row)), orderSnapshot(after));
        return after;
      });
    },
    async listAudit(options) {
      const {before, limit} = pageOptions(options);
      const {rows} = await pool.query('SELECT id, entity_type, entity_id, actor_id, action, before_snapshot, after_snapshot, created_at FROM admin_audit WHERE ($1::bigint IS NULL OR id < $1::bigint) ORDER BY id DESC LIMIT $2', [before, limit + 1]);
      const selected = rows.slice(0, limit);
      return {entries: selected.map(row => ({id: String(row.id), entityType: row.entity_type, entityId: row.entity_id, actorId: row.actor_id, action: row.action, before: row.before_snapshot, after: row.after_snapshot, createdAt: row.created_at})), nextCursor: rows.length > limit ? String(selected.at(-1).id) : null};
    },
    async close() { await pool.end(); }
  };
}
