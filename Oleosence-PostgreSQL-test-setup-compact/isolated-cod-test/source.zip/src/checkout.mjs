import {timingSafeEqual} from 'node:crypto';
import {AuthError} from './customer-auth.mjs';
import {readBody} from './admin.mjs';
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const validCustomer=id=>typeof id==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(id);
async function json(req){if(req.headers['content-type']?.split(';')[0]!=='application/json')throw new AuthError(415,'Potreban je JSON zahtev.');try{const body=JSON.parse((await readBody(req,16384)).toString('utf8'));if(!body||typeof body!=='object'||Array.isArray(body))throw Error();return body;}catch(e){if(e instanceof AuthError)throw e;throw new AuthError(400,'Neispravan JSON.');}}
function keys(body,allowed){if(Object.keys(body).some(k=>!allowed.includes(k)))throw new AuthError(400,'Nepoznata polja zahteva.');}
export function createCheckout({enabled=false,auth,codStore,origin,clock=Date.now}){
 const limits=new Map();
 function limit(id,write){const now=clock();for(const[k,v]of limits)if(v.until<=now)limits.delete(k);let row=limits.get(id);if(!row){if(limits.size>=1000)throw new AuthError(429,'Usluga je zauzeta. Pokušajte kasnije.');row={until:now+60000,read:0,write:0};limits.set(id,row);}const key=write?'write':'read';if(++row[key]>(write?15:90))throw new AuthError(429,'Previše zahteva. Sačekajte minut pa pokušajte ponovo.');}
 return {async handle(req,url,send){
  const p=url.pathname,s=auth.session(req);
  if(req.method==='GET'&&p==='/api/checkout/session')return send(200,{enabled:!!enabled,user:s?.user??null,csrfToken:s?.csrfToken??null,customerReady:!!s&&validCustomer(s.user.customerId)});
  if(!enabled||!codStore)throw new AuthError(503,'Poručivanje trenutno nije omogućeno.');
  if(!s)throw new AuthError(401,'Prijavite se Google nalogom pre poručivanja.');
  if(!validCustomer(s.user.customerId))throw new AuthError(409,'Ponovo se prijavite da biste povezali nalog kupca.');
  const customerId=s.user.customerId;
  if(!['GET','HEAD'].includes(req.method)){if(req.headers.origin!==origin||!equal(req.headers['x-csrf-token'],s.csrfToken))throw new AuthError(403,'Sesija ili zaštita zahteva nije važeća. Ponovo se prijavite ili osvežite stranicu.');}
  limit(customerId,req.method==='POST'&&p==='/api/checkout/orders');
  if(req.method==='POST'&&p==='/api/checkout/quote'){const body=await json(req);keys(body,['items']);return send(200,await codStore.quote(customerId,body.items));}
  if(req.method==='POST'&&p==='/api/checkout/orders'){const body=await json(req);keys(body,['items','contact','shippingMethod','paymentMethod','expectedTotalMinor']);const result=await codStore.createOrder({...body,customerId,idempotencyKey:req.headers['idempotency-key']});return send(result.replayed?200:201,result);}
  if(req.method==='GET'&&p==='/api/checkout/orders')return send(200,await codStore.listCustomerOrders(customerId,{before:url.searchParams.get('before')||null,limit:Number(url.searchParams.get('limit')||25)}));
  const match=p.match(/^\/api\/checkout\/orders\/(COD-[a-f0-9-]{36})$/);if(req.method==='GET'&&match){const order=await codStore.getCustomerOrder(customerId,match[1]);if(!order)throw new AuthError(404,'Porudžbina nije pronađena.');return send(200,{order});}
  throw new AuthError(404,'Not found.');
 },close(){limits.clear();}};
}
