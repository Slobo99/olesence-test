import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import sharp from 'sharp';
import {createPostgresStore, StoreError} from '../src/admin-store.mjs';

const actor = {id: 'google:image-admin', email: 'not-in-audit@example.test'};
const status = expected => error => error instanceof StoreError && error.status === expected;
const seeds = ['one', 'two'].map(id => ({id, name: id, priceMinor: 100, image: 'original.jpg'}));
const descriptor = bytes => ({hash: createHash('sha256').update(bytes).digest('hex'), bytes, mime: 'image/jpeg', width: 1, height: 1});
async function jpeg(color) {
  return descriptor(await sharp({create: {width: 1, height: 1, channels: 3, background: color}}).jpeg().toBuffer());
}
// PGlite is a real PostgreSQL engine; its single session requires serial clients.
// Concurrent callers below exercise atomic outcomes, not multi-session locking.
async function fixture() {
  const {PGlite} = await import('@electric-sql/pglite');
  const db = new PGlite();
  let tail = Promise.resolve();
  const calls = [];
  async function connect() {
    const previous = tail;
    let release;
    tail = new Promise(resolve => {release = resolve;});
    await previous;
    return {release, query: async (sql, params) => {
      calls.push(sql);
      return params === undefined && sql.startsWith('-- Applied') ? (await db.exec(sql)).at(-1) : db.query(sql, params);
    }};
  }
  const pool = {connect, query: async (sql, params) => {
    const client = await connect();
    try {return await client.query(sql, params);} finally {client.release();}
  }, end: () => db.close()};
  const store = createPostgresStore(pool);
  await store.initialize(seeds);
  return {store, pool, calls};
}

test('images persist, deduplicate, retain old URLs and audit metadata only', async () => {
  const {store, pool} = await fixture();
  try {
    const first = await jpeg('#ff0000'), second = await jpeg('#0000ff');
    const saved = await store.updateProductImage('one', 1, first, actor);
    assert.equal(saved.image, 'original.jpg');
    assert.equal(saved.imagePath, `/media/${first.hash}.jpg`);
    assert.equal(saved.version, 2);
    assert.deepEqual(await store.getImage(first.hash), {bytes: first.bytes, mime: first.mime, width: 1, height: 1});
    const unchanged = await store.updateProductImage('one', 2, first, actor);
    assert.equal(unchanged.version, 2);
    await assert.rejects(store.updateProductImage('one', 1, first, actor), status(409));
    await store.updateProductImage('two', 1, first, actor);
    assert.equal((await pool.query('SELECT count(*)::int AS n FROM admin_product_images')).rows[0].n, 1);
    await store.updateProductImage('one', 2, second, actor);
    assert.deepEqual((await store.getImage(first.hash)).bytes, first.bytes);
    assert.equal((await pool.query('SELECT count(*)::int AS n FROM admin_product_images')).rows[0].n, 2);
    const audit = (await store.listAudit()).entries;
    assert.equal(audit.length, 3);
    assert.equal(audit[0].before.imagePath, `/media/${first.hash}.jpg`);
    assert.equal(audit[0].after.imagePath, `/media/${second.hash}.jpg`);
    assert.equal(JSON.stringify(audit).includes('"bytes"'), false);
    assert.equal(JSON.stringify(audit).includes(first.bytes.toString('base64')), false);
    assert.equal(JSON.stringify(audit).includes(actor.email), false);
    await store.initialize(seeds);
    assert.equal((await store.listProducts())[0].version, 3);
    assert.deepEqual((await pool.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(r => r.version), [1, 2, 3, 4, 5]);
    assert.equal(await store.getImage('0'.repeat(64)), null);
  } finally {await store.close();}
});

test('store validates image contents hash, dimensions, size, actor and immutable image paths', async () => {
  const {store, pool} = await fixture();
  try {
    const image = await jpeg('#ff0000');
    for (const invalid of [null, {...image, hash: '0'.repeat(64)}, {...image, hash: image.hash.toUpperCase()}, {...image, bytes: new Uint8Array(image.bytes)}, {...image, bytes: Buffer.alloc(0)}, {...image, mime: 'image/png'}, {...image, width: 0}, {...image, width: 1601}, {...image, height: 1.5}, {...image, height: 1601}]) {
      await assert.rejects(store.updateProductImage('one', 1, invalid, actor), status(400));
    }
    await assert.rejects(store.updateProductImage('one', 1, descriptor(Buffer.alloc(1572865)), actor), status(413));
    await assert.rejects(store.updateProductImage('one', 1, image, {id: 'email:fake'}), status(403));
    await assert.rejects(store.updateProductImage('missing', 1, image, actor), status(404));
    await assert.rejects(store.updateProduct('one', 1, {imagePath: '/media/fake.jpg'}, actor), status(400));
    await assert.rejects(store.updateProduct('one', 1, {image: 'fake.jpg'}, actor), status(400));
    await assert.rejects(store.getImage('../secret'), status(400));
    assert.equal((await pool.query('SELECT count(*)::int AS n FROM admin_product_images')).rows[0].n, 0);
    assert.equal((await store.listAudit()).entries.length, 0);
    // Mutation after invocation cannot change the bytes owned by the store.
    const owned = {...image, bytes: Buffer.from(image.bytes)};
    const pending = store.updateProductImage('one', 1, owned, actor);
    owned.bytes.fill(0);
    await pending;
    assert.deepEqual((await store.getImage(image.hash)).bytes, image.bytes);
  } finally {await store.close();}
});

test('audit failure rolls back image insertion, revision and URL; concurrent stale writes are atomic', async () => {
  const {store, pool, calls} = await fixture();
  try {
    const first = await jpeg('#ff0000'), second = await jpeg('#0000ff');
    await pool.query("ALTER TABLE admin_audit ADD CONSTRAINT reject_test_actor CHECK (actor_id <> 'google:rollback')");
    await assert.rejects(store.updateProductImage('one', 1, first, {id: 'google:rollback'}), /reject_test_actor/);
    assert.equal(await store.getImage(first.hash), null);
    assert.equal((await store.listProducts())[0].version, 1);
    assert.equal((await store.listProducts())[0].imagePath, undefined);
    const outcomes = await Promise.allSettled([store.updateProductImage('one', 1, first, actor), store.updateProductImage('one', 1, second, actor)]);
    assert.equal(outcomes.filter(r => r.status === 'fulfilled').length, 1);
    assert.equal(outcomes.find(r => r.status === 'rejected').reason.status, 409);
    assert.equal(await store.getImage(second.hash), null);
    assert.equal((await store.listAudit()).entries.length, 1);
    const lockIndex = calls.findIndex(sql => sql.startsWith('SELECT') && sql.includes('FOR UPDATE'));
    assert.match(calls[lockIndex - 1], /pg_advisory_xact_lock/);
  } finally {await store.close();}
});

test('100 MiB retained-image quota serializes competing uploads and rolls back rejected upload', async () => {
  const {store, pool} = await fixture();
  try {
    // Populate 99 MiB entirely inside PostgreSQL, with per-row limits respected.
    // Synthetic bytes test storage accounting; JPEG decoding is an API responsibility.
    await pool.query("INSERT INTO admin_product_images (hash, bytes, mime, width, height) SELECT lpad(to_hex(n), 64, '0'), decode(repeat('00', 1572864), 'hex'), 'image/jpeg', 1, 1 FROM generate_series(1,66) n");
    const first = descriptor(Buffer.alloc(786432, 1)), second = descriptor(Buffer.alloc(786432, 2));
    const outcomes = await Promise.allSettled([store.updateProductImage('one', 1, first, actor), store.updateProductImage('two', 1, second, actor)]);
    assert.equal(outcomes.filter(r => r.status === 'fulfilled').length, 1);
    assert.equal(outcomes.find(r => r.status === 'rejected').reason.status, 413);
    assert.equal(await store.getImage(second.hash), null);
    assert.equal((await store.listProducts()).find(p => p.id === 'two').version, 1);
    assert.equal((await store.listAudit()).entries.length, 1);
    assert.equal(Number((await pool.query('SELECT sum(octet_length(bytes)) AS total FROM admin_product_images')).rows[0].total), 99 * 1024 * 1024 + first.bytes.length);
    // Content already counted can be attached to another product with no extra use.
    await store.updateProductImage('two', 1, first, actor);
    assert.equal((await store.listAudit()).entries.length, 2);
  } finally {await store.close();}
});

test('migration enforces binary and metadata limits for direct database writes', async () => {
  const {store, pool} = await fixture();
  try {
    for (const args of [['bad', Buffer.from('x'), 'image/jpeg', 1, 1], ['a'.repeat(64), Buffer.alloc(0), 'image/jpeg', 1, 1], ['a'.repeat(64), Buffer.alloc(1572865), 'image/jpeg', 1, 1], ['a'.repeat(64), Buffer.from('x'), 'image/png', 1, 1], ['a'.repeat(64), Buffer.from('x'), 'image/jpeg', 0, 1], ['a'.repeat(64), Buffer.from('x'), 'image/jpeg', 1, 1601]]) {
      await assert.rejects(pool.query('INSERT INTO admin_product_images(hash, bytes, mime, width, height) VALUES ($1, $2, $3, $4, $5)', args), /check constraint/);
    }
  } finally {await store.close();}
});
