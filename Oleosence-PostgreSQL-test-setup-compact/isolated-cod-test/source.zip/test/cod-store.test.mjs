import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {createCodStore} from '../src/cod-store.mjs';
import {createPostgresStore} from '../src/admin-store.mjs';

const customerId='11111111-1111-4111-8111-111111111111';
const otherCustomerId='22222222-2222-4222-8222-222222222222';
const actor='google:approved-admin';
const contact={fullName:'Test Kupac',email:'buyer@example.invalid',phone:'0600000000',address:'Izmisljena 1',city:'Beograd',postalCode:'11000',country:'RS'};
const status=expected=>error=>error.status===expected;
const input=(key='cod_order_key_000001',overrides={})=>({customerId,items:[{productId:'p1',quantity:1,expectedRevision:1}],contact:{...contact},shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:179000,idempotencyKey:key,...overrides});

async function fixture(t){
 const db=new PGlite();
 // PGlite exposes one PostgreSQL session. Serialize its complete transactions
 // and standalone queries; this is not a multi-connection PostgreSQL race test.
 let queue=Promise.resolve();
 async function acquire(){const previous=queue;let release;queue=new Promise(resolve=>{release=resolve;});await previous;return release;}
 const queries=[];
 const query=async(sql,args)=>{queries.push(sql);return sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args);};
 const pool={async query(sql,args){const release=await acquire();try{return await query(sql,args);}finally{release();}},async connect(){const release=await acquire();return {query,release};}};
 for(const file of ['001_admin.sql','002_product_images.sql','003_customers.sql','004_order_model.sql','005_cod_checkout.sql'])await db.exec(await readFile(new URL('../migrations/'+file,import.meta.url),'utf8'));
 for(const [id,subject] of [[customerId,'one'],[otherCustomerId,'two']])await db.query("INSERT INTO commerce_customers(id,provider,subject,email,name) VALUES($1,'google',$2,$3,'Test')",[id,subject,subject+'@example.invalid']);
 for(const [id,priceMinor] of [['p1',149000],['p2',159000],['p3',84000]])await db.query('INSERT INTO admin_products(id,document) VALUES($1,$2::jsonb)',[id,JSON.stringify({name:'Original '+id,priceMinor,stockQuantity:5,available:true})]);
 t.after(()=>db.close());
 const stock=async(id='p1')=>(await db.query('SELECT document,revision FROM admin_products WHERE id=$1',[id])).rows[0];
 const counts=async()=>(await db.query('SELECT (SELECT count(*)::int FROM admin_orders) AS orders,(SELECT count(*)::int FROM admin_order_items) AS items')).rows[0];
 return {db,pool,queries,stock,counts,store:createCodStore(pool),admin:createPostgresStore(pool)};
}

test('COD uses server prices, seals a payable-on-delivery snapshot and deducts stock once',async t=>{
 const {db,store,stock,queries}=await fixture(t);
 const {order,replayed}=await store.createOrder(input());
 assert.equal(replayed,false);assert.equal(order.customerId,customerId);assert.equal(order.status,'pending');
 assert.equal(order.paymentStatus,'cod_due');assert.equal(order.inventoryStatus,'deducted');
 assert.equal(order.currency,'RSD');assert.equal(order.subtotalMinor,149000);assert.equal(order.deliveryMinor,30000);assert.equal(order.totalMinor,179000);
 assert.equal(order.items[0].unitPriceMinor,149000);assert.equal(order.items[0].lineTotalMinor,149000);assert.equal(order.items[0].productRevision,1);
 assert.deepEqual(order.contact,contact);assert.equal(order.shipping.method,'courier');
 assert.match(order.id,/[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i);
 assert.equal((await stock()).document.stockQuantity,4);assert.equal((await stock()).revision,2);
 const saved=(await db.query('SELECT model_version,snapshot_sealed,payment_status,inventory_status FROM admin_orders WHERE id=$1',[order.id])).rows[0];
 assert.deepEqual(saved,{model_version:2,snapshot_sealed:true,payment_status:'cod_due',inventory_status:'deducted'});
 assert(queries.some(sql=>sql.includes('commerce_customers')&&sql.includes('FOR UPDATE')));
 assert(queries.some(sql=>sql.includes('admin_products')&&sql.includes('FOR UPDATE')));
});

test('shipping is 30000 minor units below 350000 and free inclusively at the threshold',async t=>{
 const {db,store}=await fixture(t);
 for(const [index,priceMinor,deliveryMinor] of [[1,349999,30000],[2,350000,0],[3,350001,0],[4,0,30000]]){
  await db.query("UPDATE admin_products SET document=document || jsonb_build_object('priceMinor',$1::int),revision=$2 WHERE id='p1'",[priceMinor,index]);
  const {order}=await store.createOrder(input('shipping_key_00000'+index,{items:[{productId:'p1',quantity:1,expectedRevision:index}],expectedTotalMinor:priceMinor+deliveryMinor}));
  assert.equal(order.subtotalMinor,priceMinor);assert.equal(order.deliveryMinor,deliveryMinor);assert.equal(order.totalMinor,priceMinor+deliveryMinor);
 }
});

test('zero, insufficient, unavailable and unknown stock reject the entire basket',async t=>{
 const {db,store,stock,counts}=await fixture(t);
 for(const [index,patch] of [{stockQuantity:0},{stockQuantity:1},{stockQuantity:null},{available:false},{stockQuantity:'5'},{stockQuantity:-1},{stockQuantity:1.5}].entries()){
  await db.query("UPDATE admin_products SET document=$1::jsonb WHERE id='p2'",[JSON.stringify({name:'Original p2',priceMinor:159000,available:true,stockQuantity:5,...patch})]);
  await assert.rejects(store.createOrder(input('stock_failure_key_'+index,{items:[{productId:'p1',quantity:1,expectedRevision:1},{productId:'p2',quantity:2,expectedRevision:1}],expectedTotalMinor:467000})),status(409));
  assert.equal((await stock()).document.stockQuantity,5);assert.equal((await stock()).revision,1);assert.deepEqual(await counts(),{orders:0,items:0});
 }
 await db.query("UPDATE admin_products SET document=document - 'stockQuantity' WHERE id='p2'");
 await assert.rejects(store.createOrder(input('missing_stock_key_01',{items:[{productId:'p2',quantity:1,expectedRevision:1}],expectedTotalMinor:189000})),status(409));
 await assert.rejects(store.createOrder(input('missing_product_key',{items:[{productId:'missing',quantity:1,expectedRevision:1}]})),status(404));
 assert.deepEqual(await counts(),{orders:0,items:0});
});

test('client prices, forged totals, malformed inputs and stale revisions cannot create orders',async t=>{
 const {store,counts,stock}=await fixture(t);
 const bad=[{items:[]},{items:[{productId:'p1',quantity:1,expectedRevision:1,priceMinor:1}]},{items:[{productId:'p1',quantity:1,expectedRevision:1,unitPriceMinor:1}]},{items:[{productId:'p1',quantity:0,expectedRevision:1}]},{items:[{productId:'p1',quantity:1.5,expectedRevision:1}]},{items:[{productId:'p1',quantity:21,expectedRevision:1}]},{items:Array(2).fill({productId:'p1',quantity:1,expectedRevision:1})},{totalMinor:1},{subtotalMinor:1},{paymentStatus:'paid'},{paymentMethod:'card'},{shippingMethod:'pickup'},{contact:{...contact,phone:'------'}},{contact:{...contact,postalCode:'BAD'}},{contact:{...contact,country:'US'}},{contact:{...contact,email:'x\ny@example.com'}},{contact:{...contact,address:'<script>'}},{customerId:'forged'},{idempotencyKey:'short'}];
 for(const patch of bad)await assert.rejects(store.createOrder(input(undefined,patch)),status(400),JSON.stringify(patch));
 await assert.rejects(store.createOrder(input(undefined,{expectedTotalMinor:1})),status(409));
 await assert.rejects(store.createOrder(input(undefined,{items:[{productId:'p1',quantity:1,expectedRevision:2}]})),status(409));
 await assert.rejects(store.createOrder(input(undefined,{customerId:'33333333-3333-4333-8333-333333333333'})),status(404));
 assert.deepEqual(await counts(),{orders:0,items:0});assert.equal((await stock()).document.stockQuantity,5);
});

test('corrupt catalog prices fail closed, while zero is a valid integer price',async t=>{
 const {db,store,counts}=await fixture(t);
 for(const [index,priceMinor] of [-1,1.25,'149000',null,100000001].entries()){
  await db.query("UPDATE admin_products SET document=document || $1::jsonb WHERE id='p1'",[JSON.stringify({priceMinor})]);
  await assert.rejects(store.createOrder(input('invalid_price_key_'+index)),status(409));
 }
 assert.deepEqual(await counts(),{orders:0,items:0});
});

test('concurrent same-key submissions replay one order and one stock deduction',async t=>{
 const {store,stock,counts}=await fixture(t);
 const results=await Promise.all(Array.from({length:6},()=>store.createOrder(input())));
 assert.equal(new Set(results.map(result=>result.order.id)).size,1);assert.equal(results.filter(result=>!result.replayed).length,1);
 assert.equal((await stock()).document.stockQuantity,4);assert.equal((await stock()).revision,2);assert.deepEqual(await counts(),{orders:1,items:1});
 await assert.rejects(store.createOrder(input(undefined,{contact:{...contact,city:'Novi Sad'}})),status(409));
 assert.equal((await stock()).document.stockQuantity,4);
});

test('different keys competing for the last unit permit only one serialized transaction',async t=>{
 const {db,store,stock,counts}=await fixture(t);await db.query("UPDATE admin_products SET document=document || '{\"stockQuantity\":1}' WHERE id='p1'");
 const results=await Promise.allSettled([store.createOrder(input('last_unit_buyer_one')),store.createOrder(input('last_unit_buyer_two',{customerId:otherCustomerId}))]);
 assert.equal(results.filter(result=>result.status==='fulfilled').length,1);assert.equal(results.filter(result=>result.status==='rejected'&&result.reason.status===409).length,1);
 assert.equal((await stock()).document.stockQuantity,0);assert.equal((await stock()).revision,2);assert.deepEqual(await counts(),{orders:1,items:1});
});

test('a deferred database failure rolls back completed order lines and inventory together',async t=>{
 const {db,store,stock,counts,queries}=await fixture(t);
 await db.exec(`CREATE FUNCTION reject_fixture_commit() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'fixture rejects commit'; END $$;
 CREATE CONSTRAINT TRIGGER fixture_commit_failure AFTER INSERT ON admin_orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION reject_fixture_commit();`);
 await assert.rejects(store.createOrder(input()),/fixture rejects commit/);
 assert(queries.some(sql=>/UPDATE admin_products/i.test(sql)));assert(queries.some(sql=>/INSERT INTO admin_order_items/i.test(sql)));assert(queries.includes('COMMIT'));assert(queries.includes('ROLLBACK'));
 assert.deepEqual(await counts(),{orders:0,items:0});assert.equal((await stock()).document.stockQuantity,5);assert.equal((await stock()).revision,1);
 await db.exec('DROP TRIGGER fixture_commit_failure ON admin_orders');
 assert.equal((await store.createOrder(input())).replayed,false);assert.equal((await stock()).document.stockQuantity,4);
});

test('saved history and duplicate replay retain sealed snapshots after catalog and caller edits',async t=>{
 const {store,admin}=await fixture(t);const submission=input();const saved=await store.createOrder(submission);
 submission.contact.city='Mutated by caller';submission.items[0].quantity=20;
 await admin.updateProduct('p1',2,{name:'Later name',priceMinor:84000},actor);
 const replay=await store.createOrder(input());assert.equal(replay.replayed,true);assert.equal(replay.order.id,saved.order.id);assert.equal(replay.order.items[0].name,'Original p1');assert.equal(replay.order.items[0].unitPriceMinor,149000);assert.equal(replay.order.totalMinor,179000);assert.deepEqual(replay.order.contact,contact);
 const history=await store.listCustomerOrders(customerId);assert.equal(history.orders.length,1);assert.equal(history.orders[0].id,saved.order.id);assert.equal(history.orders[0].items[0].unitPriceMinor,149000);
 assert.equal(await store.getCustomerOrder(otherCustomerId,saved.order.id),null);assert.deepEqual((await store.listCustomerOrders(otherCustomerId)).orders,[]);
 const listed=(await admin.listOrders()).orders[0];assert.equal(listed.items[0].name,'Original p1');assert.equal(listed.totalMinor,179000);assert.equal(listed.paymentStatus,'cod_due');
});

test('database constraints prevent changing lines, contact, shipping, totals or payment',async t=>{
 const {db,store}=await fixture(t);const {order}=await store.createOrder(input());
 for(const sql of ["UPDATE admin_orders SET total_minor=1 WHERE id=$1","UPDATE admin_orders SET contact_snapshot='{}' WHERE id=$1","UPDATE admin_orders SET shipping_snapshot='{}' WHERE id=$1","UPDATE admin_orders SET customer_id='22222222-2222-4222-8222-222222222222' WHERE id=$1","UPDATE admin_orders SET snapshot_sealed=false WHERE id=$1","UPDATE admin_orders SET document='{}' WHERE id=$1","UPDATE admin_orders SET payment_status='paid' WHERE id=$1","UPDATE admin_orders SET inventory_status='unreserved' WHERE id=$1","UPDATE admin_order_items SET unit_price_minor=1 WHERE order_id=$1","UPDATE admin_order_items SET quantity=2,line_total_minor=298000 WHERE order_id=$1","DELETE FROM admin_order_items WHERE order_id=$1"] )await assert.rejects(db.query(sql,[order.id]),undefined,sql);
 await assert.rejects(db.query("INSERT INTO admin_order_items(order_id,line_number,product_id,sku_snapshot,name_snapshot,quantity,unit_price_minor,line_total_minor,product_revision) VALUES($1,2,'p2','p2','Extra',1,0,0,1)",[order.id]),/sealed/);
 assert.equal((await store.getCustomerOrder(customerId,order.id)).totalMinor,179000);
});

test('cancellation never restores stock, including after a daily absolute import',async t=>{
 const {store,admin,stock}=await fixture(t);
 const first=(await store.createOrder(input())).order;
 const second=(await store.createOrder(input('second_order_key_01',{items:[{productId:'p1',quantity:1,expectedRevision:2}]}))).order;
 const cancelled=await admin.updateOrder(first.id,1,{status:'cancelled'},actor);
 assert.equal(cancelled.status,'cancelled');assert.equal(cancelled.inventoryStatus,'deducted_manual_adjustment_required');assert.equal(cancelled.paymentStatus,'cod_cancelled');assert.equal((await stock()).document.stockQuantity,3);assert.equal((await stock()).revision,3);
 await assert.rejects(admin.updateOrder(first.id,cancelled.version,{status:'cancelled'},actor),status(409));
 await assert.rejects(admin.updateOrder(first.id,1,{status:'processing'},actor),status(409));
 await admin.applyStockImport([{id:'p1',version:3,stockQuantity:30}],actor);assert.equal((await stock()).document.stockQuantity,30);
 const afterImport=await admin.updateOrder(second.id,1,{status:'cancelled'},actor);
 assert.equal(afterImport.inventoryStatus,'deducted_manual_adjustment_required');assert.equal((await stock()).document.stockQuantity,30);assert.equal((await stock()).revision,4);
 const history=await store.getCustomerOrder(customerId,second.id);assert.equal(history.status,'cancelled');assert.equal(history.totalMinor,179000);
 const audit=await admin.listAudit();const orderEvents=audit.entries.filter(entry=>entry.entityType==='order');assert.equal(orderEvents.length,2);assert(orderEvents.every(entry=>entry.actorId===actor));assert(!JSON.stringify(orderEvents).includes(contact.address));
});

test('a new order invalidates an earlier absolute-stock import preview atomically',async t=>{
 const {store,admin,stock}=await fixture(t);
 const preview=(await admin.listProducts()).filter(product=>['p1','p2'].includes(product.id)).map(product=>({id:product.id,version:product.version,stockQuantity:30}));
 await store.createOrder(input());
 await assert.rejects(admin.applyStockImport(preview,actor),status(409));
 assert.equal((await stock('p1')).document.stockQuantity,4);assert.equal((await stock('p1')).revision,2);assert.equal((await stock('p2')).document.stockQuantity,5);assert.equal((await stock('p2')).revision,1);
});


test('quotes are read-only, authoritative and customer-scoped',async t=>{
 const {store,stock,counts}=await fixture(t);
 const quoted=await store.quote(customerId,[{productId:'p1',quantity:2}]);
 assert.equal(quoted.subtotalMinor,298000);assert.equal(quoted.deliveryMinor,30000);assert.equal(quoted.totalMinor,328000);assert.equal(quoted.currency,'RSD');assert.equal(quoted.paymentMethod,'cod');assert.equal(quoted.items[0].productRevision,1);assert.equal(quoted.items[0].unitPriceMinor,149000);assert.equal(quoted.shipping.isEstimate,false);
 assert.equal((await stock()).document.stockQuantity,5);assert.equal((await stock()).revision,1);assert.deepEqual(await counts(),{orders:0,items:0});
 await assert.rejects(store.quote(customerId,[{productId:'p1',quantity:1,unitPriceMinor:1}]),status(400));
 await assert.rejects(store.quote('33333333-3333-4333-8333-333333333333',[{productId:'p1',quantity:1}]),status(404));
 await assert.rejects(store.quote(customerId,[{productId:'p1',quantity:6}]),status(409));
});

test('customer history pagination and idempotency keys stay scoped to their owner',async t=>{
 const {store}=await fixture(t);
 const a=(await store.createOrder(input())).order;
 const b=(await store.createOrder(input(undefined,{customerId:otherCustomerId,items:[{productId:'p1',quantity:1,expectedRevision:2}]}))).order;
 assert.notEqual(a.id,b.id);
 for(const revision of [3,4])await store.createOrder(input('history_order_key_'+revision,{items:[{productId:'p1',quantity:1,expectedRevision:revision}]}));
 const page=await store.listCustomerOrders(customerId,{limit:2});assert.equal(page.orders.length,2);assert(page.nextCursor);assert(page.orders.every(order=>order.customerId===customerId));
 const next=await store.listCustomerOrders(customerId,{limit:2,before:page.nextCursor});assert.equal(next.orders.length,1);assert.equal(next.orders[0].id,a.id);assert.equal(next.nextCursor,null);
 assert.equal((await store.listCustomerOrders(otherCustomerId)).orders.length,1);
 for(const options of [{limit:0},{limit:101},{before:'-1'},{before:'1 OR 1=1'}])await assert.rejects(store.listCustomerOrders(customerId,options),status(400));
});

test('repeated initialization preserves COD records and migration versions',async t=>{
 const {db,store,admin}=await fixture(t);const {order}=await store.createOrder(input());
 await admin.initialize([]);await admin.initialize([]);
 const restored=await store.getCustomerOrder(customerId,order.id);assert.equal(restored.totalMinor,179000);assert.equal(restored.items[0].name,'Original p1');assert.equal(restored.paymentStatus,'cod_due');
 assert.deepEqual((await db.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(row=>row.version),[1,2,3,4,5]);
});
