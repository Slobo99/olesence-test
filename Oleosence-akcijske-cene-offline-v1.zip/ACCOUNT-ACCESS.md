# Moj nalog i administratorske uloge

Veza „Administracija sajta” je podrazumevano skrivena. Prikazuje se tek kada server potvrdi administratorski pristup prijavljenog korisnika. Sakrivanje veze ne zamenjuje zaštitu: administratorske stranice i API proveravaju pravo pristupa na serveru za svaki zahtev.

## Registrovani korisnici

Sekcija „Registrovani korisnici” prikazuje trajno sačuvane naloge sa potvrđenom Google prijavom. Kupovina bez registracije ne pravi takav nalog. Lista je dostupna samo administratorima. Prava se vezuju za trajni identitet korisnika, a ne za imejl upisan u formular.

Vlasnik može da potvrdi dodelu ili ukidanje administratorske uloge postojećem registrovanom korisniku. Ukidanje uloge ne briše korisnički nalog ni njegove porudžbine. Ostali administratori ne mogu da upravljaju ulogama. Promene zahtevaju potvrdu, važeću sesiju i CSRF zaštitu, proveru verzije i zapis u istoriji izmena. Sledeći zahtev ranije prijavljenog administratora proverava trenutno pravo pristupa, pa ukidanje ne čeka njegovu odjavu.

## Vlasnik i zaštita pristupa

Postojeći ADMIN_EMAILS spisak ostaje početni izvor administratorskog pristupa. Ako sadrži tačno jedan nalog, taj nalog je vlasnik. Ako ih ima više, ADMIN_OWNER_EMAIL mora izričito označiti jedan nalog sa tog spiska; bez toga upravljanje ulogama nije dostupno. Ne unositi nov ili neproveren imejl radi aktivacije. Pre postavljanja proveriti da konfiguracija odgovara glavnom nalogu vlasnika.

Početni administratori sa ADMIN_EMAILS spiska ne mogu biti uklonjeni kroz ovu stranicu. Time vlasnik ne može sebi da ukine pristup. Ostali korisnici dobijaju ili gube samo delegiranu ulogu u bazi. Registracija i naknadna prijava nikada same ne dodeljuju administratorska prava.

Sa stranice „Moj nalog” uklonjen je proširivi tekst „O prijavi i čuvanju naloga”. Funkcionalni tok prijave, odjave i kupovine ostaje dostupan.

## Postavljanje

Paket uključuje i prethodnu izmenu čitljivih brojeva porudžbina. Nova migracija za administratorske uloge je dodatna; postojeći korisnici podrazumevano ne dobijaju delegirana prava. Samo objavljivanje ne dodeljuje administratorsku ulogu dodatnim korisnicima. Ne treba menjati ostala podešavanja baze, Google prijave ili kupovine.

Pri povratku na stariju aplikaciju zadržati nove tabele/kolone i audit. Starija aplikacija ne prepoznaje delegirane administratore, ali postojeći ADMIN_EMAILS pristup ostaje dostupan.
