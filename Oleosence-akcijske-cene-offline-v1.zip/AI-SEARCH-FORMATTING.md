# Oleosence: priprema za pretragu i uređivanje opisa

Status: pripremljeno za pregled. Ovaj paket sam po sebi nije objava.

## Šta je promenjeno

- Sve tri javne stranice proizvoda sada u prvom HTML odgovoru sadrže trenutni naslov, opis, cenu, sastav, primenu i upozorenja. Nije potrebno izvršavanje JavaScripta da bi se te informacije pročitale.
- Product JSON-LD koristi isti objavljeni proizvod iz baze kao vidljivi tekst. Cena je RSD; stanje je zasnovano na uključenoj dostupnosti i pozitivnoj zalihi. Offer se ne dodaje dok je poručivanje isključeno. Nema izmišljenih ocena, recenzija, GTIN brojeva ili zdravstvenih tvrdnji.
- Kasnije izmene u administraciji automatski ulaze u novi HTML odgovor i strukturirane podatke. Nema zasebne kopije teksta „za AI“. Posetioci moraju osvežiti stranicu; Google i drugi servisi moraju ponovo obići stranicu da bi registrovali izmenu.
- Administracija za svaki proizvod ima izbor običnog ili formatiranog opisa, dugmad Podnaslov, Podebljano, Lista, Numerisana lista i Novi pasus, kao i trenutni pregled.
- Postojeći opisi ostaju u običnom formatu, sa dosadašnjim naslovom/pasusima. Tekstovi, cene, slike i zalihe se ne menjaju postavljanjem ovog paketa.

## Kako kasnije formatirati opis

1. Otvorite Administracija → Proizvodi i pronađite proizvod.
2. Pod „Prikaz opisa“ izaberite „Formatirani tekst“ samo ako želite formatiranje tog opisa.
3. Unesite ili označite tekst, pa koristite dugmad iznad pregleda. Oznake u polju su vidljive, a u pregledu i na sajtu prikazuju se kao formatiranje.
4. Proverite pregled, tekst, cenu i ostala polja, kliknite „Sačuvaj izmene“ i potvrdite dijalog.
5. Osvežite javnu stranicu i proverite rezultat.

Podržane oznake: `## Podnaslov`, `### Manji podnaslov`, `**podebljano**`, `- stavka`, `1. stavka`. HTML, skripte, linkovi i slike se ne izvršavaju iz opisa. Ukupna granica je 2.000 znakova uključujući oznake; postojeća granica nije promenjena. Za povratak na običan tekst prvo uklonite oznake koje više ne želite da budu vidljive.

Objava marketing nacrta i dalje zahteva postojeće vlasničko odobrenje. Agenti nemaju novo pravo menjanja režima formatiranja. Promena režima čini stariji nacrt zastarelim, pa mora da se ponovo pregleda; već formatiran opis zadržava režim pri objavi novog teksta.

## Šta ostaje isto

- Marketing API ostaje u postojećem stanju ON. Ne pratiti staro OFF-ROLLOUT.md uputstvo za isključivanje: ono se odnosi na raniju, zasebnu fazu.
- Ne menjati environment variables, ključeve, Google prijavu, bazu, pristupne dozvole, Start Command, health check ili checkout podešavanja.
- Privatne stranice i API rute ostaju zaštićene/noindex. CSP nije olabavljen; nije dodat unsafe-inline. Pravila robots.txt i izbor AI crawler/training pristupa nisu menjani.
- Katalog je jedini izvor podataka. Privatni marketing nacrti ne pojavljuju se u HTML-u ili JSON-LD-u.

## Granice i važna napomena

Ovo su tehničke dorade dostupnosti sadržaja, a ne garancija rangiranja, indeksiranja ili citiranja u AI odgovorima. Google ne zahteva poseban „AI schema“ format. Sadržaj treba da bude tačan, koristan i usklađen sa vidljivom stranicom. Zdravstvene tvrdnje, deklaracije i registracioni podaci ovim nisu medicinski/pravno potvrđeni niti prepravljeni.

Paket SSR-uje stranice proizvoda; naslovna stranica i njeni interaktivni odeljci ostaju u dosadašnjem klijentskom prikazu. Ne menja postojeće URL-ove. Nema Search Console prijave ili slanja sadržaja trećim servisima u ovom koraku.

## Provera i postavljanje

`npm run check` proverava sintaksu i ceo skup testova. Dodatne provere obuhvataju server HTML bez JavaScripta, kasnije promene sadržaja/cene/zalihe, Markdown/XSS, usklađenost vidljivog teksta i šeme, čuvanje formata i marketing konflikte.

Tek posle odobrenja objave: postaviti ZIP neizmenjen u koren GitHub grane main; postaviti tačnu Build Command komandu iz prateće potvrde paketa; sačuvati; pokrenuti Manual Deploy → Deploy latest commit; sačekati Live; proveriti objavljeni JS/CSS/HTML i zaštićene rute. Stari ZIP sačuvati za povratak.

Start Command ostaje `node hosted/server.mjs`, health check `/healthz`. Ne pokretati postupak iz OFF-ROLLOUT.md.

## Zvanični izvori provereni tokom pripreme

- https://developers.google.com/search/docs/appearance/ai-features
- https://developers.google.com/search/docs/appearance/structured-data/product-snippet
- https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics
- https://developers.openai.com/api/docs/bots
