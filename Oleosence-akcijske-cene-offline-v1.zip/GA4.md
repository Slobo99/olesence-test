> Historical GA4 page-view release notes. For the current purchase changes and release gates, use PURCHASE.md and PURCHASE-QA.json.

# GA4 integration: G-105CEG84DT

Prepared on 7 November 2026, based on the verified live AI-search release (45a55743405a50fec7e4509d7e1d2ee7ef07a6fa), not the failed/unpublished order-filter release. Not yet deployed.

## Included

- Google tag initialization in the head of every customer-facing HTML response: home, three products, checkout and account (including .html aliases).
- The external Google library loads only after explicit analytics acceptance. With no choice or a refusal, there is no Google analytics request or analytics cookie. Essential shop behavior is unaffected.
- Equal accept/refuse buttons and a persistent “Podešavanja analitike” button. Consent choice expires after 180 days. Refusal/withdrawal disables GA4 and deletes first-party `_ga` cookies without deleting shop cookies or reloading forms. Consent withdrawal in another open tab also disables collection.
- Both HTTP and HTML-meta CSP allow the exact initialization-script SHA-256 plus specific Google hosts. No unsafe-inline or unsafe-eval. Hash is generated from the exact deployed file, avoiding drift. Strict API, OAuth and protected admin policies remain unchanged.
- One explicit page_view per public catalogue document after acceptance. Fixed page title and URL from a closed route list; no query strings, fragments or referrer are passed. No email, name, phone, address, order IDs, user IDs, form values, purchase or ecommerce events are explicitly sent.
- Ad storage, ad user data, ad personalization and Google signals remain disabled.
- Analytics activates only on https://olesence.rs home and product pages; Render preview and local tests do not send real events. The bootstrap is present on account/checkout HTML, but loading Google and collecting events there are deliberately disabled until Google-side automatic measurement settings are reviewed. Protected admin, APIs and OAuth callbacks are not tracked.

## Required GA4-side verification

Website code cannot inspect your GA4 property settings. Before extending collection to account/checkout, verify the G-105CEG84DT web stream and disable Enhanced Measurement form interactions, site search and browser-history page changes; the site sends its own sanitized page views. Disable automatic user-provided data collection and any separately configured custom events/destinations that capture personal information. These Google-side settings and GA4 Realtime receipt have not been verified, and no test events were sent to the real property.

The banner is a technical consent mechanism, not a complete legal privacy notice. The site owner should review their own privacy/cookie disclosures, applicable consent requirements, recipients and retention settings. Google necessarily receives technical connection data once the visitor accepts analytics.

## Files and tests

`src/analytics.mjs` builds the header/meta CSP and HTML insertion; `public/analytics-init.js` is read and inlined by the server, not publicly mounted. `public/analytics.css` styles the controls. The rest of the shop modules and database migrations are unchanged.

Run `npm ci --ignore-scripts --no-audit --no-fund && npm run check`. The tests include consent before/after acceptance, refusal, withdrawal, persistence/expiry, blocked storage, cross-tab revocation, sanitized page data, route coverage, CSP hashes, private endpoints, and existing shop regressions. These are local automated tests, not proof of receipt in GA4.

## Publish and verify

Upload the complete `Oleosence-ga4-v1.zip` to the existing GitHub repository `Slobo99/oleosence-preview`. Use the checksum/build command delivered with the package rather than the old order-filter build command. Keep the existing environment variables, database, start command `node hosted/server.mjs`, and `/healthz` check.

After a successful Render build/deploy, verify the exact release commit is live, then test consent in a fresh browser on olesence.rs: no request to Google before consent or after refusal; one tag and one sanitized page_view after acceptance; no CSP errors on home and each product; no Google requests on checkout/account even when consent is granted. Check GA4 Realtime using an opted-in test visit and confirm ID G-105CEG84DT. Do not submit a real order for this check.

Rollback to the previously verified live AI-search release if the health check or storefront flow fails. Do not deploy the unrelated failed order-filter archive as a recovery action.
