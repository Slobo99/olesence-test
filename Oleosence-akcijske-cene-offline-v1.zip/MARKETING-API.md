# Oleosence marketing API — local preparation, 2026-10-28

**Not deployed. No production key has been issued.** This is a separate feature package based on the published `Oleosence-empty-cart-home-v1.zip`, SHA-256 `54c5bc20ed9e9dd61774f3ad8811495169ee8b82547cded3b814918dd93ef321`. Read-only Render configuration and live deployment metadata matched that baseline on 2026-10-28. The production repository was not changed; its earlier connector access limitation was not bypassed.

## Owner-controlled workflow

1. After separately authorized staging/deployment, the verified Google owner opens **Administracija → Marketing**.
2. The owner explicitly creates a labeled key with selected scopes and an expiry (at most 90 days). Its random secret is shown once; only its SHA-256 hash is persisted. No key is created by installation, migration or startup.
3. Transfer that secret directly into the marketing team's protected credential field. Never paste it into chat, URLs, source files, screenshots, analytics or ordinary logs. The team's reported Bearer/secure-field support has not been tested here.
4. The team reads the catalog, optional exact stock and optional aggregate order values; it creates or replaces private product-content drafts and uploads private sanitized images.
5. The owner reviews the exact revision and before/after values, **approves**, then separately confirms **publish**. Approval is not publication. A new edit clears approval. Stale edits/approvals/publishes return 409 without writes.
6. The owner can reject drafts, revoke a key and inspect marketing history. Revocation/expiry are checked on every API request; draft/image writes also check the key and its scope within their transaction. An already in-flight read can complete; revocation is not a recall of previously downloaded data.

The team has **no publish/approval route**, no access to Google admin APIs and no mutation of prices, stock, availability, orders, customer records, roles or key permissions. Each key can see/edit only its own drafts and private images. Owners may review all drafts. Delegated administrators cannot issue keys, view these drafts or approve/publish them.

Scope: existing product copy (including warnings), product images, product-page SEO title/description. Homepage/FAQ/sliders, campaign attribution, GA/Meta, newsletters and social publishing are not included. Product warnings/health-related claims still require substantive owner review; approval is not a medical or regulatory validation.

## HTTPS REST contract

Base: `https://olesence.rs/api/marketing/v1` **after activation only**. Requests are server-to-server; no CORS or browser cookie authentication. Public Host and HTTPS proxy controls remain in place. Do not send browser Origin/Fetch-Metadata headers.

```http
Authorization: Bearer <KEY_FROM_PROTECTED_CREDENTIAL_FIELD>
Content-Type: application/json
```

Use the key in the header only, never in query strings. The placeholder is intentionally not a usable credential. All marketing responses are `Cache-Control: no-store` and retain private noindex headers.

| Method / path | Scope | Result |
|---|---|---|
| GET `/catalog` | `catalog:read` | `{products:[...]}` with published product content, price in minor RSD units, availability and `contentVersion`; no exact stock or customer data |
| GET `/stock` | `stock:read` | `{products:[{id,stockQuantity,available}]}`; `null` means unknown, not zero |
| GET `/sales?from=2026-10-01T00:00:00Z&to=2026-11-01T00:00:00Z` | `sales:read` | Aggregate COD order values for creation timestamps in the start-inclusive/end-exclusive interval (maximum 366 days) |
| GET `/drafts?limit=50&before=<cursor>` | `drafts:read` | `{drafts,nextCursor}`; key's own drafts, newest first, limit 1–100 |
| GET `/drafts/:id` | `drafts:read` | Exact private draft revision, base content, patch and approval state |
| POST `/drafts` | `drafts:write` | Creates draft, 201; body below |
| PATCH `/drafts/:id` | `drafts:write` | Replaces the **whole patch**, 200; requires `version` equal to the draft's current `revision` |
| POST `/media` | `media:write` | Raw JPEG/PNG bytes; returns `{hash,imagePath,width,height}`, 201; private until owner publishes a referencing draft |
| GET `/media/:hash.jpg` | `drafts:read` | Own staged JPEG preview only; after publication use the public `imagePath` |

Create:

```json
{
  "productId": "crni-kim",
  "baseContentVersion": "<COPY_CONTENT_VERSION_FROM_CATALOG>",
  "patch": {
    "description": "Predlog opisa za pregled vlasnika.",
    "seoTitle": "Predlog naslova proizvoda",
    "seoDescription": "Predlog kratkog opisa stranice."
  }
}
```

Update uses the same `baseContentVersion`/`patch` fields plus `"version": 1`, but no `productId`. Refresh the catalog and draft before retrying a 409; do not silently rebase or publish changed content. Closed published/rejected drafts cannot be edited: create a new draft.

Allowed patch fields: `name`, `botanical`, `category`, `volume` (120 characters each); `description`, `ingredients`, `note` (2000); `method` (500); `seoTitle` (120), `seoDescription` (320); `declaration: {"warnings":"..."}` (nonempty, ≤10000); `imagePath`. `volume`, `method`, `note` may be null. Everything is plain text, never executable HTML. No SKU, price, inventory, status, role, arbitrary declaration or URL fields are accepted.

`imagePath` can be the path returned by this API's upload, an existing public `/media/<sha256>.jpg`, or exactly one of `/assets/crni-kim.jpg`, `/assets/origano.jpg`, `/assets/cetiri-lopova.jpg`. No external URL is fetched. Upload input is ≤3 MiB JPEG/PNG, max 12 megapixels and 8192 pixels/side, normalized by the existing bounded worker to metadata-free JPEG ≤1600×1600 and ≤1.5 MiB. SVG/animation/mismatched/corrupt content is rejected. A draft image is not in public `/media`; owner preview uses the protected admin route. Bytes identical to an already-public image are already public, not newly privatized.

Limits: 120 requests/minute and 20 writes/minute per key, 600 pre-auth requests/minute per process, one marketing image decode at a time, max 100 stored key records, 1000 open drafts, and 100 MiB combined historical public/private image bytes. JSON body ≤64 KiB. These are single-instance limits, not a distributed abuse-control service. Closed drafts and audit records remain stored; retention/cleanup needs a separately reviewed plan, never automatic deletion.

Errors: 400 invalid fields/query/version; 401 absent/invalid/expired/revoked credential; 403 insufficient scope/owner/browser origin; 404 disabled/unknown/inaccessible resource; 409 changed content/revision or closed/incorrect workflow state; 413 size/quota; 415 MIME; 422 invalid image; 429 request cap; 500/503 unexpected/unavailable storage. No secrets are returned in error messages.

## Sales are not collected revenue

Only structured accepted COD orders (`model_version=2`, payment method COD) are aggregated; legacy/draft orders are excluded. Output contains `orderCount`, `orderValueMinor`, `byStatus` with order/product/delivery values, and **`collectedRevenueMinor: null`, `paymentCollectionTracked: false`**. Totals include cancelled orders, identified separately by status; they are not net sales. “Completed” is a fulfillment status, not proof money was collected. All amounts are integer minor RSD units (100 = 1 RSD). No names, emails, phone numbers, addresses, order IDs or customer IDs are selected/returned.

## Owner admin endpoints

Under `/admin/api/marketing`: GET/POST `/keys`, POST `/keys/:id/revoke` with `{}`; GET `/drafts` and `/drafts/:id`; POST `/drafts/:id/approve`, `/publish`, `/reject` with `{ "version": <reviewed revision> }`; GET `/audit`; GET `/media/:hash.jpg`. These require the current verified Google owner. Mutations additionally require the existing exact Origin and session CSRF token. Key create accepts exactly `{label,scopes,expiresAt}`; the 201 response contains `{key,token}` once. No API for scope expansion exists: revoke and create a new explicitly scoped key.

Draft and published product content use a canonical content-only SHA-256 fingerprint. Stock/price changes do not unnecessarily invalidate a draft, and publication merges only approved content onto the freshly locked product row. Content changes cause a 409. Existing product revision increments on publication deliberately preserve current checkout/admin stale protection; existing checkout reconfirmation behavior is not relaxed. Product and draft changes, media publication and audit are atomic. Marketing audit is separate from the existing admin history and stores before/after content and actor IDs, never plaintext keys, credential hashes, image bytes or order PII.

While the feature is enabled, published product SEO is emitted escaped in server HTML; the storefront also uses published product SEO in client metadata. With the feature OFF, server-side product metadata lookup is skipped entirely (no additional per-page database call). Draft SEO never reaches public pages. **Existing X-Robots-Tag, meta robots and robots.txt remain unchanged**; this feature does not solve the known indexing obstacle or claim search indexing has been enabled.

## Activation, migration and safe rollback (not executed)

For an authorized direct-to-production rollout with the feature OFF first, see `OFF-ROLLOUT.md`. This keeps activation/key issuance separate; it does not waive recovery or access checks.

- Keep `MARKETING_API_ENABLED=0` by default. Preserve all existing approved environment values; no new DB, storage account or OAuth scope is needed.
- Separate authorization is required before production deployment/activation or issuing any real key. Confirm secure team credential handling, hosting access, approved Google owner and backup/restore first.
- `MARKETING_API_ENABLED=1` requires existing Google auth and administration with an unambiguous owner (`ADMIN_OWNER_EMAIL` within `ADMIN_EMAILS`, or the sole bootstrap address). Ambiguous owner/startup storage failures fail closed.
- After base migrations 001–008, `createMarketingStore.initialize()` applies additive migration 009 in a transaction under the existing schema advisory lock, before listening. It adds `marketing_api_keys`, `marketing_drafts`, `marketing_draft_images`, `marketing_audit`, indexes and ledger version 9. It does not seed credentials or modify product/order/customer rows. Repeated startup is idempotent.
- Prefer a separately authorized staging database; if the owner chooses direct production, first follow `OFF-ROLLOUT.md` and retain these activation checks: owner login/delegate rejection, least-privilege key, scope denials, draft invisibility, upload privacy, approval→edit invalidation, live-content conflict, stock-only nonconflict, separate publish confirmation, revocation/expiry, aggregate interpretation, checkout, restart persistence, backup restore and image quota. Local tests do not verify production PostgreSQL connections/TLS/pooling or real Google login.
- **Safe rollback:** disable `MARKETING_API_ENABLED` and restart using the authorized deployment process. All marketing routes become unavailable; keep migration 009 tables and audit for recovery. Previously published product content stays published; flag rollback is not a content rollback. Existing new-code image uploads continue counting retained private images once ledger 9 exists.
- If reverting application code to the audited October 22 ZIP, retain additive tables/ledger; old code ignores them and checkout data stays intact. Old code does not count private images in its original public-image quota. Do not drop tables or restore a whole database over newer orders.
- To undo published content, use a newly reviewed compensating draft based on the current product state (or a separately approved, version-checked owner repair). Restoring an old whole product snapshot could overwrite newer stock/price values and is unsafe. Published image URLs may remain in browser caches and cannot be recalled by reverting a draft.
- Destructive schema/key/audit/image cleanup is deliberately not automated. It needs a verified backup, retention decision, reference review and separate approval.

Build/check: `npm ci --ignore-scripts --no-audit --no-fund && npm run check`. See `MARKETING-VALIDATION.md` for measured local results and remaining verification limits.
