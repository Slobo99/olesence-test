# Marketing integration validation — 2026-10-28

## Status

Local implementation package only. **Not deployed, not pushed, no production key issued, no real grants or orders created.** No Render settings, live content, noindex/robots or production database were changed. All fixtures use isolated local identities/data.

## Baseline evidence

- Materialized authorized Library source `Oleosence-empty-cart-home-v1.zip`, Library ID `libfile_4d060f777acc81918d95f83a1456374e`.
- Verified SHA-256 `54c5bc20ed9e9dd61774f3ad8811495169ee8b82547cded3b814918dd93ef321` against current read-only Render build configuration.
- Latest live deployment metadata: October 22, 2026, `dep-dbco2pgm7kps73ccg69g`, commit `687ae2c26497ae1ceaced241895b55f8b948d420`; auto-deploy off. This confirms the source baseline, not deployment of this feature.
- Earlier GitHub connector access limitation was not bypassed. No alternate repository was substituted for production.
- This deliverable has a new Library identity; the audited baseline file is not replaced.

## Executed local checks

- Locked dependencies installed with lifecycle scripts disabled. `package-lock.json` is unchanged; no dependency upgrade or online vulnerability-audit claim.
- `npm run check`: syntax checks plus **330 tests passed, 0 failed, 0 skipped**. Includes all 278 baseline tests and 52 new marketing tests (counts include nested cases).
- HTTP boundary tests: 16. Disabled defaults, missing/expired/revoked credentials, per-scope denials, server-to-server transport, no CORS/cookie substitution, owner/delegate separation, CSRF, exact request fields, private images, escaped published SEO, request caps, and static-page fallback during database outage, and OFF-mode denial of every marketing surface without marketing storage calls or extra product-page DB reads.
- Real PostgreSQL-engine store tests: 14 using PGlite. Additive migration idempotence; hash-only key storage/audit secrecy; transactional scope/revocation checks; own-draft isolation; content allowlist; approval revision and invalidation on edit; content stale conflicts; stock/price-preserving publish; image privacy/combined quota; audit-failure rollback; COD aggregates without customer PII or inferred collections.
- End-to-end HTTP + real store: 1. Private draft/image → approve → edit invalidates → reject stale publish → reapprove → publish. Public content/media appear only after publication, with intervening commercial changes preserved; revoked key then fails.
- Marketing UI/DOM: 21 (including nested capability cases). Separate explicit approval/publication, stale409 fresh review, repeated-click guards, detached/stale response suppression, safe text/media rendering, owner-capability loss, revoke/cancel, scoped expiry, one-time secret clearing, uncertain key-issuance reconciliation, audit pagination. Focused current+existing admin/image UI suite: 72/72 passed.
- Independent security review: no unresolved concrete security findings. Independently exercised HTTP/store/UI suites; the caught static-page outage regression, key-label cap mismatch and misleading warnings diff were corrected and retested.
- Verified baseline bytes unchanged for `public/robots.txt`, original public HTML, package lock, checkout/COD/guest implementations and all original image assets. New code only renders published product SEO dynamically; it does not enable indexing.

## Verification limits

- **Browser/pixel QA not completed:** local Chromium failed to start before any page request. A single supported escalation also failed before execution due to a protected read-only environment path. No restriction was bypassed and no screenshots exist. DOM tests are not a substitute for desktop/narrow-phone visual verification.
- PGlite is a real PostgreSQL engine but a single serialized session here. Tests exercise SQL/transactions/rollback and stale outcomes; they do **not** prove real PostgreSQL multi-session lock timing, hosted connection pooling, TLS, runtime DB permissions, production performance, backup or restore.
- No real Google owner/delegated login, hosted migration, restart persistence on Render, live API request, marketing-platform connection, credential transfer or deployment was attempted. Those require the authorized controlled rollout and separately authorized activation.
- The team's HTTPS Bearer/secure credential-field capability remains user-reported and untested.
- Product drafts only: homepage, FAQ, sliders, advertising/social integrations and attribution are excluded. Known public noindex/robots behavior remains unchanged and is still an independent marketing/indexing decision.
- COD order values are not verified collected revenue. Collection tracking is absent; `collectedRevenueMinor` is null even for completed orders.
- Existing checkout shared product revision remains; marketing drafts avoid stock-only conflicts via a separate content fingerprint, while publish still increments product revision to preserve checkout stale protection.

## Next authorized gate

Use `MARKETING-API.md` for API contract, owner steps, additive migration009 and safe flag/code rollback. Before any production action, review the package and explicitly authorize deployment/activation; validate the owner workflow, narrow-phone layout, real database/Google integration and backup/restore in an approved environment. Issue a least-privilege real key only after that approval and enter it directly into the team's protected field, never chat.
