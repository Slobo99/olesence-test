# Kratko uputstvo za vlasnika

**Dorada je pripremljena lokalno. Nije postavljena na živi sajt i pravi API ključ nije napravljen.** Dogovoren je kontrolisan redosled: prvo provera oporavka i objava sa isključenim API-jem, zatim provera prodavnice. Uključivanje API-ja i izdavanje ključa traže zasebno odobrenje.

## Šta AI tim može

- Čitanje objavljenih proizvoda, po dozvoli tačnih zaliha i zbirnih vrednosti porudžbina.
- Predlaganje novih tekstova proizvoda, fotografija i SEO naslova/opisa kao privatnih nacrta.
- Izmena sopstvenih nacrta — svaka izmena poništava ranije odobrenje.

Tim ne može da objavljuje, menja cene ili zalihe, obrađuje porudžbine, upravlja nalozima niti dobija lične podatke kupaca. Nacrti i nove fotografije nisu javno dostupni pre objave.

## Kako ćete kontrolisati izmene

Nakon odobrenog uključivanja, prijavite se postojećim Google nalogom vlasnika i otvorite **Administracija → Marketing**:

1. Otvorite nacrt i pregledajte „Pre” i „Predlog”, fotografiju i broj verzije.
2. **Odobri ovu verziju** samo odobrava pregledani nacrt — još ga ne objavljuje.
3. **Objavi odobrenu verziju** zahteva novu, odvojenu potvrdu i tek tada menja javni katalog.
4. Ako je tim u međuvremenu izmenio nacrt ili se javni tekst promenio, server odbija staru potvrdu. Ponovo pregledajte najnovije podatke; nema automatskog odobrenja.
5. Neodgovarajući nacrt odbijte. Sve radnje ostaju u marketing istoriji.

Pristup timu se kasnije daje kroz ograničen ključ sa izabranim mogućnostima i rokom 7, 30 ili 90 dana. Prikazuje se samo jednom. Prenesite ga direktno u zaštićeno polje svog AI sistema — **ne u chat ili dokument**. Dugme **Opozovi ključ** prekida budući pristup; postojeći nacrti ostaju vama za pregled. Ako odgovor pri kreiranju ključa nije jasan, prvo osvežite spisak, umesto ponovnog pravljenja ključa.

## Važne granice ove verzije

- Uređuju se proizvodi; početna strana, FAQ i slajderi nisu obuhvaćeni.
- Vrednost porudžbina pouzećem nije dokaz naplaćenog prihoda. Naplaćeni prihod se prikazuje kao nepoznat, uključujući završene porudžbine.
- Postojeći `noindex`/`robots.txt` nisu menjani. Omogućavanje indeksiranja je zasebna odluka.
- Lokalno je prošlo 330 testova. Stvarni Google/Render tok, produkcijska baza i vizuelni pregled u pregledaču još nisu potvrđeni.

Tehnički ugovor, migracija i bezbedan povratak: `MARKETING-API.md`. Detalji provera i ograničenja: `MARKETING-VALIDATION.md`.
