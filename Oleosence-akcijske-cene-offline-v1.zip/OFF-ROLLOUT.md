> ARHIVSKO UPUTSTVO za raniju OFF fazu. Za ovaj paket koristite AI-SEARCH-FORMATTING.md. Ne isključujte aktivni marketing API i ne menjajte postojeća podešavanja.

# Production rollout with the marketing feature OFF

Prepared 2026-10-28. This is a plan, not evidence of deployment. Use only after owner authorization and the recovery/access gates below are satisfied. Do not issue keys, activate marketing, change live content/stock/prices or change noindex/robots in this phase.

## Verified starting point

- Existing service: `srv-db5k1r4s728c7383l140`, `oleosence-login-test`, workspace `tea-db3ibnei0phs73aagbh0`, region Oregon, one instance.
- Source: `Slobo99/oleosence-preview`, branch `main`, auto-deploy OFF.
- Live deployment: `dep-dbco2pgm7kps73ccg69g`, commit `687ae2c26497ae1ceaced241895b55f8b948d420`, October 22.
- Current archive: `Oleosence-empty-cart-home-v1.zip`, SHA256 `54c5bc20ed9e9dd61774f3ad8811495169ee8b82547cded3b814918dd93ef321`.
- Start command: `node hosted/server.mjs`; health path `/healthz`.
- Current read-only metadata matches these values. No new deployment exists at the preparation checkpoint.

## Blocking gates — do not skip

1. **Legitimate repository access:** the connected production repository still returned404 on the October28 read check. This does not prove it is absent. Do not substitute the separate test repository or another identity to bypass access. The authorized owner can upload/commit the ZIP in the existing production repository, or restore the intended authorized connector access.
2. **Database binding and recoverability:** an available paid database named `oleosence-db` exists, but its name/status do not prove the web service binding or a usable recovery point. Confirm the actual service-to-database binding without copying credentials. In its Recovery page, verify an available recent PITR window or completed logical backup and note the timestamp. Do not download/export customer data, create a restore instance, change credentials or alter permissions as part of this check.
3. **Code rollback availability:** on the service Deploys page confirm that the October22 live deployment's retained build artifact is eligible for rollback. A historical deployment row alone is not proof the artifact is retained. Retain the baseline ZIP/hash as a second code-rebuild path.
4. **Configuration:** retain all existing auth, database, checkout, guest-checkout, origin and redirect-host values. Explicitly keep `MARKETING_API_ENABLED=0` for the new deploy. Never replace the environment with `.env.example` (it contains safe defaults, not the approved live configuration). Preserve auto-deploy OFF.

Dashboard links:
- Service: https://dashboard.render.com/web/srv-db5k1r4s728c7383l140
- Candidate database (binding still requires confirmation): https://dashboard.render.com/d/dpg-db6ade2jnfac73d1n5s0-a

The assistant's read-only database dashboard check reached a sign-in page. No sign-in or secret entry was attempted. Recovery remains unverified until the owner/authenticated authorized session can inspect it. Share only a redacted Recovery section with timestamps/status, not connection strings or passwords.

## Phase 1 — code deployed, feature OFF

1. Upload the latest `Oleosence-marketing-drafts-v1.zip` to the root of the existing production repository, preserving the old ZIP, and commit to `main`. Verify the resulting remote commit and archive hash. Use the **current hash delivered with this Library version**, not a superseded hash.
2. Change only the Build Command to the existing checksum-verify → ZIP-extract → install → test pattern, substituting the new filename/hash. Keep the start command and health path unchanged. Exact checksum-bearing command is supplied with the final archive receipt; its SHA cannot be embedded inside its own archive without circularity.
3. Confirm `MARKETING_API_ENABLED=0`; use a standard manual deployment of the verified new commit, not Restart Service. Do not trigger before the file and build configuration agree.
4. Follow that specific deploy to a terminal status. A trigger/queued/building response is not success. On failure, diagnose the first failure; do not repeatedly trigger unchanged deploys.
5. After Live, verify `/healthz`, public catalog, homepage, three product pages, images, account and checkout-session availability, empty-cart navigation, and unchanged robots headers. Verify marketing agent endpoints return404 and owner admin capabilities are false/tab hidden. No real order, stock edit or content save is needed for these checks.
6. Verify the returned public JS hash matches this package, deployment commit matches the intended commit, and logs show no new startup/request errors. `/healthz` is liveness only, so it is not sufficient evidence that catalog/database/auth flows work.

### What OFF means

The new marketing store is not constructed/initialized, migration009 is not applied, no key is generated, marketing capabilities are false and the tab is hidden, and all marketing workflows remain unavailable. Product-page server SEO lookup is skipped entirely, without an extra database call. Existing base migrations001–008 and seed-if-missing startup behavior remain unchanged; do not describe application startup as performing literally no SQL. Existing admin/frontend source still contains the new code, so post-deploy regression verification is required.

## Rollback

If phase1 regresses the shop, roll back to the confirmed retained October22 build artifact through the authorized process, then verify public catalog/checkout capability and deployment state again. Rollback is a new deployment and does not restore database contents. Keep auto-deploy OFF. A future standard deploy can reuse current saved build settings, so reconcile them with the intended source before any subsequent deployment.

Fallback rebuild of the baseline uses its original filename/hash and existing start command. Do not restore a whole old database over newer orders. Do not drop schema objects, delete keys/audit/images, create paid recovery resources or change DB connection/permissions without appropriate separate authorization.

## Later phase — separate approval

Only after phase1 is verified and the owner separately approves activation may `MARKETING_API_ENABLED=1` be deployed. That applies additive migration009 before listening and exposes the owner workflow. Real key issuance/transfer remains a distinct explicit owner action. Staging is not being created by this plan; production activation retains the documented verification risks.

Current platform references consulted: [deploys](https://render.com/docs/deploys), [health checks](https://render.com/docs/health-checks), [rollbacks](https://render.com/docs/rollbacks), [Postgres recovery](https://render.com/docs/postgresql-backups). Platform capabilities do not establish a verified recovery point for this particular database.
