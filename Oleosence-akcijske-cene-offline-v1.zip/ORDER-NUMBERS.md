# Brojevi porudžbina

Nove prihvaćene porudžbine dobijaju čitljiv broj, na primer **2026-1000**, **2026-1001**. Godina se određuje prema vremenu kreiranja u vremenskoj zoni **Europe/Belgrade**. Brojanje počinje od 1000 svake godine. Postojeće porudžbine zadržavaju svoj dosadašnji prikaz; nema naknadnog prebrojavanja.

Broj se prikazuje na potvrdi, u istoriji kupovine i u administraciji. Interni nepredvidivi ID ostaje isti i koristi se za tehničke veze. Poznavanje čitljivog broja ne daje pristup porudžbini; pristup i dalje zavisi od prijavljenog kupca ili važeće gostujuće sesije. Nema javne pretrage porudžbina po broju.

Migracija 007 dodaje broj i godišnji brojač. PostgreSQL ga dodeljuje unutar iste transakcije koja prihvata porudžbinu i umanjuje stanje. Ponovljeni zahtev sa istim ključem vraća istu porudžbinu i broj. Otkazivanje ne oslobađa broj. Neuspešna transakcija ne izdaje broj kupcu; njene promene brojača se vraćaju zajedno sa ostalim promenama. Brojevi potvrđenih porudžbina se ne menjaju i ne koriste ponovo.

## Postavljanje

Paket je zasnovan na objavljenom design-update-v1. Postojeća podešavanja hostinga, kupovine i baze ostaju ista. Migracija se primenjuje kroz postojeći migracioni postupak pri pokretanju. Pre vraćanja starije aplikacije zadržati novu šemu i brojač: ne brisati dodeljene brojeve niti vraćati brojač unazad. Stariji kod može prikazivati tehnički ID umesto novog broja. Ovo nije fiskalni broj računa.
