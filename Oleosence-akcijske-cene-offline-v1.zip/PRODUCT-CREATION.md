# Dodavanje proizvoda kroz admin

Status paketa: pripremljen, nije objavljen. Osnova je produkcijski purchase paket sa commita 8c385b3562b63c1562936d789adf754f1e578528, potvrđen preko Render-a 11. novembra 2026. Paket neuspelih filtera porudžbina nije uključen.

## Korišćenje

1. U administraciji otvorite Proizvodi → + Dodaj proizvod.
2. Unesite naziv, jedinstven SKU/adresu, cenu u RSD, opis, kategoriju, sastav i proverene podatke deklaracije. Upozorenja, upotreba i čuvanje su obavezni. SKU koristi mala latinična slova, brojeve i crtice; nakon čuvanja se ne menja.
3. Sačuvajte nacrt i potvrdite. Nacrt nije u javnom katalogu, pretrazi, sitemap-u niti kupovini; početna zaliha je 0.
4. U kartici novog proizvoda izaberite JPEG/PNG fotografiju do 3 MiB i 12 megapiksela. Pregledajte i sačuvajte fotografiju. Server uklanja metapodatke i čuva ograničenu JPEG verziju u postojećoj bazi.
5. Proverite sve podatke. Označite „Objavljen u prodavnici” i sačuvajte uz potvrdu. Stranica, katalog, povezani proizvodi i sitemap koriste proizvod bez novih izmena koda.
6. Za poručivanje unesite potvrđenu pozitivnu zalihu i uključite dostupnost. Objavljen ali nedostupan proizvod ostaje vidljiv, bez mogućnosti kupovine.

Deklaracija se može naknadno uređivati, uključujući upotrebu i čuvanje. Upozorenja se ne smeju obrisati. Ne unosite pretpostavljene zdravstvene tvrdnje. Povlačenje objave uklanja proizvod iz javnih prikaza i kupovine, ali čuva podatke i ranije porudžbine.

## Uvoz zaliha

- Standardni .xlsx uvoz koristi novi SKU u koloni SKU i količinu u availableQuantity.
- Originalni magacinski .xls izveštaj koristi opcionu jedinstvenu „Šifru u izveštaju zaliha” (Ident), najviše 40 velikih slova, brojeva, crtica ili donjih crta.
- Postojeće O001/O002/O003 veze ostaju fiksne. Nepoznate i duplirane šifre odbijaju se, bez prećutnog povezivanja proizvoda.
- I dalje se koristi samo Magacin Bio Prodavnica B2C. Uvoz ne menja cene i ne objavljuje nacrte.

## Bezbednost i provere

Postojeće Google admin ovlašćenje, origin/CSRF provere, revizije, audit, obrada slika, kontrola zaliha i potvrđene GA4 purchase poruke su sačuvani. Nove stranice mere se samo uz saglasnost i serverom potvrđenu javnu stranicu; privatni admin, lični podaci, parametri URL-a i referrer ne šalju se analitici.

Identifikator je jedinstven u bazi; ponovljeno kreiranje ne prepisuje postojeći proizvod. Ako odgovor čuvanja nije potvrđen, novi pokušaj se blokira uz uputstvo da se osveži prikaz i pronađe SKU. Fotografije nacrta i slike koje više nisu vezane za javni proizvod zahtevaju admin pristup.

Nema nove SQL migracije niti izmene postojeće konfiguracije baze. Novi podaci čuvaju se u postojećim JSONB tabelama. Nikakav pravi proizvod ili porudžbina nisu kreirani tokom provera.

## Važno za vraćanje verzije

Posle kreiranja novih proizvoda/nacrta ne vraćati automatski stari purchase paket: stari kod ne poznaje status neobjavljenog proizvoda. Koristiti popravku na ovoj verziji ili zasebno pregledan plan vraćanja koji čuva privatnost nacrta i sve podatke. Ne brisati podatke radi vraćanja bez posebnog odobrenja.

## Objavljivanje

Pročitati UPUTSTVO-ZA-OBJAVU.txt i PRODUCT-CREATION-QA.json. Istorijska uputstva i purchase/GA4 izveštaji u paketu opisuju ranije verzije. Aktuelni CSP generiše se iz aktuelnog analytics-init.js, ne preuzimati hash iz starog PURCHASE-CSP.txt.
