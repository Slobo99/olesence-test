# Uređivanje upozorenja proizvoda

U administraciji otvorite „Proizvodi”, pronađite proizvod i izmenite polje „Upozorenja”. Polje sadrži postojeći tekst. Sačuvajte izmene i potvrdite pregled. Tekst mora biti neprazan i može sadržati najviše 10.000 znakova. Ostali delovi deklaracije ostaju samo za čitanje.

Ako tekst niste menjali, upozorenje se ne šalje kao izmena. Prethodna i nova vrednost čuvaju se u istoriji izmena. Ako je drugi zahtev promenio proizvod, sačuvavanje zastarele verzije se odbija; osvežite podatke i proverite tekst.

Promena se čuva u postojećem PostgreSQL dokumentu proizvoda i javno prikazuje kao običan tekst, bez izvršavanja HTML sadržaja. Nema nove migracije, polja sa tajnama, dodatnih dozvola ili podešavanja. Postojeća upozorenja nisu prepravljena ovim paketom. Ako javni katalog nije dostupan, postojeći prikaz rezervnih osnovnih podataka i upozorenje o nedostupnosti kataloga ostaju isti.

Objava koristi kompletan ZIP u korenu produkcionog repozitorijuma; postojeće postavke prijave, kupovine, cena i zaliha ostaju iste.

Na stranici svakog proizvoda „Sastav i osnovne informacije” nalazi se u istom obojenom bloku sa „Namena i deklaracija”. Naslovi delova su podebljani radi jasnijeg čitanja. Sadržaj deklaracija i upozorenja nije izmenjen.

Korpa u zaglavlju ima naglašen kontrast, ikonu i oznaku ukupnog broja komada. U otvorenoj korpi „Nastavi kupovinu” vraća na kolekciju uz očuvan sadržaj korpe. Dugme „Završi kupovinu” ispod vodi na unos podataka i pregled porudžbine; ne šalje porudžbinu. Ako poručivanje nije dostupno, prelazak na porudžbinu ostaje onemogućen.

Na užim ekranima kontrole korpe i količine imaju najmanje 44 px, polja za unos koriste veličinu slova 16 px, a dugmad se prikazuju jedno ispod drugog. Ove izmene ne menjaju slanje porudžbine, prijavu ili obračun zaliha.
