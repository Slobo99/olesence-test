# GA4 purchase: faza 1

Pripremljeno 11. novembra 2026. Nije objavljeno. Ovaj dokument zamenjuje ranije GA4 uputstvo samo za praćenje potvrde kupovine.

## Izmena

- `public/checkout.js`: `trackPurchase(order)` se poziva iz potvrde koju je vratio server. Samo potvrđene, neotkazane porudžbine sa validnim cenama i količinama. Istorija porudžbina ne pokreće događaj.
- `public/analytics-init.js`: mali API za pristanak i bezbednu potvrdu; Google se ne učitava na formularu, panelu sa nepotvrđenim ishodom ili nalogu. Nema checkout page_view. Povratak na formular ponovo isključuje prikupljanje.
- `src/analytics.mjs`: tekst pristanka sada navodi i potvrđene porudžbine. HTTP i meta CSP automatski dobijaju isti SHA-256 iz tačnih bajtova skripte. Nema novih domena niti unsafe-inline.
- `test/purchase.test.mjs`: dodatni automatizovani testovi potvrde, pristanka, privatnosti, ponavljanja i grešaka skladišta.

`transaction_id` je `order.id`. `value` uključuje dostavu, `shipping` je dostava; svi iznosi se dele sa 100 i valuta je RSD. Stavke dolaze iz potvrđenog odgovora, ne korpe. `payment_type` je `pouzece`. `tax` nije poslat. Ne šalju se ime, imejl, telefon, adresa, grad, poštanski broj ili ID naloga. Bezbedni kontekst u konfiguraciji i događaju je `https://olesence.rs/checkout/potvrda`, prazan referrer i fiksni naslov.

Uspešan poziv reda za slanje nije dokaz da je Google primio događaj. Blokator reklama ili mrežni prekid mogu sprečiti prijem.

## Deduplikacija i izuzeci

Posle poziva gtag upisuje se `olesence.purchase-tracked:<order.id>`. Pre slanja čuva se zasebna rezervacija `:reserved`; ona sprečava duplikat čak i ako poslednji upis zakaže. Neizvestan pokušaj se ne šalje automatski ponovo. Nedostupno sessionStorage skladište zatvara praćenje bez uticaja na porudžbinu. Opseg je ista sesija kartice; globalna deduplikacija između različitih uređaja nije uvedena.

Uputstvo istovremeno traži slanje kada brisanje pending zapisa zakaže i zabranjuje slanje dok je pending panel vidljiv. Zadržano je postojeće bezbedno obnavljanje porudžbine: u ovom retkom slučaju praćenje se odlaže do uspešnog ponovnog pokušaja. Kontakt podaci se ne uklanjaju iz postojeće potvrde niti menja sadržaj porudžbine.

Trenutni API prihvata samo pouzeće. Kod sadrži naziv `kartica`, ali buduće kartično plaćanje zahteva proširenje postojeće validacije i posebne testove. Otkazivanja ne brišu prethodni purchase; refund nije uveden.

## Faza 2 nije uključena

Nema Meta Pixel, Google Ads, marketing pristanka, novih reklamnih CSP domena, view_item, add_to_cart, begin_checkout ni refund. Potrebni su pravi ID-ovi i posebno odobrenje. Reklamni signali ostaju denied; Google signals i personalizacija ostaju isključeni.

## Obavezno pre objave

1. Proveriti aktuelni produkcijski deploy i uporediti izvornu verziju. Ne koristiti neuspešni paket filtera porudžbina. Javni checkout.js, app.js, product-view.js, catalog.js i inline analytics upoređeni su 11. novembra sa polaznim GA4 paketom i podudaraju se; Render zatim potvrđuje aktivni deploy dep-dbncjcdg1s2s73catlv0, commit 7dc10c4c7ffee62a4950174ebeaddfa89feba798, i checksum polaznog GA4 ZIP-a 0755a230279175845d25176b755340c32355eca94db5e11b21680c813a3b4057.
2. U GA4 stream-u G-105CEG84DT proveriti da su isključeni Enhanced Measurement form interactions, site search, browser-history page changes i automatsko prikupljanje korisničkih podataka. Proveriti i druge događaje/destinacije. Ove postavke nisu dostupne iz izvornog koda. Google biblioteka na potvrdi radi u dokumentu koji sadrži lične podatke, pa ovo ostaje uslov objave.
3. U stvarnom pregledaču proveriti Network i CSP: pre pristanka i na formularu nema Google zahteva; posle potvrde tačno jedan sanitizovan purchase, bez upita ?order= i kontakt podataka. Automatizovani testovi koriste simuliranu Google biblioteku, ne stvarni GA4.
4. Tek po potvrdi pristupa i prethodnih provera objaviti na postojeći servis. Ne menjati bazu, promenljive okruženja, tajne ili start komandu. Test porudžbina na produkciji i njeno otkazivanje nisu izvršeni.
5. Nakon objave proveriti tačan commit/deploy, /healthz, kupovinu, pristanak i GA4 DebugView/Tag Assistant. Zabeležiti order.id/orderNumber test porudžbine i sanitizovani dokaz događaja; osvežavanje i replay ne smeju ponoviti događaj.

Render radni prostor je potvrđen i aktuelni deploy je proveren. GitHub veza trenutno vraća da repozitorijum nije pronađen, a pregledač je odjavljen i prikazuje 404. Google Analytics takođe traži prijavu. Potrebna je autentifikacija u oba servisa, zatim provere postavki i mrežnog saobraćaja. Nije potvrđen prijem događaja u GA4 i nema snimka DebugView. Ovaj paket je kod za pregled i testiranje, ne potvrda produkcijske objave.
