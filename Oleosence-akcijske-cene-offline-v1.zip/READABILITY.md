# Čitljiviji opis proizvoda — priprema, nije objavljeno

30. oktobar 2026. Ova dorada menja prikaz, ne tekst proizvoda.

## Promena

Postojeći opis se ranije ubacivao u jedan HTML pasus, pa je browser spajao njegove nove redove. Sada se plain-text redovi prikazuju kao odvojeni semantički pasusi. Kratak prvi red bez završne interpunkcije, kada iza njega postoje drugi redovi, dobija naslov drugog nivoa. Ne dodaju se nove reči niti se HTML/Markdown iz kataloga tumači kao kod: svako polje se postavlja preko `textContent`.

Opis koristi 16 px, prored 1.8, jasne razmake između pasusa i prelom dugih reči. Na telefonu ostaje 16 px umesto dosadašnjih 13 px. Nema skraćivanja, „pročitaj više”, skrivanja teksta ili novih harmonika.

Javni opis crnog kima od 30. oktobra proveravan je kao tačno 1.241 znak: postojeći naslov i četiri pasusa. Njegov SHA256 u UTF-8 je `56bc2f0e4b63cdc00ac1f558f36e5e9c266e875a9f767ad0cebcb7c645d9f7e6`. Tekst nije upisan u seed katalog niti u bazu. Stvarni sajt i dalje čita aktuelan javni katalog iz baze; naknadne vlasničke izmene nisu prepisane snapshot-om.

Namena, upozorenja, način primene, cene, korpa, poručivanje, prijava, administracija, marketing API, vlasničko odobravanje/objava i tehnički SEO ostaju nepromenjeni. Nema novih medicinskih ili registracionih tvrdnji, promene doziranja, novih tajni/prava ili SQL migracija.

## Provere

- `npm run check`: 352/352 testova, bez padova ili preskakanja; pet novih DOM regresija.
- Nezavisno: 72 fokusirana testa i 94 dodatne DOM provere, bez blokirajućih nalaza.
- Browser: prikaz pre/posle pregledan u narrow-phone okviru (390 px spoljne širine) i desktop okviru. Provereno odsustvo horizontalnog overflow-a, četiri pasusa, 16 px tekst i otvorena upozorenja. To je stvarni browser rendering u uskom iframe-u, ne fizički telefon. DevTools emulacija nije korišćena jer je onemogućena politikom browsera.
- Poređenje sa baseline ZIP-om potvrđuje da runtime izmene obuhvataju samo `public/app.js` i `public/styles.css`; server, katalog, moduli baze i sve migracije su nepromenjeni.

Samostalni HTML pregled „Pre / Predlog”, sa izborom telefona/računara, čuva javni sadržaj samo kao vizuelni uzorak. Nema zahteva ka produkcijskom API-ju, aktivne kupovine ili slanja podataka. Nije deo produkcijskog paketa.

## Osnova i kasnija objava

Osnova: `Oleosence-technical-seo-v1.zip`, SHA256 `7558706a66588ae499bcb5b6dcd9619f31babc4e4bf96f187490e59362974bbf`; potvrđeni prethodni deploy `dep-dbh2e0g8v5cc73e787h0`, commit `e8bc0a0fa7653c29e6f36b02fa3105ce755a0883`.

Ovaj ZIP je pripremljen za pregled, nije objavljen. Tek po odobrenju objave postaviti ga u postojeći produkcijski repozitorijum i zameniti samo filename/hash u checksum → unzip → npm ci → npm run check Build Command-u. Start ostaje `node hosted/server.mjs`, health `/healthz`, a sve environment vrednosti (uključujući aktivni marketing API), prava i tajne ostaju iste. Ne kopirati `.env.example` u produkcijsku konfiguraciju.

Za rollback koristiti potvrđeni prethodni SEO build ili tačnu baseline ZIP datoteku i njen checksum. Ne vraćati staru bazu preko novih porudžbina, ne menjati sadržaj proizvoda niti brisati migracije/ključeve. Posle eventualne objave proveriti aktuelne opise, desktop/telefon, otvorena upozorenja, checkout readiness, javne SEO rute i zaštićeni API bez pravljenja stvarnih porudžbina ili ključeva.
