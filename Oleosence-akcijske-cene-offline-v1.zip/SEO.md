# Tehnički SEO — priprema za olesence.rs

Pripremljeno 28. oktobra 2026. Ovaj dokument opisuje novi paket, ne potvrđuje da je objavljen. Starija marketing/OFF dokumentacija u paketu je istorijska; ne isključivati aktivni marketing API radi ove promene.

## Promene

- Javna početna i postojeće javne stranice proizvoda na tačnom produkcijskom poreklu `https://olesence.rs` mogu da se indeksiraju. Uklonjeno je globalno sprečavanje indeksiranja samo za uspešne javne odgovore. Druga/preview porekla ostaju noindex.
- Jedinstveni naslovi, neutralni opisi i jedan apsolutni canonical nalaze se već u serverskom HTML-u. Nema zastarele rečenice „Kupovina nije dostupna” u javnim meta opisima. Nisu dodate zdravstvene, registracione ili komercijalne tvrdnje.
- Ako vlasnik objavi SEO naslov/opis kroz postojeći marketing tok, taj aktuelni sadržaj iz baze ima prednost nad podrazumevanim tekstom. Nacrti i odobreni-ali-neobjavljeni predlozi se ne čitaju. Kod ne upisuje SEO u bazu niti prepisuje izmene napravljene dok se paket priprema.
- `/sitemap.xml` se pravi iz tekućeg javnog kataloga: početna i podržane, postojeće javne stranice proizvoda. Sadrži samo `https://olesence.rs/` URL-ove bez parametara, alternativnih hostova, privatnih ruta, nacrta ili izmišljenih lastmod datuma. Nedostupnost zaliha ne uklanja legitimnu stranicu proizvoda.
- `/index.html`, završna kosa crta proizvoda i `/proizvod/ID/index.html` dobijaju 308 preusmerenje na čistu rutu. Parametri se zadržavaju pri preusmerenju, ali se ne kopiraju u canonical.
- Nepoznat/nepostojeći proizvod vraća stvarni 404. Nedostupnost baze pri proveri proizvoda/sitemap vraća 503 sa noindex umesto zastarelog 200 ili lažnog 404. Klijentski 404 uklanja canonical i postavlja noindex; fallback kataloga čuva serverski SEO tekst, ali ne dozvoljava indeksiranje zastarelog prikaza.
- `robots.txt` dopušta javne stranice, slike, JS/CSS i javni `/api/catalog` koji renderer koristi, uz sitemap vezu. Privatni admin/API/auth/orders prostori su isključeni iz crawl-a. `/api/catalog` i dalje ima noindex zaglavlje.

## Privatnost i nepromenjene funkcije

Noindex ostaje podrazumevani HTTP odgovor. Admin, nalog, checkout, autentifikacija, API, greške i privatni nacrti nisu postali indeksabilni. Javne stranice naloga/checkout-a ostaju dostupne za učitavanje noindex direktive; njihov sadržaj/akcije i dalje koriste postojeće provere sesije i autorizacije. Robots nije zamena za autorizaciju.

Nisu menjani ključevi, tajne, prava korisnika, marketinški approve/publish tok, cene, zalihe, porudžbine, uslovi dostave, zdravstveni tekstovi ni migracije. Nema novih SQL upisa ili migracija u ovoj izmeni. Postojeći startup/seed-if-missing mehanizam ostaje isti. API i prodavnica zadržavaju postojeća podešavanja, uključujući `MARKETING_API_ENABLED=1`.

Objavljene slike ostaju dostupne; trenutno povezane javne slike mogu da se indeksiraju. Stari javni URL-ovi slika zadržavaju postojeći pristup, uz noindex kada više nisu u javnom katalogu. Neobjavljene marketing slike ostaju zaštićene.

## Objava

1. Tačna osnova je `Oleosence-marketing-drafts-v1.zip`, SHA256 `9fd0ebb796d4a6a34be92747e00ce24e784809b12bab85c3f4435ac6547c5904`, Library `libfile_bc1c4cd4d1d081918eb13eac418116ac`, verzija 1. Poslednja potvrđena aktivacija: commit `1ab0cac18eba08dc997aa75d13ad33d0990be47c`, deploy `dep-dbgqdaff3r2c73adoivg`.
2. Novi ZIP postaviti u koren postojećeg produkcijskog repozitorijuma `Slobo99/oleosence-preview`, sačuvati stari ZIP i potvrditi tačan commit. Konektor nema potvrđen pristup ovom repozitorijumu; ne koristiti drugi repozitorijum kao zamenu.
3. Na postojećem Render servisu `srv-db5k1r4s728c7383l140` promeniti samo Build Command na dostavljenu checksum → unzip → npm ci → npm run check komandu za novi ZIP. Tačan hash komande je uz završni ZIP, jer ga arhiva ne može sadržati bez kružne reference.
4. Start ostaje `node hosted/server.mjs`, health `/healthz`, root directory prazno, auto-deploy OFF. Ne menjati environment promenljive; naročito ne kopirati `.env.example` preko produkcijskih podešavanja i ne gasiti aktivni marketing API.
5. Tek po potvrdi datoteke, hasha, commita i Build Command-a pokrenuti jednu standardnu objavu. Ne koristiti Restart kao zamenu za build. Sačekati terminalni Live ili failed status tačnog deploy-a.
6. Posle Live proveriti GET i HEAD za `/`, tri stranice proizvoda, `/robots.txt`, `/sitemap.xml`, javne slike, `/api/catalog`, `/account`, `/checkout`, `/healthz`. Proveriti canonical, noindex granice, 308 alias rute, nepoznati proizvod 404, marketing bez tokena 401 i postojeću checkout-session sposobnost. Uporediti javne JS hash-eve sa manifestom. Ne kreirati stvarnu porudžbinu, ključ ili nacrt za smoke test.

## Povratak na prethodni kod

- Ako se pojavi regresija, zaustaviti dalje objave i koristiti potvrđeni prethodni zadržani build artefakt, ako je dostupan, ili rebuild tačne baseline ZIP datoteke iznad.
- Baseline Build Command:

```sh
printf '%s\n' '9fd0ebb796d4a6a34be92747e00ce24e784809b12bab85c3f4435ac6547c5904  Oleosence-marketing-drafts-v1.zip' | sha256sum -c - && unzip -q Oleosence-marketing-drafts-v1.zip -d hosted && cd hosted && npm ci --ignore-scripts --no-audit --no-fund && npm run check
```

- Sačuvati postojeće environment vrednosti, posebno aktivni marketing API. Povratak ovog SEO koda ne zahteva DB restore, brisanje migracija, ključeva, nacrta, proizvoda ili porudžbina. Ne vraćati celu staru bazu preko novih porudžbina.
- Potvrditi uspeh rollback deploy-a i ponoviti catalog/checkout/auth/marketing smoke provere. Pre narednog deploy-a uskladiti sačuvani Build Command sa željenim ZIP-om.

## Provere i granice

`npm run check`: sintaksa i 347 testova, uključujući 17 novih SEO/DOM regresija. Nezavisna provera: 44 fokusirana testa, 123 dodatne HTTP tvrdnje i posebne DOM provere. Testovi koriste sintetičke podatke; SQL testovi koriste lokalni PGlite, ne produkcijsku bazu. Izvorni auth/commerce/store moduli i sve migracije su byte-identični prethodnoj verziji.

Pixel/browser provera nije izvršena: Chromium je zaustavljen pre otvaranja stranice zbog sandbox zabrane socket operacije. HTTP i DOM provere jesu izvršene. Prava Google prijava, vlasnički UI, produkcijski PostgreSQL/TLS i Google indeksiranje nisu dokazani ovim lokalnim testovima. Nisu kreirani Search Console pristup/nalog, praćenje, oglasi niti sitemap submission. Omogućeno indeksiranje nije obećanje indeksiranja ili pozicije.

Primarni izvori provereni tokom izrade: [robots/noindex](https://developers.google.com/search/docs/crawling-indexing/robots-meta-tag), [robots ograničenja](https://developers.google.com/search/docs/crawling-indexing/robots/intro), [sitemap](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap), [canonical](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls), [JavaScript SEO](https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics), [HTTP statusi](https://developers.google.com/crawling/docs/troubleshooting/http-status-codes).
