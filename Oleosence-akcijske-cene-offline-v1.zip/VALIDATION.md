# Čitljiviji opis — pripremljen predlog

Pogledajte [READABILITY.md](READABILITY.md) za najnoviju prikaznu doradu. Ovo nije dokaz objave; SEO i marketing funkcije ostaju sačuvane.

---

# Tehnički SEO — nova priprema

Pogledajte [SEO.md](SEO.md) za aktuelnu tehničku SEO promenu, provere i postupak objave/povratka. Aktivni marketing API se čuva; istorijska OFF uputstva ispod nisu nalog da se sada isključi. Ovaj novi ZIP još nije dokaz objave.

---

> Historical baseline validation retained below. For the new draft-only marketing feature and current package results, see MARKETING-VALIDATION.md. No production deployment is implied by either report.

# Account and admin roles candidate — 19 October 2026

Based on the reviewed order-number v1 archive SHA256 `115cf52021ec9184b3062b56b789cbf030e2d231ba30ac2e5e35c45766043528`, including all prior design and numbering changes. Final full check: **269 passed, 0 failed, 0 skipped** (142.5s); independently repeated with all 269 passing and no blocking review findings.

New coverage includes fail-closed account admin-link visibility, stale responses/logout/pagehide, equal Google/guest choices, owner-only confirmed role controls, per-request database authorization, existing-session revocation for admin pages/assets and every API class, verified subject/UUID/email matching, CSRF/exact input validation, protected bootstrap roles, stale role revisions, audit rollback, and migration 7→8 preserving existing records without granting roles. Earlier migrations 001–007 remain byte-identical to the reviewed baseline.

These SQL tests use serialized PGlite sessions, not independent PostgreSQL clients. No new browser pixel-layout check or production role change was performed. Owner configuration must be verified before deployment. The package contains only functioning Google and guest account choices; email/password registration and recovery are a separate pending stage requiring a configured sender.

# Order numbers candidate — 19 October 2026

Final `npm run check`: **234 passed, 0 failed, 0 skipped** (113.6 seconds).

Based on the deployed design update v1 archive SHA256 `917a46d4be9804c75fc386a8f68bf1844dd60480182bfab45beb869753c77a69`.

New coverage includes yearly numbering across the Europe/Belgrade New Year boundary, shared customer/guest numbering, repeated and concurrent caller submissions, immutable/unique numbers, rejected client-supplied numbers, rollback, legacy migration/replay, scoped opaque-ID routes, and display-only UI labels with legacy fallback and escaping. The concurrency calls in these local SQL tests are serialized through PGlite; genuine multi-connection PostgreSQL contention for migration 007 has not been executed here. Earlier staging PostgreSQL results apply to the preceding checkout source, not this new allocator.

All earlier migrations 001–006 remain byte-identical. No production orders or database changes were made during preparation. Migration 007 is additive; preserve its columns, triggers and counter if reverting application code. No real-browser order was created to test these new numbers; receipt/admin DOM behavior is tested with synthetic data.

# Cart visibility and mobile usability addition — 19 October 2026

Full final `npm run check`: **222 passed, 0 failed, 0 skipped**, independently repeated. Cart-button text contrast: 8.26:1.

The pending warnings/layout package now also gives the header cart a contrasting button, clear icon and total-quantity badge. The drawer places “Nastavi kupovinu” above “Završi kupovinu”: the first returns to the product collection with the cart preserved, the second opens checkout details and confirmation. Neither action submits an order. Disabled/empty checkout safeguards remain in place.

Mobile CSS provides at least 44px quantity/remove/close targets, 16px checkout inputs, stacked actions, text wrapping and safe-area-aware dialog scrolling. Catalog warning/source text, prices, stock logic, authentication and checkout request handling are unchanged.

Browser evidence is limited to the previously deployed synthetic checkout in an ordinary 500px desktop viewport, not a physical phone. The new unpublished assets could not be opened in the cloud browser because its loopback connection was refused. No denied device-emulation or standalone browser-launch route was used in this continuation. Automated DOM/CSS checks cover the new controls; 360–390px visual testing of the new source remains pending.

# Product warnings and information layout candidate — 18 October 2026

Based on deployed guest-v2 source SHA256 `f73c5c5909aa0630421491f7aa0cc84c5604b534cfd1c791249bae2fcc6b0cea`. Adds administrator editing of warnings only, with nonempty plain-text validation, bounded Unicode requests, existing revisions and atomic audit records. No schema migration or seed-text changes. Composition/basic information now shares the declaration card; section labels are bold and long warning strings wrap within the card.

Full `npm run check`: **212 passed, 0 failed, 0 skipped**. The final layout-specific repeat passed 5/5.

Focused tests cover persisted warning-only merge, reseed/restart preservation, rejected/stale updates, audit rollback, public HTML escaping, authentication/CSRF, Unicode body bounds, unchanged warning omission, draft/retry/cancel behavior, all three product layouts and semantic content preservation. Checkout, guest sessions, prices, shipping and stock logic remain unchanged.

Desktop/mobile screenshot verification of this new layout was not completed: the local browser launch was rejected by the execution environment before page creation. DOM and CSS checks passed; they are not a visual browser test. No production deployment or database change was performed.

Prior validation follows for history.

# Guest checkout candidate — 18 October 2026

Based on the deployed readability source archive SHA256 `672688405f85dc0edb718bb4c852ce9a189ce6c17b15f3f25955eea3805e8df8`. Full `npm run check`: **190 passed, 0 failed, 0 skipped**. The migration regression additionally pins the prior production request hash, checked by executing the unchanged archived normalizer.

New coverage includes 19 guest/account DOM cases, 6 guest HTTP cases and 16 database cases: secure cookie/CSRF, no fake customer identities, required guest email and rejection of blank, whitespace-only and malformed values, durable quotas across store reconstruction, owner-isolated receipts/history, Google precedence and logout boundaries, immutable snapshots, migration of existing customer orders, unchanged idempotency replay, expiry, zero stock, whole-transaction rollback and cancellation without restocking.

The database tests use PGlite with a serialized single connection. They do not establish genuine multi-connection PostgreSQL behavior for the new guest/session paths. Earlier genuine PostgreSQL concurrency results apply to the original COD code, not all additions here. New guest UI browser/mobile visual QA remains pending; DOM tests are not a substitute. Guest checkout defaults OFF and no live configuration or data was changed.

Prior COD validation follows for history:

# Validation — COD checkout candidate, 16 October 2026

## Baseline and checks

Built from the exact B2C v3 archive SHA-256 `b2274f7290939f6ce53e4b761b67293a2da1ea6c6a62ec2b9b8917f176a7f076` . Existing source was copied into a separate candidate tree. No live configuration or data changed.

The initial full `npm run check` passed 133/133 tests, independently repeated with zero failures or skips. This includes the 110 baseline tests plus 15 COD store and 8 HTTP integration tests. The added checkout UI harness passed 16/16 and covers uncertain/reloaded retries, account changes, cancelled replays and failed browser-storage cleanup. Independent review found no remaining high/critical backend defects after the two UI retry fixes.

New coverage: server-authoritative prices and delivery threshold, known/available stock, insufficient quantities, malformed/extra fields and forged totals, idempotent replay/conflict, rollback on deferred SQL failure, competing last-unit submissions, immutable snapshots, customer isolation, CSRF/origin/session checks, disabled-by-default dependencies, cancellation without restock, absolute import followed by cancellation, stale import-preview rejection, and repeated initialization with saved COD records.

HTTP tests exercise the real server and verified-session flow with isolated fictional OAuth and customer fixtures. No real credentials or customer data are used. All eleven static image assets and package-lock.json are byte-identical to v3; no dependencies were added for checkout.

Final frozen-source `npm run check`: **149/149 passed**, zero failures or skips. Every top-level src/public JavaScript file also passed syntax checking.

## Limits and activation checks

- PostgreSQL server/initdb binaries are not installed in this workspace. PGlite executes PostgreSQL semantics through a serialized single-session test adapter. Concurrent test calls do not establish multi-connection networked PostgreSQL behavior. Run an approved disposable PostgreSQL staging test of simultaneous last-unit orders and import/order contention before activation.
- Browser interaction tests use jsdom. Actual Chromium launch was attempted but the execution environment rejected required sandbox/socket operations before launch; no screenshots or visual-pass claim. A real-browser acceptance test remains a launch gate.
- No production migration, deployment, feature activation, real checkout, payment or email sending was performed.
- No new dependency vulnerability scan or comprehensive security certification is claimed.
- Sessions and rate limits are single-instance/in-memory; business records and idempotency are persistent PostgreSQL data.
- Daily Excel remains absolute replacement as chosen by the owner. The known export/import timing gap is not eliminated by product revision checks. Cancellation never restores stock automatically.

Before launch, complete COD-CHECKOUT.md checks: deployment approval, seller/legal/customer notices, fiscalization, delivery/payment operations, real catalog stock/availability, backup/restore, and browser/staging smoke checks. Keep CHECKOUT_COD_ENABLED=0 until approved activation.


## Empty-cart homepage navigation, 2026-10-22

- Empty-cart “Završi kupovinu” now closes the cart and navigates to `/`. Nonempty checkout gating remains unchanged.
- Based on accounts/admin-roles v1; baseline app.js matched the live app.js byte-for-byte before the change. No backend, migration, dependency, account or admin changes.
- `npm run check`: **278 passed, 0 failed, 0 skipped**. Cart DOM coverage includes direct empty carts, last quantity to zero, last removal, re-add, checkout availability states and original populated-cart navigation.
- Independent source review: no findings. Real browser confirmed the original live behavior only. Patched cross-document navigation is checked by DOM destination/click tests; post-deployment browser verification remains required.
- This build was prepared locally, not deployed.
