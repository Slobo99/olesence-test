-- Applied in the initialization transaction. Existing orders are not backfilled.
-- The opaque id remains the key for ownership, API routes, lines and audit.
ALTER TABLE admin_orders ADD COLUMN IF NOT EXISTS order_number text;
ALTER TABLE admin_orders ADD CONSTRAINT admin_orders_order_number_check CHECK (
 order_number IS NULL OR (model_version IS NOT NULL AND model_version=2
 AND order_number ~ '^[1-9][0-9]{3}-[1-9][0-9]{3,}$')
);
CREATE UNIQUE INDEX admin_orders_order_number_unique ON admin_orders(order_number) WHERE order_number IS NOT NULL;

CREATE TABLE admin_order_number_counters (
 order_year integer PRIMARY KEY CHECK (order_year BETWEEN 1000 AND 9999),
 last_number bigint NOT NULL CHECK (last_number >= 1000)
);

CREATE FUNCTION assign_order_number() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE local_year integer; allocated bigint;
BEGIN
 IF NEW.order_number IS NOT NULL THEN RAISE EXCEPTION 'Order numbers are assigned by the database'; END IF;
 IF NEW.model_version=2 THEN
  local_year := EXTRACT(YEAR FROM NEW.created_at AT TIME ZONE 'Europe/Belgrade')::integer;
  -- PostgreSQL serializes competing increments for each year. This row change
  -- commits with the order, lines and stock, so retries do not consume numbers.
  -- A failed transaction may reuse its uncommitted allocation; a committed
  -- number is never reused, even if its order is subsequently cancelled.
  INSERT INTO admin_order_number_counters(order_year,last_number) VALUES(local_year,1000)
  ON CONFLICT (order_year) DO UPDATE SET last_number=admin_order_number_counters.last_number+1
  RETURNING last_number INTO allocated;
  NEW.order_number := local_year::text || '-' || allocated::text;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER admin_orders_assign_number BEFORE INSERT ON admin_orders FOR EACH ROW EXECUTE FUNCTION assign_order_number();

-- Separate from the existing snapshot trigger, retaining every prior protection.
-- NULL is immutable too: historical orders must continue using their old IDs.
CREATE FUNCTION protect_order_number() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.order_number IS DISTINCT FROM OLD.order_number THEN RAISE EXCEPTION 'Order numbers are immutable'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER admin_orders_number_immutable BEFORE UPDATE ON admin_orders FOR EACH ROW EXECUTE FUNCTION protect_order_number();
INSERT INTO admin_schema_migrations(version) VALUES (7) ON CONFLICT DO NOTHING;
