-- Applied in the initialization transaction. Existing customers receive no grant.
-- Owner/bootstrap authority stays in server configuration and is not mutable here.
ALTER TABLE commerce_customers ADD COLUMN admin_role text NOT NULL DEFAULT 'customer'
 CHECK (admin_role IN ('customer','admin'));
ALTER TABLE commerce_customers ADD COLUMN role_revision integer NOT NULL DEFAULT 1
 CHECK (role_revision > 0);

ALTER TABLE admin_audit DROP CONSTRAINT admin_audit_entity_type_check;
ALTER TABLE admin_audit ADD CONSTRAINT admin_audit_entity_type_check
 CHECK (entity_type IN ('product','order','customer_role'));
INSERT INTO admin_schema_migrations(version) VALUES (8) ON CONFLICT DO NOTHING;
