-- Applied only when marketing integration is explicitly enabled, after 001–008.
CREATE TABLE IF NOT EXISTS marketing_api_keys (
 id text PRIMARY KEY CHECK (id ~ '^[A-Za-z0-9_-]{1,100}$'),
 label text NOT NULL CHECK (length(label) BETWEEN 1 AND 120),
 secret_hash text UNIQUE NOT NULL CHECK (secret_hash ~ '^[a-f0-9]{64}$'),
 scopes jsonb NOT NULL CHECK (jsonb_typeof(scopes)='array'),
 expires_at timestamptz NOT NULL,
 revoked_at timestamptz,
 created_by text NOT NULL CHECK (created_by LIKE 'google:%'),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS marketing_drafts (
 sequence_id bigint GENERATED ALWAYS AS IDENTITY UNIQUE,
 id text PRIMARY KEY,
 product_id text NOT NULL REFERENCES admin_products(id),
 key_id text REFERENCES marketing_api_keys(id),
 created_by text NOT NULL CHECK (created_by LIKE 'google:%' OR created_by LIKE 'agent:%'),
 base_content_version text NOT NULL CHECK (base_content_version ~ '^[a-f0-9]{64}$'),
 base_content jsonb NOT NULL CHECK (jsonb_typeof(base_content)='object'),
 patch jsonb NOT NULL CHECK (jsonb_typeof(patch)='object'),
 revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
 status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','published','rejected')),
 approved_revision integer,
 approved_by text CHECK (approved_by LIKE 'google:%'),
 approved_at timestamptz,
 published_by text CHECK (published_by LIKE 'google:%'),
 published_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK (status <> 'approved' OR (approved_revision=revision AND approved_by IS NOT NULL AND approved_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS marketing_drafts_owner_page ON marketing_drafts(key_id, sequence_id DESC);
CREATE TABLE IF NOT EXISTS marketing_draft_images (
 hash text NOT NULL CHECK (hash ~ '^[a-f0-9]{64}$'),
 actor_id text NOT NULL CHECK (actor_id LIKE 'google:%' OR actor_id LIKE 'agent:%'),
 key_id text REFERENCES marketing_api_keys(id),
 bytes bytea NOT NULL CHECK (octet_length(bytes) > 0 AND octet_length(bytes) <= 1572864),
 mime text NOT NULL CHECK (mime = 'image/jpeg'),
 width integer NOT NULL CHECK (width BETWEEN 1 AND 1600),
 height integer NOT NULL CHECK (height BETWEEN 1 AND 1600),
 created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(hash,actor_id)
);
CREATE TABLE IF NOT EXISTS marketing_audit (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 entity_type text NOT NULL CHECK (entity_type IN ('key','draft','media','product')),
 entity_id text NOT NULL,
 actor_id text NOT NULL CHECK (actor_id LIKE 'google:%' OR actor_id LIKE 'agent:%'),
 action text NOT NULL CHECK (action IN ('create','update','revoke','approve','publish','reject','stage')),
 before_snapshot jsonb NOT NULL,
 after_snapshot jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO admin_schema_migrations(version) VALUES (9) ON CONFLICT DO NOTHING;
