const status=document.querySelector('#auth-status'),login=document.querySelector('#google-login'),logout=document.querySelector('#logout');
const adminLink=document.querySelector('.account-admin-link');
let csrf=null,busy=false,epoch=0,googleEnabled=false,adminEpoch=0,pageActive=false;
function hideAdminLink(){adminEpoch++;if(adminLink)adminLink.hidden=true;}
async function refreshAdminLink(requestEpoch){
 hideAdminLink();
 if(!adminLink||requestEpoch!==epoch||!pageActive||document.hidden)return;
 const checkEpoch=adminEpoch;
 try{
  const response=await fetch('/admin/api/session',{method:'GET',cache:'no-store',credentials:'same-origin'});
  if(!response.ok)return;
  const data=await response.json();
  if(requestEpoch!==epoch||checkEpoch!==adminEpoch||!pageActive||document.hidden)return;
  adminLink.hidden=data?.user?.role!=='admin';
 }catch{}
}
function hideCheckoutLinks(){for(const id of ['checkout-guest','checkout-account','checkout-return']){const element=document.querySelector('#'+id);if(element)element.hidden=true;}}
async function refreshCheckoutLink(requestEpoch){const link=document.querySelector('#checkout-account'),hint=document.querySelector('#checkout-return'),guest=document.querySelector('#checkout-guest');if(!link)return;hideCheckoutLinks();try{const response=await fetch('/api/checkout/session',{cache:'no-store',credentials:'same-origin'});if(!response.ok)return;const data=await response.json();if(requestEpoch!==epoch)return;const guestReady=data.enabled===true&&data.guest===true&&!data.user&&data.customerReady===true&&typeof data.guestId==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(data.guestId)&&typeof data.csrfToken==='string'&&!!data.csrfToken;link.hidden=!(data.enabled===true&&data.user);if(hint)hint.hidden=link.hidden;if(guest)guest.hidden=!guestReady;if(guestReady&&!googleEnabled){status.hidden=false;status.textContent='Google prijava trenutno nije dostupna. Možete nastaviti bez registracije.';}}catch{}}
async function refresh(){const requestEpoch=++epoch;hideAdminLink();login.disabled=true;login.hidden=false;logout.hidden=true;csrf=null;googleEnabled=false;hideCheckoutLinks();try{const response=await fetch('/auth/session',{cache:'no-store',credentials:'same-origin'});if(!response.ok)throw Error();const data=await response.json();if(requestEpoch!==epoch)return;csrf=data.csrfToken;googleEnabled=data.enabled===true;if(data.user){status.hidden=false;status.textContent=`Prijavljeni ste kao ${data.user.name||data.user.email}. Nalog kupca.`;login.hidden=true;logout.hidden=false;}else{status.hidden=googleEnabled;status.textContent=googleEnabled?'':'Google prijava trenutno nije dostupna.';login.disabled=!googleEnabled;}}catch{if(requestEpoch!==epoch)return;status.hidden=false;status.textContent='Servis prijave nije dostupan. Sačekajte trenutak pa osvežite stranicu.';}if(requestEpoch===epoch)await Promise.all([refreshCheckoutLink(requestEpoch),refreshAdminLink(requestEpoch)]);}
login.addEventListener('click',async()=>{if(busy||login.disabled)return;busy=true;login.disabled=true;const requestEpoch=epoch;try{const r=await fetch('/auth/google/start',{method:'POST',credentials:'same-origin'});if(!r.ok)throw Error();const data=await r.json();if(requestEpoch!==epoch)return;const u=new URL(data.url);if(u.origin!=='https://accounts.google.com')throw Error();window.location.assign(u.href);}catch{if(requestEpoch!==epoch)return;status.hidden=false;status.textContent='Prijava nije pokrenuta. Sačekajte minut pa pokušajte ponovo.';busy=false;login.disabled=!googleEnabled;}});
logout.addEventListener('click',async()=>{hideAdminLink();if(busy)return;busy=true;logout.disabled=true;const requestEpoch=++epoch;try{const r=await fetch('/auth/logout',{method:'POST',credentials:'same-origin',headers:{'X-CSRF-Token':csrf}});if(!r.ok)throw Error();if(requestEpoch!==epoch)return;await refresh();}catch{if(requestEpoch===epoch){status.hidden=false;status.textContent='Odjava nije potvrđena. Pokušajte ponovo.';}}finally{busy=false;logout.disabled=false;}});
window.addEventListener('pageshow',async()=>{pageActive=true;busy=false;await refresh();if(pageActive&&new URL(location.href).searchParams.get('login')==='failed'){status.hidden=false;status.textContent='Prijava je otkazana, istekla ili nije potvrđena. Pokušajte ponovo.';history.replaceState(null,'','/account');}});
window.addEventListener('pagehide',()=>{pageActive=false;epoch++;hideAdminLink();csrf=null;googleEnabled=false;busy=false;status.textContent='';status.hidden=true;login.disabled=true;logout.hidden=true;hideCheckoutLinks();});
document.addEventListener('visibilitychange',()=>{hideAdminLink();if(!document.hidden&&pageActive&&!busy)refresh();});
setInterval(()=>{if(!document.hidden&&pageActive&&!busy&&adminLink&&!adminLink.hidden)refreshAdminLink(epoch);},60000);
