import {descriptionMarkup} from './product-view.js';
const $ = id => document.getElementById(id);
const state = { csrf: null, principal: null, manageRoles: false, marketingOwner: false, view: 'products', epoch: 0, controller: null, products: [], cursor: null, busy: false, dirty: false, preview: null, drafts: new Map(), images: new Map() };
const labels = {products: ['KATALOG', 'Proizvodi'], customers:['NALOZI', 'Registrovani korisnici'], orders: ['PRODAJA', 'Porudžbine'], audit: ['EVIDENCIJA', 'Istorija izmena'], marketing: ['VLASNIČKA KONTROLA', 'Marketing nacrti']};
const transitions = {pending:['processing','cancelled'],processing:['shipped','cancelled'],shipped:['completed'],completed:[],cancelled:[]};
const statuses = {draft:'Nacrt',pending:'Na čekanju',processing:'U obradi',shipped:'Poslata',completed:'Završena',cancelled:'Otkazana'};
const limits = {name:120,description:2000,botanical:120,category:120,volume:120,ingredients:2000,method:500,note:2000};
const names = {name:'Naziv proizvoda',description:'Opis',botanical:'Botanički naziv',category:'Kategorija',volume:'Zapremina',ingredients:'Sastav',method:'Način dobijanja',note:'Napomena'};
const legacyStockCodes=Object.assign(Object.create(null),{'divlji-origano':'O001','cetiri-lopova':'O002','crni-kim':'O003'});
const declarationLabels = {benefit:'Namena',usage:'Upotreba',notes:'Napomene',warnings:'Upozorenja',storage:'Čuvanje',editorialCaveat:'Dodatno upozorenje'};
function el(tag, text, className) { const node = document.createElement(tag); if (text !== undefined) node.textContent = text; if (className) node.className = className; return node; }
function status(text, error = false) { $('status').textContent = text; $('status').className = `notice${error ? ' error' : ''}`; }
export function parsePrice(value) {
  const match = /^(\d+)(?:[.,](\d{1,2}))?$/.exec(value.trim());
  if (!match) throw new Error('Cena mora biti pozitivan iznos u RSD, sa najviše dve decimale, bez separatora hiljada.');
  const minor = BigInt(match[1]) * 100n + BigInt((match[2] || '').padEnd(2, '0'));
  if (minor > 100000000n) throw new Error('Cena je previsoka.');
  return Number(minor);
}
export function parseStock(value) {
  if (!value.trim()) return null;
  if (!/^\d+$/.test(value.trim()) || !Number.isSafeInteger(Number(value)) || Number(value)>1000000) throw new Error('Zaliha mora biti ceo broj od 0 do 1.000.000.');
  return Number(value);
}
function money(minor) {return Number.isSafeInteger(minor) ? new Intl.NumberFormat('sr-Latn-RS',{style:'currency',currency:'RSD'}).format(minor/100) : 'Iznos nije poznat';}
function date(value) {const d = new Date(value); return Number.isNaN(d.getTime()) ? 'Datum nije poznat' : d.toLocaleString('sr-Latn-RS');}
function updateDirty() {state.dirty=state.drafts.size>0||state.images.size>0;}
function clearImage(id) {const selected=state.images.get(id);if(selected)URL.revokeObjectURL(selected.url);state.images.delete(id);updateDirty();}
function clearImages() {for(const id of state.images.keys())clearImage(id);}
function clearSensitive() {
  clearMarketingSecret();clearImages();
  state.epoch++; state.controller?.abort(); state.csrf=null; state.principal=null; state.manageRoles=false; state.marketingOwner=false; state.products=[]; state.cursor=null; state.preview=null; state.dirty=false; state.busy=false; state.drafts.clear();
  $('content').replaceChildren(); $('identity').textContent=''; $('workspace').hidden=true; $('more').hidden=true;
  if ($('confirm').open) $('confirm').close('cancel');
  $('confirm-message').textContent='';$('customers-tab').hidden=true;$('marketing-tab').hidden=true;setBusy(false);
}
function access(code) {
  clearSensitive(); $('access').hidden=false;
  const storage = code === 503;
  $('access-title').textContent=storage ? 'Skladište podataka nije spremno' : 'Administratorski pristup je ograničen';
  $('access-message').textContent=storage ? 'Trajno čuvanje podataka trenutno nije dostupno. Izmene nisu omogućene. Pokušajte ponovo kada skladište bude podešeno.' : code===403 ? 'Ovaj Google nalog nema administratorsku dozvolu. Prijavite se odobrenim nalogom.' : 'Prijavite se odobrenim Google nalogom. Ako ste već bili prijavljeni, sesija je istekla.';
  status(storage ? 'Panel trenutno nije dostupan.' : 'Prijava je potrebna.',true);
}
async function api(path, options = {}) {
  const requestEpoch=state.epoch;
  const response = await fetch(path,{credentials:'same-origin',cache:'no-store',...options,headers:{...options.headers}});
  let data; try {data=await response.json();} catch { data={}; }
  if (!response.ok) {
    if ([401,403,503].includes(response.status)&&requestEpoch===state.epoch) access(response.status);
    const error = new Error(response.status===409 ? 'Podaci su u međuvremenu promenjeni. Osvežite prikaz i ponovo unesite izmene.' : [400,413,422].includes(response.status) ? 'Podaci nisu prihvaćeni. Proverite sva polja i format datoteke.' : response.status===429 ? 'Previše zahteva. Sačekajte trenutak i pokušajte ponovo.' : 'Zahtev nije uspeo. Proverite vezu i osvežite podatke pre ponovnog pokušaja.');
    if(response.status===422&&typeof data.error==='string')error.message=`Datoteka nije prihvaćena: ${data.error.slice(0,500)}`;
    error.status=response.status; throw error;
  }
  return data;
}
function dirtyGuard() {return !state.dirty || window.confirm('Imate nesačuvane izmene. Odbaciti ih i nastaviti?');}
async function confirmSave(message, marketing = false) {
  $('confirm-message').textContent=message;
  $('confirm-title').textContent=marketing?'Potvrda marketing radnje':'Sačuvati izmene?';
  $('confirm-save').textContent=marketing?'Potvrdi':'Sačuvaj izmene';
  $('confirm-note').textContent=marketing?'Radnja je dozvoljena samo vlasniku i biće zabeležena u istoriji. Odobrenje nije objava.':'Izmena će biti zabeležena u istoriji. Dostupnost za kupovinu zavisi od objave i potvrđenih zaliha.';
  return new Promise(resolve=> {const dialog=$('confirm');dialog.returnValue='cancel';dialog.addEventListener('close',()=>resolve(dialog.returnValue==='save'),{once:true});dialog.showModal();});
}
function setBusy(value) {
  state.busy=value;
  document.querySelectorAll('#workspace button, #workspace input, #workspace textarea, #workspace select').forEach(node=>node.disabled=value);
}
function principal(session) {return session.user?.id || session.user?.email || null;}
function applySession(session) {
  state.csrf=session.csrfToken;state.principal=principal(session);state.manageRoles=session.capabilities?.manageRoles===true;
  $('customers-tab').hidden=session.capabilities?.customers!==true;
  state.marketingOwner=session.capabilities?.marketingOwner===true&&session.capabilities?.marketingEnabled===true;
  $('marketing-tab').hidden=!state.marketingOwner;
  if(!state.marketingOwner&&state.view==='marketing'){
    clearMarketingSecret();$('content').replaceChildren();
    if($('confirm').open)$('confirm').close('cancel');
  }
  $('identity').textContent=session.user?.email || session.user?.name || 'Administrator';
  if(!state.manageRoles){
    document.querySelectorAll('.customer-role-actions').forEach(node=>node.remove());
    if(state.view==='customers'&&$('confirm').open)$('confirm').close('cancel');
  }
}
async function boot() {
  clearSensitive(); $('access').hidden=true; status('Proveravamo administratorski pristup…');
  const epoch=state.epoch;
  try {
    const session=await api('/admin/api/session');
    if(epoch!==state.epoch)return;
    if(!session.csrfToken) throw new Error('Sesija nije ispravna. Ponovo se prijavite.');
    applySession(session);
    $('workspace').hidden=false; await load('products');
  } catch(error) {if(epoch!==state.epoch)return; status(error.message,true); $('access').hidden=false; $('access-message').textContent='Provera pristupa nije završena. Pokušajte ponovo.';}
}
async function load(view=state.view, append=false, preserveDrafts=false) {
  if (!state.csrf || state.busy) return;
  if(view==='marketing'&&!state.marketingOwner)return;
  state.controller?.abort(); state.controller=new AbortController(); const epoch=++state.epoch;
  clearMarketingSecret();state.view=view;state.preview=null;if(!preserveDrafts){state.drafts.clear();clearImages();}updateDirty();
  document.querySelectorAll('[data-view]').forEach(node=>{if(node.dataset.view===view)node.setAttribute('aria-current','page');else node.removeAttribute('aria-current');});
  $('section-label').textContent=labels[view][0];$('section-title').textContent=labels[view][1];
  $('content').setAttribute('aria-busy','true');$('more').hidden=true;
  if(!append) $('content').replaceChildren(el('p','Učitavanje…','muted'));
  status('Učitavamo najnovije podatke…');
  try {
    const query=append&&state.cursor ? `?before=${encodeURIComponent(state.cursor)}` : '';
    const data=view==='marketing'?await api(`/admin/api/marketing/drafts${query}`,{signal:state.controller.signal}):await api(`/admin/api/${view}${query}`,{signal:state.controller.signal});
    if(epoch!==state.epoch)return;
    if(!append)$('content').replaceChildren();
    if(view==='products') {state.products=data.products || [];renderProducts();}
    else if(view==='customers')renderCustomers(data.customers||[],append);
    else if(view==='orders')renderOrders(data.orders || [],append);
    else if(view==='marketing'){renderMarketing(data.drafts||[],append);if(!append){const keys=await api('/admin/api/marketing/keys',{signal:state.controller.signal});if(epoch!==state.epoch)return;renderMarketingKeys(keys.keys||[]);}}
    else renderAudit(data.entries || [],append);
    state.cursor=data.nextCursor || null;$('more').hidden=!state.cursor;
    status('Podaci su ažurni. Izmene se čuvaju tek nakon vaše potvrde.');return true;
  }catch(error){if(epoch!==state.epoch || error.name==='AbortError')return;status(error.message,true);if(!append)$('content').replaceChildren(el('p','Podatke nije moguće učitati. Pokušajte ponovo pomoću dugmeta „Osveži podatke”.','muted'));}
  finally{if(epoch===state.epoch)$('content').setAttribute('aria-busy','false');}
}
function field(key,value,{label=names[key],max=limits[key],multiline=false,required=false,hint='',inputMode}={}) {
  const wrap=el('label',label,'field');const input=el(multiline?'textarea':'input');input.name=key;input.value=value??'';input.required=required;if(max)input.maxLength=max;if(inputMode)input.inputMode=inputMode;wrap.append(input);
  if(hint)wrap.append(el('small',hint));return wrap;
}
// The shared renderer only creates escaped text and a small fixed set of formatting tags.
// No raw HTML, links, images, inline styles or executable markup are accepted.
function renderDescriptionEditor(product) {
 const box=el('section',undefined,'description-editor');box.setAttribute('aria-label','Uređivanje opisa');
 const formatLabel=el('label','Prikaz opisa','field'),format=el('select');format.name='descriptionFormat';
 for(const [value,label]of [['plain','Običan tekst (postojeći prikaz)'],['markdown','Formatirani tekst (naslovi, isticanje i liste)']]){const option=el('option',label);option.value=value;format.append(option);}
 format.value=product.descriptionFormat==='markdown'?'markdown':'plain';formatLabel.append(format);box.append(formatLabel);
 box.append(field('description',product.description,{multiline:true,hint:'Najviše 2.000 znakova, uključujući oznake formatiranja. Postojeći tekst ostaje običan dok sami ne izaberete formatirani prikaz.'}));
 const input=box.querySelector('textarea'),toolbar=el('div',undefined,'description-toolbar');toolbar.setAttribute('role','group');toolbar.setAttribute('aria-label','Formatiranje opisa');
 const instructions=el('p','Formatirani prikaz: ## podnaslov, **podebljano**, - stavka ili 1. stavka. Prazan red odvaja pasuse. HTML, linkovi i slike se ne izvršavaju.','small');
 const message=el('p','','form-message');message.setAttribute('role','status');
 const previewTitle=el('h4','Pregled opisa'),preview=el('div',undefined,'description-preview');preview.setAttribute('aria-label','Pregled opisa');
 const update=()=>{
  const parsed=new DOMParser().parseFromString(descriptionMarkup(input.value,format.value),'text/html');
  preview.replaceChildren(...[...parsed.body.childNodes].map(node=>document.importNode(node,true)));
 };
 const insert=kind=>{
  if(state.busy)return;
  if(format.value!=='markdown'){message.textContent='Najpre izaberite „Formatirani tekst”. Time birate tumačenje oznaka u opisu.';return;}
  const start=input.selectionStart,end=input.selectionEnd;
  let from=start,to=end,replacement;
  if(kind==='bold')replacement='**'+(input.value.slice(start,end)||'podebljani tekst')+'**';
  else if(kind==='paragraph')replacement='\n\n';
  else{
   from=start===0?0:input.value.lastIndexOf('\n',start-1)+1;const next=input.value.indexOf('\n',end);to=next===-1?input.value.length:next;
   const lines=input.value.slice(from,to).split('\n');
   replacement=lines.map((line,index)=>(kind==='heading'?'## ':kind==='bullet'?'- ':String(index+1)+'. ')+line).join('\n');
  }
  const next=input.value.slice(0,from)+replacement+input.value.slice(to);
  if(next.length>limits.description){message.textContent='Opis sa oznakama može imati najviše 2.000 znakova.';return;}
  input.value=next;input.focus();input.setSelectionRange(from,from+replacement.length);message.textContent='';input.dispatchEvent(new Event('input',{bubbles:true}));
 };
 for(const [kind,label]of [['heading','Podnaslov'],['bold','Podebljano'],['bullet','Lista'],['number','Numerisana lista'],['paragraph','Novi pasus']]){const button=el('button',label,'secondary');button.type='button';button.dataset.descriptionAction=kind;button.addEventListener('click',()=>insert(kind));toolbar.append(button);}
 box.append(toolbar,instructions,message,previewTitle,preview);
 input.addEventListener('input',update);format.addEventListener('input',()=>{message.textContent='';update();});format.addEventListener('change',update);update();
 box.refreshDescription=update;return box;
}
function track(form,product){form.addEventListener('input',()=>{state.dirty=true;if(product)state.drafts.set(product.id,{product,values:Object.fromEntries(new FormData(form))});});}
function empty(title,description){const box=el('div',undefined,'empty');box.append(el('h3',title),el('p',description));$('content').append(box);}
export function productSlug(value) {
  return String(value).toLowerCase().replace(/đ/g,'dj').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,80).replace(/-+$/,'');
}
function renderNewProduct() {
  const saved=state.drafts.get('__new'),box=el('details',undefined,'new-product');box.open=!!saved;
  box.append(el('summary','+ Dodaj proizvod'));
  const form=el('form');form.id='new-product-form';
  form.append(el('h3','Novi proizvod'),el('p','1. Sačuvajte nacrt. 2. Dodajte fotografiju i proverite podatke. 3. Objavite proizvod. Za kupovinu unesite potvrđenu zalihu i uključite dostupnost.','small'));
  form.append(field('name','',{required:true}),field('id','',{label:'SKU / adresa proizvoda',max:80,required:true,hint:'Mala slova a–z, brojevi i crtice. Jedinstvena trajna oznaka; posle čuvanja se ne menja.'}));
  const id=form.querySelector('[name="id"]');id.pattern='[a-z0-9]+(-[a-z0-9]+)*';let manual=!!saved;
  id.addEventListener('input',()=>{manual=true;});form.querySelector('[name="name"]').addEventListener('input',event=>{if(!manual)id.value=productSlug(event.target.value);});
  form.append(field('price','',{label:'Cena (RSD)',required:true,inputMode:'decimal',max:12,hint:'Veća od nule, npr. 1490,00.'}),renderDescriptionEditor({}));
  for(const key of ['category','ingredients','botanical','volume','method','note'])form.append(field(key,'',{required:['category','ingredients'].includes(key),multiline:['ingredients','note'].includes(key)}));
  form.querySelector('[name="description"]').required=true;
  for(const [key,label]of Object.entries(declarationLabels))form.append(field('declaration_'+key,'',{label,multiline:true,max:10000,required:['warnings','usage','storage'].includes(key),hint:key==='warnings'?'Prepišite proverenu deklaraciju proizvoda. Ne unosite pretpostavljene zdravstvene tvrdnje.':''}));
  form.append(field('stockCode','',{label:'Šifra u izveštaju zaliha (opciono)',max:40,hint:'Velika slova, brojevi, crtica ili donja crta. Tačan Ident iz magacinskog izveštaja, npr. O004. Ne koristi se kao adresa proizvoda.'}));
  const message=el('p','','form-message');message.setAttribute('role','status');const actions=el('div',undefined,'actions'),save=el('button','Sačuvaj nacrt'),cancel=el('button','Odustani','secondary');save.type='submit';cancel.type='button';actions.append(cancel,save);form.append(message,actions);box.append(form);$('content').append(box);
  if(saved)for(const input of form.elements)if(input.name&&Object.hasOwn(saved.values,input.name))input.value=saved.values[input.name];
  form.querySelector('.description-editor').refreshDescription();
  form.addEventListener('input',()=>{state.drafts.set('__new',{values:Object.fromEntries(new FormData(form))});updateDirty();});
  cancel.addEventListener('click',()=>{if(state.busy)return;if(state.drafts.has('__new')&&!window.confirm('Odbaciti nacrt novog proizvoda?'))return;state.drafts.delete('__new');updateDirty();form.reset();box.open=false;$('content').replaceChildren();renderProducts();});
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(state.busy||form.dataset.uncertain==='true')return;
    const values=new FormData(form),payload={id:String(values.get('id')??'').trim(),declaration:{}};
    try {
      if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(payload.id)||payload.id.length>80)throw new Error('Unesite ispravan SKU: mala slova a–z, brojevi i crtice, najviše 80 znakova.');
      if(state.products.some(p=>p.id===payload.id))throw new Error('Ovaj SKU već postoji. Izaberite drugu jedinstvenu oznaku.');
      payload.priceMinor=parsePrice(String(values.get('price')??''));if(payload.priceMinor<=0)throw new Error('Cena mora biti veća od nule.');
      for(const key of Object.keys(limits))payload[key]=String(values.get(key)??'').trim();
      for(const key of ['name','description','category','ingredients'])if(!payload[key])throw new Error('Popunite naziv, opis, kategoriju i sastav.');
      payload.descriptionFormat=String(values.get('descriptionFormat'));
      for(const key of Object.keys(declarationLabels))payload.declaration[key]=String(values.get('declaration_'+key)??'').trim();
      for(const key of ['warnings','usage','storage'])if(!payload.declaration[key])throw new Error('Unesite proverenu upotrebu, upozorenja i način čuvanja sa deklaracije.');
      const stockCode=String(values.get('stockCode')??'').trim();if(stockCode){if(!/^[A-Z0-9][A-Z0-9_-]{0,39}$/.test(stockCode))throw new Error('Šifra zaliha: velika slova, brojevi, crtica ili donja crta, najviše 40 znakova.');payload.stockCode=stockCode;}
    }catch(error){message.textContent=error.message;return;}
    const epoch=state.epoch;setBusy(true);let sent=false;
    try {
      if(!await confirmSave(`Sačuvati „${payload.name}” kao neobjavljen nacrt, SKU ${payload.id}, cena ${money(payload.priceMinor)}? Proizvod neće biti vidljiv kupcima dok ga ne objavite.`))return;
      if(epoch!==state.epoch||!state.csrf)return;sent=true;
      const result=await api('/admin/api/products',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},body:JSON.stringify(payload)});
      if(epoch!==state.epoch)return;const product=result.product||result;
      state.products.unshift(product);state.drafts.delete('__new');updateDirty();$('content').replaceChildren();renderProducts();status('Nacrt je sačuvan. Sada dodajte fotografiju, proverite podatke i objavite proizvod kada je spreman.');
    }catch(error){if(epoch===state.epoch){
      if(error.status===409)message.textContent='SKU ili šifra zaliha već postoji. Osvežite podatke i proverite postojeći proizvod pre novog pokušaja.';
      else if(sent&&(!error.status||error.status>=500)){form.dataset.uncertain='true';message.textContent='Ishod čuvanja nije potvrđen. Ne šaljite ponovo. Osvežite podatke i potražite SKU '+payload.id+' pre novog pokušaja.';}
      else message.textContent=error.message;status(message.textContent,true);
    }}finally{if(epoch===state.epoch){setBusy(false);if(form.dataset.uncertain==='true')save.disabled=true;}}
  });
}
const saleMinute=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Belgrade',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
function renderSaleEditor(product){
 const box=el('details',undefined,'product-sale-editor');box.append(el('summary','Akcijska cena i rok'));
 if(product.sale){
  const s=product.sale;
  box.append(el('p',`${money(s.previousMinor)} → ${money(s.priceMinor)} · od ${saleMinute.format(new Date(s.startAt))} do ${saleMinute.format(new Date(s.endAt))} (Beograd).`,'small'));
 }
 const label=el('label','Šta želite da uradite?','field'),select=el('select');select.name='saleAction';
 for(const [value,caption] of [['keep','Bez promene akcije'],['start','Pokreni novu akciju nakon potvrde'],['end','Završi akciju odmah']]){
  const option=el('option',caption);option.value=value;if(value==='end'&&!product.sale)option.disabled=true;select.append(option);
 }
 label.append(select);box.append(label);
 const entries=el('div');entries.append(field('salePrevious','',{label:'Prethodna cena (RSD)',inputMode:'decimal',max:12,hint:'Unesite proverenu najnižu cenu iz odgovarajućeg prethodnog perioda, ne nužno redovnu cenu.'}),field('salePrice','',{label:'Akcijska cena (RSD)',inputMode:'decimal',max:12}),field('saleEnd','',{label:'Akcija traje do (vreme u Beogradu)'}));
 entries.querySelector('[name=saleEnd]').type='datetime-local';
 const verify=el('label',undefined,'check'),checked=el('input');checked.type='checkbox';checked.name='saleVerified';verify.append(checked,document.createTextNode('Proverio/la sam prethodnu cenu na osnovu istorije prodajne ponude.'));entries.append(verify);box.append(entries);
 const toggle=()=>{entries.hidden=select.value!=='start';if(select.value!=='keep')box.open=true;};select.addEventListener('change',toggle);
 return {box,toggle};
}
function renderProducts() {
  $('product-count').textContent=String(state.products.length);renderNewProduct();renderImport();
  if(!state.products.length){empty('Katalog je prazan','Nema proizvoda dostupnih za uređivanje.');return;}
  const grid=el('div',undefined,'product-grid');
  for(const current of state.products){
    const draft=state.drafts.get(current.id);const p=draft?.product||current;
    const form=el('form',undefined,'product-card');const head=el('header');
    head.append(el('span',p.published===false?'Nacrt · nije javno':p.available?'Dostupno':'Nedostupno',`tag${p.available?'':' off'}`),el('h3',p.name),el('span',`SKU: ${p.id} · Verzija ${p.version}`,'small'));form.append(head);
    form.append(renderProductImage(p));
    const descriptionEditor=renderDescriptionEditor(p);form.append(field('name',p.name,{required:true}),descriptionEditor);
    const pair=el('div',undefined,'pair');pair.append(field('price',Number.isSafeInteger(p.priceMinor)?`${Math.floor(p.priceMinor/100)},${String(p.priceMinor%100).padStart(2,'0')}`:'',{label:'Redovna cena (RSD)',required:true,inputMode:'decimal',max:12,hint:'Npr. 1490,00'}),field('stockQuantity',p.stockQuantity,{label:'Zaliha (kom.)',inputMode:'numeric',max:7,hint:'Prazno = nepoznato'}));form.append(pair);const saleEditor=renderSaleEditor(p);form.append(saleEditor.box);
    const available=el('label',undefined,'check'),checkbox=el('input');checkbox.type='checkbox';checkbox.name='available';checkbox.checked=Boolean(p.available);available.append(checkbox,document.createTextNode('Proizvod je dostupan'));form.append(available);
    const publication=el('label',undefined,'check'),published=el('input');published.type='checkbox';published.name='published';published.checked=p.published!==false;publication.append(published,document.createTextNode('Objavljen u prodavnici (javna stranica i katalog)'));form.append(publication);
    form.append(field('stockCode',legacyStockCodes[p.id]||p.stockCode,{label:'Šifra u izveštaju zaliha',max:40,hint:'Opciono. Velika slova, brojevi, crtica ili donja crta. Tačan Ident iz magacinskog izveštaja, npr. O004. SKU za običan uvoz ostaje '+p.id+'.'}));
    if(legacyStockCodes[p.id])form.querySelector('[name=stockCode]').readOnly=true;
    const details=el('details');details.append(el('summary','Detalji proizvoda'));for(const key of ['botanical','category','volume','ingredients','method','note'])details.append(field(key,p[key],{multiline:['ingredients','note'].includes(key)}));form.append(details);
    const warningField=field('warnings',p.declaration?.warnings,{label:'Upozorenja',multiline:true,required:true,max:10000,hint:'Obavezno polje, najviše 10.000 znakova. Izmena se čuva tek nakon potvrde.'});
    // Compare against the rendered value so browser newline normalization does not turn an unchanged warning into an edit.
    const originalWarnings=warningField.querySelector('textarea').value;form.append(warningField);
    const declaration=el('details');declaration.append(el('summary','Deklaracija · namena, upotreba i čuvanje'));for(const [key,label]of Object.entries(declarationLabels)){if(key!=='warnings')declaration.append(field('declaration_'+key,p.declaration?.[key],{label,multiline:true,max:10000}));}form.append(declaration);
    const message=el('p','','form-message');message.setAttribute('role','status');const save=el('button','Sačuvaj izmene','save');save.type='submit';form.append(message,save);if(draft){for(const input of form.elements){if(['available','published','saleVerified'].includes(input.name))input.checked=Object.hasOwn(draft.values,input.name);else if(input.name&&Object.hasOwn(draft.values,input.name))input.value=draft.values[input.name];}}descriptionEditor.refreshDescription();saleEditor.toggle();track(form,p);
    form.addEventListener('submit',async event=>{
      event.preventDefault();if(state.busy)return;
      let patch;
      try {const values=new FormData(form);patch={version:p.version,priceMinor:parsePrice(values.get('price')),stockQuantity:parseStock(values.get('stockQuantity')),available:checkbox.checked};if(values.get('saleAction')==='end')patch.sale=null;if(values.get('saleAction')==='start'){const priceMinor=parsePrice(values.get('salePrice')),previousMinor=parsePrice(values.get('salePrevious')),endLocal=String(values.get('saleEnd')??'');if(!form.elements.saleVerified.checked||!endLocal)throw Error('Unesite rok akcije i potvrdite prethodnu cenu.');if(priceMinor<=0||priceMinor>=previousMinor||previousMinor>patch.priceMinor)throw Error('Akcijska cena mora biti niža od prethodne, a prethodna ne sme biti viša od redovne.');patch.sale={priceMinor,previousMinor,endLocal,historyVerified:true};}for(const key of Object.keys(limits))patch[key]=key==='description'?String(values.get(key)??''):String(values.get(key)||'').trim();if(patch.description.length>limits.description)throw new Error('Opis sa oznakama može imati najviše 2.000 znakova.');const format=String(values.get('descriptionFormat'));if(!['plain','markdown'].includes(format))throw new Error('Izaberite podržani prikaz opisa.');if(format!==(p.descriptionFormat??'plain'))patch.descriptionFormat=format;if(!patch.name)throw new Error('Unesite naziv proizvoda.');const warnings=String(values.get('warnings')??'');if(!warnings.trim())throw new Error('Unesite upozorenja za proizvod.');if(warnings.length>10000)throw new Error('Upozorenja mogu imati najviše 10.000 znakova.');if(warnings!==originalWarnings)patch.declaration={warnings};for(const key of Object.keys(declarationLabels)){if(key==='warnings')continue;const value=String(values.get('declaration_'+key)??'');if(value!==(p.declaration?.[key]??''))patch.declaration={...patch.declaration,[key]:value};}if(published.checked!==(p.published!==false))patch.published=published.checked;const stockCode=String(values.get('stockCode')??'').trim();if(stockCode!==(legacyStockCodes[p.id]||p.stockCode||''))patch.stockCode=stockCode||null;if(checkbox.checked&&!published.checked)throw new Error('Za dostupnost u prodavnici najpre označite da je proizvod objavljen.');if(published.checked&&p.published===false&&!productImageSource(p))throw new Error('Pre objave sačuvajte fotografiju proizvoda.');if(patch.available&&(patch.stockQuantity===null||patch.stockQuantity===0))throw new Error('Za dostupan proizvod unesite potvrđenu zalihu veću od nule.');}catch(error){message.textContent=error.message;return;}
      await saveChange(`/admin/api/products/${encodeURIComponent(p.id)}`,patch,`Proizvod „${patch.name}”: cena ${money(patch.priceMinor)}, zaliha ${patch.stockQuantity??'nepoznata'}, ${patch.available?'dostupan':'nedostupan'}.${patch.descriptionFormat?' Prikaz opisa: '+(patch.descriptionFormat==='markdown'?'formatirani tekst':'običan tekst')+'.':''}${patch.sale?` Pokrećete akciju: prethodno ${money(patch.sale.previousMinor)}, sada ${money(patch.sale.priceMinor)}, do ${patch.sale.endLocal.replace('T',' ')} (Beograd).`:patch.sale===null?' Akcijska cena će odmah prestati da važi.':''}${patch.declaration?' Izmena deklaracije biće sačuvana.':''}${patch.published===true?' Proizvod će postati javno vidljiv.':patch.published===false?' Proizvod će biti povučen iz javnog kataloga i kupovine.':''}`,message);
    });grid.append(form);
  }$('content').append(grid);
}
export function productImageSource(product) {
  if(typeof product.imagePath==='string'&&/^\/media\/[a-f0-9]{64}\.jpg$/.test(product.imagePath))return product.imagePath;
  if(typeof product.image==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_.-]*\.(?:jpe?g|png|webp)$/i.test(product.image))return `/assets/${product.image}`;
  return null;
}
export function validateImageFile(file) {
  if(!file||!['image/jpeg','image/png'].includes(file.type)||!file.size||file.size>3*1024*1024)throw new Error('Izaberite nepraznu JPEG ili PNG fotografiju do 3 MiB.');
}
function renderProductImage(p) {
  const box=el('section',undefined,'product-image');box.setAttribute('aria-label','Fotografija proizvoda');
  const current=el('img');current.alt=`Trenutna fotografija: ${p.name}`;current.className='product-thumbnail';
  const source=productImageSource(p),dimensions=el('p','','small');
  if(source){current.src=source;box.append(current);current.addEventListener('load',()=>{if(current.naturalWidth&&current.naturalHeight)dimensions.textContent=`Trenutna fotografija: ${current.naturalWidth} × ${current.naturalHeight} px`;});}
  else box.append(el('p','Fotografija nije dostupna.','small'));
  if(Number.isSafeInteger(p.imageWidth)&&Number.isSafeInteger(p.imageHeight)&&p.imageWidth>0&&p.imageHeight>0)dimensions.textContent=`Trenutna fotografija: ${p.imageWidth} × ${p.imageHeight} px`;
  box.append(dimensions,el('p',(p.published===false?'Fotografija se čuva uz nacrt; proizvod još nije objavljen. ':'Čuvanjem objavljujete fotografiju proizvoda u javnom katalogu ovog sajta. ')+'Izbor datoteke pravi samo lokalni pregled; ništa se ne šalje pre potvrde. JPEG/PNG do 3 MiB i 12 megapiksela. Server uklanja metapodatke i čuva JPEG do 1600 px i 1,5 MiB.','small'));
  const label=el('label','Nova fotografija (JPEG ili PNG)','field'),input=el('input');input.type='file';input.accept='image/jpeg,image/png';label.append(input);
  const preview=el('div',undefined,'image-preview'),message=el('p','','form-message');message.setAttribute('role','status');
  const actions=el('div',undefined,'image-actions'),save=el('button','Sačuvaj fotografiju'),clear=el('button','Ukloni izbor','secondary');save.type=clear.type='button';actions.append(save,clear);box.append(label,preview,message,actions);
  const show=()=>{preview.replaceChildren();const selected=state.images.get(p.id);actions.hidden=!selected;if(!selected)return;selected.refresh=show;selected.reject=text=>{clearImage(p.id);input.value='';message.textContent=text;show();};const img=el('img');img.className='product-thumbnail';img.alt='Lokalni pregled nove fotografije';img.src=selected.url;preview.append(img,el('p',selected.width?`Novi lokalni pregled: ${selected.width} × ${selected.height} px`:'Proveravamo dimenzije fotografije…','small'));};
  // The unnamed file control is independent of the product text form and draft.
  input.addEventListener('input',event=>event.stopPropagation());
  input.addEventListener('change',()=>{
    if(state.busy)return;clearImage(p.id);message.textContent='';const file=input.files[0];
    try{validateImageFile(file);}catch(error){input.value='';message.textContent=error.message;show();return;}
    let url;try{url=URL.createObjectURL(file);}catch{message.textContent='Lokalni pregled nije dostupan u ovom pregledaču.';input.value='';show();return;}
    const selected={file,url,version:p.version,width:null,height:null};state.images.set(p.id,selected);updateDirty();show();
    const probe=new Image();
    probe.onload=()=>{if(state.images.get(p.id)!==selected)return;const width=probe.naturalWidth,height=probe.naturalHeight;if(!width||!height||width*height>12000000){selected.reject('Fotografija mora imati najviše 12 megapiksela.');}else{selected.width=width;selected.height=height;selected.refresh();}};
    probe.onerror=()=>{if(state.images.get(p.id)!==selected)return;selected.reject('Fotografiju nije moguće otvoriti. Izaberite ispravnu JPEG ili PNG datoteku.');};probe.src=url;
  });
  clear.addEventListener('click',()=>{if(state.busy)return;clearImage(p.id);input.value='';message.textContent='';show();});
  save.addEventListener('click',async()=>{
    if(state.busy)return;const selected=state.images.get(p.id);if(!selected)return;
    if(state.drafts.has(p.id)){message.textContent='Najpre sačuvajte tekstualne izmene ovog proizvoda ili ih odbacite osvežavanjem prikaza, pa ponovo izaberite fotografiju.';return;}
    if(!selected.width){message.textContent='Sačekajte proveru dimenzija fotografije.';return;}
    setBusy(true);const epoch=state.epoch;
    try{
      if(!await confirmSave(`Sačuvati novu fotografiju proizvoda „${p.name}”${p.published===false?' uz nacrt':' u javnom katalogu ovog sajta'}? Trenutna fotografija biće zamenjena nakon čuvanja.`))return;
      if(epoch!==state.epoch||!state.csrf||state.images.get(p.id)!==selected)return;
      const data=await api(`/admin/api/products/${encodeURIComponent(p.id)}/image`,{method:'POST',headers:{'Content-Type':selected.file.type,'X-CSRF-Token':state.csrf,'X-Product-Version':String(selected.version)},body:selected.file});
      if(epoch!==state.epoch)return;
      const updated=data.product||data;state.products=state.products.map(product=>product.id===p.id?updated:product);clearImage(p.id);$('content').replaceChildren();renderProducts();status(p.published===false?'Fotografija je sačuvana uz nacrt. Pregledajte podatke i označite „Objavljen u prodavnici” kada je proizvod spreman.':'Fotografija je sačuvana i objavljena u javnom katalogu ovog sajta.');
    }catch(error){if(epoch===state.epoch){message.textContent=error.status===409?'Proizvod je u međuvremenu promenjen. Fotografija nije sačuvana. Osvežite prikaz uz potvrdu odbacivanja izbora i ponovo pregledajte proizvod pre slanja.':error.message;status(message.textContent,true);}}
    finally{if(epoch===state.epoch)setBusy(false);}
  });show();return box;
}
async function saveChange(path,patch,summary,message,allowed=()=>true) {
  if(state.busy||!allowed())return;setBusy(true);const epoch=state.epoch;
  try {
    if(!await confirmSave(summary))return;if(epoch!==state.epoch || !state.csrf || !allowed())return;
    await api(path,{method:'PATCH',headers:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},body:JSON.stringify(patch)});
    if(epoch!==state.epoch)return;
    state.drafts.delete(decodeURIComponent(path.split('/').at(-1)));updateDirty();setBusy(false);const refreshed=await load(state.view,false,true);if(state.csrf&&refreshed)status('Izmene su uspešno sačuvane i podaci su ponovo učitani.');
  }catch(error){if(epoch===state.epoch){message.textContent=error.message;status(error.message,true);}}
  finally{if(epoch===state.epoch)setBusy(false);}
}
function renderCustomers(customers,append){
 if(!customers.length&&!append){empty('Još nema registrovanih korisnika','Ovde se prikazuju sačuvani nalozi sa potvrđenom Google prijavom. Kupovina bez registracije ne kreira korisnički nalog.');return;}
 if(!append)$('content').append(el('p','Samo glavni vlasnik može da dodeli ili ukloni administratorsku ulogu registrovanom korisniku.','muted'));
 const roles={owner:'Glavni vlasnik',admin:'Administrator',customer:'Korisnik'};
 for(const customer of customers){
  const card=el('article',undefined,'order-card customer-card');card.append(el('h3',customer.name||'Korisnik'),el('p',customer.email),el('p',`Uloga: ${roles[customer.role]||'Nije dostupna'}`,'customer-role'),el('p',`ID: ${customer.id}`,'small'),el('p',`Poslednja prijava: ${date(customer.lastLoginAt)}`,'small'));
  const manageable=customer.canManageRole===true&&['admin','customer'].includes(customer.role)&&customer.roleManagedBy!=='bootstrap'&&Number.isSafeInteger(customer.roleVersion)&&customer.roleVersion>=1;
  if(state.manageRoles&&manageable){
   const actions=el('div',undefined,'customer-role-actions'),message=el('p','','form-message');message.setAttribute('role','status');
   const grant=customer.role==='customer',button=el('button',grant?'Dodeli administratorsku ulogu':'Ukloni administratorsku ulogu','secondary');button.type='button';
   actions.append(message,button);card.append(actions);
   button.addEventListener('click',()=>{
    if(!state.manageRoles||!state.csrf||!card.isConnected||state.view!=='customers')return;
    const target=`„${customer.name||'Korisnik'}” (${customer.email})`;
    const summary=grant?`Dodeliti administratorsku ulogu korisniku ${target}? Korisnik će dobiti pristup upravljanju proizvodima i porudžbinama i pregledu registrovanih korisnika. Samo glavni vlasnik može da menja administratorske uloge.`:`Ukloniti administratorsku ulogu korisniku ${target}? Korisnik će izgubiti administratorski pristup. Korisnički nalog i njegove porudžbine neće biti obrisani.`;
    saveChange(`/admin/api/customers/${encodeURIComponent(customer.id)}/role`,{role:grant?'admin':'customer',version:customer.roleVersion},summary,message,()=>state.manageRoles&&card.isConnected&&state.view==='customers');
   });
  }
  $('content').append(card);
 }
}
function renderOrders(orders,append){
  if(!orders.length&&!append){empty('Još nema porudžbina','Ovde će se pojaviti stvarne porudžbine kada prijem porudžbina bude omogućen.');return;}
  for(const current of orders){const draft=state.drafts.get(current.id);const order=draft?.product||current;const card=el('article',undefined,'order-card');const head=el('div',undefined,'order-header');head.append(el('h3',`Porudžbina ${order.orderNumber||order.id}`),el('span',statuses[order.status]||order.status,'tag'));card.append(head,el('p',date(order.createdAt),'small'));
    const cod=order.paymentMethod==='cod'||order.paymentStatus==='cod_due';
    if(order.status==='draft')card.append(el('p','Nacrt: zaliha nije rezervisana, plaćanje nije izvršeno i isporuka nije aktivirana.','notice'));
    if(cod)card.append(el('p',order.paymentStatus==='cod_cancelled'?'Pouzeće otkazano. Ovaj panel ne potvrđuje naplatu.':'Plaćanje pouzećem · iznos dospeva pri preuzimanju. Ovaj panel ne potvrđuje naplatu.','notice'));
    if(order.customer)card.append(el('p',[order.customer.name,order.customer.email].filter(Boolean).join(' · '),'small'));
    if(order.contact){const contact=el('section',undefined,'order-contact');contact.append(el('h4','Kontakt i adresa za dostavu'));for(const value of [order.contact.fullName,order.contact.email,order.contact.phone,order.contact.address,[order.contact.postalCode,order.contact.city,order.contact.country==='RS'?'Srbija':order.contact.country].filter(Boolean).join(' ')])if(value)contact.append(el('p',value));card.append(contact);}
    if(Array.isArray(order.items)){const list=el('ul');for(const item of order.items)list.append(el('li',`${item.name||item.productId||item.id} × ${item.quantity}${Number.isSafeInteger(item.unitPriceMinor)?` · ${money(item.unitPriceMinor)} / kom.`:''}${Number.isSafeInteger(item.lineTotalMinor)?` = ${money(item.lineTotalMinor)}`:''}`));card.append(list);}
    if(Number.isSafeInteger(order.subtotalMinor))card.append(el('p',`Vrednost proizvoda: ${money(order.subtotalMinor)}`));
    if(Number.isSafeInteger(order.deliveryMinor))card.append(el('p',`Dostava${order.shipping?.method==='courier'?' kurirskom službom':''}${order.shipping?.isEstimate?' (procena)':''}: ${money(order.deliveryMinor)}`));
    if(order.totalMinor!==undefined)card.append(el('p',`Ukupno${cod?(order.paymentStatus==='cod_cancelled'?' (otkazana porudžbina)':' za plaćanje pouzećem'):''}: ${money(order.totalMinor)}`));
    if(['deducted','deducted_manual_adjustment_required'].includes(order.inventoryStatus))card.append(el('p','Zaliha je umanjena pri prijemu porudžbine.','small'));
    if(cod)card.append(el('p',order.status==='cancelled'?'Porudžbina je otkazana. Zaliha nije automatski vraćena; proverite Pantheon/Excel i ručno uskladite stanje.':'Otkazivanje ne vraća automatski zalihu. Ako se porudžbina otkaže, proverite Pantheon/Excel i ručno uskladite stanje.','notice'));
    const form=el('form'),wrap=el('label','Status','field'),select=el('select');select.name='status';for(const key of [order.status,...(transitions[order.status]||[])]){const title=statuses[key]||key;const option=el('option',title);option.value=key;option.selected=order.status===key;select.append(option);}wrap.append(select);form.append(wrap);
    const message=el('p','','form-message');message.setAttribute('role','status');const save=el('button','Sačuvaj status');save.type='submit';form.append(message,save);if(draft&&Object.hasOwn(draft.values,'status'))select.value=draft.values.status;track(form,order);form.addEventListener('submit',event=>{event.preventDefault();const cancellation=select.value==='cancelled'&&cod?' Zaliha se neće automatski vratiti. Proverite Pantheon/Excel i ručno uskladite stanje.':'';saveChange(`/admin/api/orders/${encodeURIComponent(order.id)}`,{version:order.version,status:select.value},`Porudžbina ${order.orderNumber||order.id}: status „${statuses[select.value]}”.${cancellation}`,message);});if(transitions[order.status]?.length)card.append(form);$('content').append(card);
  }
}
function renderAudit(entries,append){
  if(!entries.length&&!append){empty('Nema zabeleženih izmena','Sačuvane promene proizvoda i porudžbina pojaviće se ovde.');return;}
  for(const entry of entries){const card=el('article',undefined,'audit-entry');card.append(el('h3',entry.action||'Izmena'),el('p',`${date(entry.createdAt||entry.timestamp)} · ${entry.actorEmail||entry.actor?.email||entry.actorId||'Administrator'}`,'small'));
    card.append(el('p',`Stavka: ${entry.targetId||entry.entityId||entry.productId||entry.orderId||'—'}`,'small'));
    const details=el('details');details.append(el('summary','Prikaži zapis'),el('pre',JSON.stringify(entry,null,2)));card.append(details);$('content').append(card);
  }
}
function renderImport(){
 const box=el('details',undefined,'import-panel');box.append(el('summary','Uvoz raspoloživih zaliha iz Excel datoteke'));
 box.append(el('p','Podržan je originalni dnevni izveštaj .xls do 1 MB. Koristi se samo raspoloživo za prodaju iz magacina Magacin Bio Prodavnica B2C. Njegove količine zamenjuju trenutno stanje zaliha; cene iz izveštaja se ne uvoze. B2C sekcija je obavezna. Ostali magacini se isključuju i navode u upozorenju pregleda. Možete koristiti i .xlsx šablon sa kolonama SKU i availableQuantity. Nema automatskog povezivanja sa Pantheon sistemom.'));
 const label=el('label','Excel datoteka (.xls ili .xlsx)','field'),input=el('input');input.type='file';input.accept='.xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';label.append(input);const preview=el('button','Proveri datoteku','secondary');preview.type='button';const result=el('div'),message=el('p','','form-message');message.setAttribute('role','status');box.append(label,preview,message,result);
 input.addEventListener('change',()=>{state.preview=null;result.replaceChildren();message.textContent='';});
 preview.addEventListener('click',async()=>{
  if(state.busy)return;const file=input.files[0];state.preview=null;result.replaceChildren();
  if(!file||!/\.xlsx?$/i.test(file.name)||file.size>1024*1024||!file.size){message.textContent='Izaberite nepraznu .xls ili .xlsx datoteku veličine do 1 MB.';return;}
  if(!dirtyGuard())return;setBusy(true);const epoch=state.epoch;message.textContent='Proveravamo datoteku…';
  try {const data=await api('/admin/api/stock/preview',{method:'POST',headers:{'Content-Type':file.name.toLowerCase().endsWith('.xls')?'application/vnd.ms-excel':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','X-CSRF-Token':state.csrf},body:file});if(epoch!==state.epoch)return;state.preview=data;message.textContent=`Provereno ${data.rows.length} stavki. Pregled važi do ${date(data.expiresAt)}.`;
   result.append(el('p','Uvoze se samo prijavljeni redovi iz B2C magacina. Proizvodi kojih nema u B2C delu datoteke ostaju nepromenjeni; odsustvo reda ne znači potvrđenu nulu.'));if(Array.isArray(data.warnings)&&data.warnings.length){const warnings=el('div',undefined,'notice');warnings.setAttribute('role','status');warnings.append(el('strong','Proverite pre potvrde'));const warningList=el('ul');for(const warning of data.warnings)warningList.append(el('li',String(warning)));warnings.append(warningList);result.append(warnings);}const list=el('ul');for(const row of data.rows){const item=el('li',`${row.name} (${row.id})${row.sourceIdent?` · Ident: ${row.sourceIdent}`:''}: ${row.oldQuantity??'nepoznato'} → ${row.stockQuantity} kom.`);if(Array.isArray(row.warehouseQuantities)){const breakdown=el('ul');for(const warehouse of row.warehouseQuantities)breakdown.append(el('li',`${warehouse.warehouse}: ${warehouse.quantity} kom.`));item.append(breakdown);}list.append(item);}result.append(list);
   const apply=el('button','Potvrdi zamenu zaliha');apply.type='button';result.append(apply);apply.addEventListener('click',async()=>{
    if(state.busy||!state.preview)return;setBusy(true);const token=state.preview.previewToken;const generation=state.epoch;
    try {if(!await confirmSave(`Zameniti raspoloživo stanje zaliha za ${data.rows.length} proizvoda prikazanim količinama iz pregledane datoteke? Cene se ne menjaju.`))return;if(generation!==state.epoch||!state.csrf)return;await api('/admin/api/stock/apply',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},body:JSON.stringify({previewToken:token})});if(generation!==state.epoch)return;state.preview=null;state.dirty=false;setBusy(false);const refreshed=await load('products');if(state.csrf&&refreshed)status('Zalihe su sačuvane. Proverite dostupnost svakog proizvoda.');}
    catch(error){if(generation===state.epoch){state.preview=null;result.replaceChildren();message.textContent=`${error.message} Ponovo proverite datoteku pre uvoza.`;}}
    finally{if(generation===state.epoch)setBusy(false);}
   });
  }catch(error){if(epoch===state.epoch)message.textContent=error.message;}finally{if(epoch===state.epoch)setBusy(false);}
 });$('content').append(box);
}
function clearMarketingSecret(){for(const input of document.querySelectorAll('.marketing-secret input'))input.value='';for(const box of document.querySelectorAll('.marketing-secret')){box.replaceChildren();box.hidden=true;}}
const marketingStatuses={draft:'Nacrt · nije javno',approved:'Odobren · još nije objavljen',published:'Objavljen',rejected:'Odbijen'};
const marketingScopes={'catalog:read':'Čitanje kataloga','stock:read':'Čitanje zaliha','sales:read':'Zbirna prodaja bez ličnih podataka','drafts:read':'Čitanje sopstvenih nacrta','drafts:write':'Kreiranje i izmena sopstvenih nacrta','media:write':'Privatna priprema fotografija'};
function marketingAllowed(node){return state.csrf&&state.marketingOwner&&state.view==='marketing'&&node.isConnected;}
function marketingRequest(path,body){return api('/admin/api/marketing'+path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},body:JSON.stringify(body)});}
function marketingDraftCard(draft) {
  const card=el('article',undefined,'marketing-draft');
  card.dataset.draftId=String(draft.id);
  card.append(el('h3',String(draft.productId||'Proizvod')),el('p',(marketingStatuses[draft.status]||draft.status)+' · Nacrt '+draft.id+' · Verzija '+draft.revision,'small'));
  const review=el('button','Pregledaj tačan sadržaj','secondary');review.type='button';card.append(review);
  review.addEventListener('click',()=>reviewMarketingDraft(card,draft.id));return card;
}
function renderMarketing(drafts,append=false) {
  if(!state.marketingOwner)return;
  if(!append){
    const intro=el('div',undefined,'notice marketing-notice');
    intro.append(el('strong','AI tim priprema, vlasnik odlučuje.'),el('p','Nacrti i pripremljene fotografije nisu javni. AI ključ ne može da objavljuje niti da menja cene, zalihe, porudžbine ili uloge. Najpre pregledajte i odobrite tačnu verziju, a zatim je zasebno objavite.'));
    $('content').append(intro);
  }
  if(!drafts.length&&!append)$('content').append(el('p','Još nema marketing nacrta.','muted'));
  for(const draft of drafts)$('content').append(marketingDraftCard(draft));
}
async function reviewMarketingDraft(card,id) {
  if(state.busy||!marketingAllowed(card))return;
  const epoch=state.epoch;setBusy(true);
  try{
    const draft=await api('/admin/api/marketing/drafts/'+encodeURIComponent(id));
    if(epoch!==state.epoch||!marketingAllowed(card))return;
    renderReviewedMarketingDraft(card,draft);status('Prikazan je tačan sadržaj nacrta. Odobrenje i objava su odvojene radnje.');
  }catch(error){if(epoch===state.epoch)status(error.message,true);}
  finally{if(epoch===state.epoch)setBusy(false);}
}
function marketingText(value){return value===undefined?'—':typeof value==='string'?value:JSON.stringify(value,null,2);}
function marketingPreview(value,alt){
  if(typeof value!=='string')return null;
  const hash=/^\/media\/([a-f0-9]{64})\.jpg$/.exec(value);
  const asset=['/assets/crni-kim.jpg','/assets/origano.jpg','/assets/cetiri-lopova.jpg'].includes(value);
  if(!hash&&!asset)return null;
  const img=el('img');img.alt=alt;img.className='marketing-thumbnail';img.src=hash?'/admin/api/marketing/media/'+hash[1]+'.jpg':value;return img;
}
function renderReviewedMarketingDraft(card,draft) {
  card.replaceChildren();card.dataset.draftId=String(draft.id);card.dataset.revision=String(draft.revision);
  card.append(el('h3',String(draft.productId||'Proizvod')),el('p',(marketingStatuses[draft.status]||draft.status)+' · Nacrt '+draft.id+' · Pregledana verzija '+draft.revision,'small'));
  card.append(el('p','Levo je sadržaj u trenutku pripreme, desno predlog. Server će odbiti objavu ako je javni sadržaj u međuvremenu izmenjen. Promene zaliha same po sebi ne menjaju tekst nacrta.','small'));
  const diffs=el('div',undefined,'marketing-diffs');
  for(const [key,value]of Object.entries(draft.patch||{})){
    const section=el('section',undefined,'marketing-diff');const title=key==='seoTitle'?'SEO naslov':key==='seoDescription'?'SEO opis':key==='imagePath'?'Fotografija':key==='declaration'?'Upozorenja / deklaracija':names[key]||key;
    section.append(el('h4',title));const pair=el('div',undefined,'marketing-comparison'),before=el('div'),after=el('div');
    const previous=key==='declaration'&&value&&typeof value==='object'?Object.fromEntries(Object.keys(value).map(name=>[name,draft.baseContent?.declaration?.[name]])):draft.baseContent?.[key];
    before.append(el('strong','Pre'),el('pre',marketingText(previous)));after.append(el('strong','Predlog'),el('pre',marketingText(value)));
    if(key==='imagePath'){
      const oldImage=marketingPreview(draft.baseContent?.imagePath||(draft.baseContent?.image?'/assets/'+draft.baseContent.image:null),'Fotografija pre izmene'),newImage=marketingPreview(value,'Privatni pregled predložene fotografije');
      if(oldImage)before.append(oldImage);if(newImage)after.append(newImage);
    }
    pair.append(before,after);section.append(pair);diffs.append(section);
  }
  card.append(diffs);
  if(Number.isSafeInteger(draft.revision)&&draft.revision>0&&['draft','approved'].includes(draft.status)){
    const actions=el('div',undefined,'marketing-actions'),action=draft.status==='draft'?'approve':'publish';
    const button=el('button',action==='approve'?'Odobri ovu verziju':'Objavi odobrenu verziju');button.type='button';button.dataset.marketingAction=action;
    const reject=el('button','Odbij nacrt','secondary');reject.type='button';reject.dataset.marketingAction='reject';actions.append(button,reject);card.append(actions);
    for(const control of [button,reject])control.addEventListener('click',()=>{if(control.isConnected)changeMarketingDraft(card,draft,control.dataset.marketingAction);});
  }
}
async function changeMarketingDraft(card,draft,action) {
  if(state.busy||!marketingAllowed(card))return;
  const epoch=state.epoch;setBusy(true);
  const verb=action==='approve'?'Odobriti':action==='publish'?'OBJAVITI u javnom katalogu':'Odbiti';
  const message=verb+' nacrt '+draft.id+' za proizvod „'+draft.productId+'”, tačno pregledanu verziju '+draft.revision+'? '+(action==='approve'?'Odobrenje ne objavljuje sadržaj.':action==='publish'?'Tek ova potvrda menja javni tekst/fotografiju/SEO. Cene i zalihe ostaju nepromenjene.':'Odbijen nacrt neće biti objavljen.');
  try{
    if(!await confirmSave(message,true)||epoch!==state.epoch||!marketingAllowed(card))return;
    const result=await marketingRequest('/drafts/'+encodeURIComponent(draft.id)+'/'+action,{version:draft.revision});
    if(epoch!==state.epoch||!marketingAllowed(card))return;
    const updated=result.draft||result;
    if(updated.id===draft.id&&Number.isSafeInteger(updated.revision))renderReviewedMarketingDraft(card,updated);
    else card.replaceWith(marketingDraftCard({...draft,status:action==='approve'?'approved':action==='publish'?'published':'rejected'}));
    status(action==='approve'?'Verzija je odobrena. Još nije objavljena.':action==='publish'?'Odobrena verzija je objavljena.':'Nacrt je odbijen.');
  }catch(error){
    if(epoch!==state.epoch)return;
    if(error.status===409&&card.isConnected){
      const retry=el('button','Ponovo pregledaj najnoviju verziju','secondary');retry.type='button';
      card.replaceChildren(el('p','Nacrt ili javni sadržaj je promenjen. Nijedna nova verzija nije automatski odobrena ili objavljena.','notice error'),retry);retry.addEventListener('click',()=>reviewMarketingDraft(card,draft.id));
    }
    status(error.message,true);
  }finally{if(epoch===state.epoch)setBusy(false);}
}
function renderMarketingKeys(keys) {
  if(!state.marketingOwner)return;
  const section=el('section',undefined,'marketing-keys');section.append(el('h3','Pristup AI timu'),el('p','Ključ važi samo za izabrane mogućnosti i do isteka. Može se odmah opozvati. Ne šaljite ključ u chat, dokumente ili URL; unesite ga samo u zaštićeno polje svog AI sistema.','small'));
  const list=el('div',undefined,'marketing-key-list');section.append(list);
  for(const key of keys){
    const row=el('article',undefined,'marketing-key'),revoked=!!(key.revokedAt||key.revoked_at),expires=key.expiresAt||key.expires_at;
    row.append(el('strong',String(key.label||key.id)),el('p',(revoked?'Opozvan':'Pristup')+' · Ističe: '+date(expires)+' · '+(key.scopes||[]).join(', '),'small'));
    if(!revoked){
      const revoke=el('button','Opozovi ključ','secondary');revoke.type='button';row.append(revoke);
      revoke.addEventListener('click',async()=>{
        if(state.busy||!marketingAllowed(row))return;const epoch=state.epoch;setBusy(true);
        try{
          if(!await confirmSave('Opozvati ključ „'+(key.label||key.id)+'”? AI tim više neće moći da ga koristi. Postojeći nacrti ostaju za pregled vlasniku.',true)||epoch!==state.epoch||!marketingAllowed(row))return;
          await marketingRequest('/keys/'+encodeURIComponent(key.id)+'/revoke',{});
          if(epoch!==state.epoch||!marketingAllowed(row))return;
          revoke.remove();row.append(el('p','Ključ je opozvan.','small'));status('Ključ je opozvan.');
        }catch(error){if(epoch===state.epoch)status(error.message,true);}
        finally{if(epoch===state.epoch)setBusy(false);}
      });
    }
    list.append(row);
  }
  const details=el('details');details.append(el('summary','Napravi novi ograničeni ključ'));const form=el('form',undefined,'marketing-key-form');
  const label=field('label','',{label:'Naziv pristupa',required:true,max:100,hint:'Npr. AI marketing tim — bez tajni ili ličnih podataka.'});
  const expiry=el('label','Važenje','field'),days=el('select');days.name='expiresInDays';
  for(const value of [7,30,90]){const option=el('option',value+' dana');option.value=String(value);option.selected=value===30;days.append(option);}expiry.append(days);form.append(label,expiry);
  const scopes=el('fieldset');scopes.append(el('legend','Dozvoljene mogućnosti'));
  for(const [scope,caption]of Object.entries(marketingScopes)){const wrap=el('label',undefined,'check'),input=el('input');input.type='checkbox';input.name='scope';input.value=scope;input.checked=input.defaultChecked=true;wrap.append(input,document.createTextNode(caption));scopes.append(wrap);}
  const submit=el('button','Napravi ključ');submit.type='submit';const message=el('p','','form-message');message.setAttribute('role','status');form.append(scopes,message,submit);details.append(form);section.append(details);
  const secret=el('div',undefined,'marketing-secret');secret.hidden=true;section.append(secret);$('content').append(section);renderMarketingAudit();
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(state.busy||!marketingAllowed(form)||form.dataset.outcomeUncertain==='true')return;
    const chosen=[...form.querySelectorAll('[name=scope]:checked')].map(input=>input.value),name=form.querySelector('[name=label]').value.trim(),duration=Number(days.value);
    if(!name||name.length>100||!chosen.length||![7,30,90].includes(duration)){message.textContent='Unesite naziv i izaberite najmanje jednu mogućnost.';return;}
    const epoch=state.epoch;setBusy(true);message.textContent='';let attempted=false;
    try{
      if(!await confirmSave('Napraviti ključ „'+name+'” na '+duration+' dana? Mogućnosti: '+chosen.join(', ')+'. Ovaj ključ nema pravo objave.',true)||epoch!==state.epoch||!marketingAllowed(form))return;
      secret.replaceChildren();secret.hidden=true;
      attempted=true;const result=await marketingRequest('/keys',{label:name,scopes:chosen,expiresAt:new Date(Date.now()+duration*86400000).toISOString()});
      if(epoch!==state.epoch||!marketingAllowed(form))return;
      if(typeof result.token!=='string')throw new Error('Ključ je možda napravljen, ali tajna nije prikazana. Osvežite spisak i proverite pre novog pokušaja.');
      secret.append(el('strong','Prikazuje se samo sada'),el('p','Prenesite ključ u zaštićeno polje. Posle zatvaranja ili napuštanja ovog prikaza neće se ponovo prikazati.','small'));
      const field=el('label','Tajni API ključ','field'),input=el('input');input.type='password';input.readOnly=true;input.autocomplete='off';input.value=result.token;field.append(input);secret.append(field);
      const reveal=el('button','Prikaži / sakrij','secondary'),hide=el('button','Zatvori tajni ključ','secondary');reveal.type=hide.type='button';
      reveal.addEventListener('click',()=>{input.type=input.type==='password'?'text':'password';});hide.addEventListener('click',()=>{input.value='';secret.replaceChildren();secret.hidden=true;});
      secret.append(reveal,hide);secret.hidden=false;details.open=false;form.reset();days.value='30';
      list.append(el('p','Napravljen pristup „'+name+'”. Osvežite spisak za pregled ili opoziv; tajna se tada uklanja.','small'));status('Ograničeni ključ je napravljen. Tajna je prikazana samo u ovom privatnom panelu.');
    }catch(error){if(epoch===state.epoch){
      if(attempted){form.dataset.outcomeUncertain='true';message.textContent='Ishod kreiranja ključa nije potvrđen. Osvežite spisak i proverite postojeće ključeve pre novog pokušaja. '+error.message;}
      else message.textContent=error.message;
      status(message.textContent,true);
    }}
    finally{if(epoch===state.epoch){setBusy(false);if(form.dataset.outcomeUncertain==='true')submit.disabled=true;}}
  });
}

function renderMarketingAudit(){
  const section=el('section',undefined,'marketing-audit marketing-keys'),list=el('div'),loadButton=el('button','Učitaj marketing istoriju','secondary');
  section.append(el('h3','Istorija marketing promena'),el('p','Ključevi, nacrti, odobrenja i objave imaju zaseban trag. Ovde se ne prikazuju tajne ključeva niti lični podaci kupaca.','small'),list,loadButton);
  loadButton.type='button';$('content').append(section);let cursor=null,loaded=false;
  loadButton.addEventListener('click',async()=>{
    if(state.busy||!marketingAllowed(section))return;
    const epoch=state.epoch;setBusy(true);
    try{
      const data=await api('/admin/api/marketing/audit'+(cursor?'?before='+encodeURIComponent(cursor):''));
      if(epoch!==state.epoch||!marketingAllowed(section))return;
      if(!loaded)list.replaceChildren();
      for(const entry of data.entries||[]){
        const item=el('article',undefined,'audit-entry');
        item.append(el('h4',String(entry.action||'Izmena')+' · '+String(entry.entityType||'')+' '+String(entry.entityId||'')),el('p',date(entry.createdAt)+' · '+String(entry.actorId||''),'small'));
        const details=el('details');details.append(el('summary','Pre i posle'),el('pre',JSON.stringify({pre:entry.before,posle:entry.after},null,2)));item.append(details);list.append(item);
      }
      if(!loaded&&!(data.entries||[]).length)list.append(el('p','Još nema marketing promena.','small'));
      loaded=true;cursor=data.nextCursor||null;loadButton.hidden=!cursor;loadButton.textContent='Učitaj starije marketing promene';
    }catch(error){if(epoch===state.epoch)status(error.message,true);}
    finally{if(epoch===state.epoch)setBusy(false);}
  });
}
if(typeof document!=='undefined'){
 document.querySelectorAll('[data-view]').forEach(node=>node.addEventListener('click',()=>{if(!state.busy&&dirtyGuard())load(node.dataset.view);}));
 $('refresh').addEventListener('click',()=>{if(dirtyGuard())load();});$('retry').addEventListener('click',boot);$('more').addEventListener('click',()=>{if(dirtyGuard())load(state.view,true);});
 window.addEventListener('pageshow',boot);window.addEventListener('pagehide',clearSensitive);
 window.addEventListener('beforeunload',event=>{if(state.dirty){event.preventDefault();event.returnValue='';}});
 async function checkSession(){if(document.hidden||!state.csrf||state.busy)return;const epoch=state.epoch;try{
  const session=await api('/admin/api/session');if(epoch!==state.epoch)return;
  if(!session.csrfToken){access(401);return;}
  if(principal(session)!==state.principal){await boot();return;}
  const hadRoleAccess=state.manageRoles;applySession(session);
  if(state.view==='marketing'&&!state.marketingOwner){setBusy(false);await load('products');}
  else if(state.view==='customers'&&$('customers-tab').hidden)await load('products');
  else if(state.view==='customers'&&!hadRoleAccess&&state.manageRoles)await load('customers');
 }catch(error){if(epoch===state.epoch&&state.csrf)status('Provera sesije nije uspela. Pre čuvanja će se ponovo proveriti pristup.',true);}}
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkSession();});setInterval(checkSession,60000);
}
