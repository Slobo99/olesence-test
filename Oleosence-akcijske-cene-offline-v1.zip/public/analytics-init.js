/* Basic consent mode: the Google library is not requested before opt-in. */
(function () {
  'use strict';
  var id = 'G-105CEG84DT';
  var key = 'olesence.analytics-consent.v1';
  var maxAge = 180 * 24 * 60 * 60 * 1000;
  var labels = {'/': 'Olesence', '/proizvod/crni-kim': 'Ulje crnog kima', '/proizvod/divlji-origano': 'Ulje divljeg origana', '/proizvod/cetiri-lopova': 'Ulje 4 lopova', '/account': 'Moj nalog', '/checkout': 'Porudžbina'};
  var path = location.pathname.replace(/\.html$/, '');
  // Only a server-rendered published product may extend the fixed page allowlist.
  var productPath = document.documentElement.getAttribute('data-public-product');
  if (productPath === path && /^\/proizvod\/[a-z0-9]+(?:-[a-z0-9]+)*$/.test(path) && path.length <= 110) labels[path] = labels[path] || 'Olesence proizvod';
  if (location.origin !== 'https://olesence.rs' || !Object.prototype.hasOwnProperty.call(labels, path)) return;
  // Private forms stay untracked. Checkout may explicitly enable a receipt only.
  var collectionAllowed = path !== '/account' && path !== '/checkout';
  var choice = null, choiceAt = 0, loaded = false, banner, settings, status;
  window.dataLayer = window.dataLayer || [];
  window.gtag = function () { window.dataLayer.push(arguments); };
  window['ga-disable-' + id] = true;
  window.gtag('consent', 'default', {analytics_storage: 'denied', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied'});
  window.gtag('set', 'ads_data_redaction', true);
  window.gtag('set', 'url_passthrough', false);
  function remember(value) {
    choice = value;
    choiceAt = Date.now();
    try { localStorage.setItem(key, JSON.stringify({value: value, at: Date.now()})); } catch (_) { /* Choice still applies to this page. */ }
  }
  function clearCookies() {
    document.cookie.split(';').forEach(function (part) {
      var name = part.trim().split('=')[0];
      if (!/^_ga(?:_|$)/.test(name)) return;
      ['', '; Domain=olesence.rs', '; Domain=.olesence.rs'].forEach(function (domain) {
        document.cookie = name + '=; Max-Age=0; Path=/' + domain + '; SameSite=Lax; Secure';
      });
    });
  }
  function hasConsent() {
    return choice === 'granted' && Date.now() >= choiceAt && Date.now() - choiceAt < maxAge;
  }
  function load(safePage, pageView) {
    if (!hasConsent()) return false;
    window['ga-disable-' + id] = false;
    window.gtag('consent', 'update', {analytics_storage: 'granted', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied'});
    if (loaded) return true;
    // Fixed page context only; no title, location query, contact, or account data.
    window.gtag('js', new Date());
    window.gtag('config', id, Object.assign({send_page_view: false, allow_google_signals: false, allow_ad_personalization_signals: false, cookie_expires: 15552000, cookie_update: false, cookie_flags: 'SameSite=Lax;Secure'}, safePage));
    if (pageView) window.gtag('event', 'page_view', Object.assign({send_to: id}, safePage));
    var script = document.createElement('script');
    script.async = true;
    script.src = 'https://www.googletagmanager.com/gtag/js?id=' + id;
    script.id = 'olesence-google-tag';
    script.referrerPolicy = 'no-referrer';
    document.head.appendChild(script);
    loaded = true;
    return true;
  }
  function start() {
    if (!collectionAllowed) return;
    load({page_location: 'https://olesence.rs' + path, page_referrer: '', page_title: labels[path]}, true);
  }
  window.olesenceSuspendMeasurement = function () {
    if (path === '/checkout') window['ga-disable-' + id] = true;
  };
  window.olesenceHasAnalyticsConsent = hasConsent;
  window.olesenceEnsureMeasurement = function (safePage) {
    var receipt = document.getElementById('receipt');
    var editor = document.getElementById('checkout-editor');
    var pending = document.getElementById('pending-panel');
    if (path !== '/checkout' || !hasConsent() || !receipt || receipt.hidden || !editor || !editor.hidden || !pending || !pending.hidden) return false;
    if (!safePage || safePage.page_location !== 'https://olesence.rs/checkout/potvrda' || safePage.page_referrer !== '' || safePage.page_title !== 'Potvrda porudžbine') return false;
    // Reconstruct the allowlist, so extra properties supplied by a caller cannot leak.
    return load({page_location: 'https://olesence.rs/checkout/potvrda', page_referrer: '', page_title: 'Potvrda porudžbine'}, false);
  };
  function deny() {
    window['ga-disable-' + id] = true;
    window.gtag('consent', 'update', {analytics_storage: 'denied', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied'});
    clearCookies();
  }
  function apply(value) {
    remember(value);
    if (value === 'granted') start(); else deny();
    banner.hidden = true;
    status.textContent = value === 'granted' ? 'Analitika je uključena.' : 'Analitika je isključena.';
    settings.focus();
    window.dispatchEvent(new Event('olesence-analytics-consent-change'));
  }
  function ready() {
    banner = document.getElementById('analytics-consent');
    settings = document.getElementById('analytics-settings');
    status = document.getElementById('analytics-status');
    if (!banner || !settings || !status) return;
    document.getElementById('analytics-accept').addEventListener('click', function () { apply('granted'); });
    document.getElementById('analytics-decline').addEventListener('click', function () { apply('denied'); });
    settings.addEventListener('click', function () { banner.hidden = false; document.getElementById('analytics-decline').focus(); });
    window.addEventListener('storage', function (event) {
      if (event.key !== key && event.key !== null) return;
      // Another tab can revoke immediately; never grant implicitly from an unvalidated event.
      var next; try { next = JSON.parse(event.newValue); } catch (_) {}
      if (!next || next.value !== 'granted') { choice = 'denied'; deny(); status.textContent = 'Analitika je isključena.'; }
    });
    try {
      var saved = JSON.parse(localStorage.getItem(key));
      if (saved && ['granted', 'denied'].includes(saved.value) && Number.isFinite(saved.at) && Date.now() >= saved.at && Date.now() - saved.at < maxAge) { choice = saved.value; choiceAt = saved.at; }
    } catch (_) {}
    settings.hidden = false;
    if (choice === 'granted') start();
    else if (choice === 'denied') deny();
    banner.hidden = choice !== null;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready, {once: true}); else ready();
}());
