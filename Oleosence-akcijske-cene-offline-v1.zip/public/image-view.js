// Only bundled, immutable product photos have variants. Uploaded images retain their original URL.
const variants = {
  "/assets/crni-kim.jpg": {
    "400": "/assets/crni-kim-400.72876634ef97.webp",
    "800": "/assets/crni-kim-800.0386a74f1a73.webp",
    "1200": "/assets/crni-kim-1200.70967441a688.webp"
  },
  "/assets/origano.jpg": {
    "400": "/assets/origano-400.6542150a1ca2.webp",
    "800": "/assets/origano-800.cf917a876093.webp",
    "1200": "/assets/origano-1200.39ae7f00bfce.webp"
  },
  "/assets/cetiri-lopova.jpg": {
    "400": "/assets/cetiri-lopova-400.fd8c68fa8e54.webp",
    "800": "/assets/cetiri-lopova-800.b04c0bd393b2.webp",
    "1200": "/assets/cetiri-lopova-1200.25b4878e8fea.webp"
  }
};
function escaped(value){return String(value).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;');}
export function productImageAttributes(path,{detail=false}={}){
 const sizes=detail?'(max-width: 800px) 100vw, 50vw':'(max-width: 650px) 100vw, (max-width: 1050px) 50vw, 33vw';
 const images=variants[path];
 const responsive=images?`src="${images[detail?'1200':'400']}" srcset="${Object.entries(images).map(([width,url])=>`${url} ${width}w`).join(', ')}" sizes="${sizes}"`:`src="${escaped(path)}"`;
 return `${responsive} width="2048" height="2048" decoding="async" ${detail?'fetchpriority="high"':'loading="lazy"'}`;
}
