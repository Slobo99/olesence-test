import {shippingPolicy} from './catalog.js';
import {productImageAttributes} from './image-view.js';
export function escapeHtml(value){return String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');}
export function productImage(p){return typeof p.imagePath==='string'&&(/^\/media\/[a-f0-9]{64}\.jpg$/.test(p.imagePath)||['/assets/crni-kim.jpg','/assets/origano.jpg','/assets/cetiri-lopova.jpg'].includes(p.imagePath))?p.imagePath:'/assets/'+p.image;}
const arrow='<span aria-hidden="true">↗</span>';
function formatMoney(minor){if(!Number.isSafeInteger(minor)||minor<0)throw new RangeError('Invalid amount');return new Intl.NumberFormat('sr-Latn-RS',{style:'currency',currency:'RSD',minimumFractionDigits:2,maximumFractionDigits:2}).format(minor/100);}
// A deliberately small, escaped text format. HTML, links, images and scripts are never parsed.
function descriptionLines(value){return String(value??'').replace(/\r\n?/g,'\n').split('\n').map(line=>line.trim()).filter(Boolean);}
function inlineBold(value){return value.split(/(\*\*[^*\n]+\*\*)/g).map(part=>/^\*\*[^*\n]+\*\*$/.test(part)?'<strong>'+escapeHtml(part.slice(2,-2))+'</strong>':escapeHtml(part)).join('');}
function markdownLine(line){
 const heading=line.match(/^(#{2,3})\s+(.+)$/);if(heading)return {type:heading[1].length===2?'h2':'h3',text:heading[2]};
 const bullet=line.match(/^[-*]\s+(.+)$/);if(bullet)return {type:'ul',text:bullet[1]};
 const number=line.match(/^\d+\.\s+(.+)$/);if(number)return {type:'ol',text:number[1]};
 return {type:'p',text:line};
}
export function descriptionPlainText(value,format='plain'){
 const lines=descriptionLines(value);
 return (format==='markdown'?lines.map(line=>markdownLine(line).text.replace(/\*\*([^*\n]+)\*\*/g,'$1')):lines).join('\n');
}
export function descriptionMarkup(value,format='plain'){
 const lines=descriptionLines(value);
 if(format!=='markdown'){
  const hasHeading=lines.length>1&&lines[0].length<=100&&!/[.!?…:]$/.test(lines[0]);
  return lines.map((line,index)=>hasHeading&&index===0?`<h2 class="description-heading">${escapeHtml(line)}</h2>`:`<p>${escapeHtml(line)}</p>`).join('\n');
 }
 const blocks=[];let list=null;
 for(const line of lines){const item=markdownLine(line);if(item.type==='ul'||item.type==='ol'){
  if(!list||list.type!==item.type){list={type:item.type,items:[]};blocks.push(list);}list.items.push(item.text);
 }else{list=null;blocks.push(item);}}
 return blocks.map(block=>block.items?`<${block.type}>${block.items.map(text=>'<li>'+inlineBold(text)+'</li>').join('\n')}</${block.type}>`:`<${block.type}${block.type==='h2'?' class="description-heading"':''}>${inlineBold(block.text)}</${block.type}>`).join('\n');
}
const saleDate=new Intl.DateTimeFormat('sr-Latn-RS',{timeZone:'Europe/Belgrade',day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
export function priceMarkup(p,detail=false){
 const s=p.sale,cls=detail?'detail-price':'product-price';
 const active=s&&Number.isSafeInteger(s.previousMinor)&&s.previousMinor>p.priceMinor&&Number.isFinite(Date.parse(s.startAt))&&Number.isFinite(Date.parse(s.endAt));
 const newPrice='<strong class="'+cls+'">'+formatMoney(p.priceMinor)+'</strong>';
 const date=key=>escapeHtml(saleDate.format(new Date(s[key])));
 const badge=active&&Number.isInteger(s.percent)&&s.percent>=1&&s.percent<=99?'<span class="sale-discount" aria-label="Popust '+s.percent+' procenata">−'+s.percent+'%</span>':'';
 return '<div class="product-pricing" data-price-product="'+escapeHtml(p.id)+'" data-price-mode="'+(detail?'detail':'card')+'">'+(active
   ? '<div class="sale-prices"><del class="previous-price" aria-label="Prethodna cena '+escapeHtml(formatMoney(s.previousMinor))+'">'+formatMoney(s.previousMinor)+'</del>'+newPrice+badge+'</div><p class="sale-period">Akcija od <time datetime="'+escapeHtml(s.startAt)+'">'+date('startAt')+'</time><br>do <time datetime="'+escapeHtml(s.endAt)+'">'+date('endAt')+'</time></p>'
   : newPrice)+'</div>';
}
export function card(p){return `<article class="product-card"><a class="product-photo ${escapeHtml(p.tone)}" href="/proizvod/${escapeHtml(p.id)}"><span class="photo-label">${escapeHtml(p.category)}</span><img ${productImageAttributes(productImage(p))} alt="${escapeHtml(p.name)}, bočica i pakovanje"><span class="circle-arrow" aria-hidden="true">↗</span></a><div class="card-meta"><p>${escapeHtml(p.botanical)}</p>${p.volume?`<span>${escapeHtml(p.volume)}</span>`:''}</div><h3><a href="/proizvod/${escapeHtml(p.id)}">${escapeHtml(p.name)}</a></h3>${priceMarkup(p)}${p.available===false?'<p class="microcopy">Trenutno nije dostupno</p>':''}<a class="text-link" href="/proizvod/${escapeHtml(p.id)}">Upoznajte proizvod ${arrow}</a></article>`;}
export function productMarkup(p,products){return `<div class="breadcrumbs"><a href="/">Početna</a><span>/</span><a href="/#kolekcija">Kolekcija</a><span>/</span><span>${escapeHtml(p.name)}</span></div><section class="product-detail"><div class="detail-image ${escapeHtml(p.tone)}"><img ${productImageAttributes(productImage(p),{detail:true})} alt="${escapeHtml(p.name)}, originalna fotografija bočice i pakovanja"></div><div class="detail-copy"><span class="eyebrow">${escapeHtml(p.category)}${p.volume?' / '+escapeHtml(p.volume):''}</span><h1>${escapeHtml(p.name)}</h1><p class="botanical">${escapeHtml(p.botanical)}</p><div class="description" data-product-description>${descriptionMarkup(p.description,p.descriptionFormat)}</div><div class="sale-status">${priceMarkup(p,true)}<span data-checkout-status>Poručivanje nije omogućeno</span></div><button class="button" data-add="${escapeHtml(p.id)}" ${p.available===false?'disabled':''}>${p.available===false?'Trenutno nije dostupno':'Dodaj u korpu'} <span>+</span></button><p class="microcopy" data-checkout-note>Poručivanje trenutno nije dostupno. Dostava: 300 din po paketu; besplatna za vrednost proizvoda od 3.500 din.</p><section class="declaration-draft" aria-label="Informacije o proizvodu"><span class="eyebrow">INFORMACIJE O PROIZVODU</span><h2>Namena i deklaracija</h2><p class="draft-caution">Informacije na ovoj stranici nisu potvrda registracije ili konkretne serije. Pre upotrebe proverite konačnu deklaraciju, potpuna upozorenja na pakovanju i savet stručnjaka.</p><details open><summary>Sastav i osnovne informacije</summary><p>${escapeHtml(p.ingredients)}</p>${p.method?`<p>Način dobijanja: ${escapeHtml(p.method)}</p>`:''}<p>${escapeHtml(p.note)}</p></details><h3>Namena</h3><p>${escapeHtml(p.declaration.benefit)}</p><details open><summary>Način primene</summary><p>${escapeHtml(p.declaration.usage)}</p></details><details open><summary>Upozorenja</summary><p>${escapeHtml(p.declaration.warnings)}</p>${p.declaration.editorialCaveat?`<p class="editorial-caveat">${escapeHtml(p.declaration.editorialCaveat)}</p>`:''}</details><details open><summary>Napomene i čuvanje</summary><p>${escapeHtml(p.declaration.notes)}</p><p>${escapeHtml(p.declaration.storage)}</p></details><div class="registration-field"><span>Broj upisa u bazu Ministarstva zdravlja</span><div class="registration-number" aria-label="Broj upisa, polje za naknadnu dopunu"></div><small>Podatak još nije dostupan. Završen upis ne potvrđujemo.</small></div></section></div></section><section class="section related"><div class="section-heading"><div><span class="eyebrow">JOŠ IZ KOLEKCIJE</span><h2>Istražite <em>dalje.</em></h2></div><a class="text-link" href="/#kolekcija">Svi proizvodi ${arrow}</a></div><div class="product-grid">${products.filter(x=>x.id!==p.id).map(card).join('')}</div></section>`;}

// Only explicit public fields enter structured data, never database metadata or drafts.
export function productStructuredData(p,{origin='https://olesence.rs',offers=false}={}){
 const url=origin+'/proizvod/'+encodeURIComponent(p.id);
 const data={'@context':'https://schema.org','@type':'Product','@id':url+'#product',url,name:p.name,description:descriptionPlainText(p.description,p.descriptionFormat),image:origin+productImage(p),sku:p.id,brand:{'@type':'Brand',name:'olésence'}};
 if(offers&&Number.isSafeInteger(p.priceMinor)&&p.priceMinor>=0){data.offers={'@type':'Offer',url,priceCurrency:'RSD',price:(p.priceMinor/100).toFixed(2),...(p.sale?{priceValidUntil:p.sale.endAt}:{}),availability:'https://schema.org/'+(p.available===true?'InStock':'OutOfStock'),shippingDetails:{'@type':'OfferShippingDetails',shippingDestination:{'@type':'DefinedRegion',addressCountry:'RS'},shippingRate:{'@type':'MonetaryAmount',minValue:0,maxValue:p.priceMinor>=shippingPolicy.freeFromMinor?0:shippingPolicy.perPackageMinor/100,currency:shippingPolicy.currency},hasShippingService:{'@id':origin+'/#shipping'}}};}
 return data;
}
export function safeJson(value){return JSON.stringify(value).replace(/</g,'\\u003c').replace(/>/g,'\\u003e').replace(/&/g,'\\u0026').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');}
