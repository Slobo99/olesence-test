from PIL import Image, ImageDraw
from pathlib import Path
import hashlib,json,io
root=Path(__file__).resolve().parents[1]; assets=root/'public/assets'; stats=[]; manifest={}
def save(im,stem,fmt='WEBP',**opts):
 b=io.BytesIO(); im.save(b,format=fmt,**opts); data=b.getvalue(); ext='jpg' if fmt=='JPEG' else fmt.lower(); name=f'{stem}.{hashlib.sha256(data).hexdigest()[:12]}.{ext}'; (assets/name).write_bytes(data);stats.append({'file':name,'bytes':len(data),'width':im.width,'height':im.height});return name
for p in sorted(assets.glob('slider-*.png')):
 im=Image.open(p).convert('RGB'); name=save(im,p.stem,quality=80,method=6);manifest[p.name]=name
for stem in ['crni-kim','origano','cetiri-lopova']:
 im=Image.open(assets/(stem+'.jpg')).convert('RGB');manifest[stem+'.jpg']={}
 for width in [400,800,1200]:
  small=im.resize((width,width),Image.Resampling.LANCZOS);manifest[stem+'.jpg'][str(width)]=save(small,stem+'-'+str(width),quality=82,method=6)
# Fit the existing original collection photograph into share-card canvas; no cropped packages.
im=Image.open(assets/'slider-kolekcija-desktop.png').convert('RGB'); im.thumbnail((1200,630),Image.Resampling.LANCZOS)
canvas=Image.new('RGB',(1200,630),'#f5f3ec');canvas.paste(im,((1200-im.width)//2,(630-im.height)//2));manifest['og']=save(canvas,'olesence-og','JPEG',quality=86,optimize=True)
# Reuse the header's green, rounded leaf shape on its existing cream background.
icon=Image.new('RGBA',(256,256),'#f5f3ec');leaf=Image.new('RGBA',(192,112));draw=ImageDraw.Draw(leaf);draw.rounded_rectangle((0,0,191,111),radius=85,fill='#80ae8e');draw.rectangle((96,0,191,55),fill='#80ae8e');draw.rectangle((0,56,95,111),fill='#80ae8e');leaf=leaf.rotate(15,Image.Resampling.BICUBIC,expand=True);icon.alpha_composite(leaf,((256-leaf.width)//2,(256-leaf.height)//2))
icon.resize((180,180),Image.Resampling.LANCZOS).save(root/'public/apple-touch-icon.png');icon.resize((32,32),Image.Resampling.LANCZOS).save(root/'public/favicon.png');icon.save(root/'public/favicon.ico',sizes=[(16,16),(32,32),(48,48)])
(root/'IMAGE-OPTIMIZATION.json').write_text(json.dumps({'assets':stats,'manifest':manifest},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'assets':stats,'manifest':manifest},indent=2))
