import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
export const analyticsScript = readFileSync(new URL('../public/analytics-init.js', import.meta.url), 'utf8');
export const analyticsHash = 'sha256-' + createHash('sha256').update(analyticsScript).digest('base64');
export const analyticsCsp = `default-src 'none'; script-src 'self' '${analyticsHash}' https://www.googletagmanager.com; style-src 'self'; img-src 'self' data: blob: https://www.google-analytics.com https://region1.google-analytics.com https://www.googletagmanager.com; connect-src 'self' https://www.google-analytics.com https://region1.google-analytics.com https://analytics.google.com; frame-ancestors 'none'; base-uri 'none'; form-action 'none'; object-src 'none'`;
const controls = `<section id="analytics-consent" role="region" aria-labelledby="analytics-consent-title" hidden><h2 id="analytics-consent-title">Analitika uz vaš izbor</h2><p>Uz vašu saglasnost koristimo Google Analytics da razumemo posećenost sajta i kupovine. Google tada prima podatke o poseti i potvrđenoj porudžbini (iznos i proizvodi, bez kontakt podataka) i postavlja analitičke kolačiće. Odbijanje ne utiče na kupovinu. Izbor možete promeniti preko „Podešavanja analitike”. <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">Google politika privatnosti</a>.</p><div class="analytics-actions"><button id="analytics-decline" type="button">Odbij analitiku</button><button id="analytics-accept" type="button">Prihvati analitiku</button></div></section><button id="analytics-settings" type="button" hidden>Podešavanja analitike</button><span id="analytics-status" role="status" aria-live="polite"></span>`;
export function renderAnalytics(bytes) {
  let html = bytes.toString('utf8');
  if (html.includes('id="olesence-analytics-init"')) throw Error('Analytics already installed');
  // Both policies use the exact same generated hash; no unsafe-inline or unsafe-eval.
  html = html.replace(/<meta\s+http-equiv="Content-Security-Policy"[^>]*>/gi, '');
  html = html.replace(/<head>/i, `<head><meta http-equiv="Content-Security-Policy" content="${analyticsCsp.replace("frame-ancestors 'none'; ", '')}"><script id="olesence-analytics-init">${analyticsScript}</script><link rel="stylesheet" href="/analytics.css">`);
  return Buffer.from(html.replace('</body>', controls + '</body>'));
}
