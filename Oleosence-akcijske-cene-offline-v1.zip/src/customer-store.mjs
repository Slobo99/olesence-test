import {randomUUID} from 'node:crypto';
import {StoreError} from './admin-store.mjs';
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
const customer=row=>row?{id:row.id,email:row.email,name:row.name,createdAt:row.created_at,updatedAt:row.updated_at,lastLoginAt:row.last_login_at}:null;
const customerColumns='id,email,name,created_at,updated_at,last_login_at,admin_role,role_revision';
function verifiedIdentity(user,{durable=false}={}){
 if(!user||user.provider!=='google'||typeof user.subject!=='string'||!/^[\x21-\x7e]{1,255}$/.test(user.subject)||user.id!=='google:'+user.subject||typeof user.email!=='string'||user.email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)||(durable&&(typeof user.customerId!=='string'||!uuid.test(user.customerId))))throw new StoreError(403,'Verified Google customer identity required.');
}
function roleAuthority(row,policy={}){
 const email=row.email.toLowerCase(),bootstrap=Array.isArray(policy.emails)&&policy.emails.includes(email);
 if(bootstrap&&policy.ownerEmail===email)return {role:'owner',roleManagedBy:'owner'};
 if(bootstrap)return {role:'admin',roleManagedBy:'bootstrap'};
 return {role:row.admin_role,roleManagedBy:row.admin_role==='admin'?'delegated':null};
}
function roleCustomer(row,policy,manageRoles=false){
 const authority=roleAuthority(row,policy);
 return {...customer(row),...authority,roleVersion:row.role_revision,canManageRole:manageRoles===true&&!['owner','bootstrap'].includes(authority.roleManagedBy)};
}
async function verifiedCustomer(client,user,lock=false){
 verifiedIdentity(user,{durable:true});
 const {rows}=await client.query(`SELECT ${customerColumns} FROM commerce_customers WHERE id=$1 AND provider='google' AND subject=$2${lock?' FOR UPDATE':''}`,[user.customerId,user.subject]);
 if(!rows[0]||rows[0].email.toLowerCase()!==user.email.toLowerCase())throw new StoreError(403,'Verified customer no longer matches this session.');
 return rows[0];
}
export function readCustomerDatabaseConfig(env=process.env){const enabled=env.CUSTOMER_DATABASE_ENABLED==='1';if(enabled&&!env.DATABASE_URL)throw Error('Persistent customer storage requires DATABASE_URL.');return enabled;}
export function createCustomerStore(pool){
 return {
  // Only call after signature/audience/nonce/email verification by customer-auth.
  async upsertVerifiedGoogleUser(user){
   if(!user||user.provider!=='google'||typeof user.subject!=='string'||! /^[\x21-\x7e]{1,255}$/.test(user.subject)||user.id!=='google:'+user.subject||typeof user.email!=='string'||user.email.length>254||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)||typeof user.name!=='string'||user.name.length>100)throw new StoreError(400,'Verified identity required.');
   const {rows}=await pool.query(`INSERT INTO commerce_customers (id, provider, subject, email, name) VALUES ($1, 'google', $2, $3, $4)
    ON CONFLICT(provider,subject) DO UPDATE SET email=EXCLUDED.email,name=EXCLUDED.name,updated_at=now(),last_login_at=now()
    RETURNING id,email,name,created_at,updated_at,last_login_at`,[randomUUID(),user.subject,user.email,user.name]);
   return customer(rows[0]);
  },
  async getCustomer(id){if(typeof id!=='string'||!uuid.test(id))throw new StoreError(400,'Invalid customer ID.');const {rows}=await pool.query('SELECT id,email,name,created_at,updated_at,last_login_at FROM commerce_customers WHERE id=$1',[id]);return customer(rows[0]);},
  async getAdminAccess(user,adminPolicy){
   const row=await verifiedCustomer(pool,user);
   const {role}=roleAuthority(row,adminPolicy);
   return {role,manageRoles:role==='owner'};
  },
  async listCustomers({before,limit=50,adminPolicy,manageRoles=false}={}){
   if(!Number.isInteger(limit)||limit<1||limit>100||(before!==undefined&&(typeof before!=='string'||! /^[1-9][0-9]{0,18}$/.test(before)||BigInt(before)>9223372036854775807n)))throw new StoreError(400,'Invalid customer page.');
   const {rows}=await pool.query(`SELECT sequence_id,${customerColumns} FROM commerce_customers WHERE ($1::bigint IS NULL OR sequence_id < $1::bigint) ORDER BY sequence_id DESC LIMIT $2`,[before??null,limit+1]);
   const chosen=rows.slice(0,limit);return {customers:chosen.map(row=>roleCustomer(row,adminPolicy,manageRoles)),nextCursor:rows.length>limit?String(chosen.at(-1).sequence_id):null};
  },
  async updateCustomerRole(id,version,role,actor,adminPolicy){
   verifiedIdentity(actor,{durable:true});
   if(typeof id!=='string'||!uuid.test(id))throw new StoreError(400,'Neispravan ID kupca.');
   if(!Number.isSafeInteger(version)||version<1||version>=2147483647)throw new StoreError(400,'Potrebna je važeća verzija uloge.');
   if(!['admin','customer'].includes(role))throw new StoreError(400,'Dozvoljene su samo uloge administrator i kupac.');
   const client=await pool.connect();
   try{
    await client.query('BEGIN');
    // Revalidate the actor inside the same transaction. No request-supplied
    // role/email/customer ID can replace the identity from the verified session.
    const owner=await verifiedCustomer(client,actor,true);
    if(roleAuthority(owner,adminPolicy).role!=='owner')throw new StoreError(403,'Samo vlasnik može da menja administratorske uloge.');
    const {rows}=await client.query(`SELECT ${customerColumns} FROM commerce_customers WHERE id=$1 FOR UPDATE`,[id]);
    if(!rows.length)throw new StoreError(404,'Kupac nije pronađen.');
    const before=roleCustomer(rows[0],adminPolicy,true);
    if(!before.canManageRole)throw new StoreError(403,'Uloga vlasnika ili početnog administratora ne može da se promeni ovde.');
    if(before.roleVersion!==version)throw new StoreError(409,'Uloga je već izmenjena. Osvežite spisak pre nove izmene.');
    if(before.role===role)throw new StoreError(409,'Kupac već ima izabranu ulogu. Osvežite spisak.');
    const updated=await client.query(`UPDATE commerce_customers SET admin_role=$2,role_revision=role_revision+1,updated_at=now() WHERE id=$1 RETURNING ${customerColumns}`,[id,role]);
    const after=roleCustomer(updated.rows[0],adminPolicy,true);
    const snapshot=value=>({id:value.id,role:value.role,version:value.roleVersion});
    await client.query('INSERT INTO admin_audit (entity_type,entity_id,actor_id,before_snapshot,after_snapshot) VALUES ($1,$2,$3,$4::jsonb,$5::jsonb)',['customer_role',id,actor.id,JSON.stringify(snapshot(before)),JSON.stringify(snapshot(after))]);
    await client.query('COMMIT');
    return after;
   }catch(error){try{await client.query('ROLLBACK');}catch{/* Preserve the original failure. */}throw error;}finally{client.release();}
  }
 };
}
