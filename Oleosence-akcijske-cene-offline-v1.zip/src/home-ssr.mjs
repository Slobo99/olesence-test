import {homeMarkup} from '../public/home-view.js';
import {escapeHtml,siteSchemaMarkup} from './seo.mjs';

// The same escaped, presentational markup is used by the browser and server.
// Products are already publication-filtered and stripped of private stock fields.
export function renderHomePage(bytes, products, {checkoutEnabled=false,guestEnabled=false}={}) {
 let html=bytes.toString('utf8').replace('<main id="main" tabindex="-1"></main>',()=>'<main id="main" tabindex="-1" data-server-rendered="true">'+homeMarkup(products)+'<noscript><p class="microcopy">Za korpu i poručivanje uključite JavaScript.</p></noscript></main>');
 html=html.replace(/<div><strong>Istražite kolekciju<\/strong>[\s\S]*?<\/div>/,()=>'<div><strong>Istražite kolekciju</strong>'+products.map(p=>`<a href="/proizvod/${escapeHtml(p.id)}">${escapeHtml(p.name)}</a>`).join('')+'</div>');
 if(checkoutEnabled)html=html.replace(/(<p data-checkout-footer>)[\s\S]*?(<\/p>)/,(_,a,b)=>a+(guestEnabled?'Porudžbine bez registracije, uz plaćanje pouzećem. Google prijava je opciona.':'Porudžbine sa plaćanjem pouzećem. Google prijava koristi osnovni profil i imejl.')+b).replace(/(<span data-checkout-label>)[\s\S]*?(<\/span>)/,'$1Plaćanje pouzećem$2');
 html=html.replace('</head>',()=>siteSchemaMarkup({checkoutEnabled})+'<link rel="alternate" type="text/plain" href="https://olesence.rs/llms.txt" title="LLM informacije o sajtu"></head>');
 return Buffer.from(html);
}
