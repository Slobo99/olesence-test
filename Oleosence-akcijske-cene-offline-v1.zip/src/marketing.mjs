import {createHash, randomBytes, randomUUID} from 'node:crypto';
import {AuthError} from './customer-auth.mjs';
import {readBody} from './admin.mjs';
import {sanitizeProductImage, MAX_IMAGE_BYTES} from './product-image.mjs';
import {MARKETING_SCOPES} from './marketing-store.mjs';

const uuid = '[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}';
const draftRoute = new RegExp('^/api/marketing/v1/drafts/(' + uuid + ')$');
const ownerDraftRoute = new RegExp('^/admin/api/marketing/drafts/(' + uuid + ')(?:/(approve|publish|reject))?$');
const revokeRoute = new RegExp('^/admin/api/marketing/keys/(' + uuid + ')/revoke$');
const bad = message => {throw new AuthError(400, message);};
async function bodyJSON(req, fields, required = fields) {
  if (req.headers['content-type']?.split(';')[0] !== 'application/json') throw new AuthError(415, 'JSON required.');
  let body;
  try {body = JSON.parse((await readBody(req, 65536)).toString('utf8'));} catch (error) {if (error instanceof AuthError) throw error; bad('Invalid JSON.');}
  if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some(key => !fields.includes(key)) || required.some(key => !Object.hasOwn(body, key))) bad('Unexpected or missing request fields.');
  return body;
}
function page(url, extra = {}) {
  if ([...url.searchParams.keys()].some(k => !['before', 'limit'].includes(k))) bad('Unexpected query parameters.');
  const limit = Number(url.searchParams.get('limit') || 50), before = url.searchParams.get('before') || undefined;
  if (!Number.isInteger(limit) || limit < 1 || limit > 100 || (before && !/^[1-9][0-9]{0,18}$/.test(before))) bad('Invalid pagination.');
  return {...extra, limit, before};
}
function noQuery(url) {if (url.search) bad('Unexpected query parameters.');}
export function createMarketing({enabled = false, store, publicStore, clock = Date.now}) {
  if (enabled && !store) throw Error('Marketing API requires a persistent marketing store.');
  const limits = new Map(); let start = clock(), requests = 0, imageBusy = false;
  function throttle(keyId, mutation = false) {
    const now = clock();
    if (now - start >= 60000) {start = now; requests = 0; limits.clear();}
    if (!keyId) {if (++requests > 600) throw new AuthError(429, 'Too many requests.'); return;}
    const row = limits.get(keyId) || {reads: 0, writes: 0};
    if (!limits.has(keyId) && limits.size >= 1000) throw new AuthError(429, 'Too many clients.');
    limits.set(keyId, row);
    if (++row.reads > 120 || (mutation && ++row.writes > 20)) throw new AuthError(429, 'Too many requests.');
  }
  async function authenticate(req) {
    if (!enabled) throw new AuthError(404, 'Not found.');
    throttle(null);
    // This integration is server-to-server. Browser sessions never authorize it.
    if (req.headers.origin || req.headers['sec-fetch-site']) throw new AuthError(403, 'Server-to-server requests only.');
    const raw = req.headers.authorization;
    if (typeof raw !== 'string' || !/^Bearer omk_[A-Za-z0-9_-]{43}$/.test(raw)) throw new AuthError(401, 'Valid Bearer credential required.');
    const hash = createHash('sha256').update(raw.slice(7)).digest('hex');
    const key = await store.findKeyByHash(hash);
    if (!key || key.revokedAt || !Number.isFinite(Date.parse(key.expiresAt)) || Date.parse(key.expiresAt) <= clock()) throw new AuthError(401, 'Valid Bearer credential required.');
    throttle(key.id, !['GET', 'HEAD'].includes(req.method));
    return {id: 'agent:' + key.id, keyId: key.id, scopes: key.scopes};
  }
  function scope(actor, value) {if (!Array.isArray(actor.scopes) || !actor.scopes.includes(value)) throw new AuthError(403, 'Credential scope does not allow this operation.');}
  function imageResponse(res, image) {
    if (!image) throw new AuthError(404, 'Not found.');
    res.writeHead(200, {'Content-Type': 'image/jpeg', 'Content-Length': image.bytes.length, 'Cache-Control': 'no-store', 'Cross-Origin-Resource-Policy': 'same-origin'});
    return res.end(image.bytes);
  }
  return {
    enabled,
    async handleAgent(req, url, send, res) {
      const actor = await authenticate(req), p = url.pathname;
      if (req.method === 'GET' && p === '/api/marketing/v1/catalog') {scope(actor, 'catalog:read'); noQuery(url); return send(200, await store.listCatalog({stock: false}));}
      if (req.method === 'GET' && p === '/api/marketing/v1/stock') {scope(actor, 'stock:read'); noQuery(url); const {products} = await store.listCatalog({stock: true}); return send(200, {products: products.map(({id, stockQuantity, available}) => ({id, stockQuantity, available}))});}
      if (req.method === 'GET' && p === '/api/marketing/v1/sales') {
        scope(actor, 'sales:read');
        if ([...url.searchParams.keys()].some(k => !['from', 'to'].includes(k)) || url.searchParams.getAll('from').length !== 1 || url.searchParams.getAll('to').length !== 1) bad('An explicit from/to reporting window is required.');
        return send(200, await store.salesSummary({from: url.searchParams.get('from'), to: url.searchParams.get('to')}));
      }
      if (req.method === 'GET' && p === '/api/marketing/v1/drafts') {scope(actor, 'drafts:read'); return send(200, await store.listDrafts(page(url, {keyId: actor.keyId})));}
      if (req.method === 'POST' && p === '/api/marketing/v1/drafts') {scope(actor, 'drafts:write'); noQuery(url); return send(201, await store.createDraft(await bodyJSON(req, ['productId', 'baseContentVersion', 'patch']), actor));}
      const match = p.match(draftRoute);
      if (match && req.method === 'GET') {scope(actor, 'drafts:read'); noQuery(url); return send(200, await store.getDraft(match[1], {keyId: actor.keyId}));}
      if (match && req.method === 'PATCH') {scope(actor, 'drafts:write'); noQuery(url); const {version, ...body} = await bodyJSON(req, ['version', 'baseContentVersion', 'patch']); return send(200, await store.updateDraft(match[1], {...body, revision: version}, actor));}
      if (p === '/api/marketing/v1/media' && req.method === 'POST') {
        scope(actor, 'media:write'); noQuery(url);
        if (imageBusy) throw new AuthError(429, 'Another image is processing.');
        const mime = req.headers['content-type'];
        if (!['image/jpeg', 'image/png'].includes(mime)) throw new AuthError(415, 'Only JPEG or PNG images are accepted.');
        imageBusy = true;
        try {return send(201, await store.stageImage(await sanitizeProductImage(await readBody(req, MAX_IMAGE_BYTES), mime), actor));} finally {imageBusy = false;}
      }
      const media = p.match(/^\/api\/marketing\/v1\/media\/([a-f0-9]{64})\.jpg$/);
      if (media && req.method === 'GET') {scope(actor, 'drafts:read'); noQuery(url); return imageResponse(res, await store.getStagedImage(media[1], {keyId: actor.keyId}));}
      // No publish, pricing, inventory, customer, order or role operation exists here.
      throw new AuthError(404, 'Not found.');
    },
    // Called only after the existing Google owner, exact Origin and CSRF checks.
    async handleOwner(req, url, send, res, owner) {
      if (!enabled) throw new AuthError(404, 'Not found.');
      const p = url.pathname;
      if (p === '/admin/api/marketing/keys' && req.method === 'GET') {noQuery(url); return send(200, await store.listKeys());}
      if (p === '/admin/api/marketing/keys' && req.method === 'POST') {
        noQuery(url);
        const body = await bodyJSON(req, ['label', 'scopes', 'expiresAt']);
        if (typeof body.label !== 'string' || !body.label.trim() || body.label.length > 100 || !Array.isArray(body.scopes) || !body.scopes.length || new Set(body.scopes).size !== body.scopes.length || body.scopes.some(s => !MARKETING_SCOPES.includes(s))) bad('A label and explicit allowed scopes are required.');
        const expires = typeof body.expiresAt === 'string' ? Date.parse(body.expiresAt) : NaN;
        if (!Number.isFinite(expires) || expires <= clock() || expires > clock() + 90 * 86400000) bad('Expiry must be in the future and within 90 days.');
        // Created only following an explicit owner action. Never generated at startup.
        const token = 'omk_' + randomBytes(32).toString('base64url');
        const key = await store.createKey({id: randomUUID(), label: body.label.trim(), scopes: body.scopes, expiresAt: new Date(expires).toISOString(), hash: createHash('sha256').update(token).digest('hex')}, owner);
        return send(201, {key, token});
      }
      const revoke = p.match(revokeRoute);
      if (revoke && req.method === 'POST') {noQuery(url); await bodyJSON(req, []); return send(200, await store.revokeKey(revoke[1], owner));}
      if (p === '/admin/api/marketing/drafts' && req.method === 'GET') return send(200, await store.listDrafts(page(url)));
      if (p === '/admin/api/marketing/audit' && req.method === 'GET') return send(200, await store.listAudit(page(url)));
      const match = p.match(ownerDraftRoute);
      if (match && !match[2] && req.method === 'GET') {noQuery(url); return send(200, await store.getDraft(match[1]));}
      if (match?.[2] && req.method === 'POST') {noQuery(url); const {version} = await bodyJSON(req, ['version']); return send(200, await store[match[2] + 'Draft'](match[1], version, owner));}
      const media = p.match(/^\/admin\/api\/marketing\/media\/([a-f0-9]{64})\.jpg$/);
      if (media && req.method === 'GET') {noQuery(url); return imageResponse(res, await store.getStagedImage(media[1]) || await publicStore.getImage(media[1]));}
      throw new AuthError(404, 'Not found.');
    },
    close() {limits.clear();}
  };
}
