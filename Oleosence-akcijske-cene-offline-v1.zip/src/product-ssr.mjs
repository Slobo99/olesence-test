import {activeSale} from './sale.mjs';
import {escapeHtml, breadcrumbStructuredData, siteSchemaMarkup} from './seo.mjs';
import {productMarkup, productStructuredData, safeJson} from '../public/product-view.js';
// Match the existing public API availability rule without leaking stock counts/revisions.
export function publicProduct({stockQuantity,version,updatedAt,published,stockCode,stockIdent,sourceIdent,sale,...product},persistent=true,now=Date.now()){
 const active=activeSale({...product,published,sale},now);
 return {...product,...(active?{priceMinor:active.priceMinor,sale:{previousMinor:active.previousMinor,percent:active.percent,startAt:active.startAt,endAt:active.endAt}}:{}),...(persistent?{available:product.available===true&&stockQuantity>0}:{})};
}
export function renderProductPage(bytes,product,products,{checkoutEnabled=false,guestEnabled=false}={}){
 let main=productMarkup(product,products);
 if(checkoutEnabled){main=main.replace('<span data-checkout-status>Poručivanje nije omogućeno</span>','<span data-checkout-status>Plaćanje pouzećem</span>').replace('<p class="microcopy" data-checkout-note>Poručivanje trenutno nije dostupno. Dostava: 300 din po paketu; besplatna za vrednost proizvoda od 3.500 din.</p>','<p class="microcopy" data-checkout-note>Dostava: 300 din po porudžbini; besplatna za vrednost proizvoda od 3.500 din. Konačan iznos proveravate pre potvrde.</p>');}
 // Without JS the information remains readable; cart/checkout still require JS.
 main+='<noscript><p class="microcopy">Za korpu i poručivanje uključite JavaScript.</p></noscript>';
 let html=bytes.toString('utf8').replace('<main id="main" tabindex="-1"></main>',()=>'<main id="main" tabindex="-1" data-server-rendered="true">'+main+'</main>');
 html=html.replace('<html ',()=>`<html data-public-product="/proizvod/${escapeHtml(product.id)}" `);
 // Rebuild the collection navigation from current public products, including new entries.
 html=html.replace(/<div><strong>Istražite kolekciju<\/strong>[\s\S]*?<\/div>/,()=>'<div><strong>Istražite kolekciju</strong>'+products.map(p=>`<a href="/proizvod/${escapeHtml(p.id)}">${escapeHtml(p.name)}</a>`).join('')+'</div>');
 const json=safeJson(productStructuredData(product,{offers:checkoutEnabled}));
 html=html.replace('</head>',()=>`<script type="application/ld+json" id="product-schema" data-offers="${checkoutEnabled}">${json}</script><script type="application/ld+json" id="breadcrumb-schema">${safeJson(breadcrumbStructuredData(product))}</script>${siteSchemaMarkup({checkoutEnabled})}</head>`);
 if(checkoutEnabled){html=html.replace(/(<p data-checkout-footer>)[\s\S]*?(<\/p>)/,(_,a,b)=>a+(guestEnabled?'Porudžbine bez registracije, uz plaćanje pouzećem. Google prijava je opciona.':'Porudžbine sa plaćanjem pouzećem. Google prijava koristi osnovni profil i imejl.')+b).replace(/(<span data-checkout-label>)[\s\S]*?(<\/span>)/,'$1Plaćanje pouzećem$2');}
 return Buffer.from(html);
}
