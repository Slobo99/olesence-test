// All money is integer RSD minor units. Only the live sale is disclosed publicly.
export const MAX_SALE_MS=31*86400000;
const local=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Belgrade',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
const localMinute=t=>local.format(t).replace(' ','T');
const price=x=>Number.isSafeInteger(x)&&x>0&&x<=100000000;
export function belgradeTime(value){
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value))throw Error('Unesite datum i vreme isteka (Beograd).');
 const pretend=Date.parse(value+'Z');
 if(!Number.isFinite(pretend))throw Error('Neispravan datum isteka.');
 const matches=[1,2].map(h=>pretend-h*3600000).filter(t=>localMinute(t)===value);
 if(matches.length!==1)throw Error('Zbog pomeranja sata izaberite drugo vreme isteka.');
 return matches[0];
}
export function buildSale(input,{now,regularMinor}){
 if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).length!==4||!['priceMinor','previousMinor','endLocal','historyVerified'].every(k=>Object.hasOwn(input,k)))throw Error('Neispravna podešavanja akcije.');
 if(!price(input.priceMinor)||!price(input.previousMinor)||!price(regularMinor)||input.priceMinor>=input.previousMinor||input.previousMinor>regularMinor)throw Error('Akcijska cena mora biti niža od prethodne, a prethodna ne sme biti viša od redovne.');
 if(input.historyVerified!==true)throw Error('Potvrdite prethodnu cenu iz istorije ponude.');
 const end=belgradeTime(input.endLocal);
 const day=t=>Date.parse(localMinute(t).slice(0,10)+'T00:00:00Z');
 if(end<=now||end-now>MAX_SALE_MS||day(end-1)-day(now)>=MAX_SALE_MS)throw Error('Akcija mora isteći u budućnosti i ne sme trajati duže od 31 dan.');
 return {priceMinor:input.priceMinor,previousMinor:input.previousMinor,startAt:new Date(now).toISOString(),endAt:new Date(end).toISOString(),historyVerified:true};
}
export function activeSale(product,now=Date.now()){
 const s=product.sale;
 if(!s||s.historyVerified!==true||!price(s.priceMinor)||!price(s.previousMinor)||s.priceMinor>=s.previousMinor||s.previousMinor>product.priceMinor||product.published===false)return null;
 const start=Date.parse(s.startAt),end=Date.parse(s.endAt);
 if(!(start<=now&&now<end))return null;
 return {priceMinor:s.priceMinor,previousMinor:s.previousMinor,startAt:new Date(start).toISOString(),endAt:new Date(end).toISOString(),percent:Math.floor((s.previousMinor-s.priceMinor)*100/s.previousMinor)};
}
export const effectivePrice=(product,now)=>activeSale(product,now)?.priceMinor??product.priceMinor;
