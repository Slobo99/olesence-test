import {productImage, safeJson} from '../public/product-view.js';
import {shippingPolicy, formatMoney} from '../public/catalog.js';
// Only this production origin may be indexed. Preview origins remain noindex.
export const canonicalOrigin = 'https://olesence.rs';
export const publicProductIds = Object.freeze(['crni-kim', 'divlji-origano', 'cetiri-lopova']);
export const isPublicProduct = product => product?.published !== false && typeof product?.id === 'string' && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(product.id) && product.id.length <= 100;
export const homeSeo = Object.freeze({title: 'olésence — Biljna i eterična ulja', description: 'Olesence kolekcija biljnih i eteričnih ulja. Upoznajte proizvode, njihov sastav i informacije o upotrebi.'});
export const publicRobots = `User-agent: *
Allow: /
Disallow: /admin
Disallow: /api/
Allow: /api/catalog$
Disallow: /auth/
Disallow: /orders

Sitemap: ${canonicalOrigin}/sitemap.xml
`;
export const escapeHtml = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
export function productSeo(product) {
 return {priceMinor: product.priceMinor, image: productImage(product), imageAlt: `${product.name}, originalna fotografija bočice i pakovanja`, ...(productImage(product).startsWith('/assets/')?{imageWidth:2048,imageHeight:2048}:{}), title: product.seoTitle || `${product.name} — olésence`, description: product.seoDescription || `${product.name} iz Olesence kolekcije. Pogledajte sastav, informacije o upotrebi i upozorenja na stranici proizvoda.`};
}
export function renderSeo(bytes, path, metadata, indexable) {
 let html = bytes.toString('utf8');
 html = html.replace(/<title>[^<]*<\/title>/, () => `<title>${escapeHtml(metadata.title)}</title>`)
  .replace(/<meta name="description" content="[^"]*">/, () => `<meta name="description" content="${escapeHtml(metadata.description)}">`)
  .replace(/<meta name="robots" content="[^"]*">/, `<meta name="robots" content="${indexable ? 'index,follow' : 'noindex,nofollow'}">`)
  .replace(/<link rel="canonical" href="[^"]*">/g, '')
  .replace('</head>', () => `<link rel="canonical" href="${canonicalOrigin}${escapeHtml(path)}">${socialMetadata(path,metadata)}</head>`);
 return Buffer.from(html);
}
export function socialMetadata(path, metadata) {
 const image=metadata.image || '/assets/olesence-og.12d42915b06a.jpg';
 const imageUrl=new URL(image,canonicalOrigin).href;
 const fields={'og:type':path==='/'?'website':'product','og:site_name':'Olesence','og:locale':'sr_RS','og:title':metadata.title,'og:description':metadata.description,'og:url':canonicalOrigin+path,'og:image':imageUrl,'og:image:alt':metadata.imageAlt||'Olesence kolekcija: ulje divljeg origana, ulje 4 lopova i ulje crnog kima.'};
 const width=metadata.imageWidth||(path==='/'?1200:null),height=metadata.imageHeight||(path==='/'?630:null);
 if(width&&height){fields['og:image:width']=width;fields['og:image:height']=height;}
 if(path!=='/'&&Number.isSafeInteger(metadata.priceMinor)&&metadata.priceMinor>=0){fields['product:price:amount']=(metadata.priceMinor/100).toFixed(2);fields['product:price:currency']='RSD';}
 return Object.entries(fields).map(([key,value])=>`<meta property="${key}" content="${escapeHtml(value)}">`).join('')+Object.entries({'twitter:card':'summary_large_image','twitter:title':metadata.title,'twitter:description':metadata.description,'twitter:image':imageUrl,'twitter:image:alt':fields['og:image:alt']}).map(([key,value])=>`<meta name="${key}" content="${escapeHtml(value)}">`).join('');
}
export function siteStructuredData({checkoutEnabled=false}={}) {
 const organization={'@type':'Organization','@id':canonicalOrigin+'/#organization',name:'Olesence',url:canonicalOrigin+'/',brand:{'@id':canonicalOrigin+'/#brand'}};
 if(checkoutEnabled)organization.hasShippingService={'@type':'ShippingService','@id':canonicalOrigin+'/#shipping',name:'Dostava u Srbiji',shippingConditions:[
  {'@type':'ShippingConditions',shippingDestination:{'@type':'DefinedRegion',addressCountry:'RS'},orderValue:{'@type':'MonetaryAmount',minValue:0,maxValue:(shippingPolicy.freeFromMinor-1)/100,currency:shippingPolicy.currency},shippingRate:{'@type':'MonetaryAmount',value:shippingPolicy.perPackageMinor/100,currency:shippingPolicy.currency}},
  {'@type':'ShippingConditions',shippingDestination:{'@type':'DefinedRegion',addressCountry:'RS'},orderValue:{'@type':'MonetaryAmount',minValue:shippingPolicy.freeFromMinor/100,currency:shippingPolicy.currency},shippingRate:{'@type':'MonetaryAmount',value:0,currency:shippingPolicy.currency}}
 ]};
 return {'@context':'https://schema.org','@graph':[organization,{'@type':'Brand','@id':canonicalOrigin+'/#brand',name:'olésence',url:canonicalOrigin+'/'},{'@type':'WebSite','@id':canonicalOrigin+'/#website',name:'Olesence',url:canonicalOrigin+'/',inLanguage:'sr-Latn',publisher:{'@id':canonicalOrigin+'/#organization'}}]};
}
export function siteSchemaMarkup(options){return `<script type="application/ld+json" id="site-schema">${safeJson(siteStructuredData(options))}</script>`;}
export function breadcrumbStructuredData(product) {
 return {'@context':'https://schema.org','@type':'BreadcrumbList',itemListElement:[['Početna',canonicalOrigin+'/'],['Kolekcija',canonicalOrigin+'/#kolekcija'],[product.name,canonicalOrigin+'/proizvod/'+encodeURIComponent(product.id)]].map(([name,item],index)=>({'@type':'ListItem',position:index+1,name,item}))};
}
// Dates are persisted catalog modification timestamps, never the request/deploy clock.
function lastModified(value){if(!(value instanceof Date)&&(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}(?:T|$)/.test(value)))return null;const date=new Date(value);return Number.isFinite(date.getTime())?date.toISOString():null;}
export function sitemapXml(products) {
 const unique=[...new Map(products.filter(isPublicProduct).map(product=>[product.id,product])).values()];
 const dates=unique.map(product=>lastModified(product.updatedAt)).filter(Boolean).sort();
 const entries=[{path:'/',date:dates.at(-1)},...unique.map(product=>({path:'/proizvod/'+product.id,date:lastModified(product.updatedAt)}))];
 return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+entries.map(({path,date})=>`  <url><loc>${canonicalOrigin}${path}</loc>${date?`<lastmod>${date}</lastmod>`:''}</url>`).join('\n')+'\n</urlset>\n';
}
export function llmsText(products,{checkoutEnabled=false}={}){
 const clean=value=>String(value??'').replace(/[\r\n\[\]<>]/g,' ').trim();
 const lines=['# Olesence','','Olesence (https://olesence.rs/) je prodavnica biljnih i eteričnih ulja. Jezik sajta je srpski, latinica.'];
 if(checkoutEnabled)lines.push(`Porudžbine se primaju uz plaćanje pouzećem. Dostava kurirskom službom u Srbiji iznosi ${formatMoney(shippingPolicy.perPackageMinor)} po porudžbini, a besplatna je za vrednost proizvoda od ${formatMoney(shippingPolicy.freeFromMinor)}.`);
 lines.push('','## Proizvodi','');
 for(const p of products.filter(isPublicProduct))lines.push(`- ${clean(p.name)} (${canonicalOrigin}/proizvod/${p.id})${Number.isSafeInteger(p.priceMinor)&&p.priceMinor>=0?`: ${formatMoney(p.priceMinor)}`:''}.`);
 lines.push('','Opisi, sastav, način primene i upozorenja navedeni su na stranici svakog proizvoda.','','## Linkovi','',`- Početna: ${canonicalOrigin}/`,`- Kolekcija: ${canonicalOrigin}/#kolekcija`,`- Korisne informacije: ${canonicalOrigin}/#pitanja`,`- Mapa sajta: ${canonicalOrigin}/sitemap.xml`,'');
 return lines.join('\n');
}
