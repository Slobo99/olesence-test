import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';

const html=await readFile(new URL('../public/account.html',import.meta.url),'utf8');
const source=await readFile(new URL('../public/account.js',import.meta.url),'utf8');
const styles=(await Promise.all(['test-shop.css','checkout.css'].map(file=>readFile(new URL('../public/'+file,import.meta.url),'utf8')))).join('\n');
const response=(data,status=200)=>({ok:status>=200&&status<300,status,json:async()=>data});
const customer={name:'Customer',email:'admin@example.test',role:'customer'};
const adminSession={user:{email:customer.email,role:'admin'}};
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
const settle=async()=>{await new Promise(r=>setImmediate(r));};
const until=async(predicate)=>{for(let i=0;i<100;i++){if(predicate())return;await settle();}assert.fail('Condition timed out');};

async function fixture(t){
 const dom=new JSDOM(html,{url:'https://shop.example.test/account',runScripts:'outside-only',pretendToBeVisual:true});
 const w=dom.window;await new Promise(r=>w.addEventListener('load',r,{once:true}));t.after(()=>w.close());
 const data={auth:{enabled:true,user:customer,csrfToken:'customer-csrf'},admin:response(adminSession),calls:[],adminHandler:null,logoutHandler:null};
 const intervals=[];
 w.setInterval=(callback,delay)=>{intervals.push({callback,delay});return intervals.length;};
 w.fetch=async(path,options={})=>{
  data.calls.push({path,options});
  if(path==='/auth/session')return response(data.auth);
  if(path==='/admin/api/session')return data.adminHandler?data.adminHandler():data.admin;
  if(path==='/api/checkout/session')return response(data.checkout||{enabled:true,user:data.auth.user,customerReady:true});
  if(path==='/auth/logout')return data.logoutHandler?data.logoutHandler():response({signedOut:true});
  throw Error('Unexpected request: '+path);
 };
 vm.runInContext(source,dom.getInternalVMContext());
 const $=selector=>w.document.querySelector(selector);
 const show=()=>w.dispatchEvent(new w.PageTransitionEvent('pageshow',{persisted:true}));
 const hide=()=>w.dispatchEvent(new w.PageTransitionEvent('pagehide',{persisted:true}));
 return {w,data,$,show,hide,intervals,link:$('.account-admin-link')};
}

test('account DOM: admin link is hidden before JavaScript and session explanation is absent',async t=>{
 const {link,$}=await fixture(t);
 assert.equal(link.hidden,true);
 assert.equal(link.querySelector('a').textContent,'Administracija sajta');
 assert.equal(link.querySelector('a').getAttribute('href'),'/admin');
 assert.equal($('.account-session-details'),null);
 assert.doesNotMatch(html,/O prijavi i čuvanju naloga/);
 for(const selector of ['#google-privacy','#auth-status','#google-login','#logout','#checkout-guest','#checkout-account'])assert.ok($(selector));
});

test('account DOM: anonymous and customer sessions never expose administration based on email or customer-session role',async t=>{
 for(const [user,status]of [[null,401],[customer,403],[{...customer,role:'admin'},403]]){
  const {data,show,link}=await fixture(t);data.auth.user=user;data.admin=response({},status);
  show();await until(()=>data.calls.some(call=>call.path==='/admin/api/session'));await settle();
  assert.equal(link.hidden,true);
 }
});

test('account DOM: Google and guest choices share neutral styling without optional or promotional copy',async t=>{
 const {w,data,$,show}=await fixture(t);
 data.auth.user=null;data.admin=response({},401);
 data.checkout={enabled:true,user:null,guest:true,guestId:'00000000-0000-4000-8000-000000000010',csrfToken:'guest-csrf',customerReady:true};
 const style=w.document.createElement('style');style.textContent=styles;w.document.head.append(style);
 show();await until(()=>!$('#checkout-guest').hidden);
 assert.equal($('#google-login').disabled,false);
 assert.equal($('#google-login').textContent,'Google prijava');
 assert.equal($('#google-login').getAttribute('aria-label'),'Prijavite se Google nalogom');
 assert.equal($('#continue-guest').textContent,'Nastavi bez naloga');
 assert.equal($('#continue-guest').closest('.account-login-actions'),$('#google-login').parentElement);
 assert.equal(w.document.querySelectorAll('.account-auth-choice').length,2);
 assert.equal($('.guest-checkout-choice, .account-login-actions h2'),null);
 assert.doesNotMatch(w.document.body.textContent,/opciono|opciona|Poručite bez registracije|Unesite podatke za dostavu/);
 const google=w.getComputedStyle($('#google-login')),guest=w.getComputedStyle($('#continue-guest'));
 for(const property of ['backgroundColor','color','borderColor','fontSize','lineHeight','minHeight','padding','width'])assert.equal(google[property],guest[property],property);
 assert.equal(w.getComputedStyle($('.account-login-actions')).display,'grid');
});

test('account DOM: only the server admin session role enables the link',async t=>{
 const {data,show,link}=await fixture(t);show();await until(()=>!link.hidden);
 assert.equal(data.auth.user.role,'customer');
 const call=data.calls.find(call=>call.path==='/admin/api/session');
 assert.equal(call.options.method,'GET');
 assert.equal(call.options.credentials,'same-origin');
 assert.equal(call.options.cache,'no-store');
 for(const body of [{},null,{role:'admin'},{user:{email:customer.email}},{user:{role:'customer'}}]){
  data.admin=response(body);show();assert.equal(link.hidden,true);await settle();assert.equal(link.hidden,true);
 }
});

test('account DOM: unavailable, forbidden, malformed and failed admin checks all fail closed',async t=>{
 for(const result of [response({},401),response({},403),response({},404),response({},503),{ok:true,json:async()=>{throw Error('Malformed JSON');}}]){
  const {data,show,link}=await fixture(t);show();await until(()=>!link.hidden);
  data.admin=result;show();assert.equal(link.hidden,true);await settle();assert.equal(link.hidden,true);
 }
 const {data,show,link}=await fixture(t);show();await until(()=>!link.hidden);
 data.adminHandler=()=>{throw Error('Network failed');};show();assert.equal(link.hidden,true);await settle();assert.equal(link.hidden,true);
});

test('account DOM: pending admin session cannot reopen the link after pagehide',async t=>{
 const {data,show,hide,link}=await fixture(t);const pending=deferred();data.adminHandler=()=>pending.promise;
 show();await until(()=>data.calls.some(call=>call.path==='/admin/api/session'));
 hide();assert.equal(link.hidden,true);pending.resolve(response(adminSession));await settle();assert.equal(link.hidden,true);
});

test('account DOM: stale admin success cannot override a newer anonymous refresh',async t=>{
 const {data,show,link}=await fixture(t);const pending=deferred();data.adminHandler=()=>pending.promise;
 show();await until(()=>data.calls.some(call=>call.path==='/admin/api/session'));
 data.auth.user=null;data.adminHandler=null;data.admin=response({},401);show();await settle();
 pending.resolve(response(adminSession));await settle();assert.equal(link.hidden,true);
});

test('account DOM: stale admin failure cannot hide a newer verified administrator',async t=>{
 const {data,show,link}=await fixture(t);const pending=deferred();data.adminHandler=()=>pending.promise;
 show();await until(()=>data.calls.some(call=>call.path==='/admin/api/session'));
 data.adminHandler=null;show();await until(()=>!link.hidden);
 pending.resolve(response({},401));await settle();assert.equal(link.hidden,false);
});

test('account DOM: logout hides immediately and a failed logout stays hidden',async t=>{
 const {data,show,link,$}=await fixture(t);show();await until(()=>!link.hidden);
 const pending=deferred();data.logoutHandler=()=>pending.promise;
 $('#logout').click();assert.equal(link.hidden,true);
 const call=data.calls.find(call=>call.path==='/auth/logout');assert.equal(call.options.headers['X-CSRF-Token'],'customer-csrf');
 pending.resolve(response({},503));await until(()=>$('#auth-status').textContent.includes('Odjava nije potvrđena'));
 assert.equal(link.hidden,true);
});

test('account DOM: logout invalidates an in-flight admin check and refreshes the signed-out session',async t=>{
 const {data,show,link,$}=await fixture(t);const pending=deferred();data.adminHandler=()=>pending.promise;
 show();await until(()=>data.calls.some(call=>call.path==='/admin/api/session'));
 const logout=deferred();data.logoutHandler=()=>logout.promise;
 $('#logout').click();assert.equal(link.hidden,true);
 pending.resolve(response(adminSession));await settle();assert.equal(link.hidden,true);
 data.auth.user=null;data.adminHandler=null;data.admin=response({},401);logout.resolve(response({signedOut:true}));
 await until(()=>$('#logout').hidden);await settle();assert.equal(link.hidden,true);
 assert.equal($('#google-login').hidden,false);
});

test('account DOM: Back/pageshow hides a previous admin link until a fresh successful check',async t=>{
 const {data,show,hide,link}=await fixture(t);show();await until(()=>!link.hidden);hide();assert.equal(link.hidden,true);
 const pending=deferred();data.adminHandler=()=>pending.promise;show();assert.equal(link.hidden,true);
 await until(()=>data.calls.filter(call=>call.path==='/admin/api/session').length===2);
 assert.equal(link.hidden,true);pending.resolve(response(adminSession));await until(()=>!link.hidden);
});

test('account DOM: periodic session recheck hides immediately and expired authorization stays hidden',async t=>{
 const {data,show,link,intervals}=await fixture(t);show();await until(()=>!link.hidden);
 assert.equal(intervals.length,1);assert.equal(intervals[0].delay,60000);
 const pending=deferred();data.adminHandler=()=>pending.promise;intervals[0].callback();assert.equal(link.hidden,true);
 pending.resolve(response({},401));await settle();assert.equal(link.hidden,true);
});

test('account DOM: returning to a tab rechecks authorization and ignores a late background response',async t=>{
 const {w,data,show,link,intervals}=await fixture(t);show();await until(()=>!link.hidden);
 const pending=deferred();data.adminHandler=()=>pending.promise;intervals[0].callback();
 Object.defineProperty(w.document,'hidden',{configurable:true,value:true});w.document.dispatchEvent(new w.Event('visibilitychange'));
 pending.resolve(response(adminSession));await settle();assert.equal(link.hidden,true);
 data.adminHandler=null;data.admin=response({},401);Object.defineProperty(w.document,'hidden',{configurable:true,value:false});
 w.document.dispatchEvent(new w.Event('visibilitychange'));assert.equal(link.hidden,true);await settle();assert.equal(link.hidden,true);
});
