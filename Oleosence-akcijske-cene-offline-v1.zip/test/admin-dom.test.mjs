import {descriptionMarkup} from '../public/product-view.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
import {products as catalog} from '../public/catalog.js';
const html=await readFile(new URL('../public/admin.html',import.meta.url),'utf8');
const source=(await readFile(new URL('../public/admin.js',import.meta.url),'utf8')).replaceAll('export function ','function ').replace(/^import .*;\n/gm,'');
const response=(json,status=200)=>({ok:status>=200&&status<300,status,json:async()=>json});
const until=async(predicate,message='Condition timed out')=>{for(let i=0;i<200;i++){if(predicate())return;await new Promise(r=>setTimeout(r,5));}assert.fail(message);};
async function fixture(t){
 const dom=new JSDOM(html,{url:'https://admin.example.test/admin',runScripts:'outside-only'});const w=dom.window;await new Promise(r=>w.addEventListener('load',r,{once:true}));
 const data={products:catalog.map(p=>({...p,stockQuantity:null,available:false,version:1})),patches:[],gets:[],deny:false,delay:null,conflict:false,imports:[],previewRows:[{id:'crni-kim',name:'Ulje crnog kima',oldQuantity:null,stockQuantity:10,version:1,sourceIdent:'ORIGINAL-SKU',warehouseQuantities:[{warehouse:'Magacin Bio Prodavnica B2C',quantity:10}]}]};
 w.confirm=()=>true;w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(value=''){this.returnValue=value;this.open=false;this.dispatchEvent(new w.Event('close'));};
 w.fetch=async(path,options={})=>{
  if(data.deny)return response({},401);
  if(path==='/admin/api/stock/preview'){data.imports.push({path,options});return response({previewToken:'preview-token',rows:data.previewRows,warnings:data.previewWarnings||[],expiresAt:Date.now()+300000});}
  if(path==='/admin/api/stock/apply'){data.imports.push({path,options});return response({products:data.products});}
  if(path==='/admin/api/session'&&data.sessionDelay)return data.sessionDelay;
  if(path==='/admin/api/session')return response({user:{email:data.sessionEmail||'admin@example.test'},csrfToken:'test-csrf',capabilities:{customers:!!data.customersEnabled,manageRoles:data.manageRoles}});
  if(path==='/admin/api/products'&&options.method==='POST'){data.creates??=[];data.creates.push({body:JSON.parse(options.body),headers:options.headers});if(data.createDelay)return data.createDelay;if(data.createError)throw Error('Network interrupted');if(data.createStatus)return response({},data.createStatus);const p={...JSON.parse(options.body),version:1,published:false,available:false,stockQuantity:0};data.products.push(p);return response(p,201);}
  if(options.method==='PATCH'&&/^\/admin\/api\/customers\/[^/]+\/role$/.test(path)){
   const body=JSON.parse(options.body);data.patches.push({path,body,headers:options.headers});if(data.patchDelay)return data.patchDelay;if(data.roleError)return response({},data.roleError);
   const id=decodeURIComponent(path.split('/').at(-2)),customer=data.customerRows.find(row=>row.id===id);if(!customer)return response({},404);if(customer.roleVersion!==body.version)return response({},409);
   const updated={...customer,role:body.role,roleVersion:customer.roleVersion+1,roleManagedBy:body.role==='admin'?'delegated':null};data.customerRows=data.customerRows.map(row=>row.id===id?updated:row);return response(updated);
  }
  if(options.method==='PATCH'){const body=JSON.parse(options.body);data.patches.push({path,body,headers:options.headers});if(data.patchDelay)return data.patchDelay;if(data.conflict)return response({},409);data.products=data.products.map(p=>p.id===path.split('/').at(-1)?{...p,...body,...(body.declaration?{declaration:{...p.declaration,...body.declaration}}:{}),version:p.version+1}:p);return response({product:data.products[0]});}
  data.gets.push(path);if(data.delay){const pending=data.delay;data.delay=null;return pending;}
  if(path.startsWith('/admin/api/products'))return response({products:data.products});
  if(path.startsWith('/admin/api/customers'))return response({customers:data.customerRows||[],nextCursor:null});
  if(path.startsWith('/admin/api/orders'))return response({orders:data.orderRows||[],nextCursor:null});
  if(path.startsWith('/admin/api/audit'))return response({entries:[],nextCursor:null});
  throw Error(`Unexpected request: ${path}`);
 };
 w.descriptionMarkup=descriptionMarkup;vm.runInContext(source,dom.getInternalVMContext());w.dispatchEvent(new w.Event('pageshow'));
 await until(()=>w.document.querySelectorAll('.product-card').length===3);
 t.after(()=>w.close());
 const $=selector=>w.document.querySelector(selector);
 const edit=(selector,value)=>{const input=$(selector);input.value=value;input.dispatchEvent(new w.Event('input',{bubbles:true}));};
 const submit=index=>w.document.querySelectorAll('.product-card')[index].dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
 const close=value=>$('#confirm').close(value);
 return {w,data,$,edit,submit,close};
}
test('DOM: cancel does not save; repeated clicks cannot submit twice; success waits for server',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);
 edit('.product-card [name="price"]','1290,45');submit(0);assert.equal($('#confirm').open,true);assert.equal($('.product-card button[type="submit"]').disabled,true);submit(0);assert.equal(data.patches.length,0);close('cancel');await until(()=>!$('.product-card button[type="submit"]').disabled);assert.equal(data.patches.length,0);
 submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(data.patches.length,1);assert.equal(data.patches[0].body.priceMinor,129045);assert.equal(data.patches[0].headers['X-CSRF-Token'],'test-csrf');assert.equal($('.product-card [name="price"]').value,'1290,45');
});
test('DOM: saving one product preserves another draft and its original version',async t=>{
 const {data,$,edit,submit,close,w}=await fixture(t);
 edit('.product-card:nth-child(1) [name="name"]','Prvi novi naziv');edit('.product-card:nth-child(2) [name="name"]','Drugi nesačuvan naziv');
 data.products[1]={...data.products[1],version:8,name:'Novije serversko ime'};
 submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal($('.product-card:nth-child(2) [name="name"]').value,'Drugi nesačuvan naziv');assert.match($('.product-card:nth-child(2) header').textContent,/Verzija 1/);
 const unload=new w.Event('beforeunload',{cancelable:true});w.dispatchEvent(unload);assert.equal(unload.defaultPrevented,true);
 data.conflict=true;submit(1);close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal(data.patches[1].body.version,1);assert.equal($('.product-card:nth-child(2) [name="name"]').value,'Drugi nesačuvan naziv');
});
test('DOM: expired session immediately removes products, identity, drafts and open confirmation',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);edit('.product-card [name="name"]','Privatni nacrt');submit(0);data.deny=true;close('save');await until(()=>!$('#access').hidden);assert.equal($('#workspace').hidden,true);assert.equal($('#identity').textContent,'');assert.equal($('#content').childElementCount,0);assert.equal($('#confirm').open,false);
 data.deny=false;$('#retry').click();await until(()=>$('.product-card'));assert.notEqual($('.product-card [name="name"]').value,'Privatni nacrt');
});
test('DOM: stale refresh cannot replace newer navigation or clear a newer valid session',async t=>{
 const {data,$}=await fixture(t);let resolve;data.delay=new Promise(r=>resolve=r);$('#refresh').click();$('[data-view="orders"]').click();await until(()=>$('#content').textContent.includes('Još nema porudžbina'));resolve(response({},401));await new Promise(r=>setTimeout(r,20));assert.equal($('#workspace').hidden,false);assert.equal($('#identity').textContent,'admin@example.test');assert.match($('#content').textContent,/Još nema porudžbina/);
});
test('DOM: pageshow revalidates session and clears previous edits, 409 never shows success',async t=>{
 const {data,$,w,edit,submit,close}=await fixture(t);edit('.product-card [name="name"]','Nesačuvano');data.conflict=true;submit(0);close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.doesNotMatch($('#status').textContent,/uspešno/);w.dispatchEvent(new w.Event('pageshow'));await until(()=>$('.product-card'));assert.notEqual($('.product-card [name="name"]').value,'Nesačuvano');assert.equal($('#workspace').hidden,false);
});
test('DOM: API-supplied markup remains text content',async t=>{
 const {data,$}=await fixture(t);data.products[0]={...data.products[0],name:'<img src=x onerror=alert(1)>',declaration:{warnings:'<script>alert(1)</script>'}};$('#refresh').click();await until(()=>$('.product-card h3')?.textContent.includes('<img'));assert.equal($('#content img[src="x"], #content [onerror]'),null);assert.equal($('#content script'),null);assert.equal($('.product-card [name=warnings]').value,'<script>alert(1)</script>');
});
test('DOM: Escape after an earlier save cannot reuse the previous save decision',async t=>{
 const {data,$,w,edit,submit,close}=await fixture(t);edit('.product-card [name="price"]','200');submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(data.patches.length,1);
 edit('.product-card [name="price"]','300');submit(0);assert.equal($('#confirm').returnValue,'cancel');const dialog=$('#confirm');dialog.open=false;dialog.dispatchEvent(new w.Event('close'));await until(()=>!$('.product-card button[type="submit"]').disabled);assert.equal(data.patches.length,1);
});

test('DOM: pending save stays disabled and does not report optimistic success',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);let resolve;data.patchDelay=new Promise(r=>resolve=r);edit('.product-card [name="price"]','456');submit(0);close('save');await until(()=>data.patches.length===1);assert.equal($('.product-card button[type="submit"]').disabled,true);assert.doesNotMatch($('#status').textContent,/uspešno/);submit(0);assert.equal(data.patches.length,1);resolve(response({},409));await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal($('.product-card button[type="submit"]').disabled,false);
});

test('DOM: original XLS preview sends legacy Excel type and shows identifier and only B2C quantity',async t=>{
 const {data,$,w,close}=await fixture(t);const input=$('input[type="file"]');assert.match(input.accept,/\.xls,/);const file=new w.File(['mock original XLS'],'Dnevni izveštaj.XLS',{type:'application/vnd.ms-excel'});Object.defineProperty(input,'files',{configurable:true,value:[file]});input.dispatchEvent(new w.Event('change'));$('.import-panel button').click();await until(()=>data.imports.length===1&&!$('.import-panel button').disabled);assert.equal(data.imports[0].options.headers['Content-Type'],'application/vnd.ms-excel');assert.equal(data.imports[0].options.body,file);assert.match($('.import-panel').textContent,/ORIGINAL-SKU/);assert.match($('.import-panel').textContent,/Magacin Bio Prodavnica B2C: 10 kom/);assert.doesNotMatch($('.import-panel').textContent,/Skladište upakovanih proizvoda: 13 kom/);assert.match($('.import-panel').textContent,/→ 10 kom/);assert.match($('.import-panel').textContent,/cene iz izveštaja se ne uvoze/);$('.import-panel button:last-child').click();assert.equal($('#confirm').open,true);close('cancel');await until(()=>!$('.import-panel button').disabled);assert.equal(data.imports.length,1);
 input.dispatchEvent(new w.Event('change'));assert.doesNotMatch($('.import-panel').textContent,/ORIGINAL-SKU/);
});
test('DOM: optional XLSX template preserves the modern Excel content type',async t=>{
 const {data,$,w}=await fixture(t);const input=$('input[type="file"]');Object.defineProperty(input,'files',{value:[new w.File(['mock XLSX'],'stock.xlsx')]});input.dispatchEvent(new w.Event('change'));$('.import-panel button').click();await until(()=>data.imports.length===1&&!$('.import-panel button').disabled);assert.equal(data.imports[0].options.headers['Content-Type'],'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
});

test('DOM: import preview shows server warnings safely and never invents missing warehouse zeros',async t=>{
 const {data,$,w}=await fixture(t);data.previewWarnings=['Drugi magacin je isključen iz uvoza.','<img src=x onerror=alert(1)>'];data.previewRows[0].warehouseQuantities=[{warehouse:'Magacin Bio Prodavnica B2C',quantity:10}];data.previewRows[0].stockQuantity=10;const input=$('input[type="file"]');Object.defineProperty(input,'files',{value:[new w.File(['mock XLS'],'stock.xls')]});input.dispatchEvent(new w.Event('change'));$('.import-panel button').click();await until(()=>data.imports.length===1&&!$('.import-panel button').disabled);assert.match($('.import-panel').textContent,/Uvoze se samo prijavljeni redovi iz B2C magacina/);assert.match($('.import-panel').textContent,/Proizvodi kojih nema u B2C delu datoteke ostaju nepromenjeni/);assert.match($('.import-panel').textContent,/odsustvo reda ne znači potvrđenu nulu/);assert.match($('.import-panel .notice').textContent,/Drugi magacin je isključen iz uvoza/);assert.match($('.import-panel .notice').textContent,/<img/);assert.equal($('.import-panel img'),null);assert.doesNotMatch($('.import-panel').textContent,/Skladište upakovanih proizvoda: 0/);
});

test('DOM: customer directory is capability gated, literal text, and cleared on session expiry',async t=>{
 const {data,$,w}=await fixture(t);assert.equal($('#customers-tab').hidden,true);
 data.customersEnabled=true;data.customerRows=[{id:'customer-id',name:'<img src=x onerror=alert(1)>',email:'user@example.test',lastLoginAt:'2026-10-15T08:00:00Z'}];
 w.dispatchEvent(new w.Event('pageshow'));await until(()=>!$('#customers-tab').hidden);$('#customers-tab').click();await until(()=>$('#content').textContent.includes('user@example.test'));
 assert.match($('#content').textContent,/<img src=x/);assert.equal($('#content img[src="x"], #content [onerror]'),null);
 data.deny=true;$('#refresh').click();await until(()=>$('#workspace').hidden);assert.equal($('#customers-tab').hidden,true);assert.equal($('#content').childElementCount,0);
});

test('DOM: late session capability response cannot undo pagehide clearing',async t=>{
 const {data,$,w}=await fixture(t);Object.defineProperty(w.document,'hidden',{configurable:true,value:false});let resolve;
 data.sessionDelay=new Promise(r=>resolve=r);w.document.dispatchEvent(new w.Event('visibilitychange'));w.dispatchEvent(new w.Event('pagehide'));
 resolve(response({csrfToken:'stale',capabilities:{customers:true}}));await new Promise(r=>setTimeout(r,20));assert.equal($('#customers-tab').hidden,true);assert.equal($('#workspace').hidden,true);
});

test('DOM: product warnings are separately labelled, required and bounded; other declaration fields are editable with existing values',async t=>{
 const {data,w}=await fixture(t);const cards=[...w.document.querySelectorAll('.product-card')];
 for(const [index,card]of cards.entries()){
  const warning=card.querySelector('textarea[name=warnings]');assert.ok(warning);assert.equal(warning.value,data.products[index].declaration.warnings);assert.equal(warning.required,true);assert.equal(warning.maxLength,10000);assert.match(warning.closest('label').textContent,/^Upozorenja/);assert.equal(warning.closest('details'),null);
  const declaration=[...card.querySelectorAll('details')].find(node=>node.querySelector('summary')?.textContent.includes('Deklaracija'));
  assert.ok(declaration.querySelector('textarea'));
  for(const [key,value]of Object.entries(data.products[index].declaration))if(key!=='warnings'){assert.equal(card.querySelector(`[name="declaration_${key}"]`).value,value);}
 }
});

test('DOM: unchanged or reverted warnings never enter the product PATCH',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);const original=data.products[0].declaration.warnings;
 edit('.product-card [name=price]','123');submit(0);assert.doesNotMatch($('#confirm-message').textContent,/Izmena deklaracije/);close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal(Object.hasOwn(data.patches[0].body,'declaration'),false);assert.equal(Object.hasOwn(data.patches[0].body,'warnings'),false);
 edit('.product-card [name=warnings]','Privremena izmena');edit('.product-card [name=warnings]',original);submit(0);close('save');await until(()=>data.patches.length===2&&$('#status').textContent.includes('uspešno'));
 assert.equal(Object.hasOwn(data.patches[1].body,'declaration'),false);assert.equal(data.products[0].declaration.warnings,original);
});

test('DOM: a warning edit needs confirmation and PATCHes only declaration.warnings without replacing other declaration data',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);const original={...data.products[0].declaration},warnings='Izmenjeno test upozorenje.\nDrugi red.';
 edit('.product-card [name=warnings]',warnings);submit(0);assert.match($('#confirm-message').textContent,/Izmena deklaracije/);assert.equal(data.patches.length,0);close('cancel');await until(()=>!$('.product-card [name=warnings]').disabled);assert.equal($('.product-card [name=warnings]').value,warnings);assert.equal(data.patches.length,0);
 submit(0);submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(data.patches.length,1);assert.deepEqual(data.patches[0].body.declaration,{warnings});assert.equal(Object.hasOwn(data.patches[0].body,'warnings'),false);assert.equal(data.patches[0].body.version,1);assert.equal(data.patches[0].headers['X-CSRF-Token'],'test-csrf');assert.deepEqual(data.products[0].declaration,{...original,warnings});assert.equal($('.product-card [name=warnings]').value,warnings);
 // The saved warning becomes the new baseline, so a later unrelated edit does not resend it.
 edit('.product-card [name=price]','321');submit(0);close('save');await until(()=>data.patches.length===2&&$('#status').textContent.includes('uspešno'));assert.equal(Object.hasOwn(data.patches[1].body,'declaration'),false);
});

test('DOM: blank, whitespace-only and overlong warnings fail before confirmation or PATCH, including scripted submits',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);
 for(const value of ['', ' \n\t ', '\u00a0', 'a'.repeat(10001)]){
  edit('.product-card [name=warnings]',value);submit(0);assert.equal($('#confirm').open,false);assert.equal(data.patches.length,0);assert.match($('.product-card > .form-message').textContent,value.length>10000?/najviše 10\.000/:/Unesite upozorenja/);
 }
 edit('.product-card [name=warnings]','a'.repeat(10000));submit(0);assert.equal($('#confirm').open,true);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(data.patches[0].body.declaration.warnings.length,10000);
});

test('DOM: browser newline normalization does not submit unchanged source warnings',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);data.products[0]={...data.products[0],declaration:{...data.products[0].declaration,warnings:'Prvi red.\r\nDrugi red.\rTreći red.'}};
 $('#refresh').click();await until(()=>$('.product-card [name=warnings]')?.value==='Prvi red.\nDrugi red.\nTreći red.');
 edit('.product-card [name=price]','234');submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(Object.hasOwn(data.patches[0].body,'declaration'),false);assert.equal(data.products[0].declaration.warnings,'Prvi red.\r\nDrugi red.\rTreći red.');
});

test('DOM: warning markup stays literal in the textarea and saved request',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);const warnings='</textarea><img src=x onerror=alert(1)><script>alert(1)</script>';
 edit('.product-card [name=warnings]',warnings);submit(0);assert.equal($('#content [onerror], #content script, #confirm [onerror], #confirm script'),null);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal($('.product-card [name=warnings]').value,warnings);assert.equal(data.patches[0].body.declaration.warnings,warnings);assert.equal($('#content img[src=x], #content [onerror], #content script'),null);
});

test('DOM: warning draft survives another save and version conflict; refresh still requires explicit discard',async t=>{
 const {data,$,w,edit,submit,close}=await fixture(t);const selector='.product-card:nth-child(2) [name=warnings]';
 edit(selector,'Nesačuvano test upozorenje');edit('.product-card [name=price]','345');data.products[1]={...data.products[1],version:8,declaration:{...data.products[1].declaration,warnings:'Novije upozorenje sa servera'}};
 submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal($(selector).value,'Nesačuvano test upozorenje');assert.match($('.product-card:nth-child(2) header').textContent,/Verzija 1/);
 data.conflict=true;submit(1);close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal(data.patches[1].body.version,1);assert.deepEqual(data.patches[1].body.declaration,{warnings:'Nesačuvano test upozorenje'});assert.equal($(selector).value,'Nesačuvano test upozorenje');assert.doesNotMatch($('#status').textContent,/uspešno/);
 let discards=0;w.confirm=()=>{discards++;return false;};$('#refresh').click();assert.equal(discards,1);assert.equal($(selector).value,'Nesačuvano test upozorenje');
 w.confirm=()=>true;$('#refresh').click();await until(()=>$(selector)?.value==='Novije upozorenje sa servera');assert.match($('.product-card:nth-child(2) header').textContent,/Verzija 8/);
});

test('DOM: pagehide or expired authorization clears warning drafts and cannot submit an abandoned confirmation',async t=>{
 const {data,$,w,edit,submit,close}=await fixture(t);edit('.product-card [name=warnings]','Privatni nacrt upozorenja');submit(0);w.dispatchEvent(new w.Event('pagehide'));await new Promise(r=>setTimeout(r,10));assert.equal(data.patches.length,0);assert.equal($('#content').childElementCount,0);assert.equal($('#confirm').open,false);assert.equal($('#confirm-message').textContent,'');
 w.dispatchEvent(new w.Event('pageshow'));await until(()=>$('.product-card'));assert.notEqual($('.product-card [name=warnings]').value,'Privatni nacrt upozorenja');edit('.product-card [name=warnings]','Drugi privatni nacrt');submit(0);data.deny=true;close('save');await until(()=>$('#workspace').hidden);assert.equal($('#content').childElementCount,0);assert.equal($('#identity').textContent,'');
 data.deny=false;$('#retry').click();await until(()=>$('.product-card'));assert.notEqual($('.product-card [name=warnings]').value,'Drugi privatni nacrt');
});

test('DOM: human order number labels heading and status confirmation while PATCH keeps opaque ID',async t=>{
 const {data,$,w,edit,close}=await fixture(t);
 const order={id:'COD-00000000-0000-4000-8000-000000000001',orderNumber:'2026-1000',status:'pending',paymentMethod:'cod',paymentStatus:'cod_due',version:4,createdAt:'2026-10-19T12:00:00Z'};
 data.orderRows=[order];$('[data-view="orders"]').click();await until(()=>$('.order-card h3'));
 assert.equal($('.order-card h3').textContent,'Porudžbina 2026-1000');
 edit('.order-card [name=status]','processing');$('.order-card form').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
 assert.equal($('#confirm').open,true);assert.equal($('#confirm-message').textContent,'Porudžbina 2026-1000: status „U obradi”.');assert.equal(data.patches.length,0);
 close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal(data.patches.length,1);assert.equal(data.patches[0].path,`/admin/api/orders/${order.id}`);
 assert.deepEqual(data.patches[0].body,{version:4,status:'processing'});assert.equal(data.patches[0].headers['X-CSRF-Token'],'test-csrf');
 // Successful saving clears the draft by opaque ID, so a stale selection cannot survive the reload.
 assert.equal($('.order-card [name=status]').value,'pending');
 const unload=new w.Event('beforeunload',{cancelable:true});w.dispatchEvent(unload);assert.equal(unload.defaultPrevented,false);
});

test('DOM: legacy orders retain opaque ID in heading and status confirmation',async t=>{
 const {data,$,w,edit,close}=await fixture(t);
 const order={id:'COD-00000000-0000-4000-8000-000000000001',status:'pending',version:1,createdAt:'2026-10-19T12:00:00Z'};
 for(const legacy of [order,{...order,orderNumber:null},{...order,orderNumber:''}]){
  data.orderRows=[legacy];$('[data-view="orders"]').click();await until(()=>$('.order-card h3'));
  assert.equal($('.order-card h3').textContent,`Porudžbina ${order.id}`);
  edit('.order-card [name=status]','processing');$('.order-card form').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
  assert.equal($('#confirm-message').textContent,`Porudžbina ${order.id}: status „U obradi”.`);
  close('cancel');await until(()=>!$('.order-card [name=status]').disabled);
 }
 assert.equal(data.patches.length,0);
});

test('DOM: human order number markup stays literal in heading and status confirmation',async t=>{
 const {data,$,w,edit,close}=await fixture(t);
 const order={id:'COD-00000000-0000-4000-8000-000000000001',orderNumber:'<img src=x onerror=alert(1)><script>bad</script>',status:'pending',version:1,createdAt:'2026-10-19T12:00:00Z'};
 data.orderRows=[order];$('[data-view="orders"]').click();await until(()=>$('.order-card h3'));
 assert.equal($('.order-card h3').textContent,`Porudžbina ${order.orderNumber}`);
 edit('.order-card [name=status]','processing');$('.order-card form').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));
 assert.equal($('#confirm-message').textContent,`Porudžbina ${order.orderNumber}: status „U obradi”.`);
 assert.equal($('#content img, #content script, #content [onerror], #confirm img, #confirm script, #confirm [onerror]'),null);
 close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal(data.patches.length,1);assert.equal(data.patches[0].path,`/admin/api/orders/${order.id}`);
});

const roleCustomer={id:'00000000-0000-4000-8000-000000000001',name:'Ana Kupac',email:'ana@example.test',role:'customer',roleVersion:3,roleManagedBy:null,canManageRole:true,lastLoginAt:'2026-10-19T12:00:00Z'};
async function roleFixture(t,{manageRoles=true,rows=[roleCustomer]}={}){
 const f=await fixture(t);f.data.customersEnabled=true;f.data.manageRoles=manageRoles;f.data.customerRows=rows.map(row=>({...row}));
 f.w.dispatchEvent(new f.w.Event('pageshow'));await until(()=>!f.$('#customers-tab').hidden);f.$('#customers-tab').click();await until(()=>f.$('.customer-card'));return f;
}

test('DOM: registered users show roles but role controls require a strict owner capability',async t=>{
 const {data,$,w}=await roleFixture(t,{manageRoles:false,rows:[roleCustomer,{...roleCustomer,id:'owner',name:'Vlasnik',role:'owner',canManageRole:false},{...roleCustomer,id:'admin',name:'Administrator',role:'admin'}]});
 assert.match($('#section-title').textContent,/Registrovani korisnici/);assert.match($('#content').textContent,/Uloga: Korisnik/);assert.match($('#content').textContent,/Uloga: Glavni vlasnik/);assert.match($('#content').textContent,/Uloga: Administrator/);assert.equal($('.customer-role-actions'),null);
 for(const missing of [undefined,'true',1]){
  data.manageRoles=missing;w.dispatchEvent(new w.Event('pageshow'));await until(()=>!$('#customers-tab').hidden);$('#customers-tab').click();await until(()=>$('.customer-card'));assert.equal($('.customer-role-actions'),null);
 }
 assert.equal(data.patches.length,0);
});

test('DOM: owner and bootstrap roles stay immutable, and missing permission or revision disables role controls',async t=>{
 const rows=[roleCustomer,{...roleCustomer,id:'owner',role:'owner'},{...roleCustomer,id:'bootstrap',role:'admin',roleManagedBy:'bootstrap'},{...roleCustomer,id:'unmanaged',canManageRole:false},{...roleCustomer,id:'unknown-version',roleVersion:undefined},{...roleCustomer,id:'invalid-version',roleVersion:0},{...roleCustomer,id:'unknown-role',role:'other'}];
 const {w,$}=await roleFixture(t,{rows});assert.equal(w.document.querySelectorAll('.customer-role-actions button').length,1);assert.equal($('.customer-role-actions button').textContent,'Dodeli administratorsku ulogu');assert.match($('#content').textContent,/Uloga: Glavni vlasnik/);
});

test('DOM: owner role confirmation identifies the target safely; cancel and repeated clicks never mutate roles',async t=>{
 const customer={...roleCustomer,name:'<img src=x onerror=alert(1)>',email:'<script>bad</script>@example.test'};
 const {data,$,w,close}=await roleFixture(t,{rows:[customer]});const button=$('.customer-role-actions button');button.click();button.dispatchEvent(new w.Event('click'));
 assert.equal($('#confirm').open,true);assert.equal(button.disabled,true);assert.equal(data.patches.length,0);assert.match($('#confirm-message').textContent,/Dodeliti administratorsku ulogu/);assert.ok($('#confirm-message').textContent.includes(customer.name));assert.ok($('#confirm-message').textContent.includes(customer.email));assert.match($('#confirm-message').textContent,/Samo glavni vlasnik/);assert.equal($('#content img, #content script, #confirm img, #confirm script, [onerror]'),null);
 close('cancel');await until(()=>!button.disabled);assert.equal(data.patches.length,0);assert.match($('.customer-role').textContent,/Korisnik/);
});

test('DOM: granting and revoking delegated admin use CSRF and the current version while preserving the account',async t=>{
 const {data,$,w,close}=await roleFixture(t);$('.customer-role-actions button').click();close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal(data.patches.length,1);assert.equal(data.patches[0].path,`/admin/api/customers/${roleCustomer.id}/role`);assert.deepEqual(data.patches[0].body,{role:'admin',version:3});assert.equal(data.patches[0].headers['X-CSRF-Token'],'test-csrf');assert.match($('.customer-role').textContent,/Administrator/);assert.equal($('.customer-role-actions button').textContent,'Ukloni administratorsku ulogu');
 $('.customer-role-actions button').click();assert.ok($('#confirm-message').textContent.includes(roleCustomer.name));assert.ok($('#confirm-message').textContent.includes(roleCustomer.email));assert.match($('#confirm-message').textContent,/Ukloniti administratorsku ulogu/);assert.match($('#confirm-message').textContent,/nalog i njegove porudžbine neće biti obrisani/);close('save');await until(()=>data.patches.length===2&&$('#status').textContent.includes('uspešno'));
 assert.deepEqual(data.patches[1].body,{role:'customer',version:4});assert.equal(data.customerRows.length,1);assert.equal(data.customerRows[0].id,roleCustomer.id);assert.equal(data.customerRows[0].roleVersion,5);assert.equal(w.document.querySelectorAll('.customer-card').length,1);assert.match($('.customer-role').textContent,/Korisnik/);
});

test('DOM: pending role mutation has no optimistic success and rejects duplicate or conflicting requests',async t=>{
 const {data,$,w,close}=await roleFixture(t);let resolve;data.patchDelay=new Promise(r=>resolve=r);const button=$('.customer-role-actions button');button.click();close('save');await until(()=>data.patches.length===1);
 assert.equal(button.disabled,true);assert.equal($('#customers-tab').disabled,true);assert.match($('.customer-role').textContent,/Korisnik/);assert.doesNotMatch($('#status').textContent,/uspešno/);button.dispatchEvent(new w.Event('click'));assert.equal(data.patches.length,1);assert.equal($('#confirm').open,false);
 resolve(response({},409));await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal(button.disabled,false);assert.match($('.customer-role').textContent,/Korisnik/);assert.equal(data.patches.length,1);assert.doesNotMatch($('#status').textContent,/uspešno/);
});

test('DOM: stale customer role requires refreshing before a new version can be confirmed',async t=>{
 const {data,$,close}=await roleFixture(t);data.customerRows[0]={...data.customerRows[0],role:'admin',roleVersion:4,roleManagedBy:'delegated'};
 $('.customer-role-actions button').click();close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.deepEqual(data.patches[0].body,{role:'admin',version:3});assert.doesNotMatch($('#status').textContent,/uspešno/);assert.match($('.customer-role').textContent,/Korisnik/);
 $('#refresh').click();await until(()=>$('.customer-role-actions button')?.textContent==='Ukloni administratorsku ulogu');$('.customer-role-actions button').click();close('save');await until(()=>data.patches.length===2&&$('#status').textContent.includes('uspešno'));assert.deepEqual(data.patches[1].body,{role:'customer',version:4});
});

test('DOM: failed role update leaves role unchanged and does not report success',async t=>{
 const {data,$,close}=await roleFixture(t);data.roleError=500;$('.customer-role-actions button').click();close('save');await until(()=>$('#status').textContent.includes('Zahtev nije uspeo'));
 assert.equal(data.patches.length,1);assert.equal(data.customerRows[0].role,'customer');assert.match($('.customer-role').textContent,/Korisnik/);assert.equal($('.customer-role-actions button').disabled,false);assert.doesNotMatch($('#status').textContent,/uspešno/);
});

test('DOM: rejected role access clears private rows and recovers without retaining owner controls',async t=>{
 for(const status of [401,403,503])await t.test(String(status),async t=>{
  const {data,$,close}=await roleFixture(t);data.roleError=status;$('.customer-role-actions button').click();close('save');await until(()=>$('#workspace').hidden);
  assert.equal($('#identity').textContent,'');assert.equal($('#content').childElementCount,0);assert.equal($('#customers-tab').hidden,true);assert.equal($('#confirm').open,false);assert.equal($('#confirm-message').textContent,'');
  data.roleError=null;data.manageRoles=false;$('#retry').click();await until(()=>!$('#workspace').hidden&&$('.product-card'));assert.equal($('#customers-tab').disabled,false);$('#customers-tab').click();await until(()=>$('.customer-card'));assert.equal($('.customer-role-actions'),null);
 });
});

test('DOM: account switch during session revalidation clears former owner data and detached role handlers',async t=>{
 const {data,$,w}=await roleFixture(t);const oldButton=$('.customer-role-actions button');Object.defineProperty(w.document,'hidden',{configurable:true,value:false});data.sessionEmail='second-admin@example.test';data.manageRoles=false;data.customerRows=[{...roleCustomer,name:'Drugi korisnik',email:'second@example.test'}];w.document.dispatchEvent(new w.Event('visibilitychange'));
 await until(()=>$('#identity').textContent==='second-admin@example.test'&&$('.product-card'));assert.equal($('.customer-card'),null);assert.equal($('#content').textContent.includes(roleCustomer.email),false);oldButton.dispatchEvent(new w.Event('click'));assert.equal($('#confirm').open,false);assert.equal(data.patches.length,0);
 $('#customers-tab').click();await until(()=>$('.customer-card'));assert.equal($('.customer-role-actions'),null);assert.match($('#content').textContent,/second@example.test/);
});

test('DOM: late capability removal cancels an open role confirmation before any PATCH',async t=>{
 const {data,$,w}=await roleFixture(t);Object.defineProperty(w.document,'hidden',{configurable:true,value:false});let resolve;data.sessionDelay=new Promise(r=>resolve=r);w.document.dispatchEvent(new w.Event('visibilitychange'));$('.customer-role-actions button').click();assert.equal($('#confirm').open,true);
 resolve(response({user:{email:'admin@example.test'},csrfToken:'new-token',capabilities:{customers:true,manageRoles:false}}));await until(()=>!$('#confirm').open&&!$('#customers-tab').disabled);assert.equal($('.customer-role-actions'),null);assert.equal(data.patches.length,0);
});

test('DOM: pagehide cancels role confirmation and later responses cannot restore account data',async t=>{
 const {data,$,w,close}=await roleFixture(t);$('.customer-role-actions button').click();w.dispatchEvent(new w.Event('pagehide'));await new Promise(r=>setTimeout(r,10));assert.equal(data.patches.length,0);assert.equal($('#confirm').open,false);assert.equal($('#confirm-message').textContent,'');assert.equal($('#content').childElementCount,0);
 w.dispatchEvent(new w.Event('pageshow'));await until(()=>!$('#workspace').hidden&&$('.product-card'));$('#customers-tab').click();await until(()=>$('.customer-role-actions'));let resolve;data.patchDelay=new Promise(r=>resolve=r);$('.customer-role-actions button').click();close('save');await until(()=>data.patches.length===1);w.dispatchEvent(new w.Event('pagehide'));resolve(response({...roleCustomer,role:'admin',roleVersion:4}));await new Promise(r=>setTimeout(r,20));assert.equal($('#workspace').hidden,true);assert.equal($('#content').childElementCount,0);assert.equal($('#identity').textContent,'');assert.doesNotMatch($('#status').textContent,/uspešno/);
});

test('DOM: every description has opt-in formatting and old text is not converted or saved implicitly',async t=>{
 const {data,w,$,submit,close}=await fixture(t);
 for(const [i,card]of [...w.document.querySelectorAll('.product-card')].entries()){
  assert.equal(card.querySelector('[name=descriptionFormat]').value,'plain');
  assert.equal(card.querySelector('[name=description]').value,data.products[i].description);
  assert.ok(card.querySelector('.description-preview').textContent.includes(data.products[i].description));
  const before=card.querySelector('[name=description]').value;card.querySelector('[data-description-action=heading]').click();
  assert.equal(card.querySelector('[name=description]').value,before);assert.match(card.querySelector('.description-editor .form-message').textContent,/Najpre izaberite/);
 }
 submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal(Object.hasOwn(data.patches[0].body,'descriptionFormat'),false);
});
test('DOM: format controls preview safely and persist only after explicit save confirmation',async t=>{
 const {data,w,$,edit,submit,close}=await fixture(t);
 edit('.product-card [name=descriptionFormat]','markdown');
 const description='## Naslov\n\n**Važan tekst**\n- Prva stavka\n1. Numerisana\n<script>alert(1)</script>\n<img src=x onerror=alert(1)>';
 edit('.product-card [name=description]',description);
 const preview=$('.product-card .description-preview');assert.equal(preview.querySelector('h2').textContent,'Naslov');assert.equal(preview.querySelector('strong').textContent,'Važan tekst');assert.equal(preview.querySelectorAll('li').length,2);
 assert.equal(preview.querySelector('script,img,iframe,a,[onerror]'),null);assert.match(preview.textContent,/<script>/);
 assert.equal(data.patches.length,0);submit(0);assert.match($('#confirm-message').textContent,/formatirani tekst/);close('cancel');await until(()=>!$('.product-card button[type=submit]').disabled);assert.equal(data.patches.length,0);
 submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal(data.patches[0].body.descriptionFormat,'markdown');assert.equal(data.patches[0].body.description,description);assert.equal($('.product-card [name=descriptionFormat]').value,'markdown');assert.equal($('.product-card .description-preview h2').textContent,'Naslov');
});
test('DOM: formatting toolbar edits selected lines, tracks draft and respects length limit',async t=>{
 const {data,w,$,edit,submit,close}=await fixture(t);edit('.product-card [name=descriptionFormat]','markdown');edit('.product-card [name=description]','Prvi red\nDrugi red');
 const input=$('.product-card [name=description]');input.setSelectionRange(0,input.value.length);$('.product-card [data-description-action=bullet]').click();assert.equal(input.value,'- Prvi red\n- Drugi red');assert.equal($('.product-card .description-preview').querySelectorAll('li').length,2);
 input.setSelectionRange(2,10);$('.product-card [data-description-action=bold]').click();assert.match(input.value,/\*\*Prvi red\*\*/);assert.equal($('.product-card .description-preview strong').textContent,'Prvi red');
 edit('.product-card [name=description]','x'.repeat(2000));input.setSelectionRange(0,2000);$('.product-card [data-description-action=bold]').click();assert.equal(input.value.length,2000);assert.match($('.product-card .description-editor .form-message').textContent,/2.000/);
 assert.equal(data.patches.length,0);
});
test('DOM: save another product preserves unsaved description-format choice and preview',async t=>{
 const {data,w,$,edit,submit,close}=await fixture(t);
 edit('.product-card:nth-child(2) [name=descriptionFormat]','markdown');edit('.product-card:nth-child(2) [name=description]','## Drugi proizvod\n\n**Nesačuvano**');edit('.product-card:nth-child(1) [name=name]','New name');submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));
 assert.equal($('.product-card:nth-child(2) [name=descriptionFormat]').value,'markdown');assert.equal($('.product-card:nth-child(2) .description-preview strong').textContent,'Nesačuvano');assert.equal(data.patches.length,1);assert.equal(Object.hasOwn(data.products[1],'descriptionFormat'),false);
});
test('DOM: descriptions keep exact whitespace on unrelated saves',async t=>{
 const {data,$,edit,submit,close}=await fixture(t);const description='  Original text.\n\n';data.products[0]={...data.products[0],description};$('#refresh').click();await until(()=>$('.product-card [name=description]')?.value===description);
 edit('.product-card [name=price]','100');submit(0);close('save');await until(()=>$('#status').textContent.includes('uspešno'));assert.equal(data.patches[0].body.description,description);
});

function fillNewProduct(f){
 const values={name:'Ulje šipka',price:'1200,50',description:'Opis sa deklaracije',category:'Biljno ulje',ingredients:'Ulje šipka',declaration_warnings:'Upozorenja proizvođača',declaration_usage:'Prema deklaraciji',declaration_storage:'Na hladnom mestu'};
 for(const [name,value]of Object.entries(values))f.edit('#new-product-form [name="'+name+'"]',value);
}
test('DOM: create draft generates safe SKU, confirmation cancel and repeated submit do not create twice',async t=>{
 const f=await fixture(t);fillNewProduct(f);assert.equal(f.$('#new-product-form [name=id]').value,'ulje-sipka');
 const submit=()=>f.$('#new-product-form').dispatchEvent(new f.w.Event('submit',{cancelable:true,bubbles:true}));
 submit();assert.equal(f.$('#confirm').open,true);f.close('cancel');await until(()=>!f.$('#new-product-form button[type=submit]').disabled);assert.equal(f.data.creates,undefined);
 submit();submit();f.close('save');await until(()=>f.$('#status').textContent.includes('Nacrt je sačuvan'));
 assert.equal(f.data.creates.length,1);assert.equal(f.data.creates[0].headers['X-CSRF-Token'],'test-csrf');assert.equal(f.data.creates[0].body.priceMinor,120050);assert.equal(f.data.products.at(-1).published,false);assert.equal(f.data.products.at(-1).available,false);assert.equal(f.data.products.at(-1).stockQuantity,0);
 assert.equal(f.$('.product-card [name=published]').checked,false);assert.match(f.$('.product-card header').textContent,/Nacrt/);
});
test('DOM: new draft requires fields, cannot use duplicate SKU and preserves manual SKU',async t=>{
 const f=await fixture(t);fillNewProduct(f);f.edit('#new-product-form [name=id]','moj-sku');f.edit('#new-product-form [name=name]','Promenjeno ime');assert.equal(f.$('#new-product-form [name=id]').value,'moj-sku');
 const submit=()=>f.$('#new-product-form').dispatchEvent(new f.w.Event('submit',{cancelable:true,bubbles:true}));
 f.edit('#new-product-form [name=declaration_warnings]','');submit();assert.equal(f.$('#confirm').open,false);assert.equal(f.data.creates,undefined);
 f.edit('#new-product-form [name=declaration_warnings]','Provereno');f.edit('#new-product-form [name=id]','crni-kim');submit();assert.match(f.$('#new-product-form>.form-message').textContent,/već postoji/);assert.equal(f.data.creates,undefined);
});
test('DOM: new draft survives another product save and disappears after explicit discard or session loss',async t=>{
 const f=await fixture(t);fillNewProduct(f);f.edit('.product-card [name=price]','100');f.submit(0);f.close('save');await until(()=>f.$('#status').textContent.includes('uspešno'));assert.equal(f.$('#new-product-form [name=name]').value,'Ulje šipka');
 assert.equal(f.$('.new-product').open,true);f.$('#new-product-form>.actions button[type=button]').click();assert.equal(f.$('#new-product-form [name=name]').value,'');
 fillNewProduct(f);f.data.deny=true;f.$('#new-product-form').dispatchEvent(new f.w.Event('submit',{cancelable:true,bubbles:true}));f.close('save');await until(()=>!f.$('#access').hidden);assert.equal(f.$('#content').childElementCount,0);
});
test('DOM: uncertain creation outcome blocks duplicate retry and explains refresh reconciliation',async t=>{
 const f=await fixture(t);fillNewProduct(f);f.data.createError=true;const form=f.$('#new-product-form');form.dispatchEvent(new f.w.Event('submit',{cancelable:true,bubbles:true}));f.close('save');await until(()=>form.dataset.uncertain==='true');assert.equal(form.querySelector('button[type=submit]').disabled,true);assert.match(f.$('#status').textContent,/Ne šaljite ponovo/);form.dispatchEvent(new f.w.Event('submit',{cancelable:true,bubbles:true}));assert.equal(f.data.creates.length,1);
});
test('DOM: cannot publish a draft before image; uploaded drafts can be published with explicit confirmation',async t=>{
 const f=await fixture(t);f.data.products[0]={...f.data.products[0],published:false,image:null};f.$('#refresh').click();await until(()=>f.$('.product-card [name=published]')?.checked===false);
 f.$('.product-card [name=published]').checked=true;f.submit(0);assert.equal(f.$('#confirm').open,false);assert.match(f.$('.product-card>.form-message').textContent,/fotografiju/);
 f.data.products[0].imagePath='/media/'+'a'.repeat(64)+'.jpg';f.$('#refresh').click();await until(()=>f.$('.product-card img')?.src.includes('/media/'));f.$('.product-card [name=published]').checked=true;f.submit(0);assert.match(f.$('#confirm-message').textContent,/javno vidljiv/);f.close('save');await until(()=>f.$('#status').textContent.includes('uspešno'));assert.equal(f.data.patches[0].body.published,true);
});

test('DOM: prototype-like valid SKU is not confused with a fixed legacy stock code',async t=>{
 const f=await fixture(t);f.data.products[0]={...f.data.products[0],id:'constructor',stockCode:'NEW001'};f.$('#refresh').click();await until(()=>f.$('.product-card header')?.textContent.includes('SKU: constructor'));
 assert.equal(f.$('.product-card [name=stockCode]').value,'NEW001');assert.equal(f.$('.product-card [name=stockCode]').readOnly,false);
});

test('DOM: action sends entered prices, Belgrade expiry and attestation only after confirmation',async t=>{
 const {w,data,$,edit,submit,close}=await fixture(t);
 const pre='.product-card [name="';
 const s=k=>pre+k+'"]';
 edit(s('saleAction'),'start');
 $(s('saleAction')).dispatchEvent(new w.Event('change',{bubbles:true}));
 edit(s('salePrevious'),'1400');edit(s('salePrice'),'1120');edit(s('saleEnd'),'2030-04-20T13:00');
 submit(0);assert.equal(data.patches.length,0);assert.equal($('#confirm').open,false);
 $(s('saleVerified')).checked=true;submit(0);assert.equal($('#confirm').open,true);
 assert.match($('#confirm-message').textContent,/2030-04-20 13:00/);
 close('save');await until(()=>data.patches.length===1);
 assert.deepEqual(data.patches[0].body.sale,{previousMinor:140000,priceMinor:112000,endLocal:'2030-04-20T13:00',historyVerified:true});
});
