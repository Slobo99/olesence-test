import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {createPostgresStore} from '../src/admin-store.mjs';
import {createCustomerStore} from '../src/customer-store.mjs';
import {readAdminConfig} from '../src/admin.mjs';
import {createHostedServer} from '../server.mjs';

const origin='https://role-test.onrender.com',host='role-test.onrender.com',clientId='role-unit-test.apps.googleusercontent.com';
const ownerEmail='owner@example.invalid';
const policy={emails:[ownerEmail],ownerEmail};
const identity=(subject,email=subject+'@example.invalid')=>({id:'google:'+subject,provider:'google',subject,email,name:'Fixture Customer',role:'customer'});

async function setup(t,{adminPolicy=policy,beforeInitialize}={}){
 const db=new PGlite();let queue=Promise.resolve(),lookupFailure=false,auditFailure=false;
 async function acquire(){const prior=queue;let release;queue=new Promise(resolve=>{release=resolve;});await prior;return release;}
 const query=(sql,args)=>{
  if(lookupFailure&&sql.includes('FROM commerce_customers')&&sql.includes("provider='google'"))throw Error('Private database connection details');
  if(auditFailure&&sql.startsWith('INSERT INTO admin_audit'))throw Error('Injected audit failure');
  return sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args);
 };
 const pool={async query(sql,args){const release=await acquire();try{return await query(sql,args);}finally{release();}},async connect(){const release=await acquire();return {query,release};}};
 if(beforeInitialize)await beforeInitialize(pool);
 const store=createPostgresStore(pool);await store.initialize([]);
 await pool.query('INSERT INTO admin_products(id,document) VALUES($1,$2::jsonb)',['fixture-product',JSON.stringify({name:'Fixture Product',priceMinor:100,stockQuantity:5,available:true})]);
 const customers=createCustomerStore(pool);let flow,loginIdentity;
 const provider={authorizationURL(value){flow=value;return 'https://accounts.google.com/mock';},async exchange(){return {iss:'https://accounts.google.com',aud:clientId,sub:loginIdentity.subject,email:loginIdentity.email,name:loginIdentity.name,email_verified:true,nonce:flow.nonce,iat:1000,exp:4600,role:'owner',customerId:'untrusted-provider-extra'};}};
 const config={origin,host,auth:{origin,clientId,secure:true,redirectUri:origin+'/auth/google/callback'},admin:{enabled:true,...adminPolicy},customerDatabaseEnabled:true};
 const app=await createHostedServer({config,provider,clock:()=>1000000,store,customerStore:customers});
 await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));
 t.after(async()=>{await app.close();await db.close();});
 const request=(path,{method='GET',headers={},body}={})=>new Promise((resolve,reject)=>{
  const req=http.request({hostname:'127.0.0.1',port:app.server.address().port,path,method,headers:{host,'x-forwarded-proto':'https',...headers}},res=>{let text='';res.on('data',bytes=>{text+=bytes;});res.on('end',()=>resolve({status:res.statusCode,text,json:()=>JSON.parse(text),headers:res.headers}));});req.on('error',reject);req.end(body);
 });
 async function login(subject,email){
  loginIdentity=identity(subject,email);const started=await request('/auth/google/start',{method:'POST',headers:{origin}});
  const initialCookie=started.headers['set-cookie'][0].split(';')[0];
  const finished=await request('/auth/google/callback?state='+flow.state+'&code=fixture',{headers:{cookie:initialCookie}});
  const cookie=finished.headers['set-cookie'][0].split(';')[0];
  const session=(await request('/auth/session',{headers:{cookie}})).json();
  assert.equal(session.user.role,'customer');
  return {user:session.user,headers:{cookie,origin,'x-csrf-token':session.csrfToken}};
 }
 const patch=(target,actor,body,headerPatch={})=>request('/admin/api/customers/'+target+'/role',{method:'PATCH',headers:{...actor.headers,'content-type':'application/json',...headerPatch},body:JSON.stringify(body)});
 const roleRow=async id=>(await pool.query('SELECT admin_role,role_revision FROM commerce_customers WHERE id=$1',[id])).rows[0];
 const audit=async()=>(await store.listAudit()).entries;
 return {db,pool,store,customers,request,login,patch,roleRow,audit,failLookup(value=true){lookupFailure=value;},failAudit(value=true){auditFailure=value;}};
}

test('owner configuration is unambiguous, normalized and limited to existing bootstrap authority',()=>{
 const base={ADMIN_ENABLED:'1',DATABASE_URL:'fixture-only'};
 assert.equal(readAdminConfig({...base,ADMIN_EMAILS:' OWNER@example.invalid,owner@example.invalid '}).ownerEmail,ownerEmail);
 const multi={...base,ADMIN_EMAILS:ownerEmail+',legacy@example.invalid'};
 assert.equal(readAdminConfig(multi).ownerEmail,null);
 assert.equal(readAdminConfig({...multi,ADMIN_OWNER_EMAIL:' OWNER@example.invalid '}).ownerEmail,ownerEmail);
 assert.throws(()=>readAdminConfig({...multi,ADMIN_OWNER_EMAIL:'new@example.invalid'}),/must be one/);
 assert.throws(()=>readAdminConfig({...multi,ADMIN_OWNER_EMAIL:'not-an-email'}));
});

test('owner grants and revokes customer UUID roles immediately for already logged-in sessions',async t=>{
 const f=await setup(t),owner=await f.login('owner'),buyer=await f.login('buyer');
 const api='/admin/api/session';
 assert.equal((await f.request(api,{headers:buyer.headers})).status,403);
 const ownerSession=(await f.request(api,{headers:owner.headers})).json();
 assert.equal(ownerSession.user.role,'admin');assert.equal(ownerSession.capabilities.manageRoles,true);
 let directory=(await f.request('/admin/api/customers',{headers:owner.headers})).json();
 const ownerRow=directory.customers.find(row=>row.id===owner.user.customerId);
 assert.equal(ownerRow.role,'owner');assert.equal(ownerRow.canManageRole,false);assert.equal(ownerRow.roleManagedBy,'owner');
 const buyerRow=directory.customers.find(row=>row.id===buyer.user.customerId);
 assert.equal(buyerRow.role,'customer');assert.equal(buyerRow.canManageRole,true);assert.equal(buyerRow.roleVersion,1);
 for(const row of directory.customers)for(const key of ['subject','provider','password','token'])assert.equal(Object.hasOwn(row,key),false);
 const granted=await f.patch(buyer.user.customerId,owner,{role:'admin',version:1});
 assert.equal(granted.status,200);assert.equal(granted.json().role,'admin');assert.equal(granted.json().roleVersion,2);assert.equal(granted.json().roleManagedBy,'delegated');
 for(const path of ['/admin','/admin.js','/admin.css','/admin/api/products','/admin/api/orders','/admin/api/audit'])assert.equal((await f.request(path,{headers:buyer.headers})).status,200,path);
 const delegatedSession=(await f.request(api,{headers:buyer.headers})).json();assert.equal(delegatedSession.capabilities.manageRoles,false);
 directory=(await f.request('/admin/api/customers',{headers:buyer.headers})).json();assert.ok(directory.customers.every(row=>row.canManageRole===false));
 assert.equal((await f.patch(owner.user.customerId,buyer,{role:'customer',version:1})).status,403);
 assert.equal((await f.patch(buyer.user.customerId,buyer,{role:'customer',version:2})).status,403);
 const changed=await f.request('/admin/api/products/fixture-product',{method:'PATCH',headers:{...buyer.headers,'content-type':'application/json'},body:JSON.stringify({version:1,name:'Delegated admin edit'})});assert.equal(changed.status,200);
 const revoked=await f.patch(buyer.user.customerId,owner,{role:'customer',version:2});assert.equal(revoked.status,200);assert.equal(revoked.json().roleVersion,3);
 for(const path of ['/admin','/admin.html','/admin.js','/admin.css',api,'/admin/api/products','/admin/api/customers','/admin/api/orders','/admin/api/audit'])assert.equal((await f.request(path,{headers:buyer.headers})).status,403,path);
 for(const [method,path] of [['PATCH','/admin/api/products/fixture-product'],['PATCH','/admin/api/orders/fixture-order'],['PATCH','/admin/api/customers/'+owner.user.customerId+'/role'],['POST','/admin/api/products/fixture-product/image'],['POST','/admin/api/stock/preview'],['POST','/admin/api/stock/apply']])assert.equal((await f.request(path,{method,headers:{...buyer.headers,'content-type':'application/json'},body:'{}'})).status,403,path);
 assert.equal((await f.request('/auth/session',{headers:buyer.headers})).json().user.customerId,buyer.user.customerId);
 assert.ok(await f.customers.getCustomer(buyer.user.customerId));
 const entries=(await f.audit()).filter(entry=>entry.entityType==='customer_role');assert.equal(entries.length,2);
 for(const entry of entries){assert.equal(entry.actorId,'google:owner');assert.equal(entry.entityId,buyer.user.customerId);assert.deepEqual(Object.keys(entry.after).sort(),['id','role','version']);assert.equal(JSON.stringify(entry).includes('@'),false);}
});

test('role API enforces owner, CSRF, origin, exact body, valid UUID, allowed role and protected bootstrap targets',async t=>{
 const f=await setup(t,{adminPolicy:{emails:[ownerEmail,'legacy@example.invalid'],ownerEmail}});
 const owner=await f.login('owner'),legacy=await f.login('legacy'),buyer=await f.login('buyer');
 assert.equal((await f.request('/admin/api/session',{headers:legacy.headers})).json().capabilities.manageRoles,false);
 assert.equal((await f.patch(buyer.user.customerId,legacy,{role:'admin',version:1})).status,403);
 for(const headers of [{'x-csrf-token':'bad'},{origin:'https://evil.invalid'},{origin:''}])assert.equal((await f.patch(buyer.user.customerId,owner,{role:'admin',version:1},headers)).status,403);
 for(const body of [{role:'owner',version:1},{role:'admin'},{version:1},{role:'admin',version:'1'},{role:'admin',version:0},{role:'admin',version:1,actorId:'google:owner'},{role:'admin',version:1,email:ownerEmail}])assert.equal((await f.patch(buyer.user.customerId,owner,body)).status,400,JSON.stringify(body));
 assert.equal((await f.patch('bad-id',owner,{role:'admin',version:1})).status,400);
 assert.equal((await f.patch('12345678-1234-4123-8123-123456789abc',owner,{role:'admin',version:1})).status,404);
 for(const protectedUser of [owner,legacy])assert.equal((await f.patch(protectedUser.user.customerId,owner,{role:'customer',version:1})).status,403);
 assert.deepEqual(await f.roleRow(buyer.user.customerId),{admin_role:'customer',role_revision:1});assert.equal((await f.audit()).length,0);
 assert.equal((await f.request('/admin/api/session',{headers:owner.headers})).status,200);
});

test('multiple bootstrap administrators without an explicit owner retain access but cannot manage roles',async t=>{
 const f=await setup(t,{adminPolicy:{emails:[ownerEmail,'legacy@example.invalid']}});
 const owner=await f.login('owner'),buyer=await f.login('buyer');
 assert.equal((await f.request('/admin/api/session',{headers:owner.headers})).json().capabilities.manageRoles,false);
 assert.equal((await f.patch(buyer.user.customerId,owner,{role:'admin',version:1})).status,403);
 const rows=(await f.request('/admin/api/customers',{headers:owner.headers})).json().customers;assert.ok(rows.every(row=>row.canManageRole===false));
});

test('delegation is bound to provider subject plus UUID; registration and email changes never overwrite or copy roles',async t=>{
 const f=await setup(t),owner=await f.login('owner'),first=await f.login('first','shared@example.invalid'),second=await f.login('second','shared@example.invalid');
 assert.notEqual(first.user.customerId,second.user.customerId);
 assert.equal((await f.patch(first.user.customerId,owner,{role:'admin',version:1})).status,200);
 assert.equal((await f.request('/admin/api/session',{headers:first.headers})).status,200);
 assert.equal((await f.request('/admin/api/session',{headers:second.headers})).status,403);
 await assert.rejects(f.customers.getAdminAccess({...second.user,customerId:first.user.customerId},policy),error=>error.status===403);
 await assert.rejects(f.customers.getAdminAccess({...first.user,id:'google:second'},policy),error=>error.status===403);
 await assert.rejects(f.customers.updateCustomerRole(second.user.customerId,1,'admin',{...first.user,email:ownerEmail},policy),error=>error.status===403);
 const firstAgain=await f.login('first','changed@example.invalid');assert.equal(firstAgain.user.customerId,first.user.customerId);
 assert.equal((await f.request('/admin/api/session',{headers:firstAgain.headers})).status,200);
 assert.deepEqual(await f.roleRow(first.user.customerId),{admin_role:'admin',role_revision:2});
 assert.equal((await f.request('/admin/api/session',{headers:first.headers})).status,403);
 const third=await f.login('third','shared@example.invalid');assert.equal((await f.request('/admin/api/session',{headers:third.headers})).status,403);
 const upserted=await f.customers.upsertVerifiedGoogleUser({...identity('third','shared@example.invalid'),role:'admin',admin_role:'admin',role_revision:99});
 assert.deepEqual(await f.roleRow(upserted.id),{admin_role:'customer',role_revision:1});
});

test('role revision conflicts and audit failures leave role changes atomic; repeated initialization preserves grants',async t=>{
 const f=await setup(t),owner=await f.login('owner'),buyer=await f.login('buyer');
 const results=await Promise.all([f.patch(buyer.user.customerId,owner,{role:'admin',version:1}),f.patch(buyer.user.customerId,owner,{role:'admin',version:1})]);
 assert.deepEqual(results.map(result=>result.status).sort(),[200,409]);assert.equal((await f.audit()).length,1);
 assert.equal((await f.patch(buyer.user.customerId,owner,{role:'customer',version:1})).status,409);
 assert.equal((await f.patch(buyer.user.customerId,owner,{role:'admin',version:2})).status,409);
 f.failAudit();const failed=await f.patch(buyer.user.customerId,owner,{role:'customer',version:2});assert.equal(failed.status,500);assert.equal(failed.text.includes('Injected'),false);f.failAudit(false);
 assert.deepEqual(await f.roleRow(buyer.user.customerId),{admin_role:'admin',role_revision:2});assert.equal((await f.audit()).length,1);
 await f.store.initialize([]);assert.deepEqual(await f.roleRow(buyer.user.customerId),{admin_role:'admin',role_revision:2});
 assert.deepEqual((await f.pool.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(row=>row.version),[1,2,3,4,5,6,7,8]);
});

test('database lookup failure closes all protected routes for bootstrap and delegated existing sessions',async t=>{
 const f=await setup(t),owner=await f.login('owner'),buyer=await f.login('buyer');
 assert.equal((await f.patch(buyer.user.customerId,owner,{role:'admin',version:1})).status,200);
 f.failLookup();
 for(const actor of [owner,buyer])for(const path of ['/admin','/admin.js','/admin/api/session','/admin/api/products','/admin/api/customers']){const result=await f.request(path,{headers:actor.headers});assert.equal(result.status,503,path);assert.equal(result.text.includes('Private'),false);}
 assert.equal((await f.patch(buyer.user.customerId,owner,{role:'customer',version:2})).status,503);
 assert.equal((await f.request('/auth/session',{headers:buyer.headers})).status,200);
 f.failLookup(false);assert.equal((await f.request('/admin/api/session',{headers:buyer.headers})).status,200);assert.equal((await f.audit()).length,1);
});

test('migration 7 to 8 gives existing customers no grants and preserves existing commerce records and audits',async t=>{
 const oldCustomerId='12345678-1234-4123-8123-123456789abc';let before;
 const f=await setup(t,{async beforeInitialize(pool){
  for(const name of ['001_admin','002_product_images','003_customers','004_order_model','005_cod_checkout','006_guest_checkout','007_order_numbers'])await pool.query(await readFile(new URL('../migrations/'+name+'.sql',import.meta.url),'utf8'));
  await pool.query("INSERT INTO commerce_customers(id,provider,subject,email,name) VALUES($1,'google','preexisting','old@example.invalid','Existing Customer')",[oldCustomerId]);
  await pool.query('INSERT INTO admin_products(id,document,revision) VALUES($1,$2::jsonb,4)',['preexisting-product',JSON.stringify({name:'Existing Product',priceMinor:200,stockQuantity:9,available:true})]);
  await pool.query('INSERT INTO admin_orders(id,document) VALUES($1,$2::jsonb)',['preexisting-order',JSON.stringify({note:'Existing order'})]);
  await pool.query("INSERT INTO admin_audit(entity_type,entity_id,actor_id,before_snapshot,after_snapshot) VALUES('product','preexisting-product','google:old-owner','{}'::jsonb,'{}'::jsonb)");
  before={customer:(await pool.query('SELECT * FROM commerce_customers WHERE id=$1',[oldCustomerId])).rows[0],product:(await pool.query('SELECT * FROM admin_products WHERE id=$1',['preexisting-product'])).rows[0],order:(await pool.query('SELECT * FROM admin_orders WHERE id=$1',['preexisting-order'])).rows[0],audit:(await pool.query('SELECT * FROM admin_audit')).rows};
 }});
 const {admin_role,role_revision,...afterCustomer}=(await f.pool.query('SELECT * FROM commerce_customers WHERE id=$1',[oldCustomerId])).rows[0];
 assert.equal(admin_role,'customer');assert.equal(role_revision,1);assert.deepEqual(afterCustomer,before.customer);
 assert.deepEqual((await f.pool.query('SELECT * FROM admin_products WHERE id=$1',['preexisting-product'])).rows[0],before.product);
 assert.deepEqual((await f.pool.query('SELECT * FROM admin_orders WHERE id=$1',['preexisting-order'])).rows[0],before.order);
 assert.deepEqual((await f.pool.query('SELECT * FROM admin_audit')).rows,before.audit);
 const existing=await f.login('preexisting','old@example.invalid');assert.equal((await f.request('/admin/api/session',{headers:existing.headers})).status,403);
});
