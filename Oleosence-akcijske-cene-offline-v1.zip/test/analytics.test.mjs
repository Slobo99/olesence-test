import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import http from 'node:http';
import {JSDOM} from 'jsdom';
import {analyticsScript,analyticsHash,analyticsCsp,renderAnalytics} from '../src/analytics.mjs';
import {createHostedServer} from '../server.mjs';
const key='olesence.analytics-consent.v1';
async function browser(t,{url='https://olesence.rs/',saved,storageFails=false,productPath}={}){
 const dom=new JSDOM(renderAnalytics(Buffer.from('<html><head><title>Private title</title></head><body><input name="email" value="private@example.invalid"></body></html>')).toString(),{url,runScripts:'outside-only'});
 const w=dom.window;t.after(()=>w.close());
 await new Promise(r=>w.document.readyState==='complete'?r():w.addEventListener('load',r,{once:true}));
 if(saved!==undefined)w.localStorage.setItem(key,typeof saved==='string'?saved:JSON.stringify(saved));
 if(storageFails)Object.defineProperty(w,'localStorage',{get(){throw Error('blocked');}});
 if(productPath)w.document.documentElement.setAttribute('data-public-product',productPath);
 w.eval(analyticsScript);
 return {w,d:w.document,commands:()=>Array.from(w.dataLayer||[],x=>Array.from(x)),accept:()=>w.document.getElementById('analytics-accept').click(),decline:()=>w.document.getElementById('analytics-decline').click()};
}
test('inline initialization has exact SHA-256 in both policies and no unsafe directives',()=>{
 assert.equal(analyticsHash,'sha256-'+createHash('sha256').update(analyticsScript).digest('base64'));
 const html=renderAnalytics(Buffer.from('<html><head><meta http-equiv="Content-Security-Policy" content="old"></head><body></body></html>')).toString();
 const d=new JSDOM(html).window.document;
 assert.equal(d.querySelectorAll('meta[http-equiv="Content-Security-Policy"]').length,1);
 assert.ok(d.querySelector('meta[http-equiv]').content.includes("'"+analyticsHash+"'"));
 assert.equal(d.querySelector('#olesence-analytics-init').textContent,analyticsScript);
 assert.ok(!analyticsCsp.includes('unsafe-inline'));assert.ok(!analyticsCsp.includes('unsafe-eval'));
 assert.ok(analyticsCsp.includes("frame-ancestors 'none'"));assert.ok(analyticsCsp.includes("object-src 'none'"));
});
test('no Google request, event or analytic cookie before consent',async t=>{
 const {w,d,commands}=await browser(t);
 assert.equal(d.querySelectorAll('script[src]').length,0);assert.equal(d.cookie,'');
 assert.equal(d.getElementById('analytics-consent').hidden,false);assert.equal(w['ga-disable-G-105CEG84DT'],true);
 assert.equal(commands().filter(c=>c[0]==='config'||c[0]==='event').length,0);
 assert.equal(commands()[0][2].analytics_storage,'denied');
});
test('decline is persistent and never loads Google',async t=>{
 const {w,d,decline}=await browser(t);decline();
 assert.equal(JSON.parse(w.localStorage.getItem(key)).value,'denied');assert.equal(d.querySelectorAll('script[src]').length,0);
 assert.equal(d.getElementById('analytics-consent').hidden,true);
 const returning=await browser(t,{saved:{value:'denied',at:Date.now()}});assert.equal(returning.d.querySelectorAll('script[src]').length,0);assert.equal(returning.d.getElementById('analytics-consent').hidden,true);
});
test('accept loads correct tag once and tracks one sanitized page view',async t=>{
 const {w,d,accept,commands}=await browser(t,{url:'https://olesence.rs/proizvod/crni-kim?order=private-order&email=private@example.invalid#private-token'});accept();accept();
 assert.equal(d.querySelectorAll('#olesence-google-tag').length,1);assert.equal(d.querySelector('#olesence-google-tag').src,'https://www.googletagmanager.com/gtag/js?id=G-105CEG84DT');
 const events=commands().filter(c=>c[0]==='event');assert.equal(events.length,1);assert.equal(events[0][1],'page_view');
 const cfg=commands().find(c=>c[0]==='config')[2];assert.equal(cfg.page_location,'https://olesence.rs/proizvod/crni-kim');assert.equal(cfg.page_referrer,'');assert.equal(cfg.page_title,'Ulje crnog kima');assert.equal(cfg.send_page_view,false);assert.equal(cfg.allow_google_signals,false);
 assert.ok(!JSON.stringify(commands()).includes('private'));assert.equal(w['ga-disable-G-105CEG84DT'],false);
});
test('saved consent starts only on public catalogue pages; private customer pages stay untracked',async t=>{
 for(const p of ['/','/proizvod/crni-kim','/proizvod/divlji-origano','/proizvod/cetiri-lopova','/account','/account.html','/checkout','/checkout.html']){
  const {d,commands}=await browser(t,{url:'https://olesence.rs'+p,saved:{value:'granted',at:Date.now()}});
  const expected=/^\/(account|checkout)/.test(p)?0:1;
  assert.equal(d.querySelectorAll('#olesence-google-tag').length,expected,p);assert.equal(commands().filter(c=>c[0]==='event').length,expected);
 }
});
test('expiry, invalid and future-dated records fail closed',async t=>{
 for(const saved of ['broken',{value:'granted',at:0},{value:'granted',at:Date.now()+100000},{value:'yes',at:Date.now()}]){
  const {d}=await browser(t,{saved});assert.equal(d.querySelectorAll('script[src]').length,0);assert.equal(d.getElementById('analytics-consent').hidden,false);
 }
});
test('blocked storage does not break consent or the page',async t=>{
 const {d,accept}=await browser(t,{storageFails:true});accept();assert.equal(d.querySelectorAll('#olesence-google-tag').length,1);
});
test('withdrawal disables collection, clears GA cookies, preserves unrelated cookies and allows changing choice',async t=>{
 const {w,d,accept,decline}=await browser(t);accept();d.cookie='_ga=sample; Path=/; Secure';d.cookie='essential=keep; Path=/; Secure';
 d.getElementById('analytics-settings').click();assert.equal(d.getElementById('analytics-consent').hidden,false);decline();
 assert.equal(w['ga-disable-G-105CEG84DT'],true);assert.ok(!d.cookie.includes('_ga='));assert.ok(d.cookie.includes('essential=keep'));
 accept();assert.equal(d.querySelectorAll('#olesence-google-tag').length,1);assert.equal(w['ga-disable-G-105CEG84DT'],false);
});
test('revocation in another tab stops analytics',async t=>{
 const {w,accept}=await browser(t);accept();w.dispatchEvent(new w.StorageEvent('storage',{key,newValue:JSON.stringify({value:'denied',at:Date.now()})}));assert.equal(w['ga-disable-G-105CEG84DT'],true);
});
test('preview, localhost, admin and OAuth do not initialize tracking',async t=>{
 for(const url of ['https://oleosence-login-test.onrender.com/','http://localhost/','https://olesence.rs/admin','https://olesence.rs/auth/google/callback?code=secret']){
  const {w,d}=await browser(t,{url,saved:{value:'granted',at:Date.now()}});assert.equal(w.gtag,undefined);assert.equal(d.querySelectorAll('script[src]').length,0);
 }
});
test('server delivers matching header/meta policies and head tag on all customer pages; APIs and private routes remain strict',async t=>{
 const app=await createHostedServer({config:{origin:'https://olesence.rs',host:'olesence.rs',auth:null}});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));t.after(()=>app.close());
 const get=(path,method='GET')=>new Promise((resolve,reject)=>{const q=http.request({hostname:'127.0.0.1',port:app.server.address().port,path,method,headers:{host:'olesence.rs','x-forwarded-proto':'https'}},r=>{let body='';r.on('data',x=>body+=x);r.on('end',()=>resolve({status:r.statusCode,headers:r.headers,body}));});q.on('error',reject);q.end();});
 for(const path of ['/','/proizvod/crni-kim','/proizvod/divlji-origano','/proizvod/cetiri-lopova','/account','/account.html','/checkout','/checkout.html']){
  const r=await get(path);assert.equal(r.status,200);const d=new JSDOM(r.body).window.document;assert.equal(d.head.querySelectorAll('#olesence-analytics-init').length,1,path);assert.equal(r.headers['content-security-policy'],analyticsCsp);assert.ok(d.querySelector('meta[http-equiv]').content.includes(analyticsHash));assert.equal(d.querySelectorAll('#analytics-consent').length,1);
  const head=await get(path,'HEAD');assert.equal(head.body,'');assert.equal(head.headers['content-security-policy'],analyticsCsp);
 }
 for(const path of ['/api/catalog','/auth/session','/admin']){const r=await get(path);assert.ok(!r.body.includes('olesence-analytics-init'));assert.ok(!r.headers['content-security-policy'].includes('googletagmanager'));}
 assert.equal((await get('/analytics.css')).status,200);assert.equal((await get('/analytics-init.js')).status,404);
});

test('clearing consent storage in another tab revokes analytics',async t=>{const {w,accept}=await browser(t);accept();w.dispatchEvent(new w.StorageEvent('storage',{key:null,newValue:null}));assert.equal(w['ga-disable-G-105CEG84DT'],true);});

 test('dynamic product analytics requires a matching server marker and keeps private context out',async t=>{
  const url='https://olesence.rs/proizvod/novo-ulje?email=private@example.invalid#secret';
  for(const productPath of [undefined,'/proizvod/other']){const b=await browser(t,{url,productPath,saved:{value:'granted',at:Date.now()}});assert.equal(b.d.querySelectorAll('#olesence-google-tag').length,0);}
  const b=await browser(t,{url,productPath:'/proizvod/novo-ulje'});assert.equal(b.d.querySelectorAll('#olesence-google-tag').length,0);b.accept();
  const events=b.commands().filter(c=>c[0]==='event');assert.equal(events.length,1);assert.equal(events[0][2].page_location,'https://olesence.rs/proizvod/novo-ulje');assert.equal(events[0][2].page_title,'Olesence proizvod');assert.ok(!JSON.stringify(b.commands()).includes('private'));
 });
