import {homeMarkup} from '../public/home-view.js';
import {productMarkup,productStructuredData,safeJson,card,productImage} from '../public/product-view.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
import {products as catalog,settings,normalizeCart,formatMoney,quoteCart} from '../public/catalog.js';
import {slides,normalizeSlide,slideForKey} from '../public/slider.js';
import {faqItems} from '../public/faq.js';
const html=await readFile(new URL('../public/index.html',import.meta.url),'utf8');
const css=await readFile(new URL('../public/styles.css',import.meta.url),'utf8');
const source=(await readFile(new URL('../public/app.js',import.meta.url),'utf8')).replace(/^import .*;\n/gm,'');
const cartKey='olesence-preview-cart';
const tick=()=>new Promise(resolve=>setTimeout(resolve,5));
const response=(body,status=200)=>({ok:status>=200&&status<300,status,json:async()=>body});
async function fixture(t,{path='/',cart=[{id:'crni-kim',quantity:2}],products=catalog,enabled=true,hold=null}={}){
 const dom=new JSDOM(html,{url:`https://shop.example.test${path}`,runScripts:'outside-only'}),w=dom.window;
 await new Promise(resolve=>w.addEventListener('load',resolve,{once:true}));t.after(()=>w.close());
 w.localStorage.setItem(cartKey,JSON.stringify(cart));
 const state={calls:[],session:{enabled,guest:enabled,user:null},hold,fail:false};
 w.fetch=async(path,options={})=>{state.calls.push({path,options});assert.equal(path,'/api/checkout/session');assert.equal(options.method,undefined);if(state.fail)throw new Error('Synthetic network failure');if(state.hold)return state.hold;return response(state.session);};
 w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};
 Object.assign(w,{productMarkup,productStructuredData,safeJson,card,productImage,homeMarkup,products,settings,normalizeCart,formatMoney,quoteCart,slides,normalizeSlide,slideForKey,faqItems});
 w.watchCatalogPrices=()=>{};vm.runInContext(source,dom.getInternalVMContext());await tick();
 return {w,state,$:selector=>w.document.querySelector(selector),document:w.document};
}
function assertActions(document,enabled,{empty=false}={}){
 const actions=[...document.querySelector('.cart-actions').children];assert.equal(actions.length,2);assert.deepEqual(actions.map(node=>node.textContent),['Nastavi kupovinu','Završi kupovinu']);
 assert.ok(actions.every(node=>node.classList.contains('button')));assert.equal(actions[0].tagName,'A');assert.equal(actions[0].getAttribute('href'),'/#kolekcija');
 if(empty){assert.equal(actions[1].tagName,'A');assert.equal(actions[1].getAttribute('href'),'/');assert.equal(actions[1].hasAttribute('data-empty-cart-home'),true);assert.equal(actions[1].closest('form'),null);assert.equal(actions[1].hasAttribute('disabled'),false);assert.equal(document.querySelector('[data-checkout-link]'),null);}
 else if(enabled){assert.equal(actions[1].tagName,'A');assert.equal(actions[1].getAttribute('href'),'/checkout');assert.equal(actions[1].closest('form'),null);}
 else{assert.equal(actions[1].tagName,'BUTTON');assert.equal(actions[1].type,'button');assert.equal(actions[1].disabled,true);assert.equal(actions[1].hasAttribute('href'),false);}
 return actions;
}
test('cart: header quantity is total units and accessible name follows add, quantity edits and removals',async t=>{
 const {w,$,state}=await fixture(t,{path:'/proizvod/crni-kim',cart:[{id:'crni-kim',quantity:2},{id:'cetiri-lopova',quantity:3}]});
 const assertCount=count=>{assert.equal($('#cart-count').textContent,String(count));assert.equal($('[data-cart]').getAttribute('aria-label'),`Otvori korpu. Ukupna količina: ${count}.`);};
 assertCount(5);assert.equal($('[data-cart]').type,'button');assert.equal($('[data-cart]').getAttribute('aria-haspopup'),'dialog');assert.equal($('[data-cart]').getAttribute('aria-controls'),'cart');assert.equal($('[data-cart] svg').getAttribute('aria-hidden'),'true');assert.equal($('[data-cart] svg').querySelectorAll('circle').length,2);
 $('[data-add="crni-kim"]').click();assertCount(6);$('[data-change="crni-kim"][data-step="1"]').click();assertCount(7);$('[data-change="crni-kim"][data-step="-1"]').click();assertCount(6);$('[data-remove="cetiri-lopova"]').click();assertCount(3);$('[data-remove="crni-kim"]').click();assertCount(0);assert.deepEqual(JSON.parse(w.localStorage.getItem(cartKey)),[]);assert.ok(state.calls.every(call=>call.path==='/api/checkout/session'&&!call.options.method));
});
test('cart: action order and native collection navigation close drawer without changing items',async t=>{
 const {w,$,document}=await fixture(t);const before=w.localStorage.getItem(cartKey),[keepShopping]=assertActions(document,true);
 $('[data-cart]').click();assert.equal($('#cart').open,true);keepShopping.click();await tick();assert.equal($('#cart').open,false);assert.equal(w.location.pathname,'/');assert.equal(w.location.hash,'#kolekcija');assert.ok($('#kolekcija'));assert.equal(w.localStorage.getItem(cartKey),before);assert.equal($('#cart-count').textContent,'2');
 $('[data-cart]').click();assert.equal($('#cart').open,true);assert.equal($('.cart-item h3').textContent,catalog[0].name);assert.equal($('.quantity span').textContent,'2');
});
test('cart: product-page continue link targets the collection, permits native navigation and retains storage',async t=>{
 const {w,$,document}=await fixture(t,{path:'/proizvod/crni-kim'});const before=w.localStorage.getItem(cartKey),[keepShopping]=assertActions(document,true);$('[data-cart]').click();let nativeAllowed=false;
 // JSDOM has no cross-document navigation; observe its native destination without replacing production behavior.
 document.addEventListener('click',event=>{if(event.target===keepShopping){nativeAllowed=!event.defaultPrevented;event.preventDefault();}},{once:true});keepShopping.click();
 assert.equal(nativeAllowed,true);assert.equal(keepShopping.href,'https://shop.example.test/#kolekcija');assert.equal($('#cart').open,false);assert.equal(w.localStorage.getItem(cartKey),before);
});
test('cart: finish is navigation to checkout details only, never an order submission',async t=>{
 const {w,$,document,state}=await fixture(t),before=w.localStorage.getItem(cartKey),[,checkout]=assertActions(document,true);let nativeAllowed=false;
 document.addEventListener('click',event=>{if(event.target===checkout){nativeAllowed=!event.defaultPrevented;event.preventDefault();}},{once:true});checkout.click();await tick();
 assert.equal(nativeAllowed,true);assert.equal(checkout.href,'https://shop.example.test/checkout');assert.equal(w.localStorage.getItem(cartKey),before);assert.match($('.cart-summary .microcopy').textContent,/podaci za dostavu i pregled iznosa pre potvrde porudžbine/);assert.equal(state.calls.length,1);assert.equal(state.calls[0].path,'/api/checkout/session');assert.equal($('#cart form'),null);
});
test('cart: disabled capability, failed check and pending bootstrap cannot expose checkout link',async t=>{
 let resolve;const {w,state,document,$}=await fixture(t,{hold:new Promise(done=>resolve=done)});assertActions(document,false);assert.equal($('[href="/checkout"]'),null);
 resolve(response({enabled:false,user:null}));await tick();assertActions(document,false);assert.match($('.cart-summary .microcopy').textContent,/Poručivanje trenutno nije dostupno/);
 state.hold=null;state.session={enabled:true};w.dispatchEvent(new w.Event('pageshow'));await tick();assertActions(document,true);
 state.fail=true;w.dispatchEvent(new w.Event('pageshow'));assertActions(document,false);await tick();assertActions(document,false);assert.equal($('[href="/checkout"]'),null);
});
test('cart: late stale enabled response cannot override a newer disabled check',async t=>{
 const {w,state,document}=await fixture(t);let resolve;state.hold=new Promise(done=>resolve=done);w.dispatchEvent(new w.Event('pageshow'));assertActions(document,false);
 state.hold=null;state.session={enabled:false};w.dispatchEvent(new w.Event('pageshow'));await tick();resolve(response({enabled:true}));await tick();assertActions(document,false);
});
for(const path of ['/', '/#kolekcija', '/proizvod/crni-kim'])for(const enabled of [true,false])test(`cart: empty finish returns home from ${path} with checkout ${enabled?'enabled':'disabled'}`,async t=>{
 const {w,$,document,state}=await fixture(t,{path,cart:[],enabled});const [,finish]=assertActions(document,enabled,{empty:true});assert.equal($('#cart-count').textContent,'0');assert.match($('.empty-cart').textContent,/Vaša korpa je prazna/);$('[data-cart]').click();assert.equal($('#cart').open,true);let nativeAllowed=false;
 // JSDOM does not implement cross-document navigation. Inspect the real link and observe the native click destination.
 document.addEventListener('click',event=>{if(event.target===finish){nativeAllowed=!event.defaultPrevented;event.preventDefault();}},{once:true});finish.click();await tick();
 assert.equal(nativeAllowed,true);assert.equal(finish.href,'https://shop.example.test/');assert.equal($('#cart').open,false);assert.deepEqual(JSON.parse(w.localStorage.getItem(cartKey)),[]);assert.equal(state.calls.length,1);assert.equal(state.calls[0].path,'/api/checkout/session');assert.equal($('#cart form'),null);
});
test('cart: last quantity reduced to zero routes finish home; adding again restores checkout',async t=>{
 const {w,$,document,state}=await fixture(t,{path:'/proizvod/crni-kim',cart:[{id:'crni-kim',quantity:1}]});assertActions(document,true);$('[data-cart]').click();$('[data-change="crni-kim"][data-step="-1"]').click();
 assert.equal($('#cart-count').textContent,'0');assert.equal($('.cart-item'),null);assert.deepEqual(JSON.parse(w.localStorage.getItem(cartKey)),[]);assertActions(document,true,{empty:true});assert.equal(document.activeElement,$('#cart [data-close]'));
 $('[data-close]').click();$('[data-add="crni-kim"]').click();$('[data-cart]').click();assert.equal($('#cart-count').textContent,'1');assert.deepEqual(JSON.parse(w.localStorage.getItem(cartKey)),[{id:'crni-kim',quantity:1}]);assertActions(document,true);assert.equal($('[data-empty-cart-home]'),null);assert.equal(state.calls.length,1);
});
test('cart: removing one of several products keeps checkout; removing the last routes home',async t=>{
 const {w,$,document}=await fixture(t,{cart:[{id:'crni-kim',quantity:1},{id:'cetiri-lopova',quantity:1}]});$('[data-change="crni-kim"][data-step="-1"]').click();assertActions(document,true);assert.equal($('#cart-count').textContent,'1');$('[data-remove="cetiri-lopova"]').click();assertActions(document,true,{empty:true});assert.deepEqual(JSON.parse(w.localStorage.getItem(cartKey)),[]);
});
test('cart: empty finish stays a home link during pending and failed availability checks',async t=>{
 let resolve;const {w,state,document}=await fixture(t,{cart:[],hold:new Promise(done=>resolve=done)});assertActions(document,false,{empty:true});resolve(response({enabled:true}));await tick();assertActions(document,true,{empty:true});state.hold=null;state.fail=true;w.dispatchEvent(new w.Event('pageshow'));assertActions(document,false,{empty:true});await tick();assertActions(document,false,{empty:true});
});
test('cart: empty continue action still targets the collection and closes drawer',async t=>{
 const {w,$,document}=await fixture(t,{cart:[]});const [keepShopping]=assertActions(document,true,{empty:true});$('[data-cart]').click();keepShopping.click();await tick();assert.equal($('#cart').open,false);assert.equal(w.location.hash,'#kolekcija');assert.deepEqual(JSON.parse(w.localStorage.getItem(cartKey)),[]);
});
test('cart: malicious product display values and invalid stored items remain inert',async t=>{
 const hostile='"><img src=x onerror=alert(1)><script>alert(1)</script>',products=catalog.map(p=>p.id===catalog[0].id?{...p,name:hostile,volume:hostile}:p);
 const {document,$}=await fixture(t,{products,cart:[{id:catalog[0].id,quantity:1},{id:hostile,quantity:100}]});assert.equal($('#cart-count').textContent,'1');assert.equal($('.cart-item h3').textContent,hostile);assert.equal($('.cart-item img').getAttribute('alt'),hostile);assert.equal(document.querySelector('#cart [onerror], #cart script, #cart img[src=x]'),null);assertActions(document,true);
});
test('cart: contrast, focus, badge and stacked action styles are retained with compact mobile controls',async t=>{
 const {w,$,document}=await fixture(t),style=document.createElement('style');style.textContent=css;document.head.append(style);
 const trigger=w.getComputedStyle($('[data-cart]')),badge=w.getComputedStyle($('#cart-count')),actions=w.getComputedStyle($('.cart-actions'));
 assert.equal(trigger.minHeight,'48px');assert.equal(trigger.flexShrink,'0');assert.equal(trigger.fontWeight,'700');assert.match(css,/header \.cart-open\{[^}]*background:var\(--olive\);color:#fff/);assert.match(css,/--olive:#48523a/);assert.equal(trigger.color,'rgb(255, 255, 255)');assert.equal(badge.minWidth,'28px');assert.equal(badge.color,'rgb(32, 44, 34)');assert.equal(actions.display,'grid');assert.equal(actions.gridTemplateColumns,'1fr');assert.equal(actions.gap,'12px');
 for(const action of document.querySelectorAll('.cart-actions .button')){const computed=w.getComputedStyle(action);assert.equal(computed.minHeight,'50px');assert.equal(computed.width,'100%');assert.equal(computed.justifyContent,'center');}
 assert.match(css,/header \.cart-open:hover\{background:#303d2b;border-color:#303d2b\}/);assert.match(css,/header \.cart-open:focus-visible\{outline:3px solid #202c22;outline-offset:3px/);
 assert.match(css,/@media\(max-width:900px\)\{header \.cart-open\{padding:9px;gap:8px\}header \.cart-open>span\{display:none\}\}/);
 // Only the word label collapses on narrow screens; the SVG and count keep explicit sizes.
 assert.match(css,/header \.cart-open svg\{flex:none;width:24px;height:24px\}/);assert.equal($('[data-cart] svg').hasAttribute('hidden'),false);assert.equal($('#cart-count').hasAttribute('hidden'),false);
});

test('cart: mobile CSS keeps the word label, 44px controls, contained images and safe scrolling; checkout fields and receipts fit',async t=>{
 const {document,w,$}=await fixture(t),style=document.createElement('style');style.textContent=css;document.head.append(style);
 // JSDOM has no layout engine or viewport media evaluation. Apply matching CSS rules at 360px to inspect the real mobile declarations only.
 const mobileRules=sheet=>[...sheet.cssRules].flatMap(rule=>rule.media?(/max-width:\s*(\d+)px/.exec(rule.conditionText)?.[1]>=360?[...rule.cssRules].map(n=>n.cssText):[]):rule.cssText.startsWith('@')?[]:[rule.cssText]).join('\n');
 const mobile=document.createElement('style');mobile.textContent=mobileRules(style.sheet);document.head.append(mobile);
 assert.equal(w.getComputedStyle($('[data-cart]>span')).display,'inline');assert.equal(w.getComputedStyle($('[data-cart]')).minHeight,'48px');assert.equal(w.getComputedStyle($('#cart')).overflowY,'auto');
 for(const selector of ['#cart .quantity button','#cart .remove','#cart .icon']){const computed=w.getComputedStyle($(selector));assert.equal(computed.minWidth,'44px');assert.equal(computed.minHeight,'44px');}
 assert.equal(w.getComputedStyle($('.cart-item img')).objectFit,'contain');assert.equal(w.getComputedStyle($('.cart-item>div')).overflowWrap,'anywhere');assert.equal(w.getComputedStyle($('.cart-item')).gridTemplateColumns,'68px minmax(0,1fr)');assert.equal(w.getComputedStyle($('.cart-actions')).gridTemplateColumns,'1fr');assert.match(css,/env\(safe-area-inset-bottom\)/);
 const checkoutCss=await readFile(new URL('../public/checkout.css',import.meta.url),'utf8'),baseCss=await readFile(new URL('../public/test-shop.css',import.meta.url),'utf8'),checkoutHtml=await readFile(new URL('../public/checkout.html',import.meta.url),'utf8');
 const checkout=new JSDOM(checkoutHtml,{url:'https://shop.example.test/checkout'});t.after(()=>checkout.window.close());const c=checkout.window.document;
 const controls=c.createElement('div');controls.className='cart-row-controls';const quantity=c.createElement('button');quantity.className='quantity-button';const remove=c.createElement('button');remove.className='remove-item';controls.append(quantity,remove);c.querySelector('#checkout-cart').append(controls);
 const allStyle=c.createElement('style');allStyle.textContent=baseCss+'\n'+checkoutCss;c.head.append(allStyle);const narrowStyle=c.createElement('style');narrowStyle.textContent=mobileRules(allStyle.sheet);c.head.append(narrowStyle);const computed=node=>checkout.window.getComputedStyle(node);
 assert.equal(computed(c.querySelector('[name=email]')).fontSize,'16px');assert.equal(computed(quantity).minWidth,'44px');assert.equal(computed(quantity).minHeight,'44px');assert.equal(computed(remove).minWidth,'44px');assert.equal(computed(remove).minHeight,'44px');assert.equal(computed(c.querySelector('#receipt')).overflowWrap,'anywhere');assert.equal(computed(c.querySelector('.pending-actions')).flexDirection,'column');assert.match(checkoutCss,/env\(safe-area-inset-bottom\)/);
});

 test('home navigation and slider omit unpublished legacy products and footer includes newly published ones',async t=>{
  const products=[{...catalog[0],id:'novo-ulje',name:'Novo ulje'}];const {document}=await fixture(t,{products,cart:[]});
  assert.equal(document.querySelectorAll('.hero-slide').length,1);assert.equal(document.querySelector('a[href="/proizvod/crni-kim"]'),null);
  assert.ok([...document.querySelectorAll('footer a')].some(a=>a.getAttribute('href')==='/proizvod/novo-ulje'));
 });

 test('category tabs follow published categories, deduplicate and safely filter hostile category text',async t=>{
  const category='Posebno \" onclick=\"bad()\"><img src=x onerror=bad()> & ulje';
  const products=[{...catalog[0],category},{...catalog[1],category},{...catalog[2],category:'Nova kategorija'}];
  const {document}=await fixture(t,{products,cart:[]});const tabs=[...document.querySelectorAll('[data-filter]')];
  assert.deepEqual(tabs.map(b=>b.textContent),['Sve',category,'Nova kategorija']);assert.equal(tabs[1].dataset.filter,category);assert.equal(document.querySelector('[onclick],[onerror]'),null);
  tabs[1].click();assert.equal(document.querySelectorAll('#products .product-card').length,2);assert.equal(tabs[1].getAttribute('aria-pressed'),'true');
  tabs[2].click();assert.equal(document.querySelectorAll('#products .product-card').length,1);tabs[0].click();assert.equal(document.querySelectorAll('#products .product-card').length,3);
 });
