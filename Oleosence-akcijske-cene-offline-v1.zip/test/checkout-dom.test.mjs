import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
const root=process.env.CHECKOUT_APP_ROOT||fileURLToPath(new URL('..',import.meta.url)).replace(/\/$/,'');
const require=createRequire(root+'/package.json');
const {JSDOM}=require('jsdom');
const {products,normalizeCart,formatMoney}=await import(pathToFileURL(root+'/public/catalog.js'));
const html=await readFile(root+'/public/checkout.html','utf8');
const source=(await readFile(root+'/public/checkout.js','utf8')).replace(/^import .*?;\n/,'');
const CART='olesence-preview-cart',PENDING='olesence-cod-pending-v1';
const quote={items:[{productId:'crni-kim',name:'Ulje crnog kima',quantity:1,unitPriceMinor:149000,lineTotalMinor:149000,productRevision:7}],subtotalMinor:149000,deliveryMinor:30000,totalMinor:179000,currency:'RSD',shipping:{method:'courier',isEstimate:false,deliveryMinor:30000,freeFromMinor:350000},paymentMethod:'cod'};
const contact={fullName:'Test Customer',email:'test@example.invalid',phone:'+381 111111',address:'Test 12',city:'Beograd',postalCode:'11000',country:'RS'};
const order={...quote,id:'COD-00000000-0000-4000-8000-000000000001',status:'pending',paymentStatus:'cod_due',inventoryStatus:'deducted',contact,createdAt:'2026-10-16T08:00:00Z'};
const response=(json,status=200)=>({ok:status>=200&&status<300,status,json:async()=>structuredClone(json)});
const until=async(predicate,message='Condition timed out')=>{for(let i=0;i<200;i++){if(predicate())return;await new Promise(r=>setTimeout(r,5));}assert.fail(message);};
async function fixture(t,{pending=null,session=null,orders=[],orderHandler=null,detail=order,url='https://shop.example.test/checkout'}={}){
 const dom=new JSDOM(html,{url,runScripts:'outside-only'}),w=dom.window;
 await new Promise(r=>w.addEventListener('load',r,{once:true}));
 const data={session:session||{enabled:true,user:{id:'google:test-user',name:contact.fullName,email:contact.email},csrfToken:'csrf-1',customerReady:true},calls:[],posts:[],orders,orderHandler,quoteHandler:null,detail};
 w.localStorage.setItem(CART,JSON.stringify([{id:'crni-kim',quantity:1}]));if(pending)w.sessionStorage.setItem(PENDING,pending);
 Object.defineProperty(w.crypto,'randomUUID',{value:()=> '00000000-0000-4000-8000-000000000002'});
 Object.assign(w,{products,normalizeCart,formatMoney});
 w.fetch=async(path,options={})=>{data.calls.push({path,options});
  if(path==='/api/checkout/session')return response(data.session);
  if(path==='/api/checkout/quote')return data.quoteHandler?data.quoteHandler(path,options):response(quote);
  if(path==='/api/checkout/orders'&&options.method==='POST'){assert.ok(w.sessionStorage.getItem(PENDING),'request persisted before POST');data.posts.push({path,options});return data.orderHandler?data.orderHandler(path,options):response({order,replayed:false});}
  if(path==='/api/checkout/orders')return response({orders:data.orders,nextCursor:null});
  if(path.startsWith('/api/checkout/orders/'))return response({order:data.detail});
  throw Error('Unexpected path '+path);
 };
 w.watchCatalogPrices=()=>{};vm.runInContext(source,dom.getInternalVMContext());await until(()=>!w.document.querySelector('#checkout-status').textContent.startsWith('Proveravamo'));
 t.after(()=>w.close());const $=selector=>w.document.querySelector(selector);
 const fill=()=>{for(const [key,value]of Object.entries(contact)){const input=$('#contact-form').elements[key];if(input)input.value=value;}};
 const prepare=async()=>{fill();$('#contact-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await until(()=>!$('#quote-panel').hidden||$('#checkout-status').classList.contains('error'));};
 const commit=()=>{$('#confirm-intent').checked=true;$('#confirm-intent').dispatchEvent(new w.Event('change'));$('#place-order').click();};
 return {w,data,$,fill,prepare,commit};
}
test('checkout disabled never requests history or accepts contact; cart survives',async t=>{const {data,$,w}=await fixture(t,{session:{enabled:false,user:null,customerReady:false}});assert.equal($('#checkout-workspace').hidden,true);assert.equal($('#account-link').hidden,true);assert.match($('#checkout-status').textContent,/nije dostupno/);assert.equal(data.calls.length,1);assert.equal(JSON.parse(w.localStorage.getItem(CART))[0].quantity,1);});
test('anonymous checkout uses actual account link and guidance without imitation Google login',async t=>{const {$}=await fixture(t,{session:{enabled:true,user:null,customerReady:false}});assert.equal($('#account-link').hidden,false);assert.equal($('#account-link').getAttribute('href'),'/account?return=checkout');assert.match($('#gate-copy').textContent,/Posle Google prijave/);assert.equal($('#google-login'),null);});
test('contact validation rejects fewer than six phone digits and unsafe text',async t=>{const {w,data,$,fill}=await fixture(t);fill();$('#contact-form').elements.phone.value='(1)---';$('#contact-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await new Promise(r=>setTimeout(r,10));assert.equal(data.calls.filter(x=>x.path.endsWith('/quote')).length,0);assert.match($('#checkout-status').textContent,/6 cifara/);$('#contact-form').elements.phone.value=contact.phone;$('#contact-form').elements.address.value='<img src=x>';$('#contact-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await new Promise(r=>setTimeout(r,10));assert.equal(data.calls.filter(x=>x.path.endsWith('/quote')).length,0);});
test('server quote, contact review and explicit intent are required; double click sends once',async t=>{let resolve;const {data,$,prepare,commit,w}=await fixture(t,{orderHandler:()=>new Promise(r=>resolve=r)});await prepare();assert.equal($('#place-order').disabled,true);assert.match($('#quote-summary').textContent,/Test 12/);commit();commit();await until(()=>data.posts.length===1);assert.equal($('#receipt').hidden,true);const pending=JSON.parse(w.sessionStorage.getItem(PENDING));assert.equal(pending.body,data.posts[0].options.body);assert.equal(pending.key,data.posts[0].options.headers['Idempotency-Key']);const body=JSON.parse(pending.body);assert.equal(body.items[0].expectedRevision,7);assert.equal(body.expectedTotalMinor,179000);assert.equal(body.shippingMethod,'courier');assert.equal(body.paymentMethod,'cod');assert.equal(data.posts[0].options.headers['X-CSRF-Token'],'csrf-1');resolve(response({order,replayed:false}));await until(()=>!$('#receipt').hidden);assert.equal(w.sessionStorage.getItem(PENDING),null);assert.deepEqual(JSON.parse(w.localStorage.getItem(CART)),[]);assert.match($('#receipt').textContent,/Iznos dospeva/);assert.doesNotMatch($('#receipt').textContent,/imejl je poslat|email sent|kartica/i);});
test('contact and cart changes invalidate quote and consent',async t=>{const {$,w,prepare}=await fixture(t);await prepare();$('#confirm-intent').checked=true;$('#contact-form').elements.address.value='Second 14';$('#contact-form').elements.address.dispatchEvent(new w.Event('input',{bubbles:true}));assert.equal($('#quote-panel').hidden,true);assert.equal($('#confirm-intent').checked,false);await prepare();w.document.querySelectorAll('#checkout-cart .quantity-button')[1].click();assert.equal($('#quote-panel').hidden,true);});
test('cross-tab cart edit rejects an in-flight stale quote',async t=>{const {data,$,fill,w}=await fixture(t);let resolve;data.quoteHandler=()=>new Promise(r=>resolve=r);fill();$('#contact-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));w.localStorage.setItem(CART,JSON.stringify([{id:'crni-kim',quantity:2}]));w.dispatchEvent(new w.StorageEvent('storage',{key:CART}));resolve(response(quote));await new Promise(r=>setTimeout(r,20));assert.equal($('#quote-panel').hidden,true);assert.equal($('#place-order').disabled,true);assert.equal($('#checkout-cart output').textContent,'2');});
test('initial definitive 409 requires explicit return to review before reset',async t=>{const {data,$,prepare,commit,w}=await fixture(t,{orderHandler:()=>response({error:'Product changed; review a fresh quote.'},409)});await prepare();commit();await until(()=>!$('#revise-order').hidden);assert.equal(data.posts.length,1);assert.match($('#pending-error').textContent,/Product changed/);assert.ok(w.sessionStorage.getItem(PENDING));assert.equal($('#quote-panel').hidden,false);$('#revise-order').click();assert.equal(w.sessionStorage.getItem(PENDING),null);assert.equal($('#quote-panel').hidden,true);assert.equal($('#contact-form').elements.address.value,contact.address);assert.equal(JSON.parse(w.localStorage.getItem(CART))[0].quantity,1);});
test('lost response, retry 403, reload and replay preserve exact request and key',async t=>{
 const first=await fixture(t,{orderHandler:()=>{throw Error('Network response lost');}});await first.prepare();first.commit();await until(()=>first.$('#pending-error').textContent.includes('Network'));const original=JSON.parse(first.w.sessionStorage.getItem(PENDING));first.data.orderHandler=()=>response({error:'CSRF expired'},403);first.$('#retry-order').click();await until(()=>first.data.posts.length===2&&!first.$('#retry-order').disabled);const after403=JSON.parse(first.w.sessionStorage.getItem(PENDING));assert.equal(after403.key,original.key);assert.equal(after403.body,original.body);assert.equal(after403.rejected,false);assert.equal(first.$('#revise-order').hidden,true);
 const next=await fixture(t,{pending:first.w.sessionStorage.getItem(PENDING),orderHandler:()=>response({order,replayed:true})});assert.equal(next.$('#checkout-editor').hidden,true);next.$('#retry-order').click();await until(()=>!next.$('#receipt').hidden);assert.equal(next.data.posts[0].options.body,original.body);assert.equal(next.data.posts[0].options.headers['Idempotency-Key'],original.key);assert.match(next.$('#checkout-status').textContent,/Novi primerak nije kreiran/);
});
test('a 409 after an uncertain attempt never resets request or creates a new key',async t=>{const {data,$,prepare,commit,w}=await fixture(t,{orderHandler:()=>{throw Error('Timeout');}});await prepare();commit();await until(()=>$('#pending-error').textContent==='Timeout');const original=JSON.parse(w.sessionStorage.getItem(PENDING));data.orderHandler=()=>response({error:'Conflict'},409);$('#retry-order').click();await until(()=>data.posts.length===2&&!$('#retry-order').disabled);assert.equal($('#revise-order').hidden,true);assert.equal(JSON.parse(w.sessionStorage.getItem(PENDING)).key,original.key);assert.equal(JSON.parse(w.sessionStorage.getItem(PENDING)).body,original.body);});
test('different account cannot see or retry stored contact; original account can recover',async t=>{const a=await fixture(t,{orderHandler:()=>{throw Error('Network');}});await a.prepare();a.commit();await until(()=>a.$('#pending-error').textContent==='Network');const stored=a.w.sessionStorage.getItem(PENDING);const b=await fixture(t,{pending:stored,session:{enabled:true,user:{id:'google:other',name:'Other',email:'other@example.invalid'},csrfToken:'csrf-2',customerReady:true}});assert.equal(b.$('#pending-panel').hidden,true);assert.equal(b.$('#checkout-editor').hidden,true);assert.doesNotMatch(b.$('#pending-summary').textContent,/Test Customer|Test 12/);b.$('#retry-order').click();await new Promise(r=>setTimeout(r,10));assert.equal(b.data.posts.length,0);assert.equal(b.w.sessionStorage.getItem(PENDING),stored);});
test('pagehide clears contact and history; stale responses cannot restore them',async t=>{const {data,$,w,prepare}=await fixture(t,{orders:[order]});await until(()=>$('.order-card'));await prepare();w.dispatchEvent(new w.Event('pagehide'));assert.equal($('#checkout-workspace').hidden,true);assert.equal($('#contact-form').elements.address.value,'');assert.equal($('#quote-summary').textContent,'');assert.equal($('#customer-orders').textContent,'');assert.equal($('#identity').textContent,'');assert.equal(data.posts.length,0);});
test('history uses authenticated scoped detail route and text-safe rendering',async t=>{const malicious={...order,id:'COD-html',contact:{...contact,fullName:'<img src=x onerror=alert(1)>'},items:[{...order.items[0],name:'<script>bad</script>'}]};const {data,$,w}=await fixture(t,{orders:[malicious]});data.detail=malicious;await until(()=>$('.order-detail-button'));$('.order-detail-button').click();await until(()=>!$('.order-details').hidden);assert.match($('.order-details').textContent,/<img src=x/);assert.match($('.order-details').textContent,/<script>bad/);assert.equal($('.order-details img'),null);assert.equal($('.order-details script'),null);assert.ok(data.calls.some(x=>x.path==='/api/checkout/orders/COD-html'));assert.equal(w.document.querySelector('[name=customerId]'),null);});
test('corrupt saved request blocks new checkout instead of silently deleting uncertainty',async t=>{const {w,$,data}=await fixture(t,{pending:'not valid JSON'});assert.equal($('#checkout-editor').hidden,true);assert.equal(w.sessionStorage.getItem(PENDING),'not valid JSON');assert.match($('#checkout-status').textContent,/nije moguće pročitati/);assert.equal(data.posts.length,0);});
test('session storage failure blocks order POST',async t=>{const {$,w,data,prepare,commit}=await fixture(t);await prepare();Object.defineProperty(w,'sessionStorage',{value:{getItem(){return null;},setItem(){throw Error('blocked');},removeItem(){throw Error('blocked');}}});commit();await new Promise(r=>setTimeout(r,20));assert.equal(data.posts.length,0);assert.match($('#checkout-status').textContent,/neće biti poslata/);});

test('replayed cancelled COD order shows cancellation instead of payment due',async t=>{const cancelled={...order,status:'cancelled',paymentStatus:'cod_cancelled',inventoryStatus:'deducted_manual_adjustment_required'};const {data,$,prepare,commit}=await fixture(t,{orderHandler:()=>response({order:cancelled,replayed:true})});await prepare();commit();await until(()=>!$('#receipt').hidden);assert.match($('#receipt-title').textContent,/otkazana/);assert.doesNotMatch($('#receipt-copy').textContent,/Iznos dospeva/);assert.match($('#receipt-content').textContent,/Vrednost otkazane/);assert.equal(data.posts.length,1);});

test('failed pending cleanup never subtracts cart; replay after reload subtracts once',async t=>{const first=await fixture(t);await first.prepare();const storage=first.w.sessionStorage;Object.defineProperty(first.w,'sessionStorage',{value:{getItem:k=>storage.getItem(k),setItem:(k,v)=>storage.setItem(k,v),removeItem(){throw Error('removal blocked');}}});first.commit();await until(()=>!first.$('#receipt').hidden);assert.equal(JSON.parse(first.w.localStorage.getItem(CART))[0].quantity,1);assert.ok(first.w.sessionStorage.getItem(PENDING));assert.equal(first.$('#checkout-editor').hidden,true);assert.match(first.$('#checkout-status').textContent,/korpa nije izmenjena/);const next=await fixture(t,{pending:first.w.sessionStorage.getItem(PENDING),orderHandler:()=>response({order,replayed:true})});next.w.localStorage.setItem(CART,JSON.stringify([{id:'crni-kim',quantity:2}]));next.$('#retry-order').click();await until(()=>!next.$('#receipt').hidden);assert.equal(JSON.parse(next.w.localStorage.getItem(CART))[0].quantity,1);assert.equal(next.w.sessionStorage.getItem(PENDING),null);});

test('human order number appears in receipt and history while details and receipt reload use opaque ID',async t=>{
 const numbered={...order,orderNumber:'2026-1000'};
 const first=await fixture(t,{orders:[numbered],detail:numbered,orderHandler:()=>response({order:numbered,replayed:false})});
 await until(()=>first.$('.order-card h3'));
 assert.equal(first.$('.order-card h3').textContent,'Porudžbina 2026-1000');
 first.$('.order-detail-button').click();await until(()=>!first.$('.order-details').hidden);
 assert.ok(first.data.calls.some(call=>call.path===`/api/checkout/orders/${order.id}`));
 await first.prepare();first.commit();await until(()=>!first.$('#receipt').hidden);
 assert.equal(first.$('#receipt-content .order-id').textContent,'Broj porudžbine: 2026-1000 · Status: Na čekanju');
 assert.equal(new URL(first.w.location.href).searchParams.get('order'),order.id);
 assert.equal(first.w.sessionStorage.getItem(PENDING),null);
 assert.equal(first.data.posts.length,1);
 const body=JSON.parse(first.data.posts[0].options.body);
 assert.equal(Object.hasOwn(body,'orderNumber'),false);assert.equal(Object.hasOwn(body,'id'),false);
 const reloaded=await fixture(t,{url:first.w.location.href,detail:numbered,orders:[numbered]});
 await until(()=>!reloaded.$('#receipt').hidden);
 assert.equal(reloaded.$('#receipt-content .order-id').textContent,'Broj porudžbine: 2026-1000 · Status: Na čekanju');
 assert.ok(reloaded.data.calls.some(call=>call.path===`/api/checkout/orders/${order.id}`));
 assert.equal(new URL(reloaded.w.location.href).searchParams.get('order'),order.id);
 assert.equal(reloaded.data.posts.length,0);
 assert.equal([...first.data.calls,...reloaded.data.calls].some(call=>call.path.includes(numbered.orderNumber)),false);
});

test('legacy receipt and history retain opaque ID when human order number is absent or empty',async t=>{
 for(const legacy of [order,{...order,orderNumber:null},{...order,orderNumber:''}]){
  const {data,$,w}=await fixture(t,{url:`https://shop.example.test/checkout?order=${order.id}`,detail:legacy,orders:[legacy]});
  await until(()=>!$('#receipt').hidden&&$('.order-card h3'));
  assert.equal($('.order-card h3').textContent,`Porudžbina ${order.id}`);
  assert.equal($('#receipt-content .order-id').textContent,`Broj porudžbine: ${order.id} · Status: Na čekanju`);
  assert.equal(new URL(w.location.href).searchParams.get('order'),order.id);
  assert.ok(data.calls.some(call=>call.path===`/api/checkout/orders/${order.id}`));
 }
});

test('human order numbers render as literal text in receipt and history',async t=>{
 const numbered={...order,orderNumber:'<img src=x onerror=alert(1)><script>bad</script>'};
 const {data,$}=await fixture(t,{url:`https://shop.example.test/checkout?order=${order.id}`,detail:numbered,orders:[numbered]});
 await until(()=>!$('#receipt').hidden&&$('.order-card h3'));
 assert.equal($('.order-card h3').textContent,`Porudžbina ${numbered.orderNumber}`);
 assert.equal($('#receipt-content .order-id').textContent,`Broj porudžbine: ${numbered.orderNumber} · Status: Na čekanju`);
 assert.equal($('#receipt-content img, #receipt-content script, #customer-orders img, #customer-orders script, #customer-orders [onerror]'),null);
 $('.order-detail-button').click();await until(()=>!$('.order-details').hidden);
 assert.equal(data.calls.filter(call=>call.path===`/api/checkout/orders/${order.id}`).length,2);
});
