import test from 'node:test';
import assert from 'node:assert/strict';
import {productContent,contentVersion} from '../src/marketing-store.mjs';
test('marketing content snapshots and stale-draft hashes detect description-format changes',()=>{
 const plain={name:'Name',description:'**literal**'},formatted={...plain,descriptionFormat:'markdown'};
 assert.deepEqual(productContent(plain),plain);
 assert.deepEqual(productContent(formatted),formatted);
 assert.notEqual(contentVersion(plain),contentVersion(formatted));
 assert.notEqual(contentVersion(formatted),contentVersion({...formatted,descriptionFormat:'plain'}));
 assert.equal(contentVersion(formatted),contentVersion({...formatted,stockQuantity:5,available:true,revision:23}));
});
