import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {JSDOM} from 'jsdom';
import {createHostedServer} from '../server.mjs';
import {products as seeds} from '../public/catalog.js';
import {homeMarkup} from '../public/home-view.js';
import {publicProduct} from '../src/product-ssr.mjs';
import {analyticsCsp,analyticsScript} from '../src/analytics.mjs';
const origin='https://olesence.rs';
async function fixture(t){
 const state={products:seeds.map(p=>({...p,available:true,stockQuantity:2,updatedAt:'2026-11-12T08:00:00Z'})),fail:false};
 state.products.push({...state.products[0],id:'private-draft',name:'Secret product',published:false});
 const store={listProducts:async()=>{if(state.fail)throw Error('private DB failure');return state.products;}};
 const app=await createHostedServer({config:{origin,host:'olesence.rs',auth:{origin,clientId:'synthetic.apps.googleusercontent.com',secure:true},admin:{enabled:true,emails:['owner@example.invalid']},customerDatabaseEnabled:true,checkoutEnabled:true},store,customerStore:{},codStore:{}});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));t.after(()=>app.close());
 const get=(path,method='GET')=>new Promise((resolve,reject)=>{const req=http.request({hostname:'127.0.0.1',port:app.server.address().port,path,method,headers:{host:'olesence.rs','x-forwarded-proto':'https'}},res=>{const chunks=[];res.on('data',b=>chunks.push(b));res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,text:Buffer.concat(chunks).toString()}));});req.on('error',reject);req.end();});
 return {state,get};
}
test('home SSR has one H1, all public content, shared client markup, truthful footer and unchanged analytics/CSP',async t=>{
 const {get,state}=await fixture(t);const r=await get('/'),doc=new JSDOM(r.text).window.document;
 assert.equal(r.status,200);assert.equal(doc.querySelectorAll('h1').length,1);assert.equal(doc.querySelector('h1').textContent,'Priroda. Tradicija. Vaš ritam.');
 const main=doc.querySelector('#main');assert.equal(main.dataset.serverRendered,'true');
 for(const id of ['kolekcija','pristup','pitanja'])assert.ok(main.querySelector('#'+id));
 for(const p of seeds)assert.ok(main.querySelector(`a[href="/proizvod/${p.id}"]`));
 assert.equal(main.querySelectorAll('.product-card').length,3);assert.ok(!r.text.includes('Secret product'));assert.ok(!r.text.includes('private-draft'));
 const expected=new JSDOM('<main>'+homeMarkup(state.products.filter(p=>p.published!==false).map(p=>publicProduct(p,true)))+'</main>').window.document;
 main.querySelector('noscript').remove();assert.equal(main.innerHTML,expected.querySelector('main').innerHTML);
 assert.equal(doc.querySelector('#faq-ordering'),null);assert.ok(!r.text.includes('FAQPage'));
 assert.equal(doc.querySelector('[data-checkout-label]').textContent,'Plaćanje pouzećem');
 assert.equal(r.headers['content-security-policy'],analyticsCsp);assert.equal(doc.querySelector('#olesence-analytics-init').textContent,analyticsScript);
 assert.equal(doc.querySelectorAll('#site-schema').length,1);assert.equal(doc.querySelector('img').getAttribute('fetchpriority'),'high');
 assert.equal(r.headers['cache-control'],'no-store');
});
test('new publication and withdrawal update home, llms and sitemap without build; outage is 503',async t=>{
 const {get,state}=await fixture(t);state.products.push({...state.products[0],id:'fourth-product',name:'Fourth <product>'});
 for(const route of ['/','/sitemap.xml','/llms.txt']){const r=await get(route);assert.equal(r.status,200);assert.ok(r.text.includes('fourth-product'));assert.ok(!r.text.includes('private-draft'));}
 const llms=await get('/llms.txt');assert.match(llms.headers['content-type'],/^text\/plain/);assert.match(llms.text,/1.490/);assert.ok(!llms.text.includes('stockQuantity'));
 state.products[0].published=false;assert.ok(!(await get('/sitemap.xml')).text.includes('/crni-kim'));
 state.fail=true;for(const route of ['/','/llms.txt','/sitemap.xml'])assert.equal((await get(route)).status,503);
});
test('hashed bundled images cache immutably, icons exist, and HEAD/private paths retain policy',async t=>{
 const {get}=await fixture(t);const doc=new JSDOM((await get('/')).text).window.document;
 const image=doc.querySelector('.hero-slide img').getAttribute('src');const r=await get(image);assert.equal(r.status,200);assert.equal(r.headers['content-type'],'image/webp');assert.equal(r.headers['cache-control'],'public, max-age=31536000, immutable');
 for(const icon of ['/favicon.ico','/favicon.png','/apple-touch-icon.png'])assert.equal((await get(icon)).status,200);
 for(const path of ['/','/llms.txt','/sitemap.xml',image]){const head=await get(path,'HEAD');assert.equal(head.status,200);assert.equal(head.text,'');}
 for(const path of ['/checkout','/account','/api/catalog']){const response=await get(path);assert.equal(response.headers['cache-control'],'no-store');assert.match(response.headers['x-robots-tag'],/noindex/);}
});
