import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {productImageAttributes} from '../public/image-view.js';
import {slides} from '../public/slider.js';
const base=new URL('../public/',import.meta.url);
test('hero variants are immutable, small and preserve dimensions',()=>{
 for(const s of slides) for(const name of [s.desktop,s.mobile]){
  assert.match(name,/\.[a-f0-9]{12}\.webp$/);
  const data=fs.readFileSync(new URL('assets/'+name,base));
  assert.ok(data.length<200000,name+' size');
  assert.ok(name.includes(crypto.createHash('sha256').update(data).digest('hex').slice(0,12)));
 }
});
test('bundled products use responsive variants and requested image priority',()=>{
 for(const name of ['crni-kim','origano','cetiri-lopova']){
  const card=productImageAttributes('/assets/'+name+'.jpg');
  assert.match(card,/400w.*800w.*1200w/);assert.match(card,/loading="lazy"/);
  for(const path of card.matchAll(/\/assets\/[^\s",]+/g))assert.ok(fs.existsSync(new URL(path[0].slice(1),base)));
  const detail=productImageAttributes('/assets/'+name+'.jpg',{detail:true});
  assert.match(detail,/fetchpriority="high"/);assert.doesNotMatch(detail,/loading="lazy"/);
 }
});
test('new uploaded product photos do not acquire nonexistent bundled variants',()=>{
 const path='/media/'+'a'.repeat(64)+'.jpg';
 const attrs=productImageAttributes(path);assert.ok(attrs.includes('src="'+path+'"'));assert.doesNotMatch(attrs,/srcset/);
 assert.match(productImageAttributes('"<x>'),/&quot;&lt;x&gt;/);
});
test('favicon assets exist',()=>{for(const name of ['favicon.ico','favicon.png','apple-touch-icon.png'])assert.ok(fs.statSync(new URL(name,base)).size>100);});
