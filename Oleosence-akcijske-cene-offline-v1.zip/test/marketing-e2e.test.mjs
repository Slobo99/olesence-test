import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {createHash} from 'node:crypto';
import sharp from 'sharp';
import {PGlite} from '@electric-sql/pglite';
import {createHostedServer} from '../server.mjs';
import {createPostgresStore} from '../src/admin-store.mjs';
import {createMarketingStore} from '../src/marketing-store.mjs';
import {products as seedProducts} from '../public/catalog.js';

// Real PostgreSQL SQL semantics in isolated memory, not a hosted database.
async function sqlPool(){
 const db=new PGlite();let tail=Promise.resolve();
 async function connect(){const previous=tail;let release;tail=new Promise(resolve=>{release=resolve;});await previous;return {release,query:(sql,args)=>args===undefined&&sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args)};}
 return {connect,query:async(sql,args)=>{const client=await connect();try{return await client.query(sql,args);}finally{client.release();}},end:()=>db.close()};
}

test('real SQL plus HTTP: private image/content drafts require exact reapproval and preserve concurrent commercial changes',async t=>{
 const pool=await sqlPool();t.after(()=>pool.end());
 const store=createPostgresStore(pool,{includeMarketingImages:true});await store.initialize(seedProducts);
 const marketingStore=createMarketingStore(pool);await marketingStore.initialize();
 const owner={id:'google:local-owner',provider:'google',email:'owner@example.invalid'};
 let live=(await store.listProducts()).find(p=>p.id==='crni-kim');live=await store.updateProduct(live.id,live.version,{stockQuantity:7,available:true},owner);
 const credential='omk_'+'C'.repeat(43),keyId='99999999-9999-4999-8999-999999999999';
 await marketingStore.createKey({id:keyId,label:'Isolated test fixture only',hash:createHash('sha256').update(credential).digest('hex'),scopes:['catalog:read','stock:read','drafts:read','drafts:write','media:write'],expiresAt:new Date(Date.now()+86400000).toISOString()},owner);
 const origin='https://sql-marketing-test.onrender.com',host='sql-marketing-test.onrender.com',clientId='e2e.apps.googleusercontent.com';let flow;
 const provider={authorizationURL(value){flow=value;return 'https://accounts.google.com/mock';},async exchange(){const now=Math.floor(Date.now()/1000);return {iss:'https://accounts.google.com',aud:clientId,sub:'local-owner',email:owner.email,email_verified:true,nonce:flow.nonce,iat:now-60,exp:now+3600};}};
 const app=await createHostedServer({config:{origin,host,auth:{origin,clientId,secure:true},admin:{enabled:true,emails:[owner.email],ownerEmail:owner.email},marketingEnabled:true},store,marketingStore,provider});
 await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));t.after(()=>app.close());
 const request=(path,{method='GET',headers={},body}={})=>new Promise((resolve,reject)=>{const req=http.request({hostname:'127.0.0.1',port:app.server.address().port,path,method,headers:{host,'x-forwarded-proto':'https',...headers}},res=>{const chunks=[];res.on('data',chunk=>chunks.push(chunk));res.on('end',()=>{const bytes=Buffer.concat(chunks);resolve({status:res.statusCode,headers:res.headers,bytes,text:bytes.toString('utf8'),json:()=>JSON.parse(bytes.toString('utf8'))});});});req.on('error',reject);req.end(body);});
 const agentHeaders={authorization:`Bearer ${credential}`};
 const agent=(path,options={})=>request('/api/marketing/v1'+path,{...options,headers:{...agentHeaders,...options.headers}});
 const json=(path,body,headers,method='POST')=>request(path,{method,headers:{'content-type':'application/json',...headers},body:JSON.stringify(body)});
 const start=await request('/auth/google/start',{method:'POST',headers:{origin}}),cookie=start.headers['set-cookie'][0].split(';')[0];
 const callback=await request(`/auth/google/callback?state=${flow.state}&code=fixture`,{headers:{cookie}});assert.equal(callback.status,303);assert.equal(callback.headers.location,'/account');
 const ownerCookie=callback.headers['set-cookie'][0].split(';')[0],session=(await request('/auth/session',{headers:{cookie:ownerCookie}})).json();
 const ownerHeaders={cookie:ownerCookie,origin,'x-csrf-token':session.csrfToken};
 const catalog=(await agent('/catalog')).json(),product=catalog.products.find(p=>p.id===live.id);
 assert.equal(Object.hasOwn(product,'stockQuantity'),false);
 const image=await sharp({create:{width:25,height:19,channels:3,background:'#34753b'}}).png().toBuffer();
 const staged=await agent('/media',{method:'POST',headers:{'content-type':'image/png'},body:image});assert.equal(staged.status,201);const imagePath=staged.json().imagePath;
 assert.equal((await request(imagePath)).status,404);
 const patch={name:'Reviewed fixture title',description:'Synthetic private proposal',seoTitle:'Reviewed fixture SEO',seoDescription:'Reviewed fixture description',imagePath};
 const created=await json('/api/marketing/v1/drafts',{productId:live.id,baseContentVersion:product.contentVersion,patch},agentHeaders);assert.equal(created.status,201);let draft=created.json();
 assert.equal((await request('/api/catalog')).json().products.find(p=>p.id===live.id).name,live.name);
 assert.equal((await request('/proizvod/'+live.id)).text.includes(patch.seoTitle),false);
 const path='/admin/api/marketing/drafts/'+draft.id;
 let response=await json(path+'/approve',{version:draft.revision},ownerHeaders);assert.equal(response.status,200);draft=response.json();assert.equal(draft.status,'approved');
 response=await json('/api/marketing/v1/drafts/'+draft.id,{version:draft.revision,baseContentVersion:product.contentVersion,patch:{...patch,description:'Revised private proposal'}},agentHeaders,'PATCH');assert.equal(response.status,200);draft=response.json();assert.equal(draft.status,'draft');assert.equal(draft.approvedRevision,null);
 assert.equal((await json(path+'/publish',{version:draft.revision-1},ownerHeaders)).status,409);
 assert.equal((await json(path+'/publish',{version:draft.revision},ownerHeaders)).status,409);
 response=await json(path+'/approve',{version:draft.revision},ownerHeaders);assert.equal(response.status,200);draft=response.json();
 // Commercial data changed after approval; content fingerprint stays valid and publish must not overwrite it.
 live=await store.updateProduct(live.id,live.version,{stockQuantity:5,priceMinor:155000},owner);
 response=await json(path+'/publish',{version:draft.revision},ownerHeaders);assert.equal(response.status,200);assert.equal(response.json().status,'published');
 const published=(await store.listProducts()).find(p=>p.id===live.id);assert.equal(published.name,patch.name);assert.equal(published.description,'Revised private proposal');assert.equal(published.stockQuantity,5);assert.equal(published.priceMinor,155000);assert.equal(published.available,true);
 const media=await request(imagePath);assert.equal(media.status,200);assert.equal(media.headers['content-type'],'image/jpeg');assert.equal((await sharp(media.bytes).metadata()).format,'jpeg');
 const html=await request('/proizvod/'+live.id);assert.match(html.text,/<title>Reviewed fixture SEO<\/title>/);assert.match(html.headers['x-robots-tag'],/noindex/);
 assert.equal((await json('/api/marketing/v1/drafts/'+draft.id,{version:response.json().revision,baseContentVersion:product.contentVersion,patch},agentHeaders,'PATCH')).status,409);
 const audit=await request('/admin/api/marketing/audit',{headers:ownerHeaders});assert.equal(audit.status,200);assert.equal(audit.text.includes(credential),false);assert.equal(audit.text.includes(createHash('sha256').update(credential).digest('hex')),false);assert.equal(audit.json().entries.some(entry=>entry.action==='publish'),true);
 assert.equal((await json('/admin/api/marketing/keys/'+keyId+'/revoke',{},ownerHeaders)).status,200);assert.equal((await agent('/catalog')).status,401);
});
