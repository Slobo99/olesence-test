import {products as seedProducts} from '../public/catalog.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {createHash} from 'node:crypto';
import sharp from 'sharp';
import {createHostedServer,readHostedConfig} from '../server.mjs';
import {StoreError} from '../src/admin-store.mjs';

const origin='https://marketing-test.onrender.com',host='marketing-test.onrender.com',clientId='fixture.apps.googleusercontent.com';
// Deliberately synthetic fixture credentials; never valid against a hosted service.
const token='omk_'+'A'.repeat(43),otherToken='omk_'+'B'.repeat(43);
const keyId='11111111-1111-4111-8111-111111111111',draftId='22222222-2222-4222-8222-222222222222';
const now=Date.parse('2026-10-28T00:00:00Z'),expiresAt='2026-11-28T00:00:00Z';
const allScopes=['catalog:read','stock:read','sales:read','drafts:read','drafts:write','media:write'];
const hash=value=>createHash('sha256').update(value).digest('hex');
const authHeaders={authorization:`Bearer ${token}`};
const draftInput={productId:'crni-kim',baseContentVersion:'f'.repeat(64),patch:{description:'Unpublished proposal',seoTitle:'Unpublished SEO'}};

async function fixture(t,{enabled=true,email='owner@example.invalid',scopes=allScopes,revokedAt=null,expiry=expiresAt,ownerEmail='owner@example.invalid',delegated=false,products}={}){
 let flow,time=now;
 const calls=[],keys=new Map([[hash(token),{id:keyId,label:'Fixture only',scopes:[...scopes],expiresAt:expiry,revokedAt}]]),staged=new Map(),publicImages=new Map();
 const liveProducts=(products??[{id:'crni-kim',name:'Public product',description:'Published description',image:'crni-kim.jpg',stockQuantity:4,available:true,version:3,priceMinor:149000}]).map(p=>({...seedProducts.find(seed=>seed.id===p.id),...p}));
 const drafts=new Map();
 function call(name,...args){calls.push({name,args});}
 function findDraft(id){const draft=drafts.get(id);if(!draft)throw new StoreError(404,'Draft not found.');return draft;}
 const marketingStore={
  async findKeyByHash(value){call('findKeyByHash',value);return keys.get(value)||null;},
  async listCatalog(options={}){call('listCatalog',options);return {products:liveProducts.map(({stockQuantity,version,updatedAt,...p})=>({...p,...(options.stock?{stockQuantity}:{}),contentVersion:'f'.repeat(64)}))};},
  async salesSummary(options){call('salesSummary',options);return {...options,currency:'RSD',orderCount:2,orderValueMinor:298000,byStatus:[{status:'completed',orderCount:2,orderValueMinor:298000}],collectedRevenueMinor:null,paymentCollectionTracked:false};},
  async listKeys(){call('listKeys');return {keys:[...keys.values()]};},
  async createKey(input,actor){call('createKey',input,actor);const result={...input,hash:undefined};keys.set(input.hash,result);return result;},
  async revokeKey(id,actor){call('revokeKey',id,actor);const key=[...keys.values()].find(k=>k.id===id);if(!key)throw new StoreError(404,'Key not found.');key.revokedAt=new Date(time).toISOString();return key;},
  async createDraft(input,actor){call('createDraft',input,actor);const result={id:draftId,...input,revision:1,status:'draft',createdBy:actor.id,baseContent:{name:'Public product',description:'Published description'}};drafts.set(draftId,result);return result;},
  async updateDraft(id,input,actor){call('updateDraft',id,input,actor);const old=findDraft(id);if(old.revision!==input.revision)throw new StoreError(409,'Stale draft.');const result={...old,...input,revision:old.revision+1,status:'draft'};drafts.set(id,result);return result;},
  async listDrafts(options){call('listDrafts',options);return {drafts:[...drafts.values()],nextCursor:null};},
  async getDraft(id,options){call('getDraft',id,options);return findDraft(id);},
  async approveDraft(id,version,actor){call('approveDraft',id,version,actor);const draft=findDraft(id);if(draft.revision!==version)throw new StoreError(409,'Stale draft.');draft.status='approved';draft.revision++;return draft;},
  async publishDraft(id,version,actor){call('publishDraft',id,version,actor);const draft=findDraft(id);if(draft.revision!==version||draft.status!=='approved')throw new StoreError(409,'Stale or unapproved draft.');Object.assign(liveProducts[0],draft.patch);draft.status='published';draft.revision++;return draft;},
  async rejectDraft(id,version,actor){call('rejectDraft',id,version,actor);const draft=findDraft(id);if(draft.revision!==version)throw new StoreError(409,'Stale draft.');draft.status='rejected';draft.revision++;return draft;},
  async stageImage(image,actor){call('stageImage',image,actor);staged.set(image.hash,image);return {hash:image.hash,imagePath:`/media/${image.hash}.jpg`,width:image.width,height:image.height};},
  async getStagedImage(imageHash,options){call('getStagedImage',imageHash,options);return staged.get(imageHash)||null;},
  async listAudit(){return {entries:[],nextCursor:null};}
 };
 const store={listProducts:async()=>liveProducts,getImage:async h=>publicImages.get(h)||null,updateProduct:async(...args)=>call('updateProduct',...args),updateOrder:async(...args)=>call('updateOrder',...args),applyStockImport:async(...args)=>call('applyStockImport',...args),listAudit:async()=>({entries:[]}),listOrders:async()=>({orders:[]})};
 const provider={authorizationURL(value){flow=value;return 'https://accounts.google.com/mock';},async exchange(){return {iss:'https://accounts.google.com',aud:clientId,sub:delegated?'delegate':'owner',email,email_verified:true,nonce:flow.nonce,iat:Math.floor(time/1000)-60,exp:Math.floor(time/1000)+3600};}};
 const customerStore=delegated?{upsertVerifiedGoogleUser:async()=>({id:'33333333-3333-4333-8333-333333333333'}),getAdminAccess:async()=>({role:'admin',manageRoles:false})}:null;
 const app=await createHostedServer({config:{origin,host,auth:{origin,clientId,secure:true},admin:{enabled:true,emails:[ownerEmail],ownerEmail},marketingEnabled:enabled,customerDatabaseEnabled:!!customerStore},provider,store,marketingStore,customerStore,clock:()=>time});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));t.after(()=>app.close());
 const request=(path,{method='GET',headers={},body}={})=>new Promise((resolve,reject)=>{
  const cleanHeaders={host,'x-forwarded-proto':'https',...headers};for(const key of Object.keys(cleanHeaders))if(cleanHeaders[key]===undefined)delete cleanHeaders[key];
  const req=http.request({hostname:'127.0.0.1',port:app.server.address().port,path,method,headers:cleanHeaders},res=>{const chunks=[];res.on('data',b=>chunks.push(b));res.on('end',()=>{const bytes=Buffer.concat(chunks),text=bytes.toString('utf8');resolve({status:res.statusCode,headers:res.headers,bytes,text,json:()=>JSON.parse(text)});});});req.on('error',reject);req.end(body);
 });
 async function login(){const start=await request('/auth/google/start',{method:'POST',headers:{origin}});const cookie=start.headers['set-cookie'][0].split(';')[0];const finish=await request(`/auth/google/callback?state=${flow.state}&code=fixture`,{headers:{cookie}});assert.equal(finish.status,303);assert.equal(finish.headers.location,'/account');const sessionCookie=finish.headers['set-cookie'][0].split(';')[0];const session=(await request('/auth/session',{headers:{cookie:sessionCookie}})).json();return {cookie:sessionCookie,origin,'x-csrf-token':session.csrfToken};}
 const agent=(path,options={})=>request('/api/marketing/v1'+path,{...options,headers:{...authHeaders,...options.headers}});
 const json=(path,body,options={})=>request(path,{method:'POST',...options,headers:{'content-type':'application/json',...options.headers},body:JSON.stringify(body)});
 return {request,agent,json,login,calls,keys,drafts,staged,publicImages,liveProducts,marketingStore,store,setTime:value=>{time=value;}};
}

test('marketing HTTP stays disabled by default and rejects absent or malformed bearer credentials',async t=>{
 const disabled=await fixture(t,{enabled:false});assert.equal((await disabled.agent('/catalog')).status,404);
 const f=await fixture(t);
 for(const authorization of [undefined,'Basic '+token,'Bearer short','Bearer '+otherToken,token,'Bearer '+token+' extra'])assert.equal((await f.request('/api/marketing/v1/catalog',{headers:{authorization}})).status,401);
 for(const path of [`/api/marketing/v1/catalog?token=${token}`,`/api/marketing/v1/catalog?api_key=${token}`])assert.equal((await f.request(path)).status,401);
 const ordinarySession=await f.login();assert.equal((await f.request('/api/marketing/v1/catalog',{headers:{cookie:ordinarySession.cookie}})).status,401);
 assert.equal((await f.agent('/catalog')).status,200);
 assert.equal(f.calls.filter(x=>x.name==='findKeyByHash').every(x=>/^[a-f0-9]{64}$/.test(x.args[0])&&!x.args[0].includes(token)),true);
});

test('marketing revocation and expiration are checked on every request without session caching',async t=>{
 const f=await fixture(t);assert.equal((await f.agent('/catalog')).status,200);
 f.keys.get(hash(token)).revokedAt=new Date(now).toISOString();assert.equal((await f.agent('/catalog')).status,401);
 f.keys.get(hash(token)).revokedAt=null;f.keys.get(hash(token)).expiresAt=new Date(now).toISOString();assert.equal((await f.agent('/catalog')).status,401);
 f.keys.get(hash(token)).expiresAt=expiresAt;assert.equal((await f.agent('/catalog')).status,200);
 const missingExpiry=await fixture(t,{expiry:null});assert.equal((await missingExpiry.agent('/catalog')).status,401);
 const invalidExpiry=await fixture(t,{expiry:'not-a-date'});assert.equal((await invalidExpiry.agent('/catalog')).status,401);
});

test('marketing scope matrix separates catalog stock sales drafts and media and cannot reach live mutation routes',async t=>{
 const f=await fixture(t,{scopes:['catalog:read']});
 const catalog=await f.agent('/catalog');assert.equal(catalog.status,200);assert.equal(Object.hasOwn(catalog.json().products[0],'stockQuantity'),false);
 for(const path of ['/stock','/sales?from=2026-10-01T00:00:00Z&to=2026-10-28T00:00:00Z','/drafts'])assert.equal((await f.agent(path)).status,403,path);
 assert.equal((await f.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(draftInput)})).status,403);
 assert.equal((await f.agent('/media',{method:'POST',headers:{'content-type':'image/png'},body:Buffer.from('not read')})).status,403);
 for(const path of ['/admin/api/products/crni-kim','/admin/api/orders/order-1','/admin/api/customers/user-1/role'])assert.equal((await f.request(path,{method:'PATCH',headers:{...authHeaders,origin,'content-type':'application/json'},body:'{"version":1,"priceMinor":1,"role":"admin"}'})).status,401,path);
 const full=await fixture(t);
 for(const path of [`/drafts/${draftId}/approve`,`/drafts/${draftId}/publish`,'/products/crni-kim','/stock','/orders'])assert.equal((await full.agent(path,{method:'POST',headers:{'content-type':'application/json'},body:'{"version":1}'})).status,404,path);
 assert.equal(full.calls.some(x=>['publishDraft','approveDraft','updateProduct','updateOrder','applyStockImport'].includes(x.name)),false);
});

test('marketing transport preserves Host TLS origin no-CORS and private cache boundaries',async t=>{
 const f=await fixture(t);
 for(const headers of [{host:'evil.invalid'},{'x-forwarded-proto':'http'},{origin:'https://evil.invalid'},{origin},{'sec-fetch-site':'cross-site'},{'sec-fetch-site':'same-origin'}])assert.ok((await f.agent('/catalog',{headers})).status>=400);
 const response=await f.agent('/catalog');assert.equal(response.headers['access-control-allow-origin'],undefined);assert.equal(response.headers['cache-control'],'no-store');assert.match(response.headers['x-robots-tag'],/noindex/);
 assert.equal((await f.request('/api/marketing/v1/catalog',{method:'OPTIONS',headers:{origin:'https://evil.invalid','access-control-request-headers':'authorization'}})).status,403);
});

test('agent draft create update and read are private bound to key identity and propagate stale conflicts',async t=>{
 const f=await fixture(t);
 const created=await f.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(draftInput)});assert.equal(created.status,201);assert.equal(created.json().revision,1);
 const create=f.calls.find(x=>x.name==='createDraft');assert.deepEqual(create.args[0],draftInput);assert.equal(create.args[1].id,`agent:${keyId}`);assert.equal(create.args[1].keyId,keyId);
 assert.equal((await f.agent('/drafts')).status,200);assert.equal(f.calls.find(x=>x.name==='listDrafts').args[0].keyId,keyId);
 assert.equal((await f.agent('/drafts/'+draftId)).status,200);assert.equal(f.calls.find(x=>x.name==='getDraft').args[1].keyId,keyId);
 const patch={version:1,baseContentVersion:draftInput.baseContentVersion,patch:{description:'Revised draft'}};
 assert.equal((await f.agent('/drafts/'+draftId,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify(patch)})).status,200);
 assert.equal((await f.agent('/drafts/'+draftId,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify(patch)})).status,409);
 for(const path of ['/api/catalog','/proizvod/crni-kim']){const response=await f.request(path);assert.equal(response.status,200);assert.equal(response.text.includes('Unpublished proposal'),false);assert.equal(response.text.includes('Unpublished SEO'),false);assert.equal(response.text.includes('Revised draft'),false);}
 assert.equal((await f.request('/api/marketing/v1/drafts/'+draftId)).status,401);
});

test('draft request envelopes reject unknown fields invalid JSON wrong type and excessive bodies',async t=>{
 const f=await fixture(t);
 for(const body of [{...draftInput,publish:true},{...draftInput,actor:{id:'google:spoof'}},{...draftInput,owner:true},[],null])assert.equal((await f.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)})).status,400);
 assert.equal((await f.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:'{broken'})).status,400);
 assert.equal((await f.agent('/drafts',{method:'POST',headers:{'content-type':'text/plain'},body:JSON.stringify(draftInput)})).status,415);
 assert.equal((await f.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...draftInput,patch:{description:'x'.repeat(100000)}})})).status,413);
 assert.equal(f.calls.some(x=>x.name==='createDraft'),false);
});

test('sales response is aggregate order value never a claim of collected cash or customer PII',async t=>{
 const f=await fixture(t);const response=await f.agent('/sales?from=2026-10-01T00:00:00Z&to=2026-10-28T00:00:00Z');assert.equal(response.status,200);
 assert.equal(response.json().orderValueMinor,298000);assert.equal(response.json().collectedRevenueMinor,null);assert.equal(response.json().paymentCollectionTracked,false);
 assert.equal(/customer|contact|email|phone|address|google:/.test(response.text),false);
 assert.equal((await f.agent('/stock')).json().products[0].stockQuantity,4);
 for(const query of ['', '?from=2026-10-01T00:00:00Z','?from=2026-10-01T00:00:00Z&from=2026-10-02T00:00:00Z&to=2026-10-28T00:00:00Z','?from=2026-10-01T00:00:00Z&to=2026-10-28T00:00:00Z&customerId=private'])assert.equal((await f.agent('/sales'+query)).status,400);
});

test('owner-only actions require current Google owner session Origin and CSRF not agent or delegated admin',async t=>{
 const f=await fixture(t),headers=await f.login();
 const session=(await f.request('/admin/api/session',{headers})).json();assert.equal(session.capabilities.marketingEnabled,true);assert.equal(session.capabilities.marketingOwner,true);
 assert.equal((await f.request('/admin/api/marketing/keys',{headers})).status,200);
 assert.equal((await f.request('/admin/api/marketing/keys',{headers:authHeaders})).status,401);
 const delegate=await fixture(t,{email:'delegate@example.invalid',delegated:true});const delegateHeaders=await delegate.login();
 assert.equal((await delegate.request('/admin/api/session',{headers:delegateHeaders})).json().capabilities.marketingOwner,false);
 for(const path of ['/admin/api/marketing/keys','/admin/api/marketing/drafts'])assert.equal((await delegate.request(path,{headers:delegateHeaders})).status,403);
 const body={label:'Synthetic test key',scopes:['catalog:read'],expiresAt};
 for(const altered of [{origin:undefined},{origin:'https://evil.invalid'},{'x-csrf-token':'bad'}])assert.equal((await f.json('/admin/api/marketing/keys',body,{headers:{...headers,...altered}})).status,403);
 assert.equal(f.calls.some(x=>x.name==='createKey'),false);
});

test('owner key creation returns one-time secret while storage receives only hash then revocation denies agent',async t=>{
 const f=await fixture(t),headers=await f.login();
 const response=await f.json('/admin/api/marketing/keys',{label:'Synthetic key',scopes:['catalog:read'],expiresAt},{headers});assert.equal(response.status,201);
 assert.match(response.json().token,/^omk_[A-Za-z0-9_-]{43}$/);const saved=f.calls.find(x=>x.name==='createKey');assert.equal(saved.args[0].hash,hash(response.json().token));assert.equal(JSON.stringify(saved.args).includes(response.json().token),false);assert.equal(saved.args[1].id,'google:owner');
 const listed=await f.request('/admin/api/marketing/keys',{headers});assert.equal(listed.text.includes(response.json().token),false);assert.equal(listed.text.includes(saved.args[0].hash),false);
 assert.equal((await f.json(`/admin/api/marketing/keys/${keyId}/revoke`,{},{headers})).status,200);assert.equal((await f.agent('/catalog')).status,401);
});

test('owner review approve publish use exact reviewed revision and never silently retry stale action',async t=>{
 const f=await fixture(t),headers=await f.login();await f.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(draftInput)});
 const path=`/admin/api/marketing/drafts/${draftId}`;
 assert.equal((await f.request(path,{headers})).json().revision,1);
 assert.equal((await f.json(path+'/publish',{version:1},{headers})).status,409);
 assert.equal((await f.json(path+'/approve',{version:1},{headers})).status,200);
 assert.equal((await f.json(path+'/publish',{version:1},{headers})).status,409);
 assert.equal((await f.json(path+'/publish',{version:2},{headers})).status,200);
 assert.equal(f.calls.filter(x=>x.name==='publishDraft').length,3);
 assert.equal((await f.request('/api/catalog')).json().products[0].description,'Unpublished proposal');
 assert.equal((await f.json(path+'/approve',{version:3,patch:{name:'Unreviewed'}},{headers})).status,400);
});

test('staged image is re-encoded privately and public media remains unavailable before publishing',async t=>{
 const f=await fixture(t),headers=await f.login();const input=await sharp({create:{width:20,height:12,channels:3,background:'#336633'}}).png().toBuffer();
 assert.equal((await f.agent('/media',{method:'POST',headers:{'content-type':'image/svg+xml'},body:'<svg/>'})).status,415);
 const response=await f.agent('/media',{method:'POST',headers:{'content-type':'image/png'},body:input});assert.equal(response.status,201);assert.match(response.json().imagePath,/^\/media\/[a-f0-9]{64}\.jpg$/);
 const image=f.calls.find(x=>x.name==='stageImage').args[0];assert.equal(image.mime,'image/jpeg');assert.equal((await sharp(image.bytes).metadata()).format,'jpeg');assert.equal(image.hash,hash(image.bytes));
 assert.equal((await f.request(response.json().imagePath)).status,404);
 const privatePath=`/api/marketing/v1/media/${image.hash}.jpg`;assert.equal((await f.request(privatePath)).status,401);const preview=await f.agent(`/media/${image.hash}.jpg`);assert.equal(preview.status,200);assert.equal(preview.headers['cache-control'],'no-store');assert.equal(preview.headers['content-type'],'image/jpeg');
 assert.equal(f.calls.find(x=>x.name==='getStagedImage').args[1].keyId,keyId);
 const ownerPreview=await f.request(`/admin/api/marketing/media/${image.hash}.jpg`,{headers});assert.equal(ownerPreview.status,200);assert.equal(ownerPreview.headers['cache-control'],'no-store');
 assert.equal((await f.agent('/media',{method:'POST',headers:{'content-type':'image/png'},body:Buffer.from('not an image')})).status,422);
});

test('published product SEO is escaped in server HTML without changing noindex policy',async t=>{
 const f=await fixture(t,{products:[{id:'crni-kim',name:'Public',priceMinor:1,stockQuantity:1,available:true,seoTitle:'Example </title><script>bad()</script>',seoDescription:'Description " onmouseover="bad() <tag>'}]});
 const response=await f.request('/proizvod/crni-kim');assert.equal(response.status,200);assert.match(response.text,/<title>Example &lt;\/title&gt;&lt;script&gt;bad\(\)&lt;\/script&gt;<\/title>/);assert.equal(response.text.includes('<script>bad()'),false);assert.match(response.text,/name="description" content="Description &quot; onmouseover=&quot;bad\(\) &lt;tag&gt;"/);assert.match(response.text,/name="robots" content="noindex,nofollow"/);assert.match(response.headers['x-robots-tag'],/noindex/);
 assert.match((await f.request('/robots.txt')).text,/Disallow: \//);
});

test('agent per-key read and write rate limits bound repeated requests without changing public access',async t=>{
 const reads=await fixture(t);for(let i=0;i<120;i++)assert.equal((await reads.agent('/catalog')).status,200);assert.equal((await reads.agent('/catalog')).status,429);assert.equal((await reads.request('/api/catalog')).status,200);
 reads.setTime(now+60001);assert.equal((await reads.agent('/catalog')).status,200);
 const writes=await fixture(t);for(let i=0;i<20;i++)assert.equal((await writes.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(draftInput)})).status,201);assert.equal((await writes.agent('/drafts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(draftInput)})).status,429);
});

test('marketing enabled configuration fails closed without Google admin owner and persistent stores',async()=>{
 const env={RENDER:'true',CUSTOMER_AUTH_ORIGIN:origin};assert.equal(readHostedConfig(env).marketingEnabled,false);
 assert.throws(()=>readHostedConfig({...env,MARKETING_API_ENABLED:'1'}),/Marketing API requires/);
 await assert.rejects(createHostedServer({config:{origin,host,auth:null,admin:{enabled:true,emails:['owner@example.invalid'],ownerEmail:'owner@example.invalid'},marketingEnabled:true}}),/Marketing API dependencies/);
 await assert.rejects(createHostedServer({config:{origin,host,auth:{origin,clientId,secure:true},admin:{enabled:true,emails:['owner@example.invalid'],ownerEmail:'owner@example.invalid'},marketingEnabled:true},store:{listProducts:async()=>[]},provider:{authorizationURL:()=>''}}),/Marketing API dependencies/);
});

test('product page returns retryable noindex 503 when public catalog lookup fails',async t=>{
 for(const enabled of [false,true]){const f=await fixture(t,{enabled});f.store.listProducts=async()=>{throw Error('Synthetic database outage');};const response=await f.request('/proizvod/crni-kim');assert.equal(response.status,503);assert.match(response.headers['x-robots-tag'],/noindex/);assert.equal(response.text.includes('Synthetic database outage'),false);}
});

test('OFF rollout hides capabilities and denies every marketing surface without marketing storage calls',async t=>{
 const f=await fixture(t,{enabled:false});
 for(const name of Object.keys(f.marketingStore))f.marketingStore[name]=async()=>{throw Error('OFF must never access marketing storage');};
 const headers=await f.login();const session=(await f.request('/admin/api/session',{headers})).json();assert.equal(session.capabilities.marketingEnabled,false);assert.equal(session.capabilities.marketingOwner,false);
 for(const path of ['/catalog','/stock','/sales?from=2026-10-01T00:00:00Z&to=2026-11-01T00:00:00Z','/drafts',`/drafts/${draftId}`,`/media/${'a'.repeat(64)}.jpg`])assert.equal((await f.agent(path)).status,404,path);
 for(const path of ['/drafts','/media',`/drafts/${draftId}/publish`])assert.equal((await f.agent(path,{method:'POST',headers:{'content-type':'application/json'},body:'{}'})).status,404,path);
 for(const path of ['/keys','/drafts',`/drafts/${draftId}`,'/audit',`/media/${'a'.repeat(64)}.jpg`])assert.equal((await f.request('/admin/api/marketing'+path,{headers})).status,404,path);
 assert.equal((await f.json('/admin/api/marketing/keys',{label:'Must not create',scopes:['catalog:read'],expiresAt},{headers})).status,404);
 let productReads=0;f.store.listProducts=async()=>{productReads++;return f.liveProducts;};
 assert.equal((await f.request('/proizvod/crni-kim')).status,200);
 for(const path of ['/proizvod/crni-kim/','/proizvod/crni-kim/index.html'])assert.equal((await f.request(path)).status,308,path);
 assert.equal(productReads,3); // Public SEO validity reads are independent of disabled private marketing storage.
 assert.equal((await f.request('/admin',{headers})).status,200);assert.equal((await f.request('/admin.js',{headers})).status,200);
 assert.equal((await f.request('/healthz')).status,200);
});
