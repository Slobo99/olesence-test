import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import {createPostgresStore,StoreError} from '../src/admin-store.mjs';
import {createMarketingStore,contentVersion,MARKETING_SCOPES} from '../src/marketing-store.mjs';
import {createCodStore} from '../src/cod-store.mjs';

const owner={id:'google:marketing-owner'};
const actor={id:'agent:fixture-key',keyId:'fixture-key'};
const other={id:'agent:other-key',keyId:'other-key'};
const hash=value=>createHash('sha256').update(value).digest('hex');
const status=expected=>error=>error instanceof StoreError&&error.status===expected;
const image=()=>{const bytes=Buffer.from('test-normalized-jpeg-descriptor');return {hash:hash(bytes),bytes,mime:'image/jpeg',width:1,height:1};};
async function fixture(t){
 const db=new PGlite();let tail=Promise.resolve();const queries=[];
 async function connect(){const previous=tail;let release;tail=new Promise(resolve=>{release=resolve;});await previous;return {release,query:async(sql,args)=>{queries.push(sql);return sql.startsWith('-- Applied')?(await db.exec(sql)).at(-1):db.query(sql,args);}};}
 const pool={connect,query:async(sql,args)=>{const client=await connect();try{return await client.query(sql,args);}finally{client.release();}},end:()=>db.close()};
 const admin=createPostgresStore(pool);await admin.initialize([{id:'one',name:'Original',priceMinor:10000,image:'crni-kim.jpg',description:'Old description',declaration:{warnings:'Original warning',benefit:'Keep unchanged'}},{id:'two',name:'Second',priceMinor:10000,image:'origano.jpg'}]);
 const store=createMarketingStore(pool);await store.initialize();
 for(const [id,label] of [['fixture-key','Fixture'],['other-key','Other']])await store.createKey({id,label,hash:hash(id),scopes:[...MARKETING_SCOPES],expiresAt:new Date(Date.now()+86400000).toISOString()},owner);
 t.after(()=>db.close());
 const base=async()=>(await store.listCatalog()).products.find(p=>p.id==='one').contentVersion;
 const create=async(patch={name:'Draft name'},who=actor)=>store.createDraft({productId:'one',baseContentVersion:await base(),patch},who);
 return {db,pool,admin,store,base,create,queries};
}

test('marketing migration is repeatable and catalog content version excludes commercial changes',async t=>{
 const {store,admin,base,pool}=await fixture(t);await store.initialize();
 assert.deepEqual((await pool.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(r=>r.version),[1,2,3,4,5,6,7,8,9]);
 const original=await base();const catalog=(await store.listCatalog()).products[0];assert.equal('stockQuantity' in catalog,false);assert.equal('version' in catalog,false);
 await admin.updateProduct('one',1,{priceMinor:12345,stockQuantity:4,available:true},owner);assert.equal(await base(),original);
 assert.equal((await store.listCatalog({stock:true})).products[0].stockQuantity,4);
 await admin.updateProduct('one',2,{name:'Owner update'},owner);assert.notEqual(await base(),original);
 assert.equal(contentVersion({name:'A',declaration:{warnings:'w',benefit:'b'}}),contentVersion({declaration:{benefit:'b',warnings:'w'},name:'A',stockQuantity:10,priceMinor:99}));
});

test('credentials are scoped, hashed, revocable, expiry bounded and secret hashes never returned or audited',async t=>{
 const {store,pool,create}=await fixture(t);
 assert.equal((await store.findKeyByHash(hash('fixture-key'))).id,actor.keyId);
 const keys=await store.listKeys();assert.equal(keys.keys.length,2);assert.equal(JSON.stringify(keys).includes(hash('fixture-key')),false);
 for(const patch of [{scopes:['publish']},{scopes:[]},{scopes:['catalog:read','catalog:read']},{hash:'fake'},{expiresAt:'bad'},{expiresAt:new Date(Date.now()-1000).toISOString()},{label:'bad\nlabel'}])await assert.rejects(store.createKey({id:'invalid',label:'Valid',hash:hash('invalid'),scopes:['catalog:read'],expiresAt:new Date(Date.now()+86400000).toISOString(),...patch},owner),status(400));
 await assert.rejects(store.createKey({id:'nope'},actor),status(403));
 const before=await create();await store.revokeKey(actor.keyId,owner);assert.equal(await store.findKeyByHash(hash('fixture-key')),null);await store.revokeKey(actor.keyId,owner);
 await assert.rejects(create(),status(401));await assert.rejects(store.updateDraft(before.id,{revision:before.revision,baseContentVersion:before.baseContentVersion,patch:{name:'No'}},actor),status(401));await assert.rejects(store.stageImage(image(),actor),status(401));
 await pool.query("UPDATE marketing_api_keys SET expires_at=now()-interval '1 second' WHERE id='other-key'");assert.equal(await store.findKeyByHash(hash('other-key')),null);
 const audits=await store.listAudit();assert.equal(JSON.stringify(audits).includes(hash('fixture-key')),false);assert.equal(audits.entries.filter(a=>a.action==='revoke').length,1);
});

test('write scopes are rechecked inside the transaction, independent of the HTTP guard',async t=>{
 const {store,pool,create}=await fixture(t);await pool.query("UPDATE marketing_api_keys SET scopes='[\"catalog:read\"]'::jsonb WHERE id='fixture-key'");
 await assert.rejects(create(),status(403));await assert.rejects(store.stageImage(image(),actor),status(403));
 await assert.rejects(create({name:'No'},{id:'agent:fixture-key',keyId:'other-key'}),status(403));
});

test('draft content is private, versioned, owner-approved and published without commercial-field overwrite',async t=>{
 const {store,admin,create,base}=await fixture(t);
 const draft=await create({name:'New name',seoTitle:'New SEO',declaration:{warnings:'New warning'}});
 assert.equal(draft.status,'draft');assert.equal(draft.revision,1);assert.equal(draft.baseContent.name,'Original');
 assert.equal((await admin.listProducts())[0].name,'Original');await assert.rejects(store.publishDraft(draft.id,1,owner),status(409));await assert.rejects(store.approveDraft(draft.id,1,actor),status(403));
 const approved=await store.approveDraft(draft.id,1,owner);assert.equal(approved.revision,2);assert.equal(approved.approvedRevision,2);assert.equal(approved.status,'approved');
 await admin.updateProduct('one',1,{priceMinor:45678,stockQuantity:8,available:true},owner);
 assert.equal(await base(),draft.baseContentVersion);await assert.rejects(store.publishDraft(draft.id,1,owner),status(409));
 const published=await store.publishDraft(draft.id,2,owner);assert.equal(published.status,'published');assert.equal(published.revision,3);
 const product=(await admin.listProducts())[0];assert.equal(product.name,'New name');assert.equal(product.seoTitle,'New SEO');assert.equal(product.declaration.warnings,'New warning');assert.equal(product.declaration.benefit,'Keep unchanged');assert.equal(product.priceMinor,45678);assert.equal(product.stockQuantity,8);assert.equal(product.available,true);assert.equal(product.version,3);
 await assert.rejects(store.publishDraft(draft.id,3,owner),status(409));await assert.rejects(store.updateDraft(draft.id,{revision:3,baseContentVersion:await base(),patch:{name:'Again'}},actor),status(409));
 const actions=(await store.listAudit()).entries.map(a=>a.action);assert.equal(actions.filter(a=>a==='publish').length,2);
});

test('editing an approved draft invalidates approval and replaces rather than merges its patch',async t=>{
 const {store,create}=await fixture(t);let draft=await create({name:'First',description:'Do not keep'});draft=await store.approveDraft(draft.id,1,owner);
 const updated=await store.updateDraft(draft.id,{revision:2,baseContentVersion:draft.baseContentVersion,patch:{name:'Second'}},actor);assert.equal(updated.status,'draft');assert.equal(updated.approvedRevision,null);assert.equal(updated.approvedBy,null);assert.deepEqual(updated.patch,{name:'Second'});
 await assert.rejects(store.publishDraft(draft.id,3,owner),status(409));await assert.rejects(store.approveDraft(draft.id,2,owner),status(409));
 const approved=await store.approveDraft(draft.id,3,owner);await store.publishDraft(draft.id,approved.revision,owner);
});

test('stale published content blocks creation, approval and publish; rebasing is explicit',async t=>{
 const {store,admin,create,base}=await fixture(t);const original=await base();let first=await create();let second=await create({description:'Other'});second=await store.approveDraft(second.id,1,owner);
 await admin.updateProduct('one',1,{description:'Owner changed this'},owner);
 await assert.rejects(store.createDraft({productId:'one',baseContentVersion:original,patch:{name:'No'}},actor),status(409));await assert.rejects(store.approveDraft(first.id,1,owner),status(409));await assert.rejects(store.publishDraft(second.id,2,owner),status(409));
 await assert.rejects(store.updateDraft(first.id,{revision:1,baseContentVersion:original,patch:{name:'No'}},actor),status(409));
 first=await store.updateDraft(first.id,{revision:1,baseContentVersion:await base(),patch:{name:'Rebased'}},actor);assert.equal(first.baseContent.description,'Owner changed this');assert.equal(first.status,'draft');
});

test('agents cannot access or edit other agents drafts, owners can reject, and pages are bounded',async t=>{
 const {store,create}=await fixture(t);const first=await create();const second=await create({description:'Other'},other);
 assert.equal((await store.listDrafts({keyId:actor.keyId})).drafts.length,1);assert.equal((await store.listDrafts({keyId:other.keyId})).drafts[0].id,second.id);
 await assert.rejects(store.getDraft(first.id,{keyId:other.keyId}),status(404));await assert.rejects(store.updateDraft(first.id,{revision:1,baseContentVersion:first.baseContentVersion,patch:{name:'No'}},other),status(404));
 const page=await store.listDrafts({limit:1});assert.equal(page.drafts[0].id,second.id);assert.ok(page.nextCursor);assert.equal((await store.listDrafts({limit:1,before:page.nextCursor})).drafts[0].id,first.id);
 const rejected=await store.rejectDraft(first.id,1,owner);assert.equal(rejected.status,'rejected');await assert.rejects(store.approveDraft(first.id,2,owner),status(409));
 for(const invalid of [{limit:101},{limit:0},{before:'-1'},{before:'9999999999999999999'}]){await assert.rejects(store.listDrafts(invalid),status(400));await assert.rejects(store.listAudit(invalid),status(400));}
});

test('content allowlist rejects commercial, identity, script-source, arbitrary image and malformed changes',async t=>{
 const {create,store}=await fixture(t);
 for(const patch of [{priceMinor:1},{stockQuantity:100},{available:true},{role:'owner'},{id:'two'},{image:'evil.jpg'},{imagePath:'https://example.test/a.jpg'},{imagePath:'http://127.0.0.1/internal'},{imagePath:'/assets/missing.jpg'},{imagePath:'/media/'+'0'.repeat(64)+'.jpg'},{declaration:{benefit:'Unauthorized'}},{declaration:{warnings:''}},{description:'bad\u0000text'},{name:''},{seoTitle:'x'.repeat(121)},{}])await assert.rejects(create(patch),status(400));
 assert.equal((await store.listDrafts()).drafts.length,0);
 const draft=await create({imagePath:'/assets/origano.jpg'});assert.equal(draft.patch.imagePath,'/assets/origano.jpg');
});

test('staged media stays private until atomic publish and only its uploading agent can reference it',async t=>{
 const {store,admin,create}=await fixture(t);const descriptor=image();const staged=await store.stageImage(descriptor,actor);assert.equal(staged.imagePath,'/media/'+descriptor.hash+'.jpg');assert.equal(await admin.getImage(descriptor.hash),null);
 assert.deepEqual((await store.getStagedImage(descriptor.hash,{keyId:actor.keyId})).bytes,descriptor.bytes);assert.equal(await store.getStagedImage(descriptor.hash,{keyId:other.keyId}),null);
 await assert.rejects(create({imagePath:staged.imagePath},other),status(400));let draft=await create({imagePath:staged.imagePath});draft=await store.approveDraft(draft.id,1,owner);assert.equal(await admin.getImage(descriptor.hash),null);
 await store.publishDraft(draft.id,draft.revision,owner);assert.deepEqual((await admin.getImage(descriptor.hash)).bytes,descriptor.bytes);assert.equal(await store.getStagedImage(descriptor.hash),null);
 assert.equal((await create({imagePath:staged.imagePath},other)).patch.imagePath,staged.imagePath);
 const serialized=JSON.stringify(await store.listAudit());assert.equal(serialized.includes(descriptor.bytes.toString('base64')),false);assert.equal(serialized.includes('"bytes"'),false);
});

test('audit failure rolls back staged image, draft, and publish including public image and catalog',async t=>{
 const {store,admin,create,pool}=await fixture(t);await pool.query("ALTER TABLE marketing_audit ADD CONSTRAINT audit_failure CHECK(actor_id<>'agent:fixture-key')");
 await assert.rejects(create(),/audit_failure/);await assert.rejects(store.stageImage(image(),actor),/audit_failure/);assert.equal((await store.listDrafts()).drafts.length,0);assert.equal(await store.getStagedImage(image().hash),null);
 await pool.query('ALTER TABLE marketing_audit DROP CONSTRAINT audit_failure');const staged=await store.stageImage(image(),actor);let draft=await create({name:'Must not leak',imagePath:staged.imagePath});draft=await store.approveDraft(draft.id,1,owner);
 await pool.query("ALTER TABLE marketing_audit ADD CONSTRAINT publish_failure CHECK(action<>'publish')");await assert.rejects(store.publishDraft(draft.id,draft.revision,owner),/publish_failure/);
 assert.equal((await admin.listProducts())[0].name,'Original');assert.equal(await admin.getImage(image().hash),null);assert.ok(await store.getStagedImage(image().hash));assert.equal((await store.getDraft(draft.id)).status,'approved');
});

test('concurrent stale draft writes yield exactly one accepted edit with no partial changes',async t=>{
 const {store,create}=await fixture(t);const draft=await create();const result=await Promise.allSettled(['First','Second'].map(name=>store.updateDraft(draft.id,{revision:1,baseContentVersion:draft.baseContentVersion,patch:{name}},actor)));
 assert.equal(result.filter(r=>r.status==='fulfilled').length,1);assert.equal(result.find(r=>r.status==='rejected').reason.status,409);assert.equal((await store.getDraft(draft.id)).revision,2);
});

test('sales reports query only COD aggregate amounts and never equate completed orders with collected revenue',async t=>{
 const {store,pool,admin,queries}=await fixture(t);const customerId='11111111-1111-4111-8111-111111111111';await pool.query("INSERT INTO commerce_customers(id,provider,subject,email,name) VALUES($1,'google','private-customer','private@example.invalid','Private Name')",[customerId]);await admin.updateProduct('one',1,{stockQuantity:5,available:true},owner);
 const cod=createCodStore(pool);const contact={fullName:'Private Name',email:'private@example.invalid',phone:'0600000000',address:'Private Address',city:'Beograd',postalCode:'11000',country:'RS'};
 const order=async(index)=>cod.createOrder({customerId,items:[{productId:'one',quantity:1,expectedRevision:index+1}],contact,shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:40000,idempotencyKey:'fixture_cod_order_'+index});
 const first=(await order(1)).order;const second=(await order(2)).order;await admin.updateOrder(first.id,1,{status:'processing'},owner);await admin.updateOrder(first.id,2,{status:'shipped'},owner);await admin.updateOrder(first.id,3,{status:'completed'},owner);await admin.updateOrder(second.id,1,{status:'cancelled'},owner);
 await pool.query("INSERT INTO admin_orders(id,document,status) VALUES('legacy','{\"customer\":\"Never return\",\"totalMinor\":999999}','pending')");
 const from=new Date(Date.now()-86400000).toISOString(),to=new Date(Date.now()+86400000).toISOString();const report=await store.salesSummary({from,to});assert.equal(report.orderCount,2);assert.equal(report.orderValueMinor,80000);assert.equal(report.collectedRevenueMinor,null);assert.equal(report.paymentCollectionTracked,false);assert.deepEqual(report.byStatus.map(s=>s.status),['cancelled','completed']);assert.equal(report.byStatus.every(s=>s.orderValueMinor===40000),true);
 for(const secret of ['private@example.invalid','Private Name','Private Address',customerId,first.id])assert.equal(JSON.stringify(report).includes(secret),false);
 const sql=queries.at(-1);assert.equal(sql.includes('contact_snapshot'),false);assert.equal(sql.includes('customer_id'),false);assert.match(sql,/GROUP BY status/);
 for(const range of [{from:'bad',to},{from:to,to:from},{from:'2020-01-01T00:00:00Z',to:'2026-01-01T00:00:00Z'}])await assert.rejects(store.salesSummary(range),status(400));
});

test('image descriptor limits and caller mutation are enforced before the first await',async t=>{
 const {store}=await fixture(t);const original=image();
 for(const invalid of [null,{...original,hash:'0'.repeat(64)},{...original,mime:'image/png'},{...original,width:0},{...original,height:1601},{...original,bytes:new Uint8Array(original.bytes)},{...original,bytes:Buffer.alloc(0)}])await assert.rejects(store.stageImage(invalid,actor),status(400));
 const large=Buffer.alloc(1572865);await assert.rejects(store.stageImage({...original,bytes:large,hash:hash(large)},actor),status(413));
 const pending=store.stageImage(original,actor);original.bytes.fill(0);await pending;assert.equal((await store.getStagedImage(original.hash)).bytes.toString(),'test-normalized-jpeg-descriptor');
});

test('private and public images share the 100 MiB quota and a rejection rolls back bytes and audit',async t=>{
 const {store,pool}=await fixture(t);
 await pool.query("INSERT INTO admin_product_images(hash,bytes,mime,width,height) SELECT lpad(to_hex(n),64,'0'),decode(repeat('00',1572864),'hex'),'image/jpeg',1,1 FROM generate_series(1,66) n");
 const descriptor=byte=>{const bytes=Buffer.alloc(786432,byte);return {hash:hash(bytes),bytes,mime:'image/jpeg',width:1,height:1};};
 const first=descriptor(1),second=descriptor(2);await store.stageImage(first,actor);await assert.rejects(store.stageImage(second,other),status(413));assert.equal(await store.getStagedImage(second.hash),null);assert.ok(await store.getStagedImage(first.hash));
 assert.equal((await store.listAudit()).entries.filter(a=>a.action==='stage').length,1);
 await store.stageImage(first,actor);assert.equal((await store.listAudit()).entries.filter(a=>a.action==='stage').length,1);
});

test('description formatting changes invalidate drafts and survive later marketing publication',async t=>{
 const {store,admin,create}=await fixture(t);
 const stale=await create({description:'Stale copy'});await store.approveDraft(stale.id,1,owner);
 await admin.updateProduct('one',1,{descriptionFormat:'markdown'},owner);
 await assert.rejects(store.publishDraft(stale.id,2,owner),status(409));
 const current=await create({description:'## Current heading\n\n**Current copy**'});
 assert.equal(current.baseContent.descriptionFormat,'markdown');
 await store.approveDraft(current.id,1,owner);await store.publishDraft(current.id,2,owner);
 const product=(await admin.listProducts()).find(p=>p.id==='one');assert.equal(product.descriptionFormat,'markdown');assert.equal(product.description,'## Current heading\n\n**Current copy**');
 await assert.rejects(create({descriptionFormat:'html'}),status(400));
 await assert.rejects(create({descriptionFormat:'plain'}),status(400));
});
