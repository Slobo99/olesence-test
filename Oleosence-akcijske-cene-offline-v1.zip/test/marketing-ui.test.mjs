import {descriptionMarkup} from '../public/product-view.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
const html=await readFile(new URL('../public/admin.html',import.meta.url),'utf8');
const source=(await readFile(new URL('../public/admin.js',import.meta.url),'utf8')).replaceAll('export function ','function ').replace(/^import .*;\n/gm,'');
const response=(json,status=200)=>({ok:status>=200&&status<300,status,json:async()=>json});
const until=async(predicate)=>{for(let i=0;i<200;i++){if(predicate())return;await new Promise(r=>setTimeout(r,5));}assert.fail('Condition timed out');};
const sample=()=>({id:'draft-1',productId:'crni-kim',revision:1,status:'draft',baseContentVersion:'a'.repeat(64),baseContent:{name:'Prethodni naziv',description:'Prethodni opis'},patch:{name:'Predloženi naziv',description:'Novi opis'}});
async function fixture(t,{owner=true,enabled=true}={}){
 const dom=new JSDOM(html,{url:'https://admin.example.test/admin',runScripts:'outside-only'}),w=dom.window;
 await new Promise(r=>w.addEventListener('load',r,{once:true}));
 const data={owner,enabled,draft:sample(),keys:[{id:'key-1',label:'Test tim',scopes:['drafts:read'],expiresAt:'2026-12-01T12:00:00Z',revokedAt:null}],calls:[],error:null,delay:null,email:'owner@example.test',sessionDelay:null};
 w.confirm=()=>true;w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(value=''){this.returnValue=value;this.open=false;this.dispatchEvent(new w.Event('close'));};
 w.fetch=async(path,options={})=>{
  data.calls.push({path,options});
  if(path==='/admin/api/session'){if(data.sessionDelay)return data.sessionDelay;return response({user:{email:data.email},csrfToken:'test-csrf',capabilities:{marketingOwner:data.owner,marketingEnabled:data.enabled}});}
  if(path.startsWith('/admin/api/marketing/audit'))return response(data.audit||{entries:[],nextCursor:null});
  if(path==='/admin/api/products')return response({products:[]});
  if(path==='/admin/api/orders')return response({orders:[]});
  if(path==='/admin/api/marketing/drafts')return response({drafts:[structuredClone(data.draft)],nextCursor:null});
  if(path==='/admin/api/marketing/drafts/draft-1')return response(structuredClone(data.draft));
  if(path==='/admin/api/marketing/keys'&&options.method!=='POST')return response({keys:structuredClone(data.keys)});
  if(options.method==='POST'){
   if(data.delay)return data.delay;if(data.error)return response({},data.error);
   const body=JSON.parse(options.body);
   if(path==='/admin/api/marketing/keys'){const key={id:'key-2',label:body.label,scopes:body.scopes,expiresAt:body.expiresAt};data.keys.push(key);return response({key,token:'FAKE_LOCAL_TEST_SECRET_NEVER_PRODUCTION'});}
   if(path==='/admin/api/marketing/keys/key-1/revoke'){data.keys[0].revokedAt=new Date().toISOString();return response({revoked:true});}
   if(path.startsWith('/admin/api/marketing/drafts/draft-1/')){
    if(body.version!==data.draft.revision)return response({},409);
    data.draft={...data.draft,status:path.endsWith('approve')?'approved':path.endsWith('publish')?'published':'rejected',revision:data.draft.revision+1};
    return response(structuredClone(data.draft));
   }
  }
  throw Error('Unexpected request: '+path);
 };
 w.descriptionMarkup=descriptionMarkup;vm.runInContext(source,dom.getInternalVMContext());w.dispatchEvent(new w.Event('pageshow'));await until(()=>w.document.querySelector('#workspace').hidden===false&&w.document.querySelector('#content').textContent.includes('Katalog je prazan'));
 t.after(()=>w.close());const $=selector=>w.document.querySelector(selector);const close=value=>$('#confirm').close(value);
 const open=async()=>{$('#marketing-tab').click();await until(()=>$('.marketing-key-form'));};
 const review=async()=>{if(!$('.marketing-draft'))await open();$('.marketing-draft button').click();await until(()=>$('.marketing-diffs'));};
 const mutations=()=>data.calls.filter(call=>call.options.method==='POST');
 const create=async()=>{await open();$('.marketing-key-form [name=label]').value='Novi AI tim';$('.marketing-key-form').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));close('save');await until(()=>$('.marketing-secret input'));};
 return {w,data,$,close,open,review,mutations,create};
}

test('marketing UI requires strict enabled owner capabilities and cannot load from a forged hidden-tab click',async t=>{
 for(const [owner,enabled] of [[false,true],[true,false],['true',true],[true,1]])await t.test(String(owner)+'/'+String(enabled),async t=>{
  const {w,$,data}=await fixture(t,{owner,enabled});assert.equal($('#marketing-tab').hidden,true);$('#marketing-tab').dispatchEvent(new w.Event('click'));await new Promise(r=>setTimeout(r,10));assert.equal(data.calls.some(c=>c.path.includes('/marketing/')),false);
 });
});
test('marketing list requires a fresh exact-version review before approving or publishing',async t=>{
 const {data,$,open,review}=await fixture(t);await open();assert.equal($('[data-marketing-action]'),null);await review();
 assert.equal(data.calls.filter(c=>c.path==='/admin/api/marketing/drafts/draft-1').length,1);
 assert.match($('.marketing-draft').textContent,/Prethodni naziv/);assert.match($('.marketing-draft').textContent,/Predloženi naziv/);assert.match($('.marketing-draft').textContent,/Pregledana verzija 1/);
 assert.ok($('[data-marketing-action=approve]'));assert.equal($('[data-marketing-action=publish]'),null);
});
test('marketing approval and publication are separate confirmations using exact revision and CSRF',async t=>{
 const {data,$,review,close,mutations}=await fixture(t);await review();$('[data-marketing-action=approve]').click();
 assert.match($('#confirm-message').textContent,/verziju 1/);assert.match($('#confirm-message').textContent,/ne objavljuje/);close('save');await until(()=>$('[data-marketing-action=publish]'));
 assert.equal(mutations().length,1);assert.match($('#status').textContent,/Još nije objavljena/);assert.equal(data.draft.status,'approved');
 $('[data-marketing-action=publish]').click();assert.match($('#confirm-message').textContent,/OBJAVITI/);assert.match($('#confirm-message').textContent,/verziju 2/);close('save');await until(()=>data.draft.status==='published'&&$('[data-marketing-action]')===null);
 assert.equal(mutations().length,2);assert.deepEqual(mutations().map(x=>JSON.parse(x.options.body)),[{version:1},{version:2}]);assert.equal(mutations()[1].options.headers['X-CSRF-Token'],'test-csrf');
});
test('marketing cancel and repeated clicks do not send extra requests',async t=>{
 const {w,$,review,close,mutations}=await fixture(t);await review();const approve=$('[data-marketing-action=approve]');approve.click();approve.dispatchEvent(new w.Event('click'));assert.equal(approve.disabled,true);close('cancel');await until(()=>!approve.disabled);assert.equal(mutations().length,0);
 approve.click();close('save');await until(()=>$('[data-marketing-action=publish]'));approve.dispatchEvent(new w.Event('click'));assert.equal($('#confirm').open,false);assert.equal(mutations().length,1);
});
test('marketing stale conflict removes action controls and requires a new review without automatic approval',async t=>{
 const {data,$,review,close,mutations}=await fixture(t);await review();data.draft={...data.draft,revision:2,patch:{name:'Novija izmena'}};
 $('[data-marketing-action=approve]').click();close('save');await until(()=>$('#status').textContent.includes('međuvremenu'));assert.equal($('[data-marketing-action]'),null);assert.equal(mutations().length,1);
 $('.marketing-draft button').click();await until(()=>$('[data-marketing-action=approve]'));assert.match($('.marketing-draft').textContent,/Novija izmena/);assert.match($('.marketing-draft').textContent,/Pregledana verzija 2/);assert.equal(mutations().length,1);
});
test('marketing arbitrary content stays text and image previews stay restricted to safe same-origin paths',async t=>{
 const {data,$,review}=await fixture(t);data.draft.patch={name:'<img src=x onerror=alert(1)>',description:'</pre><script>bad()</script>',imagePath:'https://attacker.invalid/image.jpg',seoTitle:'<svg onload=bad()>'};await review();
 assert.equal($('#content [onerror], #content script, #content svg'),null);assert.equal($('.marketing-diffs img'),null);assert.match($('.marketing-diffs').textContent,/<script>bad/);
 data.draft.patch.imagePath='/media/'+'a'.repeat(64)+'.jpg';$('#refresh').click();await until(()=>$('.marketing-draft button'));$('.marketing-draft button').click();await until(()=>$('.marketing-diffs img'));assert.equal($('.marketing-diffs img').getAttribute('src'),'/admin/api/marketing/media/'+'a'.repeat(64)+'.jpg');
});
test('marketing request errors do not report success or optimistic publication',async t=>{
 const {data,$,review,close}=await fixture(t);data.draft.status='approved';await review();data.error=500;$('[data-marketing-action=publish]').click();close('save');await until(()=>$('#status').textContent.includes('Zahtev nije uspeo'));assert.equal(data.draft.status,'approved');assert.ok($('[data-marketing-action=publish]'));assert.doesNotMatch($('#status').textContent,/objavljena/);
});
test('marketing rejection uses the reviewed version and never publishes',async t=>{
 const {data,$,review,close,mutations}=await fixture(t);await review();$('[data-marketing-action=reject]').click();close('save');await until(()=>data.draft.status==='rejected'&&$('[data-marketing-action]')===null);assert.equal(mutations()[0].path,'/admin/api/marketing/drafts/draft-1/reject');assert.deepEqual(JSON.parse(mutations()[0].options.body),{version:1});
});
test('marketing key issuance is explicit, bounded, scoped and secret is shown once outside URLs and storage',async t=>{
 const {w,data,$,open,close,mutations}=await fixture(t);await open();const form=$('.marketing-key-form');form.querySelector('[name=label]').value='Novi AI tim';form.querySelector('[value="stock:read"]').checked=false;
 form.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));assert.equal(mutations().length,0);assert.match($('#confirm-message').textContent,/30 dana/);assert.doesNotMatch($('#confirm-message').textContent,/stock:read/);close('save');await until(()=>$('.marketing-secret input'));
 const request=JSON.parse(mutations()[0].options.body);assert.equal(request.label,'Novi AI tim');assert.equal(request.scopes.includes('stock:read'),false);assert.equal(Date.parse(request.expiresAt)>Date.now()+29*86400000,true);assert.equal(Date.parse(request.expiresAt)<Date.now()+31*86400000,true);
 const secret=$('.marketing-secret input');assert.equal(secret.type,'password');assert.equal(secret.value,'FAKE_LOCAL_TEST_SECRET_NEVER_PRODUCTION');assert.equal(w.localStorage.length,0);assert.equal(w.sessionStorage.length,0);assert.equal(w.location.search,'');assert.doesNotMatch($('#status').textContent,/FAKE_LOCAL/);assert.equal(data.calls.some(c=>c.path.includes('FAKE_LOCAL')),false);
 $('[data-view=orders]').click();await until(()=>$('.marketing-secret')===null);assert.equal(secret.value,'');await open();assert.equal($('.marketing-secret input'),null);
});
test('marketing secret hide button erases the field; pagehide also clears detached references',async t=>{
 const {w,$,create}=await fixture(t);await create();const first=$('.marketing-secret input');const buttons=$('.marketing-secret').querySelectorAll('button');buttons[0].click();assert.equal(first.type,'text');buttons[1].click();assert.equal(first.value,'');assert.equal($('.marketing-secret').hidden,true);
 $('#refresh').click();await until(()=>$('.marketing-key-form'));$('.marketing-key-form [name=label]').value='Drugi AI tim';$('.marketing-key-form').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));$('#confirm').close('save');await until(()=>$('.marketing-secret input'));const second=$('.marketing-secret input');w.dispatchEvent(new w.Event('pagehide'));assert.equal(second.value,'');assert.equal($('#content').childElementCount,0);
});
test('marketing key creation validates selection and cancellation does not create keys',async t=>{
 const {w,$,open,close,mutations}=await fixture(t);await open();const form=$('.marketing-key-form');form.querySelector('[name=label]').value='Test';for(const checkbox of form.querySelectorAll('[name=scope]'))checkbox.checked=false;
 form.dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));assert.equal($('#confirm').open,false);assert.match($('.marketing-key-form .form-message').textContent,/najmanje jednu/);assert.equal(mutations().length,0);
 form.querySelector('[name=scope]').checked=true;form.dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));close('cancel');await until(()=>!form.querySelector('button').disabled);assert.equal(mutations().length,0);
});
test('marketing revocation requires confirmation, uses CSRF and stops offering duplicate revocation',async t=>{
 const {data,$,open,close,mutations}=await fixture(t);await open();$('.marketing-key button').click();assert.match($('#confirm-message').textContent,/Opozvati ključ/);close('save');await until(()=>$('.marketing-key button')===null);assert.ok(data.keys[0].revokedAt);assert.equal(mutations()[0].path,'/admin/api/marketing/keys/key-1/revoke');assert.equal(mutations()[0].options.headers['X-CSRF-Token'],'test-csrf');
});
test('marketing denied session clears drafts, secret and owner controls',async t=>{
 const {data,$,create,close}=await fixture(t);await create();const secret=$('.marketing-secret input');data.error=403;$('.marketing-key button').click();close('save');await until(()=>$('#workspace').hidden);assert.equal(secret.value,'');assert.equal($('#content').childElementCount,0);assert.equal($('#marketing-tab').hidden,true);assert.equal($('#confirm').open,false);
});
test('marketing pagehide cancels confirmation and ignores late mutation response',async t=>{
 const {w,data,$,review,close,mutations}=await fixture(t);await review();$('[data-marketing-action=approve]').click();w.dispatchEvent(new w.Event('pagehide'));await new Promise(r=>setTimeout(r,10));assert.equal(mutations().length,0);assert.equal($('#confirm').open,false);
 w.dispatchEvent(new w.Event('pageshow'));await until(()=>!$('#workspace').hidden&&$('#content').textContent.includes('Katalog je prazan'));await review();let resolve;data.delay=new Promise(r=>resolve=r);$('[data-marketing-action=approve]').click();close('save');await until(()=>mutations().length===1);w.dispatchEvent(new w.Event('pagehide'));resolve(response({...data.draft,status:'approved',revision:2}));await new Promise(r=>setTimeout(r,20));assert.equal($('#content').childElementCount,0);assert.equal($('#workspace').hidden,true);
});
test('marketing loss of owner capability during session revalidation cancels pending confirmation',async t=>{
 const {w,data,$,review,mutations}=await fixture(t);await review();Object.defineProperty(w.document,'hidden',{configurable:true,value:false});let resolve;data.sessionDelay=new Promise(r=>resolve=r);w.document.dispatchEvent(new w.Event('visibilitychange'));$('[data-marketing-action=approve]').click();
 resolve(response({user:{email:data.email},csrfToken:'new-csrf',capabilities:{marketingOwner:false,marketingEnabled:true}}));await until(()=>!$('#confirm').open&&$('#marketing-tab').hidden&&$('#section-title').textContent==='Proizvodi');assert.equal(mutations().length,0);assert.equal($('.marketing-draft'),null);
});

test('marketing audit is owner-only, on demand, safely rendered and paginated',async t=>{
 const {data,$,open}=await fixture(t);await open();assert.equal(data.calls.some(c=>c.path.includes('/marketing/audit')),false);
 data.audit={entries:[{id:'1',action:'draft.approve',entityType:'draft',entityId:'<img src=x>',actorId:'google:verified',createdAt:'2026-10-28T01:00:00Z',before:{name:'<script>bad</script>'},after:{name:'Odobreno'}}],nextCursor:'1'};
 $('.marketing-audit button').click();await until(()=>$('.marketing-audit .audit-entry'));assert.match($('.marketing-audit').textContent,/<script>bad/);assert.equal($('.marketing-audit script, .marketing-audit img'),null);
 data.audit={entries:[],nextCursor:null};$('.marketing-audit button').click();await until(()=>$('.marketing-audit button').hidden);assert.ok(data.calls.some(c=>c.path==='/admin/api/marketing/audit?before=1'));
});

test('marketing uncertain key creation requires refresh before another issuance attempt',async t=>{
 const {w,data,$,open,close,mutations}=await fixture(t);await open();data.error=500;const form=$('.marketing-key-form');form.querySelector('[name=label]').value='Test tim';form.dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));close('save');
 await until(()=>$('.marketing-key-form .form-message').textContent.includes('Ishod kreiranja'));assert.equal(form.querySelector('button').disabled,true);form.dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));assert.equal(mutations().length,1);assert.equal($('#confirm').open,false);
 data.error=null;$('#refresh').click();await until(()=>$('.marketing-key-form')&&$('.marketing-key-form')!==form);assert.equal($('.marketing-key-form button').disabled,false);
});
