import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {createCodStore} from '../src/cod-store.mjs';
import {createPostgresStore} from '../src/admin-store.mjs';
import {createOrderStore} from '../src/order-store.mjs';

const customerId='11111111-1111-4111-8111-111111111111';
const otherCustomerId='22222222-2222-4222-8222-222222222222';
const guestId='33333333-3333-4333-8333-333333333333';
const actor='google:synthetic-orders-admin';
const contact={fullName:'Test Kupac',email:'buyer@example.invalid',phone:'0600000000',address:'Izmisljena 1',city:'Beograd',postalCode:'11000',country:'RS'};
const input=(key='order_number_key_01',patch={})=>({customerId,items:[{productId:'p1',quantity:1,expectedRevision:1}],contact:{...contact},shippingMethod:'courier',paymentMethod:'cod',expectedTotalMinor:179000,idempotencyKey:key,...patch});
const status=expected=>error=>error.status===expected;

async function fixture(t,{migrateNumbers=true}={}){
 const db=new PGlite();t.after(()=>db.close());
 // PGlite has one PostgreSQL session. Concurrent callers are serialized here;
 // these are transaction/constraint tests, not a multi-connection race test.
 let tail=Promise.resolve();
 async function acquire(){const prior=tail;let release;tail=new Promise(resolve=>{release=resolve;});await prior;return release;}
 const queries=[];
 const query=(sql,args)=>{queries.push(sql);return sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args);};
 const pool={async query(sql,args){const release=await acquire();try{return await query(sql,args);}finally{release();}},async connect(){const release=await acquire();return {query,release};}};
 const migrate=async name=>db.exec(await readFile(new URL('../migrations/'+name,import.meta.url),'utf8'));
 for(const file of ['001_admin.sql','002_product_images.sql','003_customers.sql','004_order_model.sql','005_cod_checkout.sql','006_guest_checkout.sql'])await migrate(file);
 if(migrateNumbers)await migrate('007_order_numbers.sql');
 for(const [id,subject] of [[customerId,'one'],[otherCustomerId,'two']])await db.query("INSERT INTO commerce_customers(id,provider,subject,email,name) VALUES($1,'google',$2,$3,'Test')",[id,subject,subject+'@example.invalid']);
 await db.query("INSERT INTO guest_checkout_sessions(id,token_hash,csrf_token,expires_at) VALUES($1,$2,$3,now()+interval '24 hours')",[guestId,'a'.repeat(64),'b'.repeat(32)]);
 for(const id of ['p1','p2','p3'])await db.query('INSERT INTO admin_products(id,document) VALUES($1,$2::jsonb)',[id,JSON.stringify({name:'Original '+id,priceMinor:149000,stockQuantity:20,available:true})]);
 // A fixture-only default exercises the actual trigger with controlled database
 // timestamps; the public create-order input never accepts a date or number.
 const at=instant=>db.query("SELECT set_config('test.order_created_at',$1,false)",[instant]);
 await at('2026-06-01T12:00:00.000Z');
 await db.exec("ALTER TABLE admin_orders ALTER COLUMN created_at SET DEFAULT current_setting('test.order_created_at')::timestamptz");
 const counters=async()=>(await db.query('SELECT order_year,last_number::text FROM admin_order_number_counters ORDER BY order_year')).rows;
 return {db,pool,queries,migrate,at,counters,store:createCodStore(pool),admin:createPostgresStore(pool)};
}

test('customer and guest orders share numbers while opaque IDs still govern access and status changes',async t=>{
 const {db,store,admin,counters}=await fixture(t);
 const first=(await store.createOrder(input())).order;
 const guestInput=input('guest_number_key_01',{owner:{guestId},items:[{productId:'p2',quantity:1,expectedRevision:1}]});delete guestInput.customerId;
 const second=(await store.createOrder(guestInput)).order;
 assert.equal(first.orderNumber,'2026-1000');assert.equal(second.orderNumber,'2026-1001');
 assert.match(first.id,/^COD-[a-f0-9-]{36}$/);assert.match(second.id,/^COD-[a-f0-9-]{36}$/);assert.notEqual(first.id,second.id);
 assert.deepEqual(await counters(),[{order_year:2026,last_number:'1001'}]);
 assert.equal((await store.getCustomerOrder(customerId,first.id)).orderNumber,first.orderNumber);
 assert.equal((await store.listCustomerOrders(customerId)).orders[0].orderNumber,first.orderNumber);
 assert.equal((await store.listGuestOrders(guestId)).orders[0].orderNumber,second.orderNumber);
 assert.equal(await store.getCustomerOrder(otherCustomerId,first.id),null);
 assert.equal(await store.getOwnerOrder({guestId},first.id),null);
 await assert.rejects(store.getCustomerOrder(customerId,first.orderNumber),status(400));
 assert.deepEqual((await admin.listOrders()).orders.map(order=>[order.id,order.orderNumber]),[[second.id,'2026-1001'],[first.id,'2026-1000']]);
 assert.equal((await admin.updateOrder(first.id,1,{status:'processing'},actor)).orderNumber,'2026-1000');
 assert.equal((await admin.updateOrder(first.id,2,{status:'cancelled'},actor)).orderNumber,'2026-1000');
 const third=(await store.createOrder(input('next_number_key_01',{items:[{productId:'p3',quantity:1,expectedRevision:1}]}))).order;
 assert.equal(third.orderNumber,'2026-1002');
 assert.equal((await db.query("SELECT document->>'stockQuantity' AS stock FROM admin_products WHERE id='p1'")).rows[0].stock,'19');
 for(const entry of (await admin.listAudit()).entries){assert.deepEqual(Object.keys(entry.after).sort(),['id','status','version']);assert.equal(entry.entityId,first.id);}
});

test('Belgrade midnight starts the new year at 1000 and cross-year retries keep their original number',async t=>{
 const {db,store,at,counters}=await fixture(t);
 await db.exec("SET TIME ZONE 'Pacific/Honolulu'");
 await at('2026-12-31T22:59:59.999Z');
 const first=(await store.createOrder(input())).order;
 assert.equal(first.orderNumber,'2026-1000');
 await at('2026-12-31T23:00:00.000Z');
 const second=(await store.createOrder(input('new_year_key_00001',{items:[{productId:'p1',quantity:1,expectedRevision:2}]}))).order;
 assert.equal(second.orderNumber,'2027-1000');
 const replay=await store.createOrder(input());
 assert.equal(replay.replayed,true);assert.equal(replay.order.id,first.id);assert.equal(replay.order.orderNumber,'2026-1000');assert.equal(new Date(replay.order.createdAt).getTime(),new Date(first.createdAt).getTime());
 const third=(await store.createOrder(input('new_year_key_00002',{items:[{productId:'p1',quantity:1,expectedRevision:3}]}))).order;
 assert.equal(third.orderNumber,'2027-1001');
 assert.deepEqual(await counters(),[{order_year:2026,last_number:'1000'},{order_year:2027,last_number:'1001'}]);
});

test('concurrent caller retries allocate once and independent owners receive distinct numbers',async t=>{
 const {db,store,counters}=await fixture(t);
 const retries=await Promise.all(Array.from({length:6},()=>store.createOrder(input())));
 assert.equal(retries.filter(result=>!result.replayed).length,1);
 assert.deepEqual(new Set(retries.map(result=>result.order.orderNumber)),new Set(['2026-1000']));
 const results=await Promise.all([
  store.createOrder(input('independent_key_001',{customerId:otherCustomerId,items:[{productId:'p2',quantity:1,expectedRevision:1}]})),
  store.createOrder(input('independent_key_002',{items:[{productId:'p3',quantity:1,expectedRevision:1}]}))
 ]);
 assert.deepEqual(new Set(results.map(result=>result.order.orderNumber)),new Set(['2026-1001','2026-1002']));
 await assert.rejects(store.createOrder(input(undefined,{contact:{...contact,city:'Novi Sad'}})),status(409));
 assert.deepEqual(await counters(),[{order_year:2026,last_number:'1002'}]);
 assert.equal((await db.query('SELECT count(*)::int AS n FROM admin_orders')).rows[0].n,3);
 assert.equal((await db.query("SELECT document->>'stockQuantity' AS stock FROM admin_products WHERE id='p1'")).rows[0].stock,'19');
});

test('failed commit rolls back the number with the order and stock before a safe retry',async t=>{
 const {db,store,counters}=await fixture(t);
 await db.exec(`CREATE FUNCTION reject_number_fixture_commit() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'fixture rejects commit'; END $$;
 CREATE CONSTRAINT TRIGGER fixture_number_commit_failure AFTER INSERT ON admin_orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION reject_number_fixture_commit();`);
 await assert.rejects(store.createOrder(input()),/fixture rejects commit/);
 assert.deepEqual(await counters(),[]);
 assert.deepEqual((await db.query('SELECT (SELECT count(*)::int FROM admin_orders) AS orders,(SELECT count(*)::int FROM admin_order_items) AS items')).rows[0],{orders:0,items:0});
 assert.deepEqual((await db.query("SELECT document->>'stockQuantity' AS stock,revision FROM admin_products WHERE id='p1'")).rows[0],{stock:'20',revision:1});
 await db.exec('DROP TRIGGER fixture_number_commit_failure ON admin_orders');
 const first=(await store.createOrder(input())).order;assert.equal(first.orderNumber,'2026-1000');
 // Rollback also restores an existing year's counter, not just its first row.
 await db.exec('CREATE CONSTRAINT TRIGGER fixture_number_commit_failure AFTER INSERT ON admin_orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION reject_number_fixture_commit()');
 const secondInput=input('number_retry_key_02',{items:[{productId:'p1',quantity:1,expectedRevision:2}]});
 await assert.rejects(store.createOrder(secondInput),/fixture rejects commit/);
 assert.deepEqual(await counters(),[{order_year:2026,last_number:'1000'}]);
 await db.exec('DROP TRIGGER fixture_number_commit_failure ON admin_orders');
 assert.equal((await store.createOrder(secondInput)).order.orderNumber,'2026-1001');
});

test('upgrade preserves unnumbered historical orders, draft records and idempotent replays',async t=>{
 const {db,pool,migrate,store,admin,counters}=await fixture(t,{migrateNumbers:false});
 const first=(await store.createOrder(input())).order;
 await db.query("INSERT INTO admin_orders(id,document) VALUES('legacy-order',$1::jsonb)",[JSON.stringify({legacyField:'preserve',orderNumber:'forged-document-number'})]);
 const before=(await db.query('SELECT * FROM admin_orders WHERE id=$1',[first.id])).rows[0];
 await migrate('007_order_numbers.sql');
 assert.equal(first.orderNumber,null);
 const replay=await store.createOrder(input());assert.equal(replay.replayed,true);assert.equal(replay.order.id,first.id);assert.equal(replay.order.orderNumber,null);
 assert.equal((await store.getCustomerOrder(customerId,first.id)).orderNumber,null);
 assert.equal((await store.listCustomerOrders(customerId)).orders[0].orderNumber,null);
 assert.deepEqual((await db.query('SELECT * FROM admin_orders WHERE id=$1',[first.id])).rows[0],{...before,order_number:null});
 await admin.initialize([]);await admin.initialize([]);
 assert.equal((await admin.listOrders()).orders.find(order=>order.id==='legacy-order').orderNumber,null);
 assert.equal((await admin.listOrders()).orders.find(order=>order.id===first.id).orderNumber,null);
 await assert.rejects(db.query('UPDATE admin_orders SET order_number=$2 WHERE id=$1',[first.id,'2026-1000']),/immutable/);
 await assert.rejects(db.query("UPDATE admin_orders SET order_number='2026-1000' WHERE id='legacy-order'"),/immutable/);
 assert.equal((await admin.updateOrder(first.id,1,{status:'processing'},actor)).orderNumber,null);
 const {order:draft}=await createOrderStore(pool,{allowDraftCreation:true}).createDraftOrder({customerId,items:[{productId:'p2',quantity:1,expectedRevision:1}],contact,shippingMethod:'delivery-estimate',idempotencyKey:'draft_number_key_01'});
 assert.equal((await admin.listOrders()).orders.find(order=>order.id===draft.id).orderNumber,null);
 assert.deepEqual(await counters(),[]);
 const next=(await store.createOrder(input('after_upgrade_key_01',{items:[{productId:'p1',quantity:1,expectedRevision:2}]}))).order;
 assert.equal(next.orderNumber,'2026-1000');
 assert.deepEqual((await db.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(row=>row.version),[1,2,3,4,5,6,7,8]);
});

test('numbers reject client injection, database rewrites, duplicates and clearing',async t=>{
 const {db,store,admin,counters}=await fixture(t);
 for(const patch of [{orderNumber:'2026-1000'},{order_number:'2026-1000'},{orderNumber:null},{createdAt:'2026-01-01'},{id:'COD-forged'}])await assert.rejects(store.createOrder(input(undefined,patch)),status(400));
 assert.deepEqual(await counters(),[]);
 const first=(await store.createOrder(input())).order;
 for(const value of ['2026-9999','2027-1000',null])await assert.rejects(db.query('UPDATE admin_orders SET order_number=$2 WHERE id=$1',[first.id,value]),/immutable/);
 await assert.rejects(admin.updateOrder(first.id,1,{orderNumber:'2026-9999'},actor),status(400));
 await assert.rejects(admin.updateOrder(first.id,1,{status:'processing',orderNumber:'2026-9999'},actor),status(400));
 await assert.rejects(db.query("INSERT INTO admin_orders(id,document,order_number) VALUES('injected-number','{}','2026-9999')"),/assigned by the database/);
 // Deliberately stale counter proves uniqueness is enforced independently of
 // the allocator. The resulting failed checkout must also preserve stock.
 await db.query('UPDATE admin_order_number_counters SET last_number=1000 WHERE order_year=2026');
 const secondInput=input('number_unique_key_02',{items:[{productId:'p1',quantity:1,expectedRevision:2}]});
 const second=(await store.createOrder(secondInput)).order;assert.equal(second.orderNumber,'2026-1001');
 await db.query('UPDATE admin_order_number_counters SET last_number=1000 WHERE order_year=2026');
 await assert.rejects(store.createOrder(input('number_unique_key_03',{items:[{productId:'p1',quantity:1,expectedRevision:3}]})),/admin_orders_order_number_unique/);
 assert.deepEqual((await db.query("SELECT document->>'stockQuantity' AS stock,revision FROM admin_products WHERE id='p1'")).rows[0],{stock:'18',revision:3});
 assert.equal((await store.getCustomerOrder(customerId,first.id)).orderNumber,'2026-1000');
});
