import test from 'node:test';
import assert from 'node:assert/strict';
import {Readable} from 'node:stream';
import {createAdmin} from '../src/admin.mjs';
const origin='https://shop.example.invalid';
const principal={id:'google:verified',provider:'google',email:'owner@example.invalid'};
function fixture({user=principal,enabled=true,storeAvailable=true}={}){
 const calls=[];const admin=createAdmin({origin,config:{enabled,emails:['owner@example.invalid']},auth:{session:()=>user?{user,csrfToken:'valid-csrf'}:null},store:storeAvailable?{createProduct:async(body,actor)=>{calls.push({body,actor});return {...body,published:false,available:false,stockQuantity:0,version:1};}}:null});
 const request=(body='{"id":"new-product"}',headers={})=>{const req=Readable.from([Buffer.from(body)]);req.method='POST';req.headers={origin,'x-csrf-token':'valid-csrf','content-type':'application/json',...headers};return admin.handle(req,new URL(origin+'/admin/api/products'),(status,data)=>({status,data}),{});};return {calls,request};
}
test('create API uses verified administrator identity and returns 201 under existing CSRF/origin gate',async()=>{
 const {request,calls}=fixture();const response=await request();assert.equal(response.status,201);assert.equal(response.data.published,false);assert.equal(calls[0].actor.id,principal.id);
 for(const headers of [{origin:'https://evil.invalid'},{origin:undefined},{'x-csrf-token':'invalid'},{'x-csrf-token':undefined}])await assert.rejects(request(undefined,headers),error=>error.status===403);
 assert.equal(calls.length,1);
});
test('anonymous/customer/disabled/unavailable creation is rejected without mutations',async()=>{
 for(const [options,status] of [[{user:null},401],[{user:{...principal,email:'customer@example.invalid'}},403],[{enabled:false},404],[{storeAvailable:false},503]]){const {request,calls}=fixture(options);await assert.rejects(request(),error=>error.status===status);assert.equal(calls.length,0);}
});
test('create API rejects malformed, oversized and non-JSON bodies',async()=>{
 const {request,calls}=fixture();for(const body of ['null','[]','{broken'])await assert.rejects(request(body),error=>error.status===400);
 await assert.rejects(request('{}',{'content-type':'text/plain'}),error=>error.status===415);
 await assert.rejects(request(' '.repeat(327681)),error=>error.status===413);assert.equal(calls.length,0);
});

test('create API accepts the complete bounded Unicode declaration payload',async()=>{
 const {request,calls}=fixture();const declaration=Object.fromEntries(['benefit','usage','notes','warnings','storage','editorialCaveat'].map(key=>[key,'界'.repeat(10000)]));
 const payload={id:'full-declaration',name:'界'.repeat(120),description:'界'.repeat(2000),ingredients:'界'.repeat(2000),note:'界'.repeat(2000),declaration};
 const body=JSON.stringify(payload);assert(Buffer.byteLength(body)>65536);assert(Buffer.byteLength(body)<327680);
 assert.equal((await request(body)).status,201);assert.deepEqual(calls[0].body,payload);
});
