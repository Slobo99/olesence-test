import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import * as XLSX from 'xlsx';
import {parseStockWorkbook} from '../src/stock-import.mjs';
import {createPostgresStore} from '../src/admin-store.mjs';
import {createCodStore} from '../src/cod-store.mjs';
import {parseStockReport, stockReportIdentifiers} from '../src/report-import.mjs';
const actor={id:'google:product-admin',email:'not-audited@example.invalid'};
const input=(id='new-oil')=>({id,name:'New oil',priceMinor:12345,category:'Oil',description:'Plain description',ingredients:'Oil',declaration:{warnings:'Read label.',usage:'Follow label.',storage:'Keep cool.'}});
const status=code=>error=>error.status===code;
async function fixture(t){
 const db=new PGlite();let tail=Promise.resolve();
 const connect=async()=>{const previous=tail;let release;tail=new Promise(r=>release=r);await previous;return {release,query:(sql,args)=>sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args)};};
 const pool={connect,query:async(sql,args)=>{const client=await connect();try{return await client.query(sql,args);}finally{client.release();}},end:()=>db.close()};
 const store=createPostgresStore(pool);await store.initialize();t.after(()=>store.close());return {db,pool,store};
}
async function image(store,p){const bytes=Buffer.from('sanitized JPEG supplied by upload pipeline');return store.updateProductImage(p.id,p.version,{bytes,hash:createHash('sha256').update(bytes).digest('hex'),mime:'image/jpeg',width:1,height:1},actor);}
test('creation persists a safe draft and atomic audit; repeated ID never overwrites',async t=>{
 const {store,db}=await fixture(t);const p=await store.createProduct(input(),actor);
 assert.equal(p.version,1);assert.equal(p.published,false);assert.equal(p.available,false);assert.equal(p.stockQuantity,0);
 assert.equal(p.botanical,'');assert.equal(p.volume,null);assert.equal(p.method,null);assert.equal(p.note,null);assert.equal(p.descriptionFormat,'plain');
 for(const key of ['benefit','notes','editorialCaveat'])assert.equal(p.declaration[key],'');assert.equal(p.declaration.warnings,'Read label.');
 await assert.rejects(store.createProduct({...input(),name:'Replacement'},actor),status(409));
 assert.equal((await store.listProducts())[0].name,'New oil');
 const audits=(await db.query('SELECT * FROM admin_audit')).rows;assert.equal(audits.length,1);assert.equal(audits[0].before_snapshot,null);assert.equal(audits[0].after_snapshot.id,p.id);assert(!JSON.stringify(audits).includes(actor.email));
 await store.initialize();assert.equal((await store.listProducts()).length,1);
});
test('creation validates identifiers, required content, privilege and unknown/system fields',async t=>{
 const {store}=await fixture(t);
 for(const patch of [{id:'Bad_ID'},{id:'-bad'},{id:'a--b'},{id:'a'.repeat(81)},{id:'../admin'},{name:' '},{category:''},{description:''},{description:'bad\u0000text'},{ingredients:''},{priceMinor:0},{priceMinor:1.1},{declaration:{warnings:'x'}},{available:true},{published:true},{stockQuantity:4},{image:'other.jpg'},{imagePath:'/media/'+ 'a'.repeat(64)+'.jpg'},{role:'admin'},{stockCode:'lower case'}])await assert.rejects(store.createProduct({...input(),...patch},actor),status(400));
 await assert.rejects(store.createProduct(input(),{id:'unverified'}),status(403));assert.equal((await store.listProducts()).length,0);
});
test('publication requires image; draft inventory cannot enable sales; publication and withdrawal retain stock',async t=>{
 const {store}=await fixture(t);let p=await store.createProduct(input(),actor);
 await assert.rejects(store.updateProduct(p.id,p.version,{published:true},actor),status(400));
 p=await store.applyStockImport([{id:p.id,version:p.version,stockQuantity:3}],actor).then(rows=>rows[0]);assert.equal(p.available,false);assert.equal(p.published,false);
 p=await image(store,p);p=await store.updateProduct(p.id,p.version,{published:true,available:true},actor);assert.equal(p.published,true);assert.equal(p.available,true);
 await assert.rejects(store.updateProduct(p.id,p.version,{ingredients:''},actor),status(400));
 p=await store.updateProduct(p.id,p.version,{published:false},actor);assert.equal(p.available,false);assert.equal(p.stockQuantity,3);
 await assert.rejects(store.updateProduct(p.id,p.version-1,{published:true},actor),status(409));
});
test('stock report codes are unique, reserved legacy codes cannot be stolen and duplicate creation rolls back',async t=>{
 const {store}=await fixture(t);let p=await store.createProduct({...input(),stockCode:'O004'},actor);
 for(const code of ['O004','O001','O002','O003'])await assert.rejects(store.createProduct({...input('another-oil'),stockCode:code},actor),status(409));
 const q=await store.createProduct(input('another-oil'),actor);
 await assert.rejects(store.updateProduct(q.id,q.version,{stockCode:'O004'},actor),status(409));
 p=await store.updateProduct(p.id,p.version,{stockCode:null},actor);assert.equal(p.stockCode,null);
 assert.equal((await store.updateProduct(q.id,q.version,{stockCode:'O004'},actor)).stockCode,'O004');
});
test('full declarations merge without dropping other sections and reject invalid values',async t=>{
 const {store}=await fixture(t);const p=await store.createProduct(input(),actor);
 const changed=await store.updateProduct(p.id,p.version,{declaration:{benefit:'Approved label text',usage:'Updated usage'}},actor);
 assert.equal(changed.declaration.warnings,p.declaration.warnings);assert.equal(changed.declaration.usage,'Updated usage');
 for(const declaration of [{warnings:''},{invented:'x'},{usage:7},{storage:'bad\u0000'}])await assert.rejects(store.updateProduct(p.id,changed.version,{declaration},actor),status(400));
});
test('audit failure rolls creation back',async t=>{
 const {store,db}=await fixture(t);await db.exec("ALTER TABLE admin_audit ADD CONSTRAINT reject_creation CHECK (entity_id <> 'new-oil')");
 await assert.rejects(store.createProduct(input(),actor));assert.equal((await store.listProducts()).length,0);
});
test('unpublished product cannot be quoted even if availability was enabled by another writer',async t=>{
 const {store,db,pool}=await fixture(t);await store.createProduct(input(),actor);
 await db.query("UPDATE admin_products SET document = document || '{\"available\":true,\"stockQuantity\":10}'::jsonb");
 const customerId='11111111-1111-4111-8111-111111111111';
 await db.query("INSERT INTO commerce_customers(id,provider,subject,email,name) VALUES($1,'google','fixture','fixture@example.invalid','Fixture')",[customerId]);
 const cod=createCodStore(pool);
 await assert.rejects(cod.quote(customerId,[{productId:'new-oil',quantity:1}]),status(409));
});
test('report mapping supports new products while preserving unknown-code and warehouse rejection',()=>{
 const products=[{id:'new-oil',stockCode:'O004'}];assert.equal(stockReportIdentifiers(products).O004,'new-oil');
 assert.throws(()=>stockReportIdentifiers([{id:'new-oil',stockCode:'O001'}]));
 assert.throws(()=>stockReportIdentifiers([{id:'crni-kim',stockCode:'OTHER'}]));
 const header=Array(13).fill(null);header[0]='Ident';header[2]='Naziv';header[9]='Zaliha';header[12]='JM';
 const row=Array(13).fill(null);row[0]='O004';row[2]='New oil';row[9]=7;row[12]='KOM';const grid=[header,['Skladište:','Magacin Bio Prodavnica B2C'],row];
 assert.throws(()=>parseStockReport(grid));assert.equal(parseStockReport(grid,products)[0].id,'new-oil');assert.equal(parseStockReport(grid,products)[0].stockQuantity,7);
 row[12]='L';assert.throws(()=>parseStockReport(grid,products));
});

test('new stock code reaches the isolated XLS parser without weakening validation',async()=>{
 const header=Array(13).fill(null);header[0]='Ident';header[2]='Naziv';header[9]='Zaliha';header[12]='JM';
 const row=Array(13).fill(null);row[0]='O004';row[2]='New oil';row[9]=7;row[12]='KOM';
 const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,XLSX.utils.aoa_to_sheet([header,['Skladište:','Magacin Bio Prodavnica B2C'],row]),'Sheet1');
 const bytes=XLSX.write(book,{type:'buffer',bookType:'biff8'});
 await assert.rejects(parseStockWorkbook(bytes));
 const parsed=await parseStockWorkbook(bytes,[{id:'new-oil',stockCode:'O004'}]);assert.equal(parsed[0].id,'new-oil');assert.equal(parsed[0].stockQuantity,7);
});

test('legacy published declarations reject clearing usage or storage without requiring missing fields',async t=>{
 const {store}=await fixture(t);
 await store.initialize([{id:'legacy-oil',name:'Legacy oil',priceMinor:100,image:'crni-kim.jpg',declaration:{warnings:'Legacy warning'}}]);
 let p=(await store.listProducts())[0];assert.equal(p.published,undefined);
 p=await store.updateProduct(p.id,p.version,{name:'Renamed legacy oil'},actor);
 for(const declaration of [{usage:''},{usage:' \t'},{storage:''},{storage:'\r\n'},{warnings:''}])await assert.rejects(store.updateProduct(p.id,p.version,{declaration},actor),status(400));
 assert.equal((await store.listProducts())[0].version,p.version);
 const updated=await store.updateProduct(p.id,p.version,{declaration:{usage:'Label usage',storage:'Label storage'}},actor);
 assert.equal(updated.declaration.warnings,'Legacy warning');assert.equal(updated.declaration.usage,'Label usage');assert.equal(updated.declaration.storage,'Label storage');
});
