import {homeMarkup} from '../public/home-view.js';
import {productMarkup,productStructuredData,safeJson,card,productImage} from '../public/product-view.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
import {products as catalog,settings,normalizeCart,formatMoney,quoteCart} from '../public/catalog.js';
import {slides,normalizeSlide,slideForKey} from '../public/slider.js';
import {faqItems} from '../public/faq.js';
const html=await readFile(new URL('../public/index.html',import.meta.url),'utf8');
const source=(await readFile(new URL('../public/app.js',import.meta.url),'utf8')).replace(/^import .*;\n/gm,'');
async function fixture(t,id,products=catalog,setup=()=>{}){
 const dom=new JSDOM(html,{url:`https://shop.example.test/proizvod/${id}`,runScripts:'outside-only'}),w=dom.window;
 await new Promise(resolve=>w.addEventListener('load',resolve,{once:true}));t.after(()=>w.close());
 const calls=[];w.fetch=async path=>{calls.push(path);assert.equal(path,'/api/checkout/session');return {ok:true,json:async()=>({enabled:false,user:null,csrfToken:null,customerReady:false})};};
 Object.assign(w,{productMarkup,productStructuredData,safeJson,card,productImage,homeMarkup,products,settings,normalizeCart,formatMoney,quoteCart,slides,normalizeSlide,slideForKey,faqItems});
 setup(w);w.watchCatalogPrices=()=>{};vm.runInContext(source,dom.getInternalVMContext());await Promise.resolve();await Promise.resolve();
 return {w,document:w.document,calls};
}
const detailsByTitle=(node,title)=>[...node.querySelectorAll('details')].find(detail=>detail.querySelector('summary')?.textContent===title);
test('description preserves a plain-text title and all authored paragraphs in open semantic blocks',async t=>{
 const description='Existing product title\nFirst paragraph, unchanged.\nSecond paragraph with all qualifiers, unchanged.\nThird paragraph remains in its original order.\nFinal caution and usage text stay visible.';
 const products=catalog.map(p=>p.id==='crni-kim'?{...p,description}:p);
 const {document}=await fixture(t,'crni-kim',products),box=document.querySelector('[data-product-description]');
 assert.equal(box.tagName,'DIV');assert.equal(box.querySelector('h2').textContent,'Existing product title');
 assert.deepEqual([...box.querySelectorAll('p')].map(p=>p.textContent),description.split('\n').slice(1));
 assert.equal(box.textContent,description);assert.equal(box.querySelector('details,[hidden],button'),null);
 assert.equal(document.querySelectorAll('h1').length,1);
 assert.equal(document.querySelector('.declaration-draft details:nth-of-type(3)').open,true);
});
test('description treats hostile HTML and Markdown as literal text, never markup',async t=>{
 const description='<img src=x onerror=alert(1)>\n<script>alert(1)</script>\n[link](javascript:alert(1)) **literal text**';
 const products=catalog.map(p=>p.id==='crni-kim'?{...p,description}:p);
 const {document}=await fixture(t,'crni-kim',products),box=document.querySelector('[data-product-description]');
 assert.equal(box.textContent,description);assert.equal(box.querySelector('img,script,a,[onerror]'),null);
});
test('description handles CRLF, blank lines and a one-line description without inventing headings or text',async t=>{
 for(const description of ['One unchanged sentence.','First sentence.\r\n\r\nSecond sentence.','',null]){
  const products=catalog.map(p=>p.id==='crni-kim'?{...p,description}:p);
  const {document}=await fixture(t,'crni-kim',products),box=document.querySelector('[data-product-description]');
  assert.equal(box.querySelector('h2'),null);
  assert.deepEqual([...box.children].map(n=>n.textContent),String(description??'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean));
 }
});
test('description rerender replaces previous blocks and preserves other product details and SEO',async t=>{
 const p={...catalog[0],description:'Current heading\nCurrent paragraph.',seoTitle:'Owner-published title',seoDescription:'Owner-published description'};
 const {document,w}=await fixture(t,p.id,[p]);
 const source='Next paragraph.\nFull warning remains.';
 w.renderProductDescription(document.querySelector('[data-product-description]'),source);
 assert.equal(document.querySelector('[data-product-description]').textContent,source);
 assert.equal(document.querySelector('[data-product-description] h2'),null);
 assert.equal(document.title,p.seoTitle);assert.equal(document.querySelector('meta[name="description"]').content,p.seoDescription);
 assert.equal(document.querySelector('.detail-price').textContent,formatMoney(p.priceMinor));
 assert.equal(detailsByTitle(document.querySelector('.declaration-draft'),'Način primene').querySelector('p').textContent,p.declaration.usage);
});
test('description CSS keeps readable size, spacing, wrapping and open content at mobile widths',async()=>{
 const css=await readFile(new URL('../public/styles.css',import.meta.url),'utf8');
 assert.match(css,/\.detail-copy \.description\{font-size:16px;line-height:1\.8;max-width:65ch/);
 assert.match(css,/\.description p\+p\{margin-top:18px\}/);
 assert.match(css,/@media\(max-width:600px\)\{\.detail-copy \.description\{font-size:16px;line-height:1\.8/);
 assert.ok(!/\.description[^}]*\{[^}]*(?:line-clamp|max-height|overflow:hidden)/.test(css));
});
test('SEO browser missing product removes canonical and marks client not-found noindex',async t=>{
 const {document}=await fixture(t,'crni-kim',[]);
 assert.equal(document.querySelector('meta[name="robots"]').content,'noindex,nofollow');
 assert.equal(document.querySelector('link[rel="canonical"]'),null);
 assert.match(document.querySelector('h1').textContent,/nije pronađena/);
});
test('SEO browser live subset and empty home render truthful product counts',async t=>{
 for(const products of [[],[catalog[0]]]){
  const {document}=await fixture(t,'crni-kim',products,w=>w.history.replaceState({},'','/'));
  assert.equal(document.querySelector('#result-count').textContent,products.length===1?'1 proizvod':'0 proizvoda');
  assert.equal(document.querySelectorAll('#products .product-card').length,products.length);
 }
});
test('SEO browser catalog outage keeps server-published metadata but prevents stale fallback indexing',async t=>{
 const {document}=await fixture(t,'crni-kim',catalog,w=>{
  w.document.documentElement.dataset.catalogUnavailable='true';w.document.title='Server-approved title';
  w.document.querySelector('meta[name="description"]').content='Server-approved description';
 });
 assert.equal(document.title,'Server-approved title');assert.equal(document.querySelector('meta[name="description"]').content,'Server-approved description');
 assert.equal(document.querySelector('meta[name="robots"]').content,'noindex,nofollow');
});
for(const product of catalog)test(`product detail: ${product.id} composition and complete declaration share the existing information card`,async t=>{
 const {document,calls}=await fixture(t,product.id),card=document.querySelector('.declaration-draft');assert.equal(document.querySelectorAll('.declaration-draft').length,1);assert.equal(card.getAttribute('aria-label'),'Informacije o proizvodu');assert.equal(card.querySelector('h2').textContent,'Namena i deklaracija');
 const composition=detailsByTitle(document,'Sastav i osnovne informacije');assert.ok(composition);assert.equal(composition.parentElement,card);assert.equal(composition.open,true);assert.equal(document.querySelector('.detail-copy > details'),null);
 assert.deepEqual([...composition.querySelectorAll('p')].map(node=>node.textContent),[product.ingredients,...(product.method?[`Način dobijanja: ${product.method}`]:[]),product.note]);
 assert.equal(card.querySelector('h3').textContent,'Namena');assert.equal(card.querySelector('h3').nextElementSibling.textContent,product.declaration.benefit);
 for(const [title,values]of [['Način primene',[product.declaration.usage]],['Upozorenja',[product.declaration.warnings,...(product.declaration.editorialCaveat?[product.declaration.editorialCaveat]:[])]],['Napomene i čuvanje',[product.declaration.notes,product.declaration.storage]]]){
  const detail=detailsByTitle(card,title);assert.ok(detail);assert.equal(detail.open,true);assert.deepEqual([...detail.querySelectorAll('p')].map(node=>node.textContent),values);
 }
 assert.equal(card.querySelector('.draft-caution').textContent,'Informacije na ovoj stranici nisu potvrda registracije ili konkretne serije. Pre upotrebe proverite konačnu deklaraciju, potpuna upozorenja na pakovanju i savet stručnjaka.');
 assert.equal(card.querySelector('.registration-number').textContent,'');assert.match(card.querySelector('.registration-field small').textContent,/Podatak još nije dostupan\. Završen upis ne potvrđujemo\./);
 assert.match(document.querySelector('.detail-image img').getAttribute('src'),new RegExp('^/assets/'+product.image.replace('.jpg','')+'-1200\\.[a-f0-9]{12}\\.webp$'));assert.match(document.querySelector('.detail-image img').getAttribute('srcset'),/400w.*800w.*1200w/);assert.equal(document.querySelector('.detail-price').textContent,formatMoney(product.priceMinor));assert.deepEqual(calls,['/api/checkout/session']);
});
test('product detail: moved composition and declaration content remain escaped, native expandable details',async t=>{
 const hostile='<img src=x onerror=alert(1)><script>alert(1)</script>',original=catalog[0];
 const products=catalog.map(p=>p.id===original.id?{...p,ingredients:hostile,method:hostile,note:hostile,declaration:Object.fromEntries(Object.keys(p.declaration).map(key=>[key,hostile]))}:p);
 const {document}=await fixture(t,original.id,products),card=document.querySelector('.declaration-draft');assert.equal(card.querySelector('img, script, [onerror]'),null);assert.ok(card.textContent.includes(hostile));
 const composition=detailsByTitle(card,'Sastav i osnovne informacije');assert.equal(composition.querySelector('p').textContent,hostile);composition.open=false;assert.equal(composition.open,false);composition.open=true;assert.equal(composition.open,true);
});

test('product detail: information headings and labels are bold with strong contrast while body paragraphs remain regular',async t=>{
 const {document,w}=await fixture(t,catalog[0].id),style=document.createElement('style');style.textContent=await readFile(new URL('../public/styles.css',import.meta.url),'utf8');document.head.append(style);
 for(const node of document.querySelectorAll('.product-detail h2,.product-detail h3,.product-detail summary,.product-detail .eyebrow,.product-detail .registration-field>span'))assert.equal(w.getComputedStyle(node).fontWeight,'700',node.textContent);
 assert.equal(w.getComputedStyle(document.querySelector('.declaration-draft')).overflowWrap,'anywhere');
 for(const node of document.querySelectorAll('.declaration-draft p'))assert.notEqual(w.getComputedStyle(node).fontWeight,'700',node.textContent);
 assert.match(style.textContent,/\.product-detail h2,\.product-detail h3,\.product-detail summary,\.product-detail \.eyebrow,\.product-detail \.registration-field>span\{font-weight:700;color:var\(--ink\)\}/);
});
