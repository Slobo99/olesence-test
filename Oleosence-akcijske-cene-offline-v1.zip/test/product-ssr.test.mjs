import {homeMarkup} from '../public/home-view.js';
import {analyticsScript} from '../src/analytics.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
import {createHostedServer} from '../server.mjs';
import {products as seeds,settings,normalizeCart,formatMoney,quoteCart} from '../public/catalog.js';
import {slides,normalizeSlide,slideForKey} from '../public/slider.js';
import {faqItems} from '../public/faq.js';
import {productMarkup,productStructuredData,safeJson,card,productImage,descriptionMarkup,descriptionPlainText} from '../public/product-view.js';
import {publicProduct} from '../src/product-ssr.mjs';
const origin='https://olesence.rs';
async function fixture(t,{checkoutEnabled=true,clock=Date.now}={}){
 const state={products:seeds.map(p=>({...p,available:true,stockQuantity:2,version:99,updatedAt:'private timestamp'})),fail:false};
 const store={listProducts:async()=>{if(state.fail)throw Error('private-db-error');return state.products;}};
 const app=await createHostedServer({config:{origin,host:'olesence.rs',auth:{origin,clientId:'synthetic.apps.googleusercontent.com',secure:true},admin:{enabled:true,emails:['owner@example.invalid']},customerDatabaseEnabled:checkoutEnabled,checkoutEnabled},store,clock,customerStore:checkoutEnabled?{}:null,codStore:checkoutEnabled?{}:null});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));t.after(()=>app.close());
 const get=path=>new Promise((resolve,reject)=>{http.get({hostname:'127.0.0.1',port:app.server.address().port,path,headers:{host:'olesence.rs','x-forwarded-proto':'https'}},res=>{const chunks=[];res.on('data',b=>chunks.push(b));res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,text:Buffer.concat(chunks).toString()}));}).on('error',reject);});
 return {state,get};
}
const documentOf=r=>new JSDOM(r.text).window.document;
const schemaOf=doc=>JSON.parse(doc.querySelector('#product-schema').textContent);
test('all product pages server-render complete public content and Product/Offer before JavaScript',async t=>{
 const {state,get}=await fixture(t);
 for(const p of state.products){const response=await get('/proizvod/'+p.id),doc=documentOf(response),data=schemaOf(doc);
  assert.equal(response.status,200);assert.equal(doc.querySelector('h1').textContent,p.name);assert.equal(doc.querySelector('[data-product-description]').textContent,p.description);
  for(const field of ['ingredients','botanical'])assert.ok(doc.querySelector('#main').textContent.includes(p[field]));
  for(const field of ['usage','warnings','storage'])assert.ok(doc.querySelector('#main').textContent.includes(p.declaration[field]));
  assert.equal(doc.querySelectorAll('h1').length,1);assert.equal(doc.querySelectorAll('#product-schema').length,1);
  assert.equal(data.name,p.name);assert.equal(data.description,p.description);assert.equal(data.image,origin+'/assets/'+p.image);
  assert.equal(data.offers.price,(p.priceMinor/100).toFixed(2));assert.equal(data.offers.priceCurrency,'RSD');assert.equal(data.offers.availability,'https://schema.org/InStock');
  assert.ok(!response.text.includes('private timestamp'));assert.equal(doc.querySelector('[data-checkout-status]').textContent,'Plaćanje pouzećem');
  assert.match(response.headers['content-security-policy'],/script-src 'self' 'sha256-[A-Za-z0-9+/=]+' https:\/\/www\.googletagmanager\.com;/);assert.ok(!response.headers['content-security-policy'].includes('unsafe-inline'));
 }
});
test('later published text, format, price, stock and image edits refresh SSR and JSON-LD together without rebuild',async t=>{
 const {state,get}=await fixture(t);await get('/proizvod/crni-kim');
 state.products[0]={...state.products[0],name:'New published name',description:'## Owner heading\nA **bold** paragraph.\n- One\n- Two',descriptionFormat:'markdown',priceMinor:123456,stockQuantity:0,imagePath:'/media/'+'a'.repeat(64)+'.jpg'};
 const p=state.products[0],response=await get('/proizvod/crni-kim'),doc=documentOf(response),data=schemaOf(doc);
 assert.equal(doc.querySelector('h1').textContent,p.name);assert.equal(doc.querySelector('[data-product-description] h2').textContent,'Owner heading');assert.equal(doc.querySelector('[data-product-description] strong').textContent,'bold');assert.equal(doc.querySelectorAll('[data-product-description] li').length,2);
 assert.equal(data.description,'Owner heading\nA bold paragraph.\nOne\nTwo');assert.equal(data.offers.price,'1234.56');assert.equal(data.offers.availability,'https://schema.org/OutOfStock');assert.ok(doc.querySelector('[data-add]').disabled);assert.equal(data.image,origin+p.imagePath);assert.equal(doc.querySelector('.detail-image img').getAttribute('src'),p.imagePath);
 assert.equal(response.headers['cache-control'],'no-store');
});
test('unavailable sales omit offers; no false seed availability, reviews or ratings invented',async t=>{
 const {get}=await fixture(t,{checkoutEnabled:false});const data=schemaOf(documentOf(await get('/proizvod/crni-kim')));
 assert.equal(data.offers,undefined);assert.equal(data.review,undefined);assert.equal(data.aggregateRating,undefined);assert.equal(data.brand.name,'olésence');assert.equal(data.sku,'crni-kim');
 assert.equal(publicProduct({...seeds[0],available:true,stockQuantity:null}).available,false);
 assert.equal(publicProduct({...seeds[0],available:false,stockQuantity:20}).available,false);
});
test('hostile product content is escaped in HTML and inert JSON, including closing script tags and replacement tokens',async t=>{
 const {state,get}=await fixture(t);const payload='</script><img src=x onerror=alert(1)> $& <script>alert(1)</script> & \u2028 \u2029';
 state.products[0]={...state.products[0],name:payload,description:'## '+payload+'\n**'+payload+'**',descriptionFormat:'markdown',botanical:payload,ingredients:payload};
 const response=await get('/proizvod/crni-kim'),doc=documentOf(response),data=schemaOf(doc);
 assert.equal(doc.querySelector('h1').textContent,payload);assert.equal(doc.querySelector('[onerror],script:not([src]):not([type="application/ld+json"]):not(#olesence-analytics-init)'),null);assert.equal(doc.querySelectorAll('#olesence-analytics-init').length,1);assert.equal(doc.querySelector('#olesence-analytics-init').textContent,analyticsScript);
 assert.equal(data.name,payload);assert.equal(data.description,doc.querySelector('[data-product-description]').textContent);assert.equal(doc.querySelectorAll('#product-schema').length,1);
 assert.ok(!doc.querySelector('#product-schema').textContent.includes('<'));assert.ok(doc.querySelector('[data-product-description]').textContent.includes('$&'));
});
test('missing, private, removed products and outages never emit public success/schema',async t=>{
 const {state,get}=await fixture(t);state.products=[];
 for(const path of ['/proizvod/crni-kim','/proizvod/draft-private']){const r=await get(path);assert.equal(r.status,404);assert.match(r.headers['x-robots-tag'],/noindex/);assert.ok(!r.text.includes('product-schema'));}
 for(const path of ['/account','/checkout']){const r=await get(path);assert.match(r.headers['x-robots-tag'],/noindex/);assert.ok(!r.text.includes('application/ld+json'));}
 state.fail=true;const r=await get('/proizvod/crni-kim');assert.equal(r.status,503);assert.ok(!r.text.includes('private-db-error'));assert.match(r.headers['x-robots-tag'],/noindex/);
});
test('limited formatting is opt-in, escaped, and visible text equals schema text',()=>{
 const raw='## Heading\n**Bold** and <img src=x onerror=bad()>\n- First\n- Second\n1. Third\n2. Fourth\n[link](javascript:bad())';
 const plain=new JSDOM(descriptionMarkup(raw)).window.document,formatted=new JSDOM(descriptionMarkup(raw,'markdown')).window.document;
 assert.equal(plain.querySelector('strong,ul,ol'),null);assert.ok(plain.body.textContent.includes('**Bold**'));assert.equal(formatted.querySelectorAll('strong').length,1);assert.equal(formatted.querySelectorAll('li').length,4);assert.equal(formatted.querySelector('a,img,script'),null);
 assert.equal(formatted.body.textContent,descriptionPlainText(raw,'markdown'));assert.equal(productStructuredData({...seeds[0],description:raw,descriptionFormat:'markdown'}).description,formatted.body.textContent);
 assert.ok(safeJson({text:'</script>'}).includes('\\u003c'));
});
const appSource=(await readFile(new URL('../public/app.js',import.meta.url),'utf8')).replace(/^import .*;\n/gm,'');
async function browser(t,html,products,{unavailable=false}={}){
 const dom=new JSDOM(html,{url:origin+'/proizvod/crni-kim',runScripts:'outside-only'}),w=dom.window;await new Promise(r=>w.addEventListener('load',r,{once:true}));t.after(()=>w.close());
 Object.assign(w,{products,settings,normalizeCart,formatMoney,quoteCart,slides,normalizeSlide,slideForKey,faqItems,productMarkup,productStructuredData,safeJson,card,productImage,homeMarkup});
 w.fetch=async()=>({ok:true,json:async()=>({enabled:true,guest:false})});if(unavailable)w.document.documentElement.dataset.catalogUnavailable='true';
 w.watchCatalogPrices=()=>{};vm.runInContext(appSource,dom.getInternalVMContext());await new Promise(r=>setTimeout(r,10));return w.document;
}
test('browser refresh replaces SSR once, updates schema with same refreshed product and keeps interactive hooks',async t=>{
 const {state,get}=await fixture(t);const {text}=await get('/proizvod/crni-kim');
 const products=state.products.map(p=>publicProduct(p));products[0]={...products[0],description:'Updated since HTML request.',priceMinor:12300,available:false};
 const doc=await browser(t,text,products);assert.equal(doc.querySelectorAll('.product-detail').length,1);assert.equal(doc.querySelectorAll('h1').length,1);assert.equal(doc.querySelector('[data-product-description]').textContent,products[0].description);assert.equal(schemaOf(doc).description,products[0].description);assert.equal(schemaOf(doc).offers.price,'123.00');assert.equal(schemaOf(doc).offers.availability,'https://schema.org/OutOfStock');assert.ok(doc.querySelector('[data-add]').disabled);
});
test('API outage keeps accurate SSR visible instead of overwriting it with stale seed text and removes schema',async t=>{
 const {state,get}=await fixture(t);state.products[0]={...state.products[0],description:'Current database description, not seed.'};const {text}=await get('/proizvod/crni-kim');
 const doc=await browser(t,text,seeds,{unavailable:true});assert.equal(doc.querySelector('[data-product-description]').textContent,state.products[0].description);assert.equal(doc.querySelector('#product-schema'),null);assert.equal(doc.querySelector('meta[name="robots"]').content,'noindex,nofollow');assert.equal(doc.querySelector('[data-add]').disabled,true);assert.equal(doc.querySelector('[data-checkout-link]'),null);
});

test('checkout copy never replaces identical words inside owner-authored descriptions',async t=>{
 const {state,get}=await fixture(t);const description='Poručivanje nije omogućeno\nPoručivanje trenutno nije dostupno. Dostava: 300 din po paketu; besplatna za vrednost proizvoda od 3.500 din.';state.products[0]={...state.products[0],description};
 const doc=documentOf(await get('/proizvod/crni-kim'));assert.equal(doc.querySelector('[data-product-description]').textContent,description);assert.equal(schemaOf(doc).description,description);assert.equal(doc.querySelector('[data-checkout-status]').textContent,'Plaćanje pouzećem');
});

test('new published products render dynamic routes while drafts are absent from every public surface',async t=>{
 const {state,get}=await fixture(t);
 const added={...state.products[0],id:'novo-ulje',name:'Novo ulje',published:true,stockCode:'PRIVATE-STOCK-CODE',imagePath:'/media/'+'b'.repeat(64)+'.jpg'};
 const draft={...added,id:'tajni-nacrt',name:'Private draft name',published:false};
 state.products.push(added,draft);
 const response=await get('/proizvod/novo-ulje'),doc=documentOf(response);
 assert.equal(response.status,200);assert.equal(doc.querySelector('h1').textContent,'Novo ulje');
 assert.equal(doc.documentElement.dataset.publicProduct,'/proizvod/novo-ulje');
 assert.equal(doc.querySelector('link[rel="canonical"]').href,origin+'/proizvod/novo-ulje');
 assert.equal(schemaOf(doc).name,'Novo ulje');assert.equal(doc.querySelector('.detail-image img').getAttribute('src'),added.imagePath);assert.equal(schemaOf(doc).image,origin+added.imagePath);assert.ok(!response.text.includes('Private draft name'));
 for(const suffix of ['/','/index.html'])assert.equal((await get('/proizvod/novo-ulje'+suffix)).status,308);
 for(const suffix of ['','/','/index.html'])assert.equal((await get('/proizvod/tajni-nacrt'+suffix)).status,404);
 const catalog=await get('/api/catalog');assert.ok(catalog.text.includes('novo-ulje'));assert.ok(!catalog.text.includes('tajni-nacrt'));assert.ok(!catalog.text.includes('PRIVATE-STOCK-CODE'));
 const sitemap=await get('/sitemap.xml');assert.ok(sitemap.text.includes('/proizvod/novo-ulje'));assert.ok(!sitemap.text.includes('tajni-nacrt'));
 state.products.find(p=>p.id==='novo-ulje').published=false;
 assert.equal((await get('/proizvod/novo-ulje')).status,404);
});

test('sale shows crossed verified reference, red badge hook, Belgrade dates and a matching public price; all revert at expiry',async t=>{
 const start=Date.parse('2030-04-20T10:00:00Z'),end=start+3600000;
 let now=start;
 const {state,get}=await fixture(t,{clock:()=>now});
 state.products[0]={...state.products[0],sale:{priceMinor:112000,previousMinor:140000,startAt:new Date(start).toISOString(),endAt:new Date(end).toISOString(),historyVerified:true}};
 const product=await get('/proizvod/crni-kim'), doc=documentOf(product);
 assert.equal(doc.querySelector('.detail-copy del').textContent,formatMoney(140000));
 assert.equal(doc.querySelector('.detail-copy .detail-price').textContent,formatMoney(112000));
 assert.equal(doc.querySelector('.detail-copy .sale-discount').textContent,'−20%');
 assert.match(doc.querySelector('.detail-copy .sale-period').textContent,/12:00.*13:00/);
 assert.equal(schemaOf(doc).offers.price,'1120.00');
 assert.equal(doc.querySelector('meta[property="product:price:amount"]').content,'1120.00');
 const catalog=JSON.parse((await get('/api/catalog')).text), entry=catalog.products[0];
 assert.equal(entry.priceMinor,112000);assert.equal(entry.sale.historyVerified,undefined);assert.equal(catalog.saleRefreshAfterMs,3600000);
 assert.ok(documentOf(await get('/')).querySelector('[data-price-product="crni-kim"] .sale-discount'));
 assert.ok((await get('/llms.txt')).text.includes(formatMoney(112000)));
 now=end;
 const expired=documentOf(await get('/proizvod/crni-kim'));
 assert.equal(expired.querySelector('.detail-copy del'),null);
 assert.equal(expired.querySelector('.detail-copy .sale-discount'),null);
 assert.equal(schemaOf(expired).offers.price,'1490.00');
 assert.equal(JSON.parse((await get('/api/catalog')).text).products[0].sale,undefined);
});
