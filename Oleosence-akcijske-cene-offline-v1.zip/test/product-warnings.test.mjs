import {homeMarkup} from '../public/home-view.js';
import {productMarkup,productStructuredData,safeJson,card,productImage} from '../public/product-view.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {PGlite} from '@electric-sql/pglite';
import {JSDOM} from 'jsdom';
import {createPostgresStore} from '../src/admin-store.mjs';
import {products as seedProducts} from '../public/catalog.js';

const actor='google:synthetic-warnings-admin';
const productId='crni-kim';
const status=expected=>error=>error.status===expected;
const jsonValue=value=>JSON.parse(JSON.stringify(value));

async function fixture(t){
 const db=new PGlite();
 // PGlite runs one PostgreSQL session: serialize complete transactions and
 // standalone queries. This validates SQL semantics, not a network race.
 let tail=Promise.resolve();
 async function connect(){const previous=tail;let release;tail=new Promise(resolve=>{release=resolve;});await previous;return {query:(sql,args)=>args===undefined&&sql.startsWith('-- Applied')?db.exec(sql):db.query(sql,args),release};}
 const pool={connect,async query(sql,args){const client=await connect();try{return await client.query(sql,args);}finally{client.release();}}};
 const store=createPostgresStore(pool);
 await store.initialize(seedProducts);
 await pool.query('UPDATE admin_products SET document=document || $2::jsonb WHERE id=$1',[productId,JSON.stringify({stockQuantity:12,available:true})]);
 const row=async()=>(await pool.query('SELECT document,revision FROM admin_products WHERE id=$1',[productId])).rows[0];
 const product=async()=>(await store.listProducts()).find(value=>value.id===productId);
 t.after(()=>db.close());
 return {pool,store,row,product};
}

test('warning-only edits preserve every other product and declaration field and create exact audit snapshots',async t=>{
 const {store,row,product}=await fixture(t);const original=await row(),before=await product();
 const others=(await store.listProducts()).filter(value=>value.id!==productId);
 const warnings='Synthetic warning: consult the supplied product instructions.\nKeep the original packaging.';
 const saved=await store.updateProduct(productId,1,{declaration:{warnings}},actor);
 assert.equal(saved.version,2);assert.equal(saved.declaration.warnings,warnings);
 assert.equal(saved.priceMinor,before.priceMinor);assert.equal(saved.stockQuantity,12);assert.equal(saved.available,true);
 assert.deepEqual((await row()).document,{...original.document,declaration:{...original.document.declaration,warnings}});
 assert.deepEqual((await store.listProducts()).filter(value=>value.id!==productId),others);
 const audit=(await store.listAudit()).entries;assert.equal(audit.length,1);
 assert.equal(audit[0].entityType,'product');assert.equal(audit[0].entityId,productId);assert.equal(audit[0].actorId,actor);
 assert.deepEqual(audit[0].before,jsonValue(before));assert.deepEqual(audit[0].after,jsonValue(saved));
});

test('saved warnings survive store recreation and repeated initialization without seed overwrite',async t=>{
 const {pool,store}=await fixture(t);const warnings='Synthetic persisted warnings for this product.';
 const saved=await store.updateProduct(productId,1,{declaration:{warnings}},actor);
 const recreated=createPostgresStore(pool);await recreated.initialize(seedProducts);await recreated.initialize(seedProducts);
 const loaded=(await recreated.listProducts()).find(value=>value.id===productId);
 assert.deepEqual(loaded,saved);assert.equal(loaded.declaration.warnings,warnings);
 assert.notEqual(loaded.declaration.warnings,seedProducts.find(value=>value.id===productId).declaration.warnings);
 assert.equal((await recreated.listAudit()).entries.length,1);
 assert.deepEqual((await pool.query('SELECT version FROM admin_schema_migrations ORDER BY version')).rows.map(value=>value.version),[1,2,3,4,5,6,7,8]);
});

test('competing warning saves accept one revision and reject stale writes without extra audit entries',async t=>{
 const {store,row}=await fixture(t);const original=await row();
 const warnings=['Synthetic first edit.','Synthetic second edit.'];
 const results=await Promise.allSettled(warnings.map(value=>store.updateProduct(productId,1,{declaration:{warnings:value}},actor)));
 assert.equal(results.filter(result=>result.status==='fulfilled').length,1);
 assert.equal(results.filter(result=>result.status==='rejected'&&result.reason.status===409).length,1);
 const saved=results.find(result=>result.status==='fulfilled').value;
 await assert.rejects(store.updateProduct(productId,1,{declaration:{warnings:'Stale synthetic edit.'},priceMinor:1,stockQuantity:0,available:false},actor),status(409));
 assert.deepEqual(await row(),{document:{...original.document,declaration:{...original.document.declaration,warnings:saved.declaration.warnings}},revision:2});
 const entries=(await store.listAudit()).entries;assert.equal(entries.length,1);assert.equal(entries[0].before.version,1);assert.equal(entries[0].after.version,2);assert.equal(entries[0].after.declaration.warnings,saved.declaration.warnings);
});

test('invalid warning values and nested declaration fields cannot alter data or create audit entries',async t=>{
 const {store,row}=await fixture(t);const original=await row();
 const invalidDeclarations=[null,undefined,[],true,12,'text',{},
  {unknownField:'Unsupported declaration field.'},{warnings:'Synthetic warning.',usage:{nested:'Not text'}},
  {warnings:'Synthetic warning.',extra:'Unknown field'},JSON.parse('{"warnings":"Synthetic warning.","__proto__":{"polluted":true}}'),
  Object.create({warnings:'Inherited warning.'}),
  ...[undefined,null,false,12,[],{},'', ' ', '\t\r\n', 'x'.repeat(10001)].map(warnings=>({warnings}))
 ];
 for(const declaration of invalidDeclarations)await assert.rejects(store.updateProduct(productId,1,{declaration},actor),status(400));
 for(const code of [...Array.from({length:32},(_,index)=>index).filter(value=>![9,10,13].includes(value)),127]){
  await assert.rejects(store.updateProduct(productId,1,{declaration:{warnings:'Synthetic'+String.fromCharCode(code)+' warning.'}},actor),status(400));
 }
 await assert.rejects(store.updateProduct(productId,1,{warnings:'Warnings must use the declaration field.'},actor),status(400));
 assert.deepEqual(await row(),original);assert.deepEqual((await store.listAudit()).entries,[]);assert.equal({}.polluted,undefined);
});

test('warnings accept exactly 10000 characters and preserve permitted multiline whitespace',async t=>{
 const {store,row}=await fixture(t);const maximum='x'.repeat(10000);
 const saved=await store.updateProduct(productId,1,{declaration:{warnings:maximum}},actor);assert.equal(saved.declaration.warnings,maximum);
 const multiline='  Synthetic first line.\nSecond line.\r\n\tIndented continuation.\t  ';
 const edited=await store.updateProduct(productId,2,{declaration:{warnings:multiline}},actor);assert.equal(edited.declaration.warnings,multiline);assert.equal((await row()).document.declaration.warnings,multiline);
 assert.equal(edited.version,3);assert.equal(edited.stockQuantity,12);assert.equal((await store.listAudit()).entries.length,2);
});

test('a failed audit insert rolls the warning update and product revision back together',async t=>{
 const {pool,store,row}=await fixture(t);const original=await row();
 await pool.query("ALTER TABLE admin_audit ADD CONSTRAINT reject_warning_fixture_actor CHECK (actor_id <> 'google:synthetic-warning-rollback')");
 await assert.rejects(store.updateProduct(productId,1,{declaration:{warnings:'This synthetic edit must roll back.'}},'google:synthetic-warning-rollback'),/reject_warning_fixture_actor/);
 assert.deepEqual(await row(),original);assert.deepEqual((await store.listAudit()).entries,[]);
 const retried=await store.updateProduct(productId,1,{declaration:{warnings:'A later valid synthetic edit.'}},actor);assert.equal(retried.version,2);assert.equal((await store.listAudit()).entries.length,1);
});

test('public catalog and product renderer display persisted warning markup as literal text',async t=>{
 const {store}=await fixture(t);
 const warnings='Synthetic <img src=x onerror="window.warningExecuted=true"> & "quoted" text\n</p><script>window.warningExecuted=true</script><svg onload="window.warningExecuted=true">';
 await store.updateProduct(productId,1,{declaration:{warnings}},actor);
 const persisted=await store.listProducts();
 const [html,catalog,slider,faq,app]=await Promise.all(['index.html','catalog.js','slider.js','faq.js','app.js'].map(file=>readFile(new URL('../public/'+file,import.meta.url),'utf8')));
 const dom=new JSDOM(html,{url:'https://synthetic-warnings.invalid/proizvod/'+productId,runScripts:'outside-only'});const w=dom.window;
 t.after(()=>w.close());await new Promise(resolve=>w.addEventListener('load',resolve,{once:true}));
 const requests=[];w.fetch=async path=>{requests.push(path);if(path==='/api/catalog')return {ok:true,json:async()=>({products:persisted})};if(path==='/api/checkout/session')return {ok:true,json:async()=>({enabled:false,guest:false})};throw Error('Unexpected synthetic browser request');};
 // Execute the actual browser modules in one async scope; only module syntax
 // is removed, and the catalog request returns the persisted store response.
 const modules=[catalog,slider,faq].map(source=>source.replace(/^export /gm,''));
 Object.assign(dom.window,{productMarkup,productStructuredData,safeJson,card,productImage,homeMarkup});
 const appBody=app.replace(/^import .+;\r?\n/gm,'');
 await vm.runInContext('(async()=>{\n'+modules.join('\n')+'\n'+appBody+'\n})()',dom.getInternalVMContext());
 assert(requests.includes('/api/catalog'));
 const section=[...w.document.querySelectorAll('.declaration-draft details')].find(value=>value.querySelector('summary')?.textContent==='Upozorenja');assert(section);
 assert.equal(section.querySelector('p').textContent,warnings);
 assert.equal(section.querySelector('script,svg,img,[onerror],[onload]'),null);
 assert.equal(w.warningExecuted,undefined);
 assert(w.document.querySelector('.declaration-draft').textContent.includes(persisted.find(value=>value.id===productId).declaration.usage));
});
