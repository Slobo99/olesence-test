import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
const root=process.env.CHECKOUT_APP_ROOT||fileURLToPath(new URL('..',import.meta.url)).replace(/\/$/,'');
const require=createRequire(root+'/package.json');
const {JSDOM}=require('jsdom');
const {products,normalizeCart,formatMoney}=await import(pathToFileURL(root+'/public/catalog.js'));
const html=await readFile(root+'/public/checkout.html','utf8');
const source=(await readFile(root+'/public/checkout.js','utf8')).replace(/^import .*?;\n/,'');
const {renderAnalytics,analyticsScript}=await import('../src/analytics.mjs');
const CONSENT='olesence.analytics-consent.v1';
const FLAG='olesence.purchase-tracked:';
const CART='olesence-preview-cart',PENDING='olesence-cod-pending-v1';
const quote={items:[{productId:'crni-kim',name:'Ulje crnog kima',quantity:1,unitPriceMinor:149000,lineTotalMinor:149000,productRevision:7}],subtotalMinor:149000,deliveryMinor:30000,totalMinor:179000,currency:'RSD',shipping:{method:'courier',isEstimate:false,deliveryMinor:30000,freeFromMinor:350000},paymentMethod:'cod'};
const contact={fullName:'Test Customer',email:'test@example.invalid',phone:'+381 111111',address:'Test 12',city:'Beograd',postalCode:'11000',country:'RS'};
const order={...quote,id:'COD-00000000-0000-4000-8000-000000000001',status:'pending',paymentStatus:'cod_due',inventoryStatus:'deducted',contact,createdAt:'2026-10-16T08:00:00Z'};
const response=(json,status=200)=>({ok:status>=200&&status<300,status,json:async()=>structuredClone(json)});
const until=async(predicate,message='Condition timed out')=>{for(let i=0;i<200;i++){if(predicate())return;await new Promise(r=>setTimeout(r,5));}assert.fail(message);};
async function fixture(t,{pending=null,session=null,orders=[],orderHandler=null,detail=order,url='https://olesence.rs/checkout',consent='granted',flags={},blocked=false}={}){
 const dom=new JSDOM(renderAnalytics(Buffer.from(html)).toString(),{url,runScripts:'outside-only'}),w=dom.window;
 await new Promise(r=>w.addEventListener('load',r,{once:true}));
 const data={session:session||{enabled:true,user:{id:'google:test-user',name:contact.fullName,email:contact.email},csrfToken:'csrf-1',customerReady:true},calls:[],posts:[],orders,orderHandler,quoteHandler:null,detail};
 w.localStorage.setItem(CART,JSON.stringify([{id:'crni-kim',quantity:1}]));if(pending)w.sessionStorage.setItem(PENDING,pending);
 Object.defineProperty(w.crypto,'randomUUID',{value:()=> '00000000-0000-4000-8000-000000000002'});
 if(consent)w.localStorage.setItem(CONSENT,JSON.stringify({value:consent,at:Date.now()}));
 for(const [k,v] of Object.entries(flags))w.sessionStorage.setItem(k,v);
 if(blocked)Object.defineProperty(w,'sessionStorage',{get(){throw Error('blocked');}});
 w.eval(analyticsScript);
 Object.assign(w,{products,normalizeCart,formatMoney});
 w.fetch=async(path,options={})=>{data.calls.push({path,options});
  if(path==='/api/checkout/session')return response(data.session);
  if(path==='/api/checkout/quote')return data.quoteHandler?data.quoteHandler(path,options):response(quote);
  if(path==='/api/checkout/orders'&&options.method==='POST'){assert.ok(w.sessionStorage.getItem(PENDING),'request persisted before POST');data.posts.push({path,options});return data.orderHandler?data.orderHandler(path,options):response({order,replayed:false});}
  if(path==='/api/checkout/orders')return response({orders:data.orders,nextCursor:null});
  if(path.startsWith('/api/checkout/orders/'))return response({order:data.detail});
  throw Error('Unexpected path '+path);
 };
 w.watchCatalogPrices=()=>{};vm.runInContext(source,dom.getInternalVMContext());await until(()=>!w.document.querySelector('#checkout-status').textContent.startsWith('Proveravamo'));
 t.after(()=>w.close());const $=selector=>w.document.querySelector(selector);
 const fill=()=>{for(const [key,value]of Object.entries(contact)){const input=$('#contact-form').elements[key];if(input)input.value=value;}};
 const prepare=async()=>{fill();$('#contact-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await until(()=>!$('#quote-panel').hidden||$('#checkout-status').classList.contains('error'));};
 const commit=()=>{$('#confirm-intent').checked=true;$('#confirm-intent').dispatchEvent(new w.Event('change'));$('#place-order').click();};
 return {w,data,$,fill,prepare,commit,commands:()=>Array.from(w.dataLayer||[],x=>Array.from(x)),purchases:()=>Array.from(w.dataLayer||[],x=>Array.from(x)).filter(c=>c[0]==='event'&&c[1]==='purchase')};
}

test('confirmed COD purchase is one sanitized event with correct RSD totals and items',async t=>{
 const f=await fixture(t);await f.prepare();assert.equal(f.$('#olesence-google-tag'),null);
 f.commit();await until(()=>!f.$('#receipt').hidden);
 assert.equal(f.purchases().length,1);const p=f.purchases()[0][2];
 assert.equal(p.transaction_id,order.id);assert.equal(p.value,1790);assert.equal(p.shipping,300);assert.equal(p.currency,'RSD');assert.equal(p.payment_type,'pouzece');
 assert.deepEqual(JSON.parse(JSON.stringify(p.items)),[{item_id:'crni-kim',item_name:'Ulje crnog kima',price:1490,quantity:1}]);
 assert.equal(p.page_location,'https://olesence.rs/checkout/potvrda');assert.equal(p.page_referrer,'');assert.equal(p.page_title,'Potvrda porudžbine');assert.equal(p.tax,undefined);
 assert.equal(f.w.sessionStorage.getItem(FLAG+order.id),'1');
 const wire=JSON.stringify(f.commands());for(const v of Object.values(contact))if(v.length>3)assert.ok(!wire.includes(v),v);
 assert.ok(!wire.includes('?order='));assert.ok(!wire.includes('google:test-user'));assert.equal(f.commands().filter(c=>c[0]==='event'&&c[1]==='page_view').length,0);
 assert.equal(f.$('#olesence-google-tag').referrerPolicy,'no-referrer');
 f.w.eval('showReceipt('+JSON.stringify(order)+')');assert.equal(f.purchases().length,1);
 const again=await fixture(t,{url:f.w.location.href,flags:{[FLAG+order.id]:'1'}});await until(()=>!again.$('#receipt').hidden);assert.equal(again.purchases().length,0);assert.equal(again.$('#olesence-google-tag'),null);
});
test('no tag or purchase while pending, on rejection or when malformed response arrives',async t=>{
 let resolve;const f=await fixture(t,{orderHandler:()=>new Promise(r=>resolve=r)});await f.prepare();f.commit();await until(()=>f.data.posts.length===1);
 assert.equal(f.$('#pending-panel').hidden,false);assert.equal(f.purchases().length,0);assert.equal(f.$('#olesence-google-tag'),null);
 resolve(response({order:{...order,totalMinor:1}}));await until(()=>f.$('#pending-error').textContent.length>0);assert.equal(f.purchases().length,0);assert.equal(f.$('#olesence-google-tag'),null);
 const rejected=await fixture(t,{orderHandler:()=>response({error:'Rejected'},409)});await rejected.prepare();rejected.commit();await until(()=>!rejected.$('#revise-order').hidden);assert.equal(rejected.purchases().length,0);assert.equal(rejected.$('#olesence-google-tag'),null);
});
test('replayed response tracks once and receipt refresh uses the same key',async t=>{
 const f=await fixture(t,{orderHandler:()=>response({order,replayed:true})});await f.prepare();f.commit();await until(()=>!f.$('#receipt').hidden);assert.equal(f.purchases().length,1);
 f.w.dispatchEvent(new f.w.Event('pageshow'));await until(()=>!f.$('#receipt').hidden);assert.equal(f.purchases().length,1);
});
test('no consent, refusal, withdrawal and expired consent never send purchase',async t=>{
 for(const consent of [null,'denied']){const f=await fixture(t,{consent,url:'https://olesence.rs/checkout?order='+order.id});await until(()=>!f.$('#receipt').hidden);assert.equal(f.purchases().length,0);assert.equal(f.$('#olesence-google-tag'),null);}
 const f=await fixture(t);f.$('#analytics-decline').click();await f.prepare();f.commit();await until(()=>!f.$('#receipt').hidden);assert.equal(f.purchases().length,0);assert.equal(f.$('#olesence-google-tag'),null);
 const expired=await fixture(t);expired.w.Date.now=()=>Date.now()+181*24*60*60*1000;await expired.prepare();expired.commit();await until(()=>!expired.$('#receipt').hidden);assert.equal(expired.purchases().length,0);
});
test('accepting analytics after receipt sends once, withdrawing stops later events',async t=>{
 const f=await fixture(t,{consent:null,url:'https://olesence.rs/checkout?order='+order.id});await until(()=>!f.$('#receipt').hidden);f.$('#analytics-accept').click();f.$('#analytics-accept').click();assert.equal(f.purchases().length,1);
 f.w.dispatchEvent(new f.w.StorageEvent('storage',{key:CONSENT,newValue:JSON.stringify({value:'denied',at:Date.now()})}));
 f.w.eval('showReceipt('+JSON.stringify({...order,id:'other-order'})+')');assert.equal(f.purchases().length,1);
});
test('cancelled receipt and order history never track',async t=>{
 const cancelled=await fixture(t,{detail:{...order,status:'cancelled'},url:'https://olesence.rs/checkout?order='+order.id});await until(()=>!cancelled.$('#receipt').hidden);assert.equal(cancelled.purchases().length,0);assert.equal(cancelled.$('#olesence-google-tag'),null);
 const history=await fixture(t,{orders:[order]});await until(()=>history.$('.order-detail-button'));history.$('.order-detail-button').click();await until(()=>!history.$('.order-details').hidden);assert.equal(history.purchases().length,0);assert.equal(history.$('#olesence-google-tag'),null);
});
test('failed cleanup stays private until successful recovery',async t=>{
 const f=await fixture(t);await f.prepare();const storage=f.w.sessionStorage;let fail=true;
 Object.defineProperty(f.w,'sessionStorage',{value:{getItem:k=>storage.getItem(k),setItem:(k,v)=>storage.setItem(k,v),removeItem:k=>{if(fail)throw Error('blocked');storage.removeItem(k);}}});
 f.commit();await until(()=>!f.$('#receipt').hidden);assert.equal(f.$('#pending-panel').hidden,false);assert.equal(f.purchases().length,0);assert.equal(f.$('#olesence-google-tag'),null);
 fail=false;f.data.orderHandler=()=>response({order,replayed:true});f.$('#retry-order').click();await until(()=>f.$('#pending-panel').hidden);assert.equal(f.purchases().length,1);
});
test('unavailable storage and a throwing analytics queue do not break receipt',async t=>{
 const f=await fixture(t);await f.prepare();f.commit();await until(()=>!f.$('#receipt').hidden);
 Object.defineProperty(f.w,'sessionStorage',{get(){throw Error('blocked');}});f.w.eval('showReceipt('+JSON.stringify({...order,id:'new-order'})+')');assert.equal(f.purchases().length,1);assert.equal(f.$('#receipt').hidden,false);
 const other=await fixture(t,{consent:null,url:'https://olesence.rs/checkout?order='+order.id});await until(()=>!other.$('#receipt').hidden);other.w.gtag=()=>{throw Error('queue error');};
 other.w.olesenceHasAnalyticsConsent=()=>true;other.w.olesenceEnsureMeasurement=()=>true;other.w['ga-disable-G-105CEG84DT']=false;other.w.eval('trackPurchase('+JSON.stringify(order)+')');assert.equal(other.w.sessionStorage.getItem(FLAG+order.id),null);assert.equal(other.$('#receipt').hidden,false);
});
test('invalid confirmed totals or quantities never emit and free delivery is converted correctly',async t=>{
 for(const detail of [{...order,totalMinor:0},{...order,items:[{...order.items[0],quantity:0}]}]){const f=await fixture(t,{detail,url:'https://olesence.rs/checkout?order='+order.id});await until(()=>!f.$('#receipt').hidden);assert.equal(f.purchases().length,0);}
 const detail={...order,items:[{...order.items[0],quantity:3,lineTotalMinor:447000}],subtotalMinor:447000,deliveryMinor:0,totalMinor:447000};
 const f=await fixture(t,{detail,url:'https://olesence.rs/checkout?order='+order.id});await until(()=>!f.$('#receipt').hidden);assert.equal(f.purchases()[0][2].value,4470);assert.equal(f.purchases()[0][2].shipping,0);
});
test('measurement API rejects forms and arbitrary page overrides; ad consent stays denied',async t=>{
 const f=await fixture(t);const safe={page_location:'https://olesence.rs/checkout/potvrda',page_title:'Potvrda porudžbine',page_referrer:''};
 assert.equal(f.w.olesenceEnsureMeasurement(safe),false);assert.equal(f.$('#olesence-google-tag'),null);
 await f.prepare();f.commit();await until(()=>!f.$('#receipt').hidden);assert.equal(f.w.olesenceEnsureMeasurement({...safe,page_location:f.w.location.href}),false);
 for(const c of f.commands().filter(c=>c[0]==='consent')){assert.equal(c[2].ad_storage,'denied');assert.equal(c[2].ad_user_data,'denied');assert.equal(c[2].ad_personalization,'denied');}
});
test('actual marker write failure cannot duplicate on reload',async t=>{
 const f=await fixture(t);await f.prepare();const storage=f.w.sessionStorage;
 Object.defineProperty(f.w,'sessionStorage',{value:{getItem:k=>storage.getItem(k),setItem:(k,v)=>{if(k===FLAG+order.id)throw Error('quota');storage.setItem(k,v);},removeItem:k=>storage.removeItem(k)}});
 f.commit();await until(()=>!f.$('#receipt').hidden);assert.equal(f.purchases().length,1);assert.equal(storage.getItem(FLAG+order.id),null);assert.equal(storage.getItem(FLAG+order.id+':reserved'),'1');
 const next=await fixture(t,{url:f.w.location.href,flags:{[FLAG+order.id+':reserved']:'1'}});await until(()=>!next.$('#receipt').hidden);assert.equal(next.purchases().length,0);
});
test('pagehide and BFCache restoration disable GA before restoring a form',async t=>{
 const f=await fixture(t);await f.prepare();f.commit();await until(()=>!f.$('#receipt').hidden);assert.equal(f.w['ga-disable-G-105CEG84DT'],false);
 f.w.dispatchEvent(new f.w.Event('pagehide'));assert.equal(f.w['ga-disable-G-105CEG84DT'],true);
 f.w.history.replaceState(null,'','/checkout');f.w.dispatchEvent(new f.w.Event('pageshow'));await until(()=>!f.$('#checkout-editor').hidden);assert.equal(f.w['ga-disable-G-105CEG84DT'],true);assert.equal(f.$('#receipt').hidden,true);
 f.$('#analytics-accept').click();assert.equal(f.w['ga-disable-G-105CEG84DT'],true);assert.equal(f.purchases().length,1);
});
