import assert from 'node:assert/strict';
import test from 'node:test';
import {activeSale,buildSale,belgradeTime} from '../src/sale.mjs';
const now=Date.parse('2030-04-20T10:00:00Z');
const base={priceMinor:8000,previousMinor:10000,endLocal:'2030-04-20T13:00',historyVerified:true};
test('sale validation requires verified non-invented reference input, correct dates and amount',()=>{
 for(const patch of [{previousMinor:12000},{priceMinor:10000},{priceMinor:0},{historyVerified:false},{endLocal:'2030-05-22T00:00'},{endLocal:'2030-04-20T12:00'},{endLocal:'2030-04-32T13:00'}]){
  assert.throws(()=>buildSale({...base,...patch},{now,regularMinor:11000}));
 }
 const sale=buildSale(base,{now,regularMinor:11000});
 assert.equal(sale.endAt,'2030-04-20T11:00:00.000Z');
 const p={priceMinor:11000,sale};
 assert.equal(activeSale(p,now-1),null);
 assert.equal(activeSale(p,now).percent,20);
 assert.equal(activeSale({...p,published:false},now),null);
 assert.equal(activeSale(p,Date.parse(sale.endAt)),null);
 assert.equal(activeSale({priceMinor:11000,sale:{...sale,priceMinor:8001}},now).percent,19);
});
test('Belgrade local time does not silently shift over DST gaps or ambiguities',()=>{
 assert.equal(belgradeTime('2030-01-20T10:30'),Date.parse('2030-01-20T09:30:00Z'));
 assert.throws(()=>belgradeTime('2030-03-31T02:30'));
 assert.throws(()=>belgradeTime('2030-10-27T02:30'));
});

test('open browser refreshes the catalog at the server expiry and recovers from a transient outage',async ()=>{
 const {readFile}=await import('node:fs/promises');
 const {createContext,runInContext}=await import('node:vm');
 const {products}=await import('../public/catalog.js');
 const active={...products[0],priceMinor:100000,sale:{previousMinor:149000,percent:32,startAt:'2030-01-01T00:00:00Z',endAt:'2030-01-01T00:00:00.900Z'}};
 const source=(await readFile(new URL('../public/catalog.js',import.meta.url),'utf8')).replace(/^export /gm,'');
 const queues=[],events=[],actual=[];
 const responses=[{ok:true,json:async()=>({products:[active],saleRefreshAfterMs:900})},{ok:false},{ok:true,json:async()=>({products:[products[0]]})}];
 const ctx=createContext({window:{},document:{hidden:false,documentElement:{dataset:{}},addEventListener:()=>{}},fetch:async()=>responses.shift(),setTimeout:(fn,ms)=>{queues.push(fn);actual.push(ms);},clearTimeout:()=>{},events});
 await runInContext('(async()=>{'+source+';watchCatalogPrices(()=>events.push(products[0].priceMinor),()=>events.push("unavailable"));})()',ctx);
 assert.equal(actual.at(-1),900);
 await queues.shift()();assert.deepEqual(events,['unavailable']);assert.equal(actual.at(-1),15000);
 await queues.shift()();assert.deepEqual(events,['unavailable',149000]);assert.equal(actual.at(-1),60000);
});
