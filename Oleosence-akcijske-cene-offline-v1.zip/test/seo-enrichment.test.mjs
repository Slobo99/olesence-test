import test from 'node:test';
import assert from 'node:assert/strict';
import {renderSeo,homeSeo,productSeo,siteStructuredData,breadcrumbStructuredData,sitemapXml,llmsText,publicRobots} from '../src/seo.mjs';
import {productStructuredData,safeJson} from '../public/product-view.js';
import {products} from '../public/catalog.js';
const product={...products[0],id:'new-oil',name:'New <oil>',updatedAt:'2026-11-12T08:00:00Z'};
const template=Buffer.from('<head><title>Old</title><meta name="description" content="old"><meta name="robots" content="noindex,nofollow"></head>');
test('server social metadata uses canonical paths, escaped values, matching title/description and own image',()=>{
 const home=renderSeo(template,'/',homeSeo,true).toString();assert.match(home,/olesence-og\.12d42915b06a\.jpg/);assert.match(home,/og:image:width" content="1200/);assert.match(home,/twitter:card/);
 const seo=productSeo(product);const html=renderSeo(template,'/proizvod/new-oil',seo,true).toString();assert.ok(html.includes('New &lt;oil&gt;'));assert.ok(!html.includes('New <oil>'));assert.match(html,/og:type" content="product/);assert.ok(html.includes('property="product:price:amount" content="'+(product.priceMinor/100).toFixed(2)+'"'));assert.match(html,/product:price:currency" content="RSD/);
 const custom=productSeo({...product,imagePath:'/media/'+'a'.repeat(64)+'.jpg'});assert.equal(custom.imageWidth,undefined);
});
test('site graph excludes unknown identity and includes precise conditional shipping only when enabled',()=>{
 const off=siteStructuredData();assert.equal(off['@graph'][0].hasShippingService,undefined);
 const graph=siteStructuredData({checkoutEnabled:true});const org=graph['@graph'][0];assert.equal(org.legalName,undefined);assert.equal(org.email,undefined);
 const c=org.hasShippingService.shippingConditions;assert.equal(c[0].orderValue.maxValue,3499.99);assert.equal(c[1].orderValue.minValue,3500);assert.equal(c[1].shippingRate.value,0);assert.equal(c[0].shippingRate.value,300);
 assert.deepEqual(graph['@graph'].map(x=>x['@type']),['Organization','Brand','WebSite']);
});
test('product and breadcrumb schema stay dynamic, omit unsupported guesses, and honor offer flag',()=>{
 const off=productStructuredData(product);assert.equal(off.offers,undefined);assert.equal(off.sku,'new-oil');assert.equal(off.brand.name,'olésence');
 const on=productStructuredData({...product,available:false},{offers:true});assert.equal(on.offers.availability,'https://schema.org/OutOfStock');assert.equal(on.offers.shippingDetails.shippingRate.maxValue,300);assert.equal(on.offers.priceValidUntil,undefined);assert.equal(on.offers.hasMerchantReturnPolicy,undefined);
 const crumbs=breadcrumbStructuredData(product);assert.equal(crumbs.itemListElement[2].item,'https://olesence.rs/proizvod/new-oil');assert.ok(!safeJson(crumbs).includes('<oil>'));
});
test('sitemap and llms use public dynamic products, genuine dates and no private data',()=>{
 const list=[product,{...product,id:'secret',name:'SECRET',published:false},{...product,id:'bad-date',updatedAt:'bad'}];
 const xml=sitemapXml(list);assert.match(xml,/<lastmod>2026-11-12T08:00:00.000Z<\/lastmod>/);assert.ok(!xml.includes('secret'));assert.equal((xml.match(/lastmod>/g)||[]).length,4);assert.match(xml,/proizvod\/bad-date<\/loc><\/url>/);
 const text=llmsText(list,{checkoutEnabled:true});assert.ok(!text.includes('SECRET'));assert.ok(text.includes('new-oil'));assert.ok(text.includes('pouzećem'));assert.ok(!llmsText(list).includes('pouzećem'));assert.match(publicRobots,/Disallow: \/admin/);
});
