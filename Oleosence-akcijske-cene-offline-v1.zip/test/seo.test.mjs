import {analyticsScript} from '../src/analytics.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
import {createHostedServer} from '../server.mjs';
import {products as seeds} from '../public/catalog.js';
import {canonicalOrigin,publicProductIds,homeSeo,productSeo,sitemapXml} from '../src/seo.mjs';

async function fixture(t,{origin=canonicalOrigin,products=seeds,fail=false,marketingEnabled=false}={}){
 const calls=[];const store={listProducts:async()=>{calls.push('publicProducts');if(fail)throw Error('Private database error');return products;},getImage:async()=>null};
 const marketingStore=new Proxy({}, {get:()=>()=>{throw Error('SEO must never read or write marketing storage');}});
 const a=await createHostedServer({config:{origin,host:new URL(origin).host,redirectHosts:['www.olesence.rs'],auth:{origin,clientId:'synthetic.apps.googleusercontent.com',secure:true},admin:{enabled:true,emails:['owner@example.invalid'],ownerEmail:'owner@example.invalid'},marketingEnabled},store,marketingStore});
 await new Promise(r=>a.server.listen(0,'127.0.0.1',r));t.after(()=>a.close());
 const request=(path,{method='GET',headers={}}={})=>new Promise((resolve,reject)=>{const q=http.request({hostname:'127.0.0.1',port:a.server.address().port,path,method,headers:{host:new URL(origin).host,'x-forwarded-proto':'https',...headers}},res=>{const chunks=[];res.on('data',b=>chunks.push(b));res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,text:Buffer.concat(chunks).toString()}));});q.on('error',reject);q.end();});
 return {request,calls,store};
}
const domOf=r=>new JSDOM(r.text).window.document;

test('production home and all live product pages have unique truthful server metadata and fixed canonical URLs',async t=>{
 const {request}=await fixture(t);const titles=new Set();
 for(const path of ['/',...publicProductIds.map(id=>'/proizvod/'+id)]){
  const r=await request(path),doc=domOf(r);assert.equal(r.status,200);assert.equal(r.headers['x-robots-tag'],undefined);
  assert.equal(doc.querySelector('meta[name="robots"]').content,'index,follow');
  assert.equal(doc.querySelectorAll('link[rel="canonical"]').length,1);assert.equal(doc.querySelector('link[rel="canonical"]').href,canonicalOrigin+path);
  assert.ok(!titles.has(doc.title));titles.add(doc.title);assert.ok(!/Kupovina nije dostupna/.test(doc.querySelector('meta[name="description"]').content));
  assert.equal(r.headers['cache-control'],'no-store');assert.match(r.headers['content-security-policy'],/frame-ancestors 'none'/);
 }
});
test('published SEO is preserved and escaped even with private marketing disabled; drafts are never consulted',async t=>{
 for(const marketingEnabled of [false,true]){
  const p={...seeds[0],seoTitle:'Approved </title><script>bad()</script>',seoDescription:'Approved " onload="bad() <tag>'};
  const {request}=await fixture(t,{products:[p],marketingEnabled});const r=await request('/proizvod/'+p.id),doc=domOf(r);
  assert.equal(r.status,200);assert.equal(doc.title,p.seoTitle);assert.equal(doc.querySelector('meta[name="description"]').content,p.seoDescription);assert.equal(doc.querySelector('script:not([src]):not([type="application/ld+json"]):not(#olesence-analytics-init)'),null);assert.equal(doc.querySelectorAll('#olesence-analytics-init').length,1);assert.equal(doc.querySelector('#olesence-analytics-init').textContent,analyticsScript);
 }
});
test('no published SEO uses current product name and neutral nonmedical defaults',()=>{
 const metadata=productSeo({name:'Current approved name',description:'Do not copy unreviewed health claims'});
 assert.equal(metadata.title,'Current approved name — olésence');assert.match(metadata.description,/Current approved name/);assert.ok(!metadata.description.includes('health claims'));
});
test('sitemap is XML with only canonical current live page routes, including out-of-stock products',async t=>{
 const {request}=await fixture(t,{products:[{...seeds[0],available:false,stockQuantity:0},seeds[2],{id:'draft-private',name:'Never public',published:false}]});
 const r=await request('/sitemap.xml');assert.equal(r.status,200);assert.match(r.headers['content-type'],/^application\/xml/);
 const doc=new JSDOM(r.text,{contentType:'application/xml'}).window.document;assert.equal(doc.documentElement.namespaceURI,'http://www.sitemaps.org/schemas/sitemap/0.9');
 assert.deepEqual([...doc.querySelectorAll('loc')].map(n=>n.textContent),[canonicalOrigin+'/',canonicalOrigin+'/proizvod/crni-kim',canonicalOrigin+'/proizvod/cetiri-lopova']);
 for(const loc of doc.querySelectorAll('loc'))assert.equal((await request(new URL(loc.textContent).pathname)).status,200);
 assert.ok(!/draft|account|admin|checkout|api|index\.html|onrender|lastmod/.test(r.text));
});
test('missing and unknown products are real noindex 404s, never soft-404 shells or sitemap entries',async t=>{
 const {request}=await fixture(t,{products:[seeds[0]]});
 for(const path of ['/proizvod/divlji-origano','/proizvod/divlji-origano/','/proizvod/divlji-origano/index.html','/proizvod/draft-private','/does-not-exist','/proizvod/crni-kim/extra']){const r=await request(path);assert.equal(r.status,404,path);assert.match(r.headers['x-robots-tag'],/noindex/);assert.ok(!r.text.includes('<link rel="canonical"'));}
 assert.ok(!(await request('/sitemap.xml')).text.includes('/divlji-origano'));
});
test('database outage is retryable noindex 503 for product and sitemap, not stale success or false deletion',async t=>{
 const {request}=await fixture(t,{fail:true});
 for(const path of ['/proizvod/crni-kim','/proizvod/crni-kim/','/sitemap.xml']){const r=await request(path);assert.equal(r.status,503);assert.match(r.headers['x-robots-tag'],/noindex/);assert.ok(!r.text.includes('Private database'));}
 assert.equal((await request('/')).status,503);
});
test('robots allows public render resources; API remains noindex and private paths excluded',async t=>{
 const {request}=await fixture(t);const r=await request('/robots.txt');assert.equal(r.status,200);assert.ok(!/^Disallow: \/$/m.test(r.text));assert.match(r.text,/^Allow: \/api\/catalog\$$/m);
 for(const path of ['/admin','/api/','/auth/','/orders'])assert.ok(r.text.includes('Disallow: '+path));assert.ok(r.text.includes('Sitemap: '+canonicalOrigin+'/sitemap.xml'));
 const catalog=await request('/api/catalog');assert.equal(catalog.status,200);assert.match(catalog.headers['x-robots-tag'],/noindex/);
 for(const path of ['/assets/crni-kim.jpg','/styles.css','/app.js','/catalog.js']){const r=await request(path);assert.equal(r.status,200);assert.equal(r.headers['x-robots-tag'],undefined);}
});
test('account and checkout shells stay noindex; protected APIs/admin/media retain authorization',async t=>{
 const {request}=await fixture(t,{marketingEnabled:true});
 for(const path of ['/account','/account.html','/checkout','/checkout.html']){const r=await request(path);assert.equal(r.status,200);assert.match(r.headers['x-robots-tag'],/noindex/);assert.match(r.text,/<meta name="robots" content="noindex,nofollow">/);assert.ok(!r.text.includes('rel="canonical"'));}
 for(const path of ['/admin','/admin.html','/admin.js','/admin/api/products','/api/marketing/v1/catalog','/api/marketing/v1/drafts','/api/orders','/media/'+'a'.repeat(64)+'.jpg']){const r=await request(path);assert.ok([401,404].includes(r.status),path+' '+r.status);assert.match(r.headers['x-robots-tag'],/noindex/);}
});
test('duplicates permanently redirect without losing query; canonical does not expose query or Host input',async t=>{
 const {request}=await fixture(t);
 for(const path of ['/index.html','/proizvod/crni-kim/','/proizvod/crni-kim/index.html'])for(const method of ['GET','HEAD']){
  const r=await request(path+'?utm_source=test',{method});assert.equal(r.status,308);const target=path==='/index.html'?'/':'/proizvod/crni-kim';assert.equal(r.headers.location,canonicalOrigin+target+'?utm_source=test');assert.equal(r.text,'');
 }
 const doc=domOf(await request('/proizvod/crni-kim?token=not-a-real-secret&next=https://evil.invalid'));assert.equal(doc.querySelector('link[rel="canonical"]').href,canonicalOrigin+'/proizvod/crni-kim');
 assert.equal((await request('/',{headers:{host:'evil.invalid','x-forwarded-host':'evil.invalid'}})).status,421);
 const alias=await request('/proizvod/crni-kim',{headers:{host:'www.olesence.rs'}});assert.equal(alias.status,308);assert.equal(alias.headers.location,canonicalOrigin+'/proizvod/crni-kim');
});
test('preview origins remain noindex and cannot leak preview URLs into canonical or sitemap',async t=>{
 const {request}=await fixture(t,{origin:'https://preview.onrender.com'});
 const r=await request('/proizvod/crni-kim');assert.match(r.headers['x-robots-tag'],/noindex/);assert.equal(domOf(r).querySelector('meta[name="robots"]').content,'noindex,nofollow');assert.equal(domOf(r).querySelector('link[rel="canonical"]').href,canonicalOrigin+'/proizvod/crni-kim');
 assert.equal((await request('/robots.txt')).text,'User-agent: *\nDisallow: /\n');assert.ok(!(await request('/sitemap.xml')).text.includes('onrender'));
});
test('HEAD matches GET policy and sends no body; POST cannot make public files indexable',async t=>{
 const {request}=await fixture(t);
 for(const path of ['/','/proizvod/crni-kim','/sitemap.xml','/robots.txt','/account']){const a=await request(path),b=await request(path,{method:'HEAD'});assert.equal(b.status,a.status);assert.equal(b.headers['x-robots-tag'],a.headers['x-robots-tag']);assert.equal(b.headers['content-type'],a.headers['content-type']);assert.equal(b.text,'');}
 const r=await request('/',{method:'POST'});assert.equal(r.status,404);assert.match(r.headers['x-robots-tag'],/noindex/);
});
test('empty public catalog makes sitemap home-only and never exposes drafts',()=>{assert.equal((sitemapXml([]).match(/<loc>/g)||[]).length,1);});
test('static public templates have distinct metadata, canonical and no obsolete description',async()=>{
 for(const [path,id] of [['public/index.html',null],...publicProductIds.map(id=>['public/proizvod/'+id+'/index.html',id])]){
  const html=await readFile(new URL('../'+path,import.meta.url),'utf8'),doc=new JSDOM(html).window.document;assert.equal(doc.title,id?productSeo(seeds.find(p=>p.id===id)).title:homeSeo.title);assert.equal(doc.querySelector('link[rel="canonical"]').href,canonicalOrigin+(id?'/proizvod/'+id:'/'));assert.ok(!doc.querySelector('meta[name="description"]').content.includes('Kupovina nije dostupna'));
 }
});
test('browser catalog accepts valid live subset/empty catalog without resurrecting removed seed products',async()=>{
 const source=await readFile(new URL('../public/catalog.js',import.meta.url),'utf8');
 for(const live of [[],[seeds[0]],[...seeds,{...seeds[0],id:'novo-ulje',name:'Novo ulje'}]]){
  const context=vm.createContext({window:{},document:{documentElement:{dataset:{}}},fetch:async()=>({ok:true,json:async()=>({products:live})})});
  const body=source.replace(/export /g,'');await vm.runInContext('(async()=>{'+body+';return products;})()',context).then(products=>assert.deepEqual(JSON.parse(JSON.stringify(products)),JSON.parse(JSON.stringify(live))));
  assert.equal(context.document.documentElement.dataset.catalogUnavailable,undefined);
 }
});

 test('catalog outage does not resurrect seed products',async()=>{
  const source=(await readFile(new URL('../public/catalog.js',import.meta.url),'utf8')).replace(/export /g,'');
  const context=vm.createContext({window:{},document:{documentElement:{dataset:{}}},fetch:async()=>{throw Error('offline');}});
  const products=await vm.runInContext('(async()=>{'+source+';return products;})()',context);assert.equal(products.length,0);assert.equal(context.document.documentElement.dataset.catalogUnavailable,'true');
 });

test('draft and orphan media never become public after replacement; current published image is public',async t=>{
 const products=[{...seeds[0],published:false,imagePath:'/media/'+'a'.repeat(64)+'.jpg'}];
 const {request,store}=await fixture(t,{products});store.getImage=async()=>({bytes:Buffer.from('synthetic-image'),mime:'image/jpeg'});
 for(const hash of ['a','b']){const r=await request('/media/'+hash.repeat(64)+'.jpg');assert.equal(r.status,401);assert.ok(!r.text.includes('synthetic-image'));assert.equal(r.headers['cache-control'],'no-store');}
 products[0].published=true;const r=await request(products[0].imagePath);assert.equal(r.status,200);assert.equal(r.text,'synthetic-image');
 products[0].imagePath='/media/'+'c'.repeat(64)+'.jpg';assert.equal((await request('/media/'+'a'.repeat(64)+'.jpg')).status,401);
});
