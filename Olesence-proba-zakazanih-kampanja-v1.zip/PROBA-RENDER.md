# Olesence: izdvojena proba zakazanih kampanja

Ovaj paket je samo za postojeći besplatni Render servis
`olesence-cod-test-runner-20261017`. Nije paket za produkciju.

1. U `Slobo99/olesence-test`, grana `main`, otpremite samo ovaj ZIP u koren, bez raspakivanja. Drugi projektni fajlovi ostaju kakvi jesu.
2. Samo u ovom test servisu ostavite Root Directory prazan. Uputstvo sa tačnim Build Command (uključujući SHA ovog omotača) odgovara nazivu otpremljenog fajla. Start Command: `node campaigns-rehearsal/preview.mjs`. Health Check: `/healthz`; ostavite free i Auto-Deploy off. Node 22+ (preporuka je postojeća 24). Ne unosite PostgreSQL pristup, pravi API ključ, OAuth tajne ili GA4 ID. Ranija oznaka `ISOLATED_COD_TEST=approved-synthetic-only` mora ostati podešena.
3. Proverite da deploy odgovara commitu sa ovim paketom; na `/healthz` očekujemo 200, `mode: synthetic-campaign-rehearsal`, `tests: 4`, `productionAccess: false` i tačan SHA kandidata. Početna strana prikazuje samo probne izmišljene cene i omogućava vizuelno poređenje tokom i posle akcije.

Build verifikuje tačan arhivirani kod kampanja, instalira zaključane npm zavisnosti iz javnih repozitorijuma i pokreće stvarne testove HTTP ruta + PostgreSQL SQL migracija u PGlite memorijskoj bazi. PGlite je PostgreSQL u WebAssembly-ju: nije test povezivanja sa zasebnim Render/PostgreSQL serverom, koji se ovde ne koristi. Testovi koriste samo loopback, simuliranu lokalnu prijavu i izmišljene kupce. Migracija 010 uključena je u provere. Pri završetku procesa izmišljeni test podaci nestaju. Javni runtime služi samo izveštaj i statičnu probnu korpu, bez autentifikacije, formulara, porudžbina, mrežne analitike ili proizvodnih veza. Svi zahtevi koji nisu GET/HEAD odbijaju se.

Ako build ne može da preuzme zavisnosti ili test padne, ne puštati dalje. Stari test servis ili prethodni deploy je odvojen od olesence.rs. Vraćanje prethodnih komandi pokretanja nije potrebno za zaštitu produkcije; produkcija ne treba da bude otvorena tokom ove probe.
