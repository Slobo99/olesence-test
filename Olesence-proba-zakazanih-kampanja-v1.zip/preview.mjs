import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import http from 'node:http';
import {sourceSha,assertTestService} from './verify.mjs';
import {buildSale,activeSale,effectivePrice} from './candidate/src/sale.mjs';
import {products,shippingEstimateMinor} from './candidate/public/catalog.js';
import {priceMarkup,productImage,escapeHtml} from './candidate/public/product-view.js';
import {productImageAttributes} from './candidate/public/image-view.js';
assertTestService(process.env);
const report=JSON.parse(await readFile(new URL('./verified.json',import.meta.url),'utf8'));
assert.equal(report.state,'passed');assert.equal(report.sourceSha,sourceSha);assert.equal(report.mode,'synthetic-campaign-rehearsal');
assert.equal(report.tests,4);assert.equal(report.productionAccess,false);
const now=Date.parse('2030-04-20T10:00:00Z');
const regularMinor=120000;
const input={priceMinor:80000,previousMinor:100000,endLocal:'2030-04-20T13:00',historyVerified:true};
const original=products.find(p=>p.id==='crni-kim');
const record={...original,priceMinor:regularMinor,published:true,sale:buildSale(input,{now,regularMinor})};
const expiredAt=Date.parse(record.sale.endAt);
assert.throws(()=>buildSale({...input,priceMinor:105000},{now,regularMinor}),/niža od prethodne/);
assert.throws(()=>buildSale({...input,endLocal:'2030-06-20T13:00'},{now,regularMinor}),/31 dan/);
assert.equal(effectivePrice(record,now),80000);assert.equal(effectivePrice(record,expiredAt),120000);
assert.equal(activeSale(record,now).percent,20);assert.equal(activeSale(record,expiredAt),null);
const cssPath=new URL('./candidate/public/styles.css',import.meta.url);
const assets=new Map(['/assets/crni-kim.jpg','/assets/crni-kim-400.72876634ef97.webp','/assets/crni-kim-800.0386a74f1a73.webp','/assets/crni-kim-1200.70967441a688.webp'].map(p=>[p,new URL('./candidate/public'+p,import.meta.url)]));
const fmt=n=>new Intl.NumberFormat('sr-Latn-RS',{style:'currency',currency:'RSD',maximumFractionDigits:2}).format(n/100);
const css='body{margin:0 auto;padding:16px;color:#222d21;max-width:960px}.sandbox-note,.sandbox-cart{padding:1.2rem;border:1px solid #dddcc9;border-radius:1rem;margin-bottom:1rem}.sandbox-links{display:flex;flex-wrap:wrap;gap:1rem;margin-bottom:1rem}.sandbox-links a{color:#3d5630;text-decoration:underline}.sandbox-copy h1{font-size:clamp(28px,4.2vw,48px);line-height:1.1}.sandbox-product{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:1.25rem;margin-bottom:1rem}.sandbox-photo{width:100%;height:auto;max-height:330px;object-fit:contain;background:white;border-radius:1rem}.sandbox-cart h2{margin:0 0 .4rem;font-size:1.5rem}.sandbox-cart p{margin:.25rem 0}.sandbox-copy .button{margin-top:1rem}@media(max-width:620px){.sandbox-product{grid-template-columns:1fr}.sandbox-photo{max-height:200px}}';
function page(stage,cart,done){
 const at=stage==='istekla'?expiredAt:now;
 const product={...record,priceMinor:effectivePrice(record,at),sale:activeSale(record,at)};
 const stageQuery=stage==='istekla'?'?akcija=istekla':'?akcija=aktivna';
 const delivery=shippingEstimateMinor(product.priceMinor),total=product.priceMinor+delivery;
 return '<!doctype html><html lang="sr-Latn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Olesence – probni prikaz akcije</title><link rel="stylesheet" href="/styles.css"><link rel="stylesheet" href="/preview.css"></head><body>'+
 '<aside class="sandbox-note"><strong>Olesence · TEST SA IZMIŠLJENIM CENAMA</strong><br>Prošla su 4 izolovana testa zakazanih akcija. Nema stvarnih porudžbina, naplate ili slanja podataka. <a href="/healthz">Rezultat provere</a>.</aside>'+
 '<nav class="sandbox-links" aria-label="Probni prikaz"><a href="/?akcija=aktivna'+(cart?'&amp;korpa=1':'')+'">Dok akcija traje</a><a href="/?akcija=istekla'+(cart?'&amp;korpa=1':'')+'">Posle isteka akcije</a></nav>'+
 '<main><section class="sandbox-product"><img class="sandbox-photo" '+productImageAttributes(productImage(product),{detail:true})+' alt="Bočica i pakovanje"><div class="sandbox-copy"><p>Proizvod u probnom katalogu</p><h1>'+escapeHtml(product.name)+'</h1>'+priceMarkup(product,true)+'<a class="button" href="/'+stageQuery+'&amp;korpa=1#probna-korpa">Dodaj u probnu korpu</a></div></section>'+
 (cart?'<section id="probna-korpa" class="sandbox-cart"><h2>Probna korpa</h2><p>Cena proizvoda: '+fmt(product.priceMinor)+'</p><p>Probna dostava: '+fmt(delivery)+'</p><p><strong>Ukupno: '+fmt(total)+'</strong></p>'+(done?'<p role="status">Proba je završena. Nije kreirana porudžbina.</p>':'<a href="/'+stageQuery+'&amp;korpa=1&amp;potvrda=1#probna-korpa">Simuliraj završetak kupovine</a>')+'</section>':'')+
 '</main></body></html>';
}
function createPreview(){
 return http.createServer({maxHeaderSize:8192},async(req,res)=>{
  res.setHeader('Content-Security-Policy',"default-src 'none'; style-src 'self'; img-src 'self'; connect-src 'none'; form-action 'none'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'");
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Robots-Tag','noindex, nofollow');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  const send=(s,t,b)=>{res.writeHead(s,{'Content-Type':t});res.end(req.method==='HEAD'?undefined:b);};
  if(!['GET','HEAD'].includes(req.method)){req.resume();res.setHeader('Allow','GET, HEAD');return send(405,'text/plain','Synthetic preview accepts no submissions.');}
  try{
   const url=new URL(req.url,'https://synthetic.invalid');
   if(url.pathname==='/healthz')return send(200,'application/json',JSON.stringify(report));
   if(url.pathname==='/'||url.pathname==='/checkout')return send(200,'text/html; charset=utf-8',page(url.searchParams.get('akcija'),url.pathname==='/checkout'||url.searchParams.get('korpa')==='1',url.searchParams.get('potvrda')==='1'));
   if(url.pathname==='/styles.css')return send(200,'text/css; charset=utf-8',await readFile(cssPath));
   if(url.pathname==='/preview.css')return send(200,'text/css; charset=utf-8',css);
   if(assets.has(url.pathname))return send(200,url.pathname.endsWith('.jpg')?'image/jpeg':'image/webp',await readFile(assets.get(url.pathname)));
   return send(404,'text/plain','Synthetic preview only.');
  }catch{return send(503,'text/plain','Synthetic preview unavailable.');}
 });
}
const port=Number(process.env.PORT||10000);
assert(Number.isInteger(port)&&port>=1&&port<=65535);
const server=createPreview();
server.listen(port,'0.0.0.0');
process.once('SIGTERM',()=>server.close(()=>process.exit(0)));
