// Only the pinned test service may run this fixture. Production env is never inherited by child processes.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdir,readFile,rm,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
export const serviceId='srv-db9p4pjbc2fs73cnn77g';
export const hostname='olesence-cod-test-runner-20261017.onrender.com';
export const sourceSha='7098b07da885426323b45f7e0ab092de578c8f2d0743fbdf5b007d803f5839be';
const dir=dirname(fileURLToPath(import.meta.url));
const zip=join(dir,'Oleosence-zakazane-kampanje-faza1-offline-v1.zip');
const candidate=join(dir,'candidate');
const report=join(dir,'verified.json');
export function assertTestService(env){
 assert.equal(env.RENDER_SERVICE_ID,serviceId);
 assert.equal(env.RENDER_EXTERNAL_HOSTNAME,hostname);
 assert.equal(env.ISOLATED_COD_TEST,'approved-synthetic-only');
}
function freshEnv(){
 return {PATH:process.env.PATH||'/usr/bin:/bin',HOME:dir,TMPDIR:join(dir,'tmp'),CI:'true',npm_config_userconfig:join(dir,'no-user.npmrc'),npm_config_globalconfig:join(dir,'no-global.npmrc'),npm_config_registry:'https://registry.npmjs.org'};
}
function run(cmd,args,opts={}){
 const p=spawnSync(cmd,args,{cwd:candidate,env:freshEnv(),encoding:'utf8',timeout:opts.timeout??90000,maxBuffer:1024*1024,stdio:opts.capture?'pipe':'inherit'});
 if(p.error)throw p.error;
 if(p.status!==0){if(opts.capture)console.error(p.stdout,p.stderr);throw new Error('Isolated command failed: '+cmd);}
 return p.stdout;
}
export async function validateExact(){
 assertTestService(process.env);
 await rm(report,{force:true});
 assert.equal(createHash('sha256').update(await readFile(zip)).digest('hex'),sourceSha);
 await rm(candidate,{recursive:true,force:true});await mkdir(candidate,{recursive:true});
 await mkdir(join(dir,'tmp'),{recursive:true});
 run('unzip',['-q',zip]);
 run('npm',['ci','--ignore-scripts','--no-audit','--no-fund','--include=dev'],{timeout:180000});
 // Test fixture starts local HTTP with fake auth and an empty in-memory DB; child env contains no DSNs or secrets.
 const out=run(process.execPath,['--test','--test-reporter=tap','test/promotions-http.test.mjs','test/sale.test.mjs'],{capture:true});
 console.log(out);
 assert.match(out,/^# tests 4$/m);assert.match(out,/^# pass 4$/m);assert.match(out,/^# fail 0$/m);
 await writeFile(report,JSON.stringify({state:'passed',mode:'synthetic-campaign-rehearsal',sourceSha,tests:4,productionAccess:false,finishedAt:new Date().toISOString()}));
 console.log('Exact archive verified. In-memory isolation ended; preview accepts GET/HEAD only.');
}
if(process.argv[1]===fileURLToPath(import.meta.url))await validateExact();
